/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Samsung Techwin Co., Ltd.
 * Samsung Techwin Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2012 Samsung Techwin Co., Ltd. All Rights Reserved| Confidential)
 */
package htc.hone.integration.eagleoffice.mail.service;


import java.io.File;
import java.rmi.RemoteException;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;

import htc.hone.integration.eagleoffice.common.vo.WsException;
import htc.hone.integration.eagleoffice.mail.vo.WsAttachFile;
import htc.hone.utils.EmailUtil;


/**
 * <ul>
 * <li>Created by : 손세일
 * <li>Created Date : 2015. 4. 30. 오후 3:11:08
 * </ul>
 *
 * @author 손세일
 */
public class MailServiceTest {

    /**
     * 그룹 메시지에서 개발 서버로의 메일은 ci.eagleoffice.co.kr 로 발송 하여야 하며
     * 송신 자는 우리 그룹에 있는 사원들만 발송이 가능합니다.  
     * http://ci.eagleoffice.co.kr/neo/index.mvc 에서 확인 가능합니다. 
     * @param args
     */
    public static void main(String[] args) {
        String END_POINT_URL = "http://ci.eagleoffice.co.kr/api/services/MailService";
        MailServiceProxy proxy = new MailServiceProxy();
        proxy.setEndpoint(END_POINT_URL);
        
        WsMailInfo mailInfo = new WsMailInfo();
        mailInfo.setSubject("[한화시스템즈 메일 전송 테스트]");
        mailInfo.setHtmlContent(true);
        mailInfo.setAttachCount(1);
        mailInfo.setSenderEmail("leejohn1010@ci.eagleoffice.co.kr"); 
        mailInfo.setImportant(false);
        
        WsRecipient[] receivers = new WsRecipient[1];
        receivers[0] = new WsRecipient();
        receivers[0].setSeqID(1);
        receivers[0].setRecvType("TO");
        receivers[0].setRecvEmail("leejohn1010@ci.eagleoffice.co.kr");
        
        WsAttachFile[] attachFiles = new WsAttachFile[1];
        attachFiles[0] = new WsAttachFile();
        attachFiles[0].setSeqID(1);
        attachFiles[0].setFileName("junit-3.8.1.ja");
//        attachFiles[0].setFileSize("123456");
//        
        File file = new File("D:\\Test\\lib\\junit-3.8.1.ja" );
        
        FileDataSource fds = null;
        DataHandler dh = null;
        
        if ( file != null && file.isFile() ) {
            fds = new FileDataSource(file);
            dh = new DataHandler(fds);
        }
        
        attachFiles[0].setFileInfo(dh);
        
        String mailBody = ""
        + " <html>                                                                                                                                                                       "
        + "     <head>                                                                                                                                                                     "
        + "         <title>Lagacy XP</title>                                                                                                                                                 "
        + "         <meta content='text/html; charset=utf-8' http-equiv=Content-Type>                                                                                                        "
        + "         <meta name=GENERATOR content=ActiveSquare>                                                                                                                               "
        + "     </head>                                                                                                                                                                    "
        + "     <body>                                                                                                                                                                     "
        + "     <table border=0 cellSpacing=0 cellPadding=0>                                                                                                                               "
        + "         <tbody>                                                                                                                                                                  "
        + "             <tr>                                                                                                                                                                   "
        + "                 <td>                                                                                                                                                                 "
        + "                     <meta name=language content=ko>                                                                                                                                    "
        + "                     <style type=text/css>HTML {                                                                                                                                        "
        + "     PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-LEFT: 0px; WIDTH: 100%; PADDING-RIGHT: 0px; HEIGHT: 100%; PADDING-TOP: 0px                                                       "
        + " }                                                                                                                                                                            "
        + " BODY {                                                                                                                                                                       "
        + "     PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-LEFT: 0px; WIDTH: 100%; PADDING-RIGHT: 0px; HEIGHT: 100%; PADDING-TOP: 0px                                                       "
        + " }                                                                                                                                                                            "
        + " BODY {                                                                                                                                                                       "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " P {                                                                                                                                                                          "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " UL {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " OL {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " LI {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " DL {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " DT {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " DD {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " FORM {                                                                                                                                                                       "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " TABLE {                                                                                                                                                                      "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " TH {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " TD {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " FIELDSET {                                                                                                                                                                   "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " INPUT {                                                                                                                                                                      "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " TEXTAREA {                                                                                                                                                                   "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " SELECT {                                                                                                                                                                     "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " BUTTON {                                                                                                                                                                     "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " H1 {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " H2 {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " H3 {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " H4 {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " H5 {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " H6 {                                                                                                                                                                         "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " PRE {                                                                                                                                                                        "
        + "     PADDING-BOTTOM: 0px; LINE-HEIGHT: 16px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Dotum, Sans-serif; COLOR: #000; FONT-SIZE: 10pt; PADDING-TOP: 0px "
        + " }                                                                                                                                                                            "
        + " TABLE {                                                                                                                                                                      "
        + "     BORDER-COLLAPSE: collapse; EMPTY-CELLS: show                                                                                                                               "
        + " }                                                                                                                                                                            "
        + " #wrap {                                                                                                                                                                      "
        + "     PADDING-BOTTOM: 10px; PADDING-LEFT: 10px; WIDTH: 800px; PADDING-RIGHT: 10px; PADDING-TOP: 10px                                                                             "
        + " }                                                                                                                                                                            "
        + " #header {                                                                                                                                                                    "
        + "     TEXT-ALIGN: center; PADDING-BOTTOM: 5px; MARGIN: 20px auto; CLEAR: both                                                                                                    "
        + " }                                                                                                                                                                            "
        + " #header SPAN {                                                                                                                                                               "
        + "     BORDER-BOTTOM: #3e5774 2px solid; PADDING-BOTTOM: 3px; PADDING-LEFT: 10px; PADDING-RIGHT: 10px; COLOR: #3e5774; FONT-SIZE: 1.8em; FONT-WEIGHT: bold                        "
        + " }                                                                                                                                                                            "
        + " #title {                                                                                                                                                                     "
        + "     MARGIN: 30px 0px 5px                                                                                                                                                       "
        + " }                                                                                                                                                                            "
        + " #title SPAN {                                                                                                                                                                "
        + "     COLOR: #3e5774; FONT-WEIGHT: bold                                                                                                                                          "
        + " }                                                                                                                                                                            "
        + " #table TABLE {                                                                                                                                                               "
        + "     BORDER-BOTTOM: #778b9c 2px solid; WIDTH: 100%; BACKGROUND: #bfcdd8; BORDER-TOP: #778b9c 2px solid                                                                          "
        + " }                                                                                                                                                                            "
        + " #table TH {                                                                                                                                                                  "
        + "     TEXT-ALIGN: center; PADDING-BOTTOM: 5px; PADDING-LEFT: 5px; PADDING-RIGHT: 5px; BACKGROUND: #f4f8fd; COLOR: #476991; FONT-WEIGHT: bold; PADDING-TOP: 5px                   "
        + " }                                                                                                                                                                            "
        + " #table TD {                                                                                                                                                                  "
        + "     PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; BACKGROUND: #ffffff; PADDING-TOP: 3px                                                                          "
        + " }                                                                                                                                                                            "
        + " #attatch {                                                                                                                                                                   "
        + "     PADDING-BOTTOM: 10px; MARGIN-TOP: 10px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; BACKGROUND: #eeeeee; PADDING-TOP: 10px                                                      "
        + " }                                                                                                                                                                            "
        + " #attatch SPAN {                                                                                                                                                              "
        + "     COLOR: #3e5774; MARGIN-LEFT: 10px; FONT-WEIGHT: bold                                                                                                                       "
        + " }                                                                                                                                                                            "
        + " SPAN.subject {                                                                                                                                                               "
        + "     FONT-WEIGHT: bold                                                                                                                                                          "
        + " }                                                                                                                                                                            "
        + " </style>                                                                                                                                                                     "
        + "                     <meta name=GENERATOR content=ActiveSquare>                                                                                                                         "
        + "                     <div id=wrap>                                                                                                                                                      "
        + "                         <div id=header><span>시설 공사 요청</span>                                                                                                                       "
        + "                         </div>                                                                                                                                                           "
        + "                         <div id=table>                                                                                                                                                   "
        + "                             <table border=0 cellSpacing=1 cellPadding=0>                                                                                                                   "
        + "                                 <colgroup>                                                                                                                                                   "
        + "                                     <col width='20%'>                                                                                                                                          "
        + "                                     <col width='30%'>                                                                                                                                          "
        + "                                     <col width='20%'>                                                                                                                                          "
        + "                                     <col width='30%'>                                                                                                                                          "
        + "                                 </colgroup>                                                                                                                                                  "
        + "                                 <tbody>                                                                                                                                                      "
        + "                                     <tr>                                                                                                                                                       "
        + "                                         <th>제목</th>                                                                                                                                            "
        + "                                         <td colSpan=3><span class=subject>CAD 서버실 하론소화기 철거 요청</span>                                                                                 "
        + "                                         </td>                                                                                                                                                    "
        + "                                     </tr>                                                                                                                                                      "
        + "                                     <tr>                                                                                                                                                       "
        + "                                         <th>요청번호</th>                                                                                                                                        "
        + "                                         <td><a href='#'>123456789-2 </a>                                                                                                                         "
        + "                                         </td>                                                                                                                                                    "
        + "                                         <th>요청일시</th>                                                                                                                                        "
        + "                                         <td>2013-12-19 15:36</td>                                                                                                                                "
        + "                                     </tr>                                                                                                                                                      "
        + "                                     <tr>                                                                                                                                                       "
        + "                                         <th>요청자</th>                                                                                                                                          "
        + "                                         <td>홍길동 GA(대리)</td>                                                                                                                                 "
        + "                                         <th>요청부서</th>                                                                                                                                        "
        + "                                         <td>정보전략 그룹</td>                                                                                                                                   "
        + "                                     </tr>                                                                                                                                                      "
        + "                                 </tbody>                                                                                                                                                     "
        + "                             </table>                                                                                                                                                       "
        + "                         </div>                                                                                                                                                           "
        + "                         <div id=title><span>■ 테이블 타이틀</span>                                                                                                                      "
        + "                         </div>                                                                                                                                                           "
        + "                         <div id=table>                                                                                                                                                   "
        + "                             <table border=0 cellSpacing=1 cellPadding=0>                                                                                                                   "
        + "                                 <colgroup>                                                                                                                                                   "
        + "                                     <col width='20%'>                                                                                                                                          "
        + "                                     <col width='30%'>                                                                                                                                          "
        + "                                     <col width='20%'>                                                                                                                                          "
        + "                                     <col width='30%'>                                                                                                                                          "
        + "                                 </colgroup>                                                                                                                                                  "
        + "                                 <tbody>                                                                                                                                                      "
       + "                                     <tr>                                                                                                                                                       "
        + "                                         <th>건물정보</th>                                                                                                                                        "
        + "                                         <td>(2사) IMS동 3층</td>                                                                                                                                 "
        + "                                         <th>세부위치</th>                                                                                                                                        "
        + "                                         <td>CAD 서버실</td>                                                                                                                                      "
        + "                                     </tr>                                                                                                                                                      "
        + "                                     <tr>                                                                                                                                                       "
        + "                                         <th>공사유형</th>                                                                                                                                        "
        + "                                         <td>설비</td>                                                                                                                                            "
        + "                                         <th>완료요구일</th>                                                                                                                                      "
        + "                                         <td>2013-12-26 17:00</td>                                                                                                                                "
        + "                                     </tr>                                                                                                                                                      "
        + "                                     <tr>                                                                                                                                                       "
        + "                                         <th>예산부서</th>                                                                                                                                        "
        + "                                         <td>정보전략 (BK024)</td>                                                                                                                                "
        + "                                         <th>귀속부서</th>                                                                                                                                        "
        + "                                         <td>정보전략 (BK024)</td>                                                                                                                                "
        + "                                     </tr>                                                                                                                                                      "
        + "                                     <tr>                                                                                                                                                       "
        + "                                         <th>계정코드</th>                                                                                                                                        "
        + "                                         <td>수선유지비-건물 (53490100)</td>                                                                                                                      "
        + "                                         <th>-</th>                                                                                                                                               "
        + "                                         <td>-</td>                                                                                                                                               "
        + "                                     </tr>                                                                                                                                                      "
        + "                                     <tr>                                                                                                                                                       "
        + "                                         <th>상세설명</th>                                                                                                                                        "
        + "                                         <td colSpan=3>2009년 설치하였으나, 더 이샹 필요 없어진 하론 소화기의 철거를 요청함. </td>                                                                "
        + "                                     </tr>                                                                                                                                                      "
        + "                                 </tbody>                                                                                                                                                     "
        + "                             </table>                                                                                                                                                       "
        + "                     </div>                                                                                                                                                             "
        + "                 </div>                                                                                                                                                               "
        + "             </div>                                                                                                                                                                 "
        + "         </td>                                                                                                                                                                    "
        + "     </tr>                                                                                                                                                                      "
        + " </tbody>                                                                                                                                                                     "
        + " </table></body>                                                                                                                                                              "
        + " </html>                                                                                                                                                                      ";
        
        
        String resultMsg;
        EmailUtil mailUtil = new EmailUtil();
        mailUtil.sendEmail("leejohn1010@ci.eagleoffice.co.kr", "leejohn1010@ci.eagleoffice.co.kr", "Util 테스트 입니다." , "메일 테스트 입니다 \n 확인 바랍니다. ");

//        try {
////            resultMsg = proxy.sendMISMail(mailBody, mailInfo, receivers, attachFiles);
//            System.out.println("resultMsg = "+resultMsg);
//        } catch (WsException e) {
//            e.printStackTrace();
//        } catch (RemoteException e) {
//            e.printStackTrace();
//        }
        
    }

}
