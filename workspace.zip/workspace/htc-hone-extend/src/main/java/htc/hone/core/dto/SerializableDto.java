package htc.hone.core.dto;

import java.io.Serializable;

public interface SerializableDto extends Serializable {

}
