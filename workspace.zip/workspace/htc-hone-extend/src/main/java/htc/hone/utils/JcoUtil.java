package htc.hone.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoMetaData;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;

import htc.hone.integration.jco.JcoFieldConverter;
import htc.hone.integration.jco.SimpleJcoFieldConverter;

public class JcoUtil {
	private final static Logger logger = LoggerFactory.getLogger(JcoUtil.class); // NOPMD

	public static final String DEFAULT_JCO_DESTINATION_NAME = "jco";

	public final static int JCO_MAXIMUM_FETCH_SIZE = 50000;

	public static Map<String, Object> convertMap(Iterator<JCoField> fieldIterator) {
		return convertMap(fieldIterator, new SimpleJcoFieldConverter());
	}

	public static Map<String, Object> convertMap(Iterator<JCoField> fieldIterator, JcoFieldConverter converter) {
		Map<String, Object> map = new HashMap<String, Object>();
		if (fieldIterator != null) {
			while (fieldIterator.hasNext()) {
				JCoField field = fieldIterator.next();
				map.put(field.getName(), converter.convert(field));
			}
		}
		return map;
	}

	public static Map<String, Object> convertMap(JCoParameterList parameterList) {
		return (parameterList != null) ? convertMap(parameterList.iterator()) : null;
	}

	public static List<Map> convertList(JCoTable table) {
		return convertList(table, new SimpleJcoFieldConverter());
	}

	public static List<Map> convertList(JCoTable table, JcoFieldConverter converter) {
		List<Map> list = new ArrayList<Map>();
		int cnt = 0;
		if (table != null && table.getNumRows() > 0) {
			table.firstRow();
			do {
				cnt++;
				if (cnt > JCO_MAXIMUM_FETCH_SIZE) {
					throw new RuntimeException("Too many data in JcoTable. maxFetchSize is " + JCO_MAXIMUM_FETCH_SIZE);
				}
				Map row = convertMap(table.iterator(), converter);
				list.add(row);
			} while (table.nextRow());
			logger.debug("converted list row[{}] for jco table", list.size());
		}
		return list;
	}

	private static void setImportParameter(JCoStructure structure, Map<String, Object> inputParam) {
		Iterator<JCoField> iter = structure.iterator();
		while (iter.hasNext()) {
			JCoField field = iter.next();
			if (inputParam.containsKey(field.getName())) {
				logger.debug("setting Jco Structure Field Value : {} = {}", field.getName(),
						inputParam.get(field.getName()));
				field.setValue(inputParam.get(field.getName()));
			}
		}
	}

	private static void setJcoFieldValues(Iterator<JCoField> fieldIter, Map<String, Object> inputParam) {
		while (fieldIter.hasNext()) {
			JCoField field = fieldIter.next();
			if (inputParam.containsKey(field.getName())) {
				logger.debug("setting Jco Field Value : {} = {}", field.getName(), inputParam.get(field.getName()));
				field.setValue(inputParam.get(field.getName()));
			}
		}
	}

	private static void setJcoTableValues(JCoTable table, List<Map> tableParam) {
		table.clear();
		for (Map<String, Object> row : tableParam) {
			table.appendRow();
			setJcoFieldValues(table.iterator(), row);
		}
	}

	public static void setImportParameter(JCoFunction function, final Map<String, Object> inputParam) {
		if (inputParam != null && !inputParam.isEmpty()) {
			JCoParameterList parameterList = function.getImportParameterList();
			if (parameterList != null) {
				Iterator<JCoField> iter = parameterList.iterator();
				while (iter.hasNext()) {
					JCoField field = iter.next();
					switch (field.getType()) {
					case JCoMetaData.TYPE_STRUCTURE:
						logger.debug("setting Jco Structure Parameters : ", field.getName());
						if (inputParam.containsKey(field.getName())) {
							setImportParameter(field.getStructure(),
									(Map<String, Object>) inputParam.get(field.getName()));
						} else {
							setImportParameter(field.getStructure(), inputParam);
						}
						break;
					case JCoMetaData.TYPE_TABLE:
						logger.debug("setting Jco Table Parameters : ", field.getName());
						if (inputParam.containsKey(field.getName())) {
							setJcoTableValues(field.getTable(), (List<Map>) inputParam.get(field.getName()));
						} else {
							setJcoTableValues(field.getTable(), new ArrayList<Map>() {
								{
									add(inputParam);
								}
							});
						}
						break;
					default:
						if (inputParam.containsKey(field.getName())) {
							logger.debug("setting Jco Field Value : {} = {}", field.getName(),
									inputParam.get(field.getName()));
							field.setValue(inputParam.get(field.getName()));
						}
						break;
					}
				}
			}
		}
	}

	public static void setTableParameter(JCoFunction function, String tableName, List<Map> tableParam) {
		JCoTable table = function.getTableParameterList().getTable(tableName);
		if (table == null) {
			throw new RuntimeException("JcoTable Not Found : " + tableName);
		}
		setJcoTableValues(table, tableParam);
	}

	private static void appendString(StringBuilder sb, Iterator<JCoField> iter) {
		if (iter != null) {
			while (iter.hasNext()) {
				JCoField field = iter.next();
				sb.append("\n\t-\t").append(field.getName()).append(" ").append(field.getTypeAsString()).append("(")
						.append(field.getByteLength()).append(")");
			}
		}
	}

	public static String toString(JCoFunction function) {
		StringBuilder sb = new StringBuilder();
		sb.append("\n\t-------------------------------");
		sb.append("\n\t- Name :").append(function.getName());
		if (function.getImportParameterList() != null) {
			sb.append("\n\t-------------------------------");
			sb.append("\n\t- Input Parameters");
			appendString(sb, function.getImportParameterList().iterator());
		}
		if (function.getExportParameterList() != null) {
			sb.append("\n\t-------------------------------");
			sb.append("\n\t- Output Parameters");
			appendString(sb, function.getExportParameterList().iterator());
		}
		if (function.getTableParameterList() != null) {
			sb.append("\n\t-------------------------------");
			sb.append("\n\t- Table Parameters");
			JCoParameterList tableList = function.getTableParameterList();
			Iterator<JCoField> iter = tableList.iterator();
			while (iter.hasNext()) {
				JCoField field = iter.next();
				String name = field.getName();
				JCoTable table = tableList.getTable(name);
				sb.append("\n\t- Table Name : ").append(name);
				appendString(sb, table.iterator());
			}
		}
		sb.append("\n\t-------------------------------");
		return sb.toString();
	}
	
	public static JCoDestination getJcoDestination(String destinationName) throws JCoException {
		return JCoDestinationManager.getDestination(destinationName);
	}

	public static JCoFunction getJcoFunction(JCoDestination destination, String functionName) throws JCoException {
		return destination.getRepository().getFunction(functionName);
	}
	
	public static JCoDestination getDefaultJcoDestination() throws JCoException {
		return getJcoDestination(DEFAULT_JCO_DESTINATION_NAME);
	}

}
