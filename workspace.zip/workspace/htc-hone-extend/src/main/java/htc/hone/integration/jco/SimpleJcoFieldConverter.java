/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Samsung Techwin Co., Ltd.
 * Samsung Techwin Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2012 Samsung Techwin Co., Ltd. All Rights Reserved| Confidential)
 */
package htc.hone.integration.jco;

import java.util.Date;

import org.apache.commons.lang.time.DateFormatUtils;

import com.sap.conn.jco.JCoField;

/**
 * <ul>
 * <li>Created by : 윤석진
 * <li>Created Date : 2014. 1. 23. 오후 2:54:11
 * </ul>
 *
 * @author 윤석진
 */
public class SimpleJcoFieldConverter implements JcoFieldConverter {

    @Override
    public Object convert(JCoField field) {
        switch (field.getType()) {
            case 1: // DATE
                return field.getValue() == null ? "" : DateFormatUtils.format((Date) field.getValue(), "yyyyMMdd");
            case 3: // TIME
                return field.getValue() == null ? "" : DateFormatUtils.format((Date) field.getValue(), "HHmmss");
            default:
                return field.getValue();
        }
    }

}
