package htc.hone.core.exception;

import htc.xplatform.utils.MessageUtil;

public class BusinessException extends RuntimeException {

	private static final long serialVersionUID = -8557280996133384872L;

	
	private String messageCode;
	private String[] messageParams;
	
	public BusinessException(Throwable e) {
		super(e);
	}
	
	public BusinessException(String messageCode) {
		super(MessageUtil.makeMessage(messageCode));
		this.messageCode = messageCode;
		this.messageParams = new String[0];
	}
	
	public BusinessException(String messageCode, String ... messageParams) {
		super(MessageUtil.makeMessage(messageCode, messageParams));
		this.messageCode = messageCode;
		this.messageParams = messageParams;
	}

	public String getMessageCode() {
		return messageCode;
	}

	public String[] getMessageParams() {
		return messageParams;
	}
	
}
