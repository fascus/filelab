package htc.hone.core.exception;

import htc.xplatform.utils.MessageUtil;

public class MessageBusinessException extends RuntimeException {
	
	private static final long serialVersionUID = -2038414070318504121L;
	private static final String MESSAGE_CODE = MessageUtil.DEFAULT_INFO_ID;
	private String message;
	
	public MessageBusinessException(Throwable e) {
		super(e);
		this.message = e.getMessage();
	}
	
	public MessageBusinessException(String message) {
		this.message = message;
	}
	
	public MessageBusinessException(String message, Throwable e) {
		super(e);
		this.message = message;
	}
	
	public String getMessageCode() {
		return MESSAGE_CODE;
	}

	public String getMessage() {
		return message;
	}
	
	
}
