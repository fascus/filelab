package htc.hone.utils;

import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import hone.bom.context.ApplicationContextHolder;

public class TransactionUtil {
    public static final String DEFAULT_TRANSACTION_MANGER_BEAN_NAME = "transactionManager";
    private static PlatformTransactionManager transactionManager;

    public static PlatformTransactionManager getTransactionManager() {
            if (transactionManager == null) {
                    transactionManager = ApplicationContextHolder.getBean(DEFAULT_TRANSACTION_MANGER_BEAN_NAME, PlatformTransactionManager.class);
            }
            return transactionManager;
    }

    public static TransactionTemplate getTransactionTemplate() {
            return new TransactionTemplate(getTransactionManager());
    }

    /**
     * 트랜잭션 매니저 이름을 기반으로 TransactionManager를 가져옴.
     * @param name
     * @return
     */
    public static PlatformTransactionManager getTransactionManager(String name) {
            return ApplicationContextHolder.getBean(name, PlatformTransactionManager.class);
    }

    /**
     * 트랜잭션 매니저 이름을 기반으로 TransactionTemplate를 가져옴.
     * @param name
     * @return
     */
    public static TransactionTemplate getTransactionTemplate(String name) {
            return new TransactionTemplate(getTransactionManager(name));
    }
}
