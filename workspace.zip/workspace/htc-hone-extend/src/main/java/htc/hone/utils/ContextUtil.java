package htc.hone.utils;

import javax.servlet.http.HttpServletRequest;

import hone.bom.context.request.RequestContext;
import hone.bom.context.request.RequestContextHolder;
import htc.commons.paging.PagingSupport;
import htc.hone.core.message.SystemHeader;
import htc.xplatform.web.HtcConstants;

public class ContextUtil {
	public static RequestContext getRequestContext() {
		return RequestContextHolder.getRequestContext();
	}
	
	public static void setAttribute(String key, Object obj) {
		getRequestContext().setAttribute(key, obj);
	}
	
	public static Object getAttribute(String key) {
		return getRequestContext().getAttribute(key);
	}
	
	public static <T> T getAttribute(String key, Class<T> clazz) {
		return clazz.cast(getAttribute(key));
	}
	

	public static void setHeader(SystemHeader header) {
		setAttribute(HtcConstants.HEADER_KEY, header);
	}
	
	public static SystemHeader getHeader() {
		return getAttribute(HtcConstants.HEADER_KEY, SystemHeader.class);
	}
	
	public static void setHttpServletRequest(HttpServletRequest request) {
		setAttribute(HtcConstants.HTTP_SERVLET_REQUEST_KEY, request);
	}
	
	public static HttpServletRequest getHttpServletRequest() {
		return getAttribute(HtcConstants.HTTP_SERVLET_REQUEST_KEY, HttpServletRequest.class);
	}
	
	public static void setPaging(PagingSupport paging) {
		setAttribute(HtcConstants.PAGING_KEY, paging);
	}
	
	public static PagingSupport getPaging() {
		return getAttribute(HtcConstants.PAGING_KEY, PagingSupport.class);
	}
	
	public static boolean hasPaging() {
		return getAttribute(HtcConstants.PAGING_KEY) != null;
	}
}
