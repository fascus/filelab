package htc.hone.utils;

import java.rmi.RemoteException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import htc.hone.integration.eagleoffice.common.vo.WsException;
import htc.hone.integration.eagleoffice.mail.service.MailServiceProxy;
import htc.hone.integration.eagleoffice.mail.service.WsMailInfo;
import htc.hone.integration.eagleoffice.mail.service.WsRecipient;
import htc.hone.integration.eagleoffice.mail.vo.WsAttachFile;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 12. 27. 오후 1:32:09
 * @Author     	  : 이준우
 *
 * <pre>
 * 사용되지 않아 Deprecate함
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 12. 27.		이준우						CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */

@Deprecated
public class EmailUtil {
    private static final Logger logger = LoggerFactory.getLogger(EmailUtil.class);
    private static final String END_POINT_URL = "http://ci.eagleoffice.co.kr/api/services/MailService";
    MailServiceProxy proxy = null;

    /**
     * 
     */
    public EmailUtil() {
        proxy = new MailServiceProxy();
        proxy.setEndpoint(END_POINT_URL);
    }

    
    /**
     * @Method Name        : sendEmail
     * @Method description : 단건 메일 발송 ( 첨부파일 제외 )
     * @Date               : 2016. 12. 27.
     * @Author             : 이준우 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 12. 27.		이준우						CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param sendMail 보내는사람 메일
     * @param revMail  받는사람 메일
     * @param subject  제목
     * @param mailBody 본문
     * @return
    */
    public boolean sendEmail(String sendMail, String revMail, String subject, String mailBody) { 
        
        WsMailInfo mailInfo = new WsMailInfo();
        mailInfo.setSubject(subject);
        mailInfo.setHtmlContent(true);
        mailInfo.setAttachCount(1);
        mailInfo.setSenderEmail(sendMail); 
        mailInfo.setImportant(false);
        
        WsRecipient[] receivers = new WsRecipient[1];
        receivers[0] = new WsRecipient();
        receivers[0].setSeqID(1);
        receivers[0].setRecvType("TO");
        receivers[0].setRecvEmail(revMail);
        
        WsAttachFile[] attachFiles = new WsAttachFile[1];

        String rstMsg = "";
            try { 
                rstMsg = proxy.sendMISMail(mailBody, mailInfo, receivers, attachFiles);
            } catch (WsException e) {
                logger.error("Email Send failed - {} \n {} " , rstMsg,  e.getMessage());
                return false;
            } catch (RemoteException e) {
                logger.error("Email Send failed - {} \n {} " , rstMsg,  e.getMessage());
                return false;
            }


        return true;
    }
    
    /**
     * @Method Name        : sendEmail
     * @Method description : 멑티 메일 발송 ( 첨부파일 제외 )
     * @Date               : 2016. 12. 27.
     * @Author             : 이준우 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 12. 27.        이준우                     CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param sendMail 보내는사람 메일
     * @param revMails  받는사람 메일(여러명일 경우)
     * @param subject  제목
     * @param mailBody 본문
     * @return
    */
    public boolean sendEmail(String sendMail, String[] revMails, String subject, String mailBody) { 
        
        WsMailInfo mailInfo = new WsMailInfo();
        mailInfo.setSubject(subject);
        mailInfo.setHtmlContent(true);
        mailInfo.setAttachCount(1);
        mailInfo.setSenderEmail(sendMail); 
        mailInfo.setImportant(false);
        
        WsRecipient[] receivers = new WsRecipient[revMails.length];
        for(int i = 0 ; i< revMails.length ; i++ ){
            receivers[i] = new WsRecipient();
            receivers[i].setSeqID(i+1);
            receivers[i].setRecvType("TO");
            receivers[i].setRecvEmail(revMails[i]);
        }
        
        WsAttachFile[] attachFiles = new WsAttachFile[1];

        String rstMsg = "";
            try { 
                rstMsg = proxy.sendMISMail(mailBody, mailInfo, receivers, attachFiles);
            } catch (WsException e) {
                logger.error("Email Send failed - {} \n {} " , rstMsg,  e.getMessage());
                return false;
            } catch (RemoteException e) {
                logger.error("Email Send failed - {} \n {} " , rstMsg,  e.getMessage());
                return false;
            }


        return true;
    }    
}
