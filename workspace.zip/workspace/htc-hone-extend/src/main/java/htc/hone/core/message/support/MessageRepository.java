package htc.hone.core.message.support;

public interface MessageRepository {
	String getMessage(String messageId);
}
