package htc.hone.web.support;

import java.io.OutputStream;

import javax.servlet.http.HttpServletResponse;

import org.springframework.core.MethodParameter;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.fasterxml.jackson.databind.ObjectMapper;

import htc.hone.core.message.JsonMessage;

public class JsonMessageReturnValueHandler implements HandlerMethodReturnValueHandler {
	private ObjectMapper objectMapper;

	public void setObjectMapper(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	@Override
	public boolean supportsReturnType(MethodParameter returnType) {
		return JsonMessage.class.isAssignableFrom(returnType.getParameterType());
	}

	@Override
	public void handleReturnValue(Object returnValue,
			MethodParameter returnType, ModelAndViewContainer mavContainer,
			NativeWebRequest webRequest) throws Exception {

		HttpServletResponse response = webRequest.getNativeResponse(HttpServletResponse.class);

		mavContainer.setRequestHandled(true);
		OutputStream out = response.getOutputStream();
		objectMapper.writeValue(out, returnValue);
		out.flush();

	}


}