package htc.hone.web;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import hone.bom.binding.utils.DtoCopyUtils;
import hone.bom.web.request.BomRequestInfo;
import hone.bom.web.request.ClientType;
import htc.hone.core.message.JsonMessage;
import htc.hone.core.message.SystemHeader;

@Controller
public class JsonRequestHandler extends ExampleRequestHandler<JsonNode> {
	private static final ClientType JSON = ClientType.get("JSON");
	
	private ObjectMapper objectMapper;
	
	public void setObjectMapper(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	
	@RequestMapping(value="/json/{serviceId}")
	public JsonMessage handler(JsonMessage requestMessage
				, @PathVariable("serviceId") String serviceId) {
		SystemHeader header = requestMessage.getHeader();
		if(header == null) {
			throw new RuntimeException("Header is null");
		}
		
		header.setServiceId(serviceId);
		return (JsonMessage) super.handle(requestMessage);
	}
	
	@Override
	protected Object[] parsePayload(JsonNode payload, Class<?>[] paramerTypes) {
		if(paramerTypes == null || paramerTypes.length < 1) {
			return new Object[] {};
		}
		
		if(paramerTypes.length == 1) {
			Class<?> parameterType = paramerTypes[0];
			Object fromMap = DtoCopyUtils.fromMap((Map<String, Object>) payload, parameterType);
			return new Object[] {fromMap} ;
		} else {
			throw new RuntimeException("not support multi parameter");
		}
	}

	@Override
	protected JsonNode makePayload(Object returnValue) {
		return objectMapper.valueToTree(returnValue);
	}

	@Override
	protected ClientType getClientType(BomRequestInfo reqInfo) {
		return JSON;
	}
	
	

}
