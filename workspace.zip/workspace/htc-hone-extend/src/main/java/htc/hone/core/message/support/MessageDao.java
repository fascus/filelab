package htc.hone.core.message.support;

public interface MessageDao {
	String getMessage(String messageId);
}
