/**
 * NeoSloWsImplService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package htc.hone.integration.eagleoffice.slo.service;

import java.net.URL;

import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;

public interface NeoSloWsImplService extends Service {
    public String getNeoSloWsImplPortAddress();

    public NeoSloWs getNeoSloWsImplPort() throws ServiceException;

    public NeoSloWs getNeoSloWsImplPort(URL portAddress) throws ServiceException;
}
