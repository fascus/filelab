/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Samsung Techwin Co., Ltd.
 * Samsung Techwin Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2012 Samsung Techwin Co., Ltd. All Rights Reserved| Confidential)
 *
 * $Revision: 1760 $
 * $LastChangedDate: 2013-04-22 21:13:34 +0900 (월, 22 4 2013) $
 * $LastChangedBy: seokjin.yoon $
 */
package htc.hone.integration.jco;

import com.sap.conn.jco.JCoField;


/**
 * JCO 함수 호출 시 JCoField 를 객체로 바인딩 하기 위한 인터페이스.
 * <ul>
 * <li>Created by : 윤석진
 * <li>Created Date : 2013. 2. 8. 오후 2:37:43
 * </ul>
 *
 * @author 윤석진
 */
public interface JcoFieldConverter {
    
    public Object convert(JCoField field);

}
