package htc.hone.web.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.prefs.Preferences;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.StringUtils;

import hone.bom.context.ApplicationContextHolder;
import htc.commons.file.dto.FileDto;
import htc.commons.file.service.FileHandlerService;

//@WebServlet(name = "fileDownloadServlet", urlPatterns = {"/download"})
public class FileDownloadServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5581083673537732170L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
		/*
		String strFileId = req.getParameter("fileId");
		int fileId = Integer.parseInt(strFileId);
		
		FileHandlerService service = ApplicationContextHolder.getBean(FileHandlerService.class);
		FileDto dto = service.getFile(fileId);
		
		
        File downloadFile = new File(dto.getStoredFileName());
        FileInputStream inStream = new FileInputStream(downloadFile);
        
        String downloadFileName = dto.getOrgFileName();
        if(StringUtils.hasText(dto.getFileExt())) {
        	downloadFileName += "." + dto.getFileExt();
        }
         
        // obtains ServletContext
        ServletContext context = getServletContext();
         
        // gets MIME type of the file
        String mimeType = context.getMimeType(dto.getStoredFileName());
        if (mimeType == null) {        
            // set to binary type if MIME mapping not found
            mimeType = "application/octet-stream";
        }
        System.out.println("MIME type: " + mimeType);
         
        // modifies response
        response.setContentType(mimeType);
        response.setContentLength((int) downloadFile.length());
         
        // forces download
        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=\"%s\"", downloadFileName);
        response.setHeader(headerKey, headerValue);
         
        // obtains response's output stream
        OutputStream outStream = response.getOutputStream();
         
        byte[] buffer = new byte[4096];
        int bytesRead = -1;
         
        while ((bytesRead = inStream.read(buffer)) != -1) {
            outStream.write(buffer, 0, bytesRead);
        }
         
        inStream.close();
        outStream.close();     
        */
	}

	
	
}
