package htc.hone.web.servlet;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.tobesoft.xplatform.data.PlatformData;
import com.tobesoft.xplatform.tx.HttpPlatformResponse;
import com.tobesoft.xplatform.tx.PlatformException;
import com.tobesoft.xplatform.tx.PlatformType;

import hone.bom.context.ApplicationContextHolder;
import htc.commons.file.dto.FileDto;
import htc.commons.file.service.FileHandlerService;
import htc.xplatform.utils.XPlatformUtil;

//@WebServlet(name = "fileUploadServlet", urlPatterns = {"/upload"})
//@MultipartConfig(location="D:/tmp",
//                 fileSizeThreshold=0,    
//                 maxFileSize=5242880,       // 5 MB
//                 maxRequestSize=20971520)   // 20 MB
public class FileUploadServlet extends HttpServlet  {

	private static final long serialVersionUID = 318647068078559148L;
	private static final Logger logger = LoggerFactory.getLogger(FileUploadServlet.class);
	/*

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		File tmp = new File("D:/tmp");
		if(!tmp.exists()) {
			tmp.mkdir();
		}
		
        Collection<Part> parts = req.getParts();
        List<FileDto> files = new ArrayList<FileDto>();
        for(Part part : parts) {
        	String absolutePath = getFileName(part);
        	long fileSize = part.getSize();
        	String baseName = FilenameUtils.getBaseName(absolutePath);
        	String ext = FilenameUtils.getExtension(absolutePath);
        	String fileName = FilenameUtils.getName(absolutePath);
        	String tmpName = "D:/tmp/" + UUID.randomUUID().toString();
            part.write(tmpName);
            
            FileDto dto = new FileDto();
            File file = new File(tmpName);
            dto.setFile(file);
            dto.setFileExt(ext);
            dto.setFileSize(fileSize);
            dto.setOrgFileName(baseName);
            dto.setRegDtm(new Date());
            dto.setRegId("test");
            dto.setStoredFileName(tmpName);
            dto.setUseYn("Y");
            
            files.add(dto);
        }
        
        FileHandlerService fileHandlerService = ApplicationContextHolder.getBean(FileHandlerService.class);
        
//        List<FileDto> newFiles = new ArrayList<FileDto>();
        List<Map> results = new ArrayList<Map>();
        for(FileDto fileDto : files) {
        	FileDto dto = fileHandlerService.saveFile(fileDto);
        	Map<String, Object> map = new HashMap<String, Object>();
        	map.put("FILE_ID", dto.getFileId());
        	map.put("FILE_NAME", dto.getOrgFileName() + (StringUtils.hasText(dto.getFileExt()) ? "." + dto.getFileExt() : ""));
        	results.add(map);
        }
        
        PlatformData platformData = new PlatformData();
        XPlatformUtil.setDataSet(platformData, "dsFile", results);
        
        if(logger.isDebugEnabled()) {
        	logger.debug(platformData.saveXml());
        }
        
		HttpPlatformResponse hPlatformRsp = new HttpPlatformResponse(res);
		hPlatformRsp.setCharset(PlatformType.DEFAULT_CHAR_SET);
		hPlatformRsp.setData(platformData);
		try {
			hPlatformRsp.sendData();
		} catch (PlatformException e) {
			logger.error("Response Failed.", e);
		}
        
	}
	
    private String getFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] tokens = contentDisp.split(";");
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf("=") + 2, token.length()-1);
            }
        }
        return "";
    }
    */
}
	
