package htc.hone.core.dto;

import java.io.Serializable;
import java.sql.Date;

import hone.bom.util.StringUtils;
import htc.hone.core.message.SystemHeader;
import htc.hone.utils.ContextUtil;

public abstract class AbstractDto implements Serializable {

	private static final long serialVersionUID = -1937246767581094868L;

	/**
	 * 입력자ID 
	 */
	private String inputpsnId;
	/**
	 * 입력일시 
	 */
	private Date inputDttm;
	/**
	 * 수정자ID
	 */
	private String mdfrId;
	/**
	 * 수정일시
	 */
	private Date mdfcDttm;
	/**
	 * 사용여부
	 */
	private String useYn;
	/**
	 * @return the inputpsnId
	 */
	public String getInputpsnId() {
		return inputpsnId;
	}
	/**
	 * @param inputpsnId the inputpsnId to set
	 */
	public void setInputpsnId(String inputpsnId) {
		this.inputpsnId = inputpsnId;
	}
	/**
	 * @return the inputDttm
	 */
	public Date getInputDttm() {
		return inputDttm;
	}
	/**
	 * @param inputDttm the inputDttm to set
	 */
	public void setInputDttm(Date inputDttm) {
		this.inputDttm = inputDttm;
	}
	/**
	 * @return the mdfrId
	 */
	public String getMdfrId() {
		return mdfrId;
	}
	/**
	 * @param mdfrId the mdfrId to set
	 */
	public void setMdfrId(String mdfrId) {
		this.mdfrId = mdfrId;
	}
	/**
	 * @return the mdfcDttm
	 */
	public Date getMdfcDttm() {
		return mdfcDttm;
	}
	/**
	 * @param mdfcDttm the mdfcDttm to set
	 */
	public void setMdfcDttm(Date mdfcDttm) {
		this.mdfcDttm = mdfcDttm;
	}
	/**
	 * @return the useYn
	 */
	public String getUseYn() {
		return useYn;
	}
	/**
	 * @param useYn the useYn to set
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public void fillDefaultSystemColumns() {
		SystemHeader header = ContextUtil.getHeader();
		String userId;
		if(header == null || !StringUtils.hasText(header.getUserId())) {
			userId = "Unknown";
		} else {
			userId = header.getUserId();
		}
		inputpsnId = inputpsnId == null ? userId : inputpsnId;
		inputDttm = inputDttm == null ? new Date(System.currentTimeMillis()): inputDttm;
		mdfrId = mdfrId == null ? userId : mdfrId;
		mdfcDttm = mdfcDttm == null ? new Date(System.currentTimeMillis()): mdfcDttm;
		useYn = useYn == null ? "Y" : useYn;
		
	}
	
	
}
