package htc.hone.core.message.support;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

public class MessageRepositoryImpl implements MessageRepository, InitializingBean {
	@Autowired
	private MessageDao messageDao;

	@Override
	public String getMessage(String messageId) {
		return messageDao.getMessage(messageId);
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		
	}

}
