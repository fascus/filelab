package htc.hone.core.message.support;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.HoneBaseRowMapper;
import htc.hone.dao.AbstractHtcDao;

@Repository
public class MessageDaoImpl extends AbstractHtcDao implements MessageDao {

	@Override
	public String getMessage(String messageId) {
		Map param = new HashMap();
		param.put("MESSAGE_ID", messageId);
		return getDaoTemplate().queryForObject("SELECT MESSAGE FROM MESSAGE WHERE MESSAGE_ID = :MESSAGE_ID", param, String.class);
	}

}
