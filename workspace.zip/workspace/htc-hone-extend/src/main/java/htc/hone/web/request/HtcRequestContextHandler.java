package htc.hone.web.request;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.InitializingBean;

import hone.bom.context.request.RequestContext;
import hone.bom.util.guid.GuidGeneratorHolder;
import hone.bom.web.request.BomRequestHolder;
import hone.bom.web.request.BomRequestInfo;
import hone.bom.web.request.RequestContextHandler;

public class HtcRequestContextHandler implements RequestContextHandler, InitializingBean {

	@Override
	public void afterPropertiesSet() throws Exception {
		// DO Nothing
	}

	@Override
	public void handle(RequestContext requestContext, HttpServletRequest request, HttpServletResponse response) {
		String requestId = this.getRequestId();
		BomRequestInfo reqInfo = new BomRequestInfo(requestContext, requestId);
		BomRequestHolder.putOnRequestContext(requestContext, reqInfo);
		
		long requestTime = System.currentTimeMillis();
		reqInfo.setRequestTime(requestTime);
		
		if(request != null) {
			reqInfo.setClientIp(request.getRemoteAddr());
			reqInfo.setServletRequest(request);
			reqInfo.setServletResponse(response);
			reqInfo.setClientLocale(request.getLocale());
			reqInfo.setCharset(request.getCharacterEncoding());
		}
	}

	protected String getRequestId() {
		return UUID.randomUUID().toString();
	}

}
