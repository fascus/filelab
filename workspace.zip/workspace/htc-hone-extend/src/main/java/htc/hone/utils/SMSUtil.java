package htc.hone.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoException;

import hone.bom.binding.utils.DtoCopyUtils;
import hone.bom.context.ApplicationContextHolder;
import htc.hone.integration.jco.JcoExecutor;

public class SMSUtil {
	private static final String SMS_FUNCTION_NAME = "Z_BC_SMS_SEND";
	private static final Logger logger = LoggerFactory.getLogger(SMSUtil.class);
	
	public static boolean sendSMS(SmsInfo smsInfo) {
		return sendSMS(DtoCopyUtils.toMap(smsInfo));
	}

	/**
	 * @param smsInfo
     *                 <p>Map column 정보 
     *                 <ul><li>RECV_TEL_NO = "받는사람 휴대폰 번호"</li>
     *                     <li>RECV_USER_NAME = "받는사람 이름"</li>                 
     *                     <li>SEND_TEL_NO = "보내는사람 휴대폰 번호"</li>
     *                     <li>SEND_USER_NAME = "보내는사람 이름"</li>
     *                     <li>SEND_MSG = "문자 메시지"</li>
     *                 </ul>
	 * @return
	 */
	public static boolean sendSMS(Map<String, Object> smsInfo) {
//		JCoDestination destination;
		try {
			ApplicationContextHolder.getBean(JcoExecutor.class).execute(SMS_FUNCTION_NAME, smsInfo);
		} catch (JCoException e) {
			logger.error("SMS Send failed - " + smsInfo.toString() + "\n" + e.getMessage(), e);
			return false;
		}

		return true;
	}


    /**
     * SMS 전송
     * @param receiver 받는사람 휴대폰 번호 예) 010-3256-xxxx, 0103256xxxx
     * @param sender 보내는사람 전화 번호 예) 010-3256-xxxx, 0103256xxxx
     * @param message 메시지
     */
    public static void sendSMS(final String receiver, String sender, String message) {
        sendSMS(new ArrayList<String>(){{add(receiver);}}, sender, message);
        
    }

    
    /**
     * SMS 전송 - 여러명의 수신자에게 발송
     * @param smsId 업무별 메시지ID
     * @param receiverList 받는사람 휴대폰 번호 String 배열
     * @param sender 보내는사람 전화 번호 예) 010-3256-xxxx, 0103256xxxx
     * @param message 메시지
     */
    public static void sendSMS(final String[] receiverList, String sender, String message) {
        sendSMS(Arrays.asList(receiverList), sender, message);
    }

    /**
     * SMS 전송 - 여러명의 수신자에게 발송
     * @param smsId 업무별 메시지ID
     * @param receiverList 받는사람 휴대폰 번호 List&lt;String&gt;
     * @param sender 보내는사람 전화 번호 예) 010-3256-xxxx, 0103256xxxx
     * @param message 메시지
     */
    public static void sendSMS(List<String> receiverList, String sender, String message) {
        List<Map> list = new ArrayList<Map>();
        for(String receiver : receiverList) {
            Map<String, Object> map = new HashMap();
            map.put("RECV_TEL_NO", receiver);
            map.put("SEND_TEL_NO", sender);
            map.put("SEND_MSG", message);
            list.add(map);
        }
        sendSMS(list);
    }

   
    /**
     * SMS 전송
     * @param smsInfoList SMS 발송정보 List&lt;Map&gt; 
     *                 <p>Map column 정보 
     *                 <ul><li>RECV_TEL_NO = "받는사람 휴대폰 번호"</li>
     *                     <li>RECV_USER_NAME = "받는사람 이름"</li>                 
     *                     <li>SEND_TEL_NO = "보내는사람 휴대폰 번호"</li>
     *                     <li>SEND_USER_NAME = "보내는사람 이름"</li>
     *                     <li>SEND_MSG = "문자 메시지"</li>
     *                 </ul>
     */  
    public static void sendSMS(List<Map> smsInfoList) {
        for(Map<String, Object> smsInfo : smsInfoList) {
            logger.info("Sending SMS by RFC call : {}", smsInfo.toString());
            sendSMS(smsInfo);
        }
    }
    
    
	
	public static class SmsInfo {
		/**
		 * 받는사람 휴대폰 번호
		 */
		private String recvTelNo;
		/**
		 * 받는사람 이름
		 */
		private String recvUserName;
		/**
		 * 보내는사람 휴대폰 번호
		 */
		private String sendTelNo;
		/**
		 * 보내는사람 이름
		 */
		private String sendUserName;
		/**
		 * 문자 메시지
		 */
		private String sendMsg;

		/**
		 * @return the recvTelNo
		 */
		public String getRecvTelNo() {
			return recvTelNo;
		}

		/**
		 * @param recvTelNo
		 *            the recvTelNo to set
		 */
		public void setRecvTelNo(String recvTelNo) {
			this.recvTelNo = recvTelNo;
		}

		/**
		 * @return the recvUserName
		 */
		public String getRecvUserName() {
			return recvUserName;
		}

		/**
		 * @param recvUserName
		 *            the recvUserName to set
		 */
		public void setRecvUserName(String recvUserName) {
			this.recvUserName = recvUserName;
		}

		/**
		 * @return the sendTelNo
		 */
		public String getSendTelNo() {
			return sendTelNo;
		}

		/**
		 * @param sendTelNo
		 *            the sendTelNo to set
		 */
		public void setSendTelNo(String sendTelNo) {
			this.sendTelNo = sendTelNo;
		}

		/**
		 * @return the sendUserName
		 */
		public String getSendUserName() {
			return sendUserName;
		}

		/**
		 * @param sendUserName
		 *            the sendUserName to set
		 */
		public void setSendUserName(String sendUserName) {
			this.sendUserName = sendUserName;
		}

		/**
		 * @return the sendMsg
		 */
		public String getSendMsg() {
			return sendMsg;
		}

		/**
		 * @param sendMsg
		 *            the sendMsg to set
		 */
		public void setSendMsg(String sendMsg) {
			this.sendMsg = sendMsg;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "SmsInfo [recvTelNo=" + recvTelNo + ", recvUserName=" + recvUserName + ", sendTelNo=" + sendTelNo
					+ ", sendUserName=" + sendUserName + ", sendMsg=" + sendMsg + "]";
		}
	}

}
