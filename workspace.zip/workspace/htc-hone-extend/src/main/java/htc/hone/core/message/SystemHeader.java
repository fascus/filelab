package htc.hone.core.message;

import htc.hone.core.dto.SerializableDto;

public class SystemHeader implements SerializableDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1648860108948096374L;

	private String screenId;
	private String serviceId;
	private String responseCode;
	private String responseMessage;
	private String userId;
	private String uuid;
	private String userIp;
	private String requestDate;
	private String requestTime;
	private String orgno;    // UI 에서 gvsOrgno 로 보내주면 자동으로 Binding
	
	
	public String getScreenId() {
		return screenId;
	}
	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}
	public String getServiceId() {
		return serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getUserIp() {
		return userIp;
	}
	public void setUserIp(String userIp) {
		this.userIp = userIp;
	}
	public String getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}
	public String getRequestTime() {
		return requestTime;
	}
	public void setRequestTime(String requestTime) {
		this.requestTime = requestTime;
	}
	@Override
	public String toString() {
		return "SystemHeader [screenId=" + screenId + ", serviceId=" + serviceId + ", responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", userId=" + userId + ", uuid=" + uuid + ", userIp="
				+ userIp + ", requestDate=" + requestDate + ", requestTime=" + requestTime + "]";
	}
	
	
}
