/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Samsung Techwin Co., Ltd.
 * Samsung Techwin Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2012 Samsung Techwin Co., Ltd. All Rights Reserved| Confidential)
 */
package htc.hone.integration.eagleoffice.mail.service;

import java.io.File;
import java.rmi.RemoteException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;

import org.apache.axis.encoding.Base64;
import org.junit.Test;

import htc.hone.integration.eagleoffice.common.vo.WsException;
import htc.hone.integration.eagleoffice.mail.vo.WsAttachFile;

/**
 * <ul>
 * <li>Created by : 손세일
 * <li>Created Date : 2015. 5. 20. 오전 10:59:53
 * </ul>
 * 
 * @author 손세일
 */
public class MailServiceProxyTest {

    String END_POINT_URL = "http://ci.eagleoffice.co.kr/api/services/MailService";
    MailServiceProxy proxy = new MailServiceProxy();
    
    String[] sendMailKey = new String[1];
    // sendMailKey[0] = 4d544d7a4d7a457a4e6a4d764c79394f
    String emailTile = "[테크윈 메일 전송 테스트] 메일 제목";
    String senderEmail = "seil.son@ci.eagleoffice.co.kr";
    String receiverEmail = "seil.son@ci.eagleoffice.co.kr";
    String mailBody = "메일 발송 테스트 본문";

    /**
     * Test method for
     * {@link hanwha.neo.branch.ss.mail.service.MailServiceProxy#sendMISMail(java.lang.String, hanwha.neo.branch.ss.mail.service.WsMailInfo, hanwha.neo.branch.ss.mail.service.WsRecipient[], hanwha.neo.branch.ss.common.vo.WsAttachFile[])}
     * .
     */
    @Test
    public void testSendMISMail() {
        //System.out.println("=====testSendMISMail=====");

        proxy.setEndpoint(END_POINT_URL);

        WsMailInfo mailInfo = new WsMailInfo();
        mailInfo.setSubject(emailTile);
        mailInfo.setHtmlContent(true);
        mailInfo.setAttachCount(1);
        mailInfo.setSenderEmail(senderEmail);
        mailInfo.setImportant(false);

        WsRecipient[] receivers = new WsRecipient[1];
        receivers[0] = new WsRecipient();
        receivers[0].setSeqID(1);
        receivers[0].setRecvType("TO");
        receivers[0].setRecvEmail(receiverEmail);

        WsAttachFile[] attachFiles = new WsAttachFile[1];
        attachFiles[0] = new WsAttachFile();
        attachFiles[0].setSeqID(1);
        attachFiles[0].setFileName("MailServiceTest.java");
        attachFiles[0].setFileSize("123456");

        File file = new File("D:\\STW-Workshop\\workspace\\EagleOfficeMail\\src\\hanwha\\neo\\branch\\ss\\mail\\service\\", attachFiles[0].getFileName());
        FileDataSource fds = null;
        DataHandler dh = null;

        if (file != null && file.isFile()) {
            fds = new FileDataSource(file);
            dh = new DataHandler(fds);
        }

        attachFiles[0].setFileInfo(dh);
        try {
            sendMailKey[0] = proxy.sendMISMail(mailBody, mailInfo, receivers, attachFiles);
            //System.out.println("sendMailKey[0] = " + sendMailKey[0]);
            
            Thread.sleep(5000); // 5초 sleep(바로 메일 상태를 호출하면 에러 발생)
            
            testGetMailStatusCounts();
            testCancelMISMailByRecipient();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (WsException e) {
            e.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    /**
     * Test method for
     * {@link hanwha.neo.branch.ss.mail.service.MailServiceProxy#getMailStatusCounts(java.lang.String[])}.
     */
    public void testGetMailStatusCounts() {
        //System.out.println("=====testGetMailStatusCounts=====");

        proxy.setEndpoint(END_POINT_URL);
        WsMailStatus[] wsMailStatus = new WsMailStatus[sendMailKey.length];

        try {
            wsMailStatus = proxy.getMailStatusCounts(sendMailKey);
            for (int i = 0; i < wsMailStatus.length; i++) {
                //System.out.println(wsMailStatus[0].getMailKey() + " 발송여부 --> " + wsMailStatus[0].isDelivery());
            }

        } catch (WsException e) {
            e.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

    }

    /**
     * Test method for
     * {@link hanwha.neo.branch.ss.mail.service.MailServiceProxy#cancelMISMailByRecipient(java.lang.String, java.lang.String[], hanwha.neo.branch.ss.mail.service.WsResource)}
     * .
     */
    public void testCancelMISMailByRecipient() {
        //System.out.println("=====testCancelMISMailByRecipient=====");

        proxy.setEndpoint(END_POINT_URL);

        // 취소할 메일 수신자
        String[] receiverForCancel = new String[1];
        receiverForCancel[0] = receiverEmail;
        try {

            WsResource senderInfo = new WsResource();
            senderInfo.setSenderEmail(senderEmail);
            senderInfo.setSenderPw(md5Digest("123456")); // 패스워드

            String resultMsg = proxy.cancelMISMailByRecipient(sendMailKey[0], receiverForCancel, senderInfo);
            //System.out.println("resultMsg = " + resultMsg);

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (WsException e) {
            e.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    // MD5 암호화하여 base64 인코딩
    public String md5Digest(String input) throws NoSuchAlgorithmException {
        
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(input.getBytes());

        return Base64.encode(md.digest());
    }

}
