/**
 * MailService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package htc.hone.integration.eagleoffice.mail.service;

import htc.hone.integration.eagleoffice.common.vo.WsException;
import htc.hone.integration.eagleoffice.mail.vo.WsAttachFile;

public interface MailService extends java.rmi.Remote {
    public WsMailStatus[] getMailStatusCounts(java.lang.String[] mailKey) throws java.rmi.RemoteException, WsException;
    public java.lang.String sendMISMail(java.lang.String mailBody, WsMailInfo mailInfo, WsRecipient[] receivers, WsAttachFile[] attachFile) throws java.rmi.RemoteException, WsException;
    public java.lang.String cancelMISMailByRecipient(java.lang.String mailKey, java.lang.String[] receiverForCancel, WsResource senderInfo) throws java.rmi.RemoteException, WsException;
}
