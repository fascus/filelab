package htc.hone.web.support;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import htc.hone.core.message.JsonMessage;
import htc.hone.core.message.HtcMessageEnvelop;

public class JsonMessageArgumentResolver implements HandlerMethodArgumentResolver {
	private ObjectMapper objectMapper;
	
	public void setObjectMapper(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}
	
	@Override
	public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest,
			WebDataBinderFactory binderFactory) throws Exception {
		HttpServletRequest request = webRequest.getNativeRequest(HttpServletRequest.class);
		Object tps = JsonMessage.class.getTypeParameters();
		Class c1 = JsonMessage.class;
		Class c2 = HtcMessageEnvelop.class;
		
//		JavaType messageType = objectMapper.getTypeFactory().constructParametricType(JsonMessage.class, JsonNode.class);
		JsonMessage requestMessage = objectMapper.readValue(request.getInputStream(), JsonMessage.class);
		requestMessage.getHeader().setScreenId("PILOTSCREENID");
		requestMessage.getHeader().setServiceId("PILOTSERVICEID");
		return requestMessage;
	}

	@Override
	public boolean supportsParameter(MethodParameter parameter) {
		return JsonMessage.class.isAssignableFrom(parameter.getParameterType());
	}

}
