package htc.hone.core.message;

import com.fasterxml.jackson.databind.JsonNode;

public class JsonMessage extends HtcMessageEnvelop<JsonNode> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7643327609235459793L;

}
