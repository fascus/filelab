package htc.hone.core.exception;

public class SystemException extends RuntimeException {
	private String messageCode;
	private String[] messageParams;
	
	public SystemException(Throwable e) {
		super(e);
	}
	
	public SystemException(String messageCode) {
		this.messageCode = messageCode;
		this.messageParams = new String[0];
	}
	
	public SystemException(String messageCode, String ... messageParams) {
		this.messageCode = messageCode;
		this.messageParams = messageParams;
	}

	public String getMessageCode() {
		return messageCode;
	}

	public String[] getMessageParams() {
		return messageParams;
	}

}
