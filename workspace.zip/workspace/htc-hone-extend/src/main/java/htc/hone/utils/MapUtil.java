package htc.hone.utils;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.util.StringUtils;

import htc.hone.core.message.SystemHeader;
import htc.xplatform.web.HtcConstants;

public class MapUtil {
	public static void fillSysColumns(Map map) {
		SystemHeader header = ContextUtil.getHeader();
		String userId;
		if(header == null || !StringUtils.hasText(header.getUserId())) {
			userId = "Unknown";
		} else {
			userId = header.getUserId();
		}
		if(isEmptyValue(map, HtcConstants.SYSCOL_INPUTPSN_ID)) {
			map.put(HtcConstants.SYSCOL_INPUTPSN_ID, userId);
		}
        if(isEmptyValue(map, HtcConstants.SYSCOL_INPUT_DTTM)) {
			map.put(HtcConstants.SYSCOL_INPUT_DTTM, new Date());
		}
        if(isEmptyValue(map, HtcConstants.SYSCOL_MDFR_ID)) {
			map.put(HtcConstants.SYSCOL_MDFR_ID, userId);
		}
        if(isEmptyValue(map, HtcConstants.SYSCOL_MDFC_DTTM)) {
			map.put(HtcConstants.SYSCOL_MDFC_DTTM, new Date());
		}
        if(isEmptyValue(map, HtcConstants.SYSCOL_USE_YN)) {
			map.put(HtcConstants.SYSCOL_USE_YN, "Y");
		}
	}

    /**
     * @Method Name        : hasValue
     * @Method description : 
     * @Date               : 2016. 11. 29.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 29.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param map
     * @param key
     * @return
    */
    
    private static boolean isEmptyValue(Map map, String key) {
        if(map == null) return true;
        if(!map.containsKey(key)) return true;
        Object value = map.get(key);
        if(value == null) return true;
        if(value instanceof String && "".equals(value)) return true;
        return false;
    }
	
	/**
	 * <pre>
	 * Map Key 값들에 해당하는 Value들을 암호화 해준다.
	 * </pre>
	 * @param map
	 * @param keys (암호화 할 데이터 들의 Key 값 목록)
	 */
	public void encryptMap(Map map, String... keys) {
		encryptMap(map, true, true, keys);
	}
	/**
	 * <pre>
	 * Map Key 값들에 해당하는 Value들을 암호화 해준다.
	 * </pre>
	 * @param map
	 * @param ignoreFailed (key 값이 없을 경우 오류 무시 여부)
	 * @param ignoreInvalidKey (암호화 실패 시 오류 무시 여부)
	 * @param keys (암호화 할 데이터 들의 Key 값 목록)
	 */
	public void encryptMap(Map map, boolean ignoreInvalidKey, boolean ignoreFailed, String... keys) {
		if(map == null || map.isEmpty()) {
			return;
		}
		
		for(String key : keys) {
			if(!map.containsKey(key)) {
				if(!ignoreInvalidKey) {
					throw new RuntimeException("Invalid Key : " + key);
				}
				continue;
			}

			if(!StringUtils.hasText((String) map.get(key))) {
				continue;
			}
			try {
				String enc = EncUtil.encrypt((String) map.get(key));
				map.put(key, enc);
			} catch (Exception e) {
				if(!ignoreFailed) {
					throw new RuntimeException(e);
				}
			}
		}
	}

	/**
	 * <pre>
	 * List<Map> Key 값들에 해당하는 Value들을 암호화 해준다.
	 * </pre>
	 * @param map
	 * @param ignoreFailed (key 값이 없을 경우 오류 무시 여부)
	 * @param ignoreInvalidKey (암호화 실패 시 오류 무시 여부)
	 * @param keys (암호화 할 데이터 들의 Key 값 목록)
	 */
	public void encryptMapList(List<Map> list, String... keys) {
		encryptMapList(list, true, true, keys);
	}
	
	/**
	 * <pre>
	 * List<Map> Key 값들에 해당하는 Value들을 암호화 해준다.
	 * </pre>
	 * @param map
	 * @param ignoreFailed (key 값이 없을 경우 오류 무시 여부)
	 * @param ignoreInvalidKey (암호화 실패 시 오류 무시 여부)
	 * @param keys (암호화 할 데이터 들의 Key 값 목록)
	 */
	public void encryptMapList(List<Map> list, boolean ignoreInvalidKey, boolean ignoreFailed, String... keys) {
		if(list == null) {
			return;
		}
		for(int i = 0; i < list.size(); i++) {
			encryptMap(list.get(i), ignoreInvalidKey, ignoreFailed, keys);
		}
	}


	/**
	 * <pre>
	 * Map Key 값들에 해당하는 Value들을 복호화 해준다.
	 * </pre>
	 * @param map
	 * @param keys (복호화 할 데이터 들의 Key 값 목록)
	 */
	public void decryptMap(Map map, String... keys) {
		decryptMap(map, true, true, keys);
	}
	/**
	 * <pre>
	 * Map Key 값들에 해당하는 Value들을 복호화 해준다.
	 * </pre>
	 * @param map
	 * @param ignoreFailed (key 값이 없을 경우 오류 무시 여부)
	 * @param ignoreInvalidKey (복호화 실패 시 오류 무시 여부)
	 * @param keys (복호화 할 데이터 들의 Key 값 목록)
	 */
	public void decryptMap(Map map, boolean ignoreInvalidKey, boolean ignoreFailed, String... keys) {
		if(map == null || map.isEmpty()) {
			return;
		}
		
		for(String key : keys) {
			if(!map.containsKey(key)) {
				if(!ignoreInvalidKey) {
					throw new RuntimeException("Invalid Key : " + key);
				}
				continue;
			}

			if(!StringUtils.hasText((String) map.get(key))) {
				continue;
			}
			try {
				String dec = EncUtil.decrypt((String) map.get(key));
				map.put(key, dec);
			} catch (Exception e) {
				if(!ignoreFailed) {
					throw new RuntimeException(e);
				}
			}
		}
	}

	/**
	 * <pre>
	 * List<Map> Key 값들에 해당하는 Value들을 복호화 해준다.
	 * </pre>
	 * @param map
	 * @param ignoreFailed (key 값이 없을 경우 오류 무시 여부)
	 * @param ignoreInvalidKey (복호화 실패 시 오류 무시 여부)
	 * @param keys (복호화 할 데이터 들의 Key 값 목록)
	 */
	public void decryptMapList(List<Map> list, String... keys) {
		decryptMapList(list, true, true, keys);
	}
	
	/**
	 * <pre>
	 * List<Map> Key 값들에 해당하는 Value들을 복호화 해준다.
	 * </pre>
	 * @param map
	 * @param ignoreFailed (key 값이 없을 경우 오류 무시 여부)
	 * @param ignoreInvalidKey (복호화 실패 시 오류 무시 여부)
	 * @param keys (복호화 할 데이터 들의 Key 값 목록)
	 */
	public void decryptMapList(List<Map> list, boolean ignoreInvalidKey, boolean ignoreFailed, String... keys) {
		if(list == null) {
			return;
		}
		for(int i = 0; i < list.size(); i++) {
			decryptMap(list.get(i), ignoreInvalidKey, ignoreFailed, keys);
		}
	}
}
