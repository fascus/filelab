package htc.hone.core.user;

import java.io.Serializable;

import htc.hone.core.message.SystemHeader;

public class UserInfo implements Serializable {
	private boolean initialized = false;
	
	private String userId;
	private String uuid;
	private String userIp;

	public UserInfo() {
	}
	
	public UserInfo(SystemHeader header) {
		this.userId = header.getUserId();
		this.uuid = header.getUuid();
		this.userIp = header.getUserIp();
		this.initialized = true;
	}

	public String getUserId() {
		return userId;
	}

	public String getUuid() {
		return uuid;
	}

	public String getUserIp() {
		return userIp;
	}
	
	

}
