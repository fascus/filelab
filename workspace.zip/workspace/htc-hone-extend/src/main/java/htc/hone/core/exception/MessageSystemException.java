package htc.hone.core.exception;

import htc.xplatform.utils.MessageUtil;

public class MessageSystemException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6988259662702730097L;
	private static final String MESSAGE_CODE = MessageUtil.DEFAULT_ERROR_ID;
	private String message;
	
	public MessageSystemException(Throwable e) {
		super(e);
		this.message = e.getMessage();
	}
	
	public MessageSystemException(String message) {
		this.message = message;
	}
	
	public MessageSystemException(String message, Throwable e) {
		super(e);
		this.message = message;
	}
	
	public String getMessageCode() {
		return MESSAGE_CODE;
	}

	public String getMessage() {
		return message;
	}
	
	
}
