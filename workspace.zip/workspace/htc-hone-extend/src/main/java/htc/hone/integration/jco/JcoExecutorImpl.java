package htc.hone.integration.jco;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;

import hone.bom.BomException;
import hone.bom.binding.utils.DtoCopyUtils;
import htc.hone.utils.JcoUtil;

public class JcoExecutorImpl implements JcoExecutor {
	private String jcoDestinationName;
	
	
	@Override
	public void setJcoDestinationName(String jcoDestinationName) {
		this.jcoDestinationName = jcoDestinationName;
	}

	@Override
	public String getJcoDestinationName() {
		return this.jcoDestinationName;
	}


	public JcoExecutorImpl() {
		this.jcoDestinationName = JcoUtil.DEFAULT_JCO_DESTINATION_NAME;
	}

	public JcoExecutorImpl(String jcoDestinationName) {
		this.jcoDestinationName = jcoDestinationName;
	}

	@Override
	public void execute(String functionName, Object params) throws JCoException {
		notSupportList(params);
		JcoPack pack = new JcoPack(this.jcoDestinationName, functionName);
		innerHandlerImportParam(params, pack);
	}

	@Override
	public void execute(String functionName, String paramTableName, List params) throws JCoException {
		JcoPack pack = new JcoPack(this.jcoDestinationName, functionName);
		innerHandlerTableParam(paramTableName, params, pack);
	}

	@Override
	public <T> T execute(String functionName, Object params, Class<T> resultClass) throws JCoException  {
		notSupportList(params);
		JcoPack pack = new JcoPack(this.jcoDestinationName, functionName);
		innerHandlerImportParam(params, pack);
		return innerHandleExportResult(resultClass, pack);
	}

	@Override
	public <T> T execute(String functionName, String paramTableName, List params, Class<T> resultClass) throws JCoException {
		JcoPack pack = new JcoPack(this.jcoDestinationName, functionName);
		innerHandlerTableParam(paramTableName, params, pack);
		return innerHandleExportResult(resultClass, pack);

	}

	@Override
	public <T> List<T> execute(String functionName, Object params, Class<T> resultClass, String resultTableName)
			throws JCoException {
		notSupportList(params);
		JcoPack pack = new JcoPack(this.jcoDestinationName, functionName);
		innerHandlerImportParam(params, pack);
		return innerHandlerTableResult(resultClass, resultTableName, pack);
	}

	@Override
	public <T> List<T> execute(String functionName, String paramTableName, List params, Class<T> resultClass,
			String resultTableName) throws JCoException {
		JcoPack pack = new JcoPack(this.jcoDestinationName, functionName);
		innerHandlerTableParam(paramTableName, params, pack);
		return innerHandlerTableResult(resultClass, resultTableName, pack);
	}

	private void notSupportList(Object params) {
		if(params != null && List.class.isAssignableFrom(params.getClass())) {
			throw new BomException("Cannot apply java.util.List param");
		}
	}

	private void innerHandlerImportParam(Object params, JcoPack pack)
			throws JCoException {
		Map paramMap = null;
		
		if(params == null) {
			paramMap = new HashMap();
		} else if(Map.class.isAssignableFrom(params.getClass())) {
			paramMap = (Map) params;
		} else  {
			paramMap = DtoCopyUtils.toMap(params);
		}
		JcoUtil.setImportParameter(pack.getFunction(), paramMap);
		pack.getFunction().execute(pack.getDestination());
	}

	private void innerHandlerTableParam(String paramTableName, List params, JcoPack pack) throws JCoException {
		List<Map> paramList = null;
		if(params == null || params.size() < 1) {
			paramList = new ArrayList<Map>();
		} else if(Map.class.isAssignableFrom(params.get(0).getClass())) {
			paramList = params;
		} else  {
			paramList = new ArrayList<Map>();
			for(Object obj : params) {
				paramList.add(DtoCopyUtils.toMap(obj));
			}
		}
		JcoUtil.setTableParameter(pack.getFunction(), paramTableName, paramList);
		pack.getFunction().execute(pack.getDestination());
	}

	private <T> T innerHandleExportResult(Class<T> resultClass, JcoPack pack) {
		JCoParameterList parameterList = pack.getFunction().getExportParameterList();
		Map returnMap = JcoUtil.convertMap(parameterList);
		
		if(Map.class.isAssignableFrom(resultClass)) {
			return (T) returnMap;
		} else {
			return (T) DtoCopyUtils.fromMap(returnMap, resultClass);
		}
	}

	
	private <T> List<T> innerHandlerTableResult(Class<T> resultClass, String resultTableName, JcoPack pack) {
		JCoTable table = pack.getFunction().getExportParameterList().getTable(resultTableName);
		List<Map> list = JcoUtil.convertList(table);
		if(Map.class.isAssignableFrom(resultClass)) {
			return (List<T>) list;
		} else {
			List<T> resultList = new ArrayList<T>();
			for(Map map : list) {
				resultList.add((T) DtoCopyUtils.fromMap(map, resultClass));
			}
			
			return resultList;
		}
	}

	
	
	private class JcoPack {
		private JCoDestination destination;
		private JCoFunction function;

		public JcoPack(String destinationName, String functionName) throws JCoException {
			this.destination = JcoUtil.getJcoDestination(destinationName);
			this.function  = JcoUtil.getJcoFunction(this.destination, functionName);
		}
		/**
		 * @return the destination
		 */
		public JCoDestination getDestination() {
			return destination;
		}
		/**
		 * @return the function
		 */
		public JCoFunction getFunction() {
			return function;
		}
		
		
	}



}
