package htc.hone.core.message;

import java.io.Serializable;

public abstract class AbstractPayload implements Serializable {
	
}
