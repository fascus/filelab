package htc.hone.utils;

import org.jasypt.encryption.pbe.PBEStringEncryptor;
import org.jasypt.util.password.ConfigurablePasswordEncryptor;
import org.jasypt.util.password.PasswordEncryptor;
import org.jasypt.util.text.StrongTextEncryptor;
import org.jasypt.util.text.TextEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import hone.bom.BomException;
import hone.bom.context.ApplicationContextHolder;

public class EncUtil {
	private static final Logger loger = LoggerFactory.getLogger(EncUtil.class);
	/**
	 * 양방향 암호화
	 * @param s
	 * @return
	 */
	public static String encrypt(String s) {
		try {
			return ApplicationContextHolder.getBean("pbeStringEncryptor", PBEStringEncryptor.class).encrypt(s);
		} catch (Exception e) {
			throw new BomException("Encryption Failed.", e);
		}
	}
	/**
	 * 양방향 복호화
	 * @param s
	 * @return
	 */
	public static String decrypt(String s) {
		try {
			return ApplicationContextHolder.getBean("pbeStringEncryptor", PBEStringEncryptor.class).decrypt(s);
		} catch (Exception e) {
			throw new BomException("Decryption Failed.", e);
		}
	}
	
	/**
	 * 단방향 암호화
	 * @param s
	 * @return
	 */
	public static String encryptPassword(String s) {
		try {
			return ApplicationContextHolder.getBean("passwordEncryptor", PasswordEncryptor.class).encryptPassword(s);
		} catch (Exception e) {
			throw new BomException("Encryption Failed.", e);
		}
	}
	
	/**
	 * 단방향 암호문 비교 (암호화 할 때마다 문자열이 달라지므로 반드시 이 메소드로 비교)
	 * @param plainPassword
	 * @param encryptedPassword
	 * @return
	 */
	public static boolean checkPassword(String plainPassword, String encryptedPassword) {
		try {
			return ApplicationContextHolder.getBean("passwordEncryptor", PasswordEncryptor.class).checkPassword(plainPassword, encryptedPassword);
		} catch (Exception e) {
			throw new BomException("Encryption Failed.", e);
		}
	}
}
