package htc.hone.core.message.support;

import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

/**
 * 시스템 메세지를 가져온다. 실제 작동을 위하여 MessageRepository Interface의 구현체를 주입하여야 한다.
 * @author taehoon
 *
 */
public class MessageSupport  {
	private boolean isNullParamToEmpty = true;
	private String marker = "{}";
	private MessageRepository repository;

	/**
	 * Message Id 기준으로 Message를 가져온다.
	 * @param messageId
	 * @return
	 */
	public String getMessage(String messageId) {
		if(repository == null) {
			throw new RuntimeException("Message Repository is not initialized.");
		}
		return repository.getMessage(messageId);
	}

	
	/**
	 * Message ID 와 Message Param을 기준으로 조립해준다.
	 * @param messageId
	 * @param messageParams
	 * @return
	 */
	public String buildMessage(String messageId, String... messageParams) {
		String message = getMessage(messageId);
		int markCount = StringUtils.countMatches(message, "{}");
		
		if(markCount == 0 || messageParams == null || messageParams.length == 0) {
			return message;
		}
		
		if(message.indexOf(marker) > -1) {
			message = message.replaceAll(Pattern.quote(marker), "%s");
		}
		String[] cleanParams = new String[markCount];
		
		if(messageParams.length > markCount) {
			System.arraycopy(messageParams, 0, cleanParams, 0, markCount);
		} else if(messageParams.length < markCount) {
			System.arraycopy(messageParams, 0, cleanParams, 0, messageParams.length); 
		} else {
			cleanParams = messageParams;
		}
		if(isNullParamToEmpty) {
			for(int index = 0; index < cleanParams.length; index++) {
				if(cleanParams[index] == null) {
					cleanParams[index] = "";
				}
			}
		}
		return String.format(message, cleanParams);
	}

	public void setRepository(MessageRepository repository) {
		this.repository = repository;
	}


	public String getMarker() {
		return marker;
	}


	public void setMarker(String marker) {
		this.marker = marker;
	}


	public boolean isNullParamToEmpty() {
		return isNullParamToEmpty;
	}


	public void setNullParamToEmpty(boolean isNullParamToEmpty) {
		this.isNullParamToEmpty = isNullParamToEmpty;
	}
}
