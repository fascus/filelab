package htc.hone.log;

import hone.bom.context.request.RequestContext;
import hone.ext.admin.oracle.log.AbstractOracleRequestDBLoggingPolicy;
import hone.ext.admin.oracle.log.header.CommonSystemHeader;
import htc.hone.core.message.SystemHeader;
import htc.xplatform.web.HtcConstants;

public class LtsRequestDBLoggingPolicy extends AbstractOracleRequestDBLoggingPolicy {

	@Override
	protected CommonSystemHeader resolveCommonSystemHeader(RequestContext requestContext) {
		CommonSystemHeader header =new CommonSystemHeader();
		SystemHeader ltsHeader = (SystemHeader) requestContext.getAttribute(HtcConstants.HEADER_KEY);
		if(ltsHeader == null) {
			ltsHeader = new SystemHeader();
			ltsHeader.setServiceId("TESTSID");
			ltsHeader.setScreenId("TESTSCID");
			ltsHeader.setUserId("TEST_ID");
		}
		
		header.setTxCode(ltsHeader.getServiceId());
		header.setScreenId(ltsHeader.getScreenId());
		header.setContextType("LTS");
		
		return header;
	}

}
