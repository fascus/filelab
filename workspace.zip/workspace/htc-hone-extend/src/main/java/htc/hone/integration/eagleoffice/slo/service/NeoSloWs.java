/**
 * NeoSloWs.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package htc.hone.integration.eagleoffice.slo.service;

import java.rmi.RemoteException;

import htc.hone.integration.eagleoffice.common.vo.WsException;

public interface NeoSloWs extends java.rmi.Remote {
    public String create(String id, String type, String target) throws RemoteException, WsException;
    public String login(String otaId, String target) throws RemoteException, WsException;
}
