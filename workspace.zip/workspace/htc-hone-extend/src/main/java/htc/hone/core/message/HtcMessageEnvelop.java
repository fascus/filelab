package htc.hone.core.message;

import hone.bom.integration.message.Message;

public class HtcMessageEnvelop<P> implements Message<SystemHeader, P> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2098488467493471264L;
	
	private SystemHeader header;
	private P payload;

	@Override
	public SystemHeader getHeader() {
		return header;
	}

	@Override
	public P getPayload() {
		return payload;
	}

	public void setHeader(SystemHeader header) {
		this.header = header;
	}

	public void setPayload(P payload) {
		this.payload = payload;
	}
	

}
