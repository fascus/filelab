package htc.hone.web;

import java.util.Map;

import hone.bom.interceptor.Position;
import hone.bom.web.dispatcher.DispatchException;
import hone.bom.web.dispatcher.ServiceMethod;
import hone.bom.web.handler.MDCValue;
import hone.bom.web.handler.MessageRequestHandlerSupport;
import hone.bom.web.message.TxMessageException;
import hone.bom.web.request.BomRequestInfo;
import hone.bom.web.request.ClientType;
import htc.hone.core.message.HtcMessageEnvelop;
import htc.hone.core.message.SystemHeader;

public abstract class ExampleRequestHandler<P> extends MessageRequestHandlerSupport<HtcMessageEnvelop<P>> {

	@Override
	protected MDCValue resolveMdcValue(HtcMessageEnvelop<P> requestMessage, BomRequestInfo requestInfo) {
		MDCValue mdcValue = super.resolveMdcValue(requestMessage, requestInfo);
		mdcValue.setScreenId(requestMessage.getHeader().getScreenId());
		mdcValue.setServiceId(requestMessage.getHeader().getServiceId());
		return mdcValue;
	}

	@Override
	protected HtcMessageEnvelop<P> handleError(Position position, HtcMessageEnvelop<P> requestMessage,
			BomRequestInfo requestInfo, Throwable e) {
		e.printStackTrace();
		requestInfo.setException(e);
		HtcMessageEnvelop<P> errorMessage = buildErrorMessage(position, requestMessage, e);
		return errorMessage;
	}

	@Override
	protected ClientType getClientType(BomRequestInfo reqInfo) {
		return ClientType.WEB;
	}

	@Override
	protected String resolveTxCode(HtcMessageEnvelop<P> message) throws DispatchException {
		return "PILOTTXCODE";
	}

	@Override
	protected Map<String, Object> resolveAdditionalData(HtcMessageEnvelop<P> message) throws DispatchException {
		return super.resolveAdditionalData(message);
	}

	@Override
	protected Object[] resolveParameters(HtcMessageEnvelop<P> message, ServiceMethod serviceMethod)
			throws TxMessageException {
		return parsePayload(message.getPayload(), serviceMethod.getParamerTypes());
	}
	

	protected abstract Object[] parsePayload(P payload, Class<?>[] paramerTypes);

	protected abstract P makePayload(Object returnValue);
	
	@Override
	protected void handlePostExecution(Object rtn, BomRequestInfo requestInfo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void handlePreExecution(Object[] parameters, BomRequestInfo requestInfo,
			HtcMessageEnvelop<P> requestMessage) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected HtcMessageEnvelop<P> buildMessage(Object... params) throws TxMessageException {
		HtcMessageEnvelop<P> requestMessage = (HtcMessageEnvelop<P>) params[0];
		
		Object returnValue = params[2];
		
		HtcMessageEnvelop<P> responseMessge = new HtcMessageEnvelop<P>();
		SystemHeader requestHeader = requestMessage.getHeader();
		responseMessge.setHeader(requestHeader);
		responseMessge.setPayload(makePayload(returnValue));
		
		return responseMessge;
	}

	@Override
	protected HtcMessageEnvelop<P> buildErrorMessage(Object... params) throws TxMessageException {
		HtcMessageEnvelop<P> responseMessage = new HtcMessageEnvelop<P>();
		SystemHeader header = new SystemHeader();
		
		Exception ex = (Exception) params[2];
		header.setResponseCode("PILOTERRORMSG");
		header.setResponseMessage(ex.getMessage());
		
		responseMessage.setHeader(header);
		return responseMessage;
	}

	
	
}
