/**
 * MailServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package htc.hone.integration.eagleoffice.mail.service;

import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;

public interface MailServiceService extends Service {
    public String getMailServiceAddress();

    public MailService getMailService() throws ServiceException;

    public MailService getMailService(java.net.URL portAddress) throws ServiceException;
}
