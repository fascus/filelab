package htc.hone.integration.eagleoffice.mail.service;

import htc.hone.integration.eagleoffice.common.vo.WsException;
import htc.hone.integration.eagleoffice.mail.vo.WsAttachFile;

public class MailServiceProxy implements MailService {
  private String _endpoint = null;
  private MailService mailService = null;
  
  public MailServiceProxy() {
    _initMailServiceProxy();
  }
  
  public MailServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initMailServiceProxy();
  }
  
  private void _initMailServiceProxy() {
    try {
      mailService = (new MailServiceServiceLocator()).getMailService();
      if (mailService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)mailService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)mailService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (mailService != null)
      ((javax.xml.rpc.Stub)mailService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public MailService getMailService() {
    if (mailService == null)
      _initMailServiceProxy();
    return mailService;
  }
  
  public WsMailStatus[] getMailStatusCounts(java.lang.String[] mailKey) throws java.rmi.RemoteException, WsException{
    if (mailService == null)
      _initMailServiceProxy();
    return mailService.getMailStatusCounts(mailKey);
  }
  
  public java.lang.String sendMISMail(java.lang.String mailBody, WsMailInfo mailInfo, WsRecipient[] receivers, WsAttachFile[] attachFile) throws java.rmi.RemoteException, WsException{
    if (mailService == null)
      _initMailServiceProxy();
    return mailService.sendMISMail(mailBody, mailInfo, receivers, attachFile);
  }
  
  public java.lang.String cancelMISMailByRecipient(java.lang.String mailKey, java.lang.String[] receiverForCancel, WsResource senderInfo) throws java.rmi.RemoteException, WsException{
    if (mailService == null)
      _initMailServiceProxy();
    return mailService.cancelMISMailByRecipient(mailKey, receiverForCancel, senderInfo);
  }
  
  
}