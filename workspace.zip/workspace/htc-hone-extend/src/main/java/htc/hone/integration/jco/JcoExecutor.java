package htc.hone.integration.jco;

import java.util.List;

import com.sap.conn.jco.JCoException;

public interface JcoExecutor {
	void setJcoDestinationName(String jcoDestinationName);
	String getJcoDestinationName();
	
	/**
	 * Import Paramter 를 넘겨주고 Return 값을 받지 않는 JCO 요청
	 * @param functionName
	 * @param params
	 * @throws JCoException
	 */
	void execute(String functionName, Object params) throws JCoException ;
	/**
	 * Table Paramter 를 넘겨주고 Return 값을 받지 않는 JCO 요청
	 * @param functionName
	 * @param tableName
	 * @param params
	 * @throws JCoException
	 */
	void execute(String functionName, String paramTableName, List params) throws JCoException ;
	/**
	 * Import Paramter 를 넘겨주고 resultClass 형태로 Import Parameter를 Return 받는 JCO 요청
	 * resultClass 를 List 로 넣을 경우 Table 
	 * @param functionName
	 * @param params
	 * @param resultClass
	 * @return
	 * @throws JCoException
	 */
	<T> T execute(String functionName, Object params, Class<T> resultClass) throws JCoException ;
	/**
	 * @param functionName
	 * Table Paramter 를 넘겨주고 resultClass 형태로 Import Parameter를 Return 받는 JCO 요청
	 * @param tableName
	 * @param params
	 * @param resultClass
	 * @return
	 * @throws JCoException
	 */
	<T> T execute(String functionName, String paramTableName, List params, Class<T> resultClass) throws JCoException ;
	/**
	 * Import Paramter 를 넘겨주고 resultClass 형태로 Table Parameter를 Return 받는 JCO 요청
	 * resultClass 를 List 로 넣을 경우 Table 
	 * @param functionName
	 * @param params
	 * @param resultClass
	 * @return
	 * @throws JCoException
	 */
	<T> List<T> execute(String functionName, Object params, Class<T> resultClass, String resultTableName) throws JCoException ;
	/**
	 * @param functionName
	 * Table Paramter 를 넘겨주고 resultClass 형태로 Table Parameter를 Return 받는 JCO 요청
	 * @param tableName
	 * @param params
	 * @param resultClass
	 * @return
	 * @throws JCoException
	 */
	<T> List<T> execute(String functionName, String paramTableName, List params, Class<T> resultClass, String resultTableName) throws JCoException ;
}
