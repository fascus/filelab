package htc.hone.dao;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.BeanInitializationException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.KeyHolder;

import hone.bom.BomException;
import hone.bom.binding.utils.DtoCopyUtils;
import hone.bom.dao.HoneBaseRowMapper;
import hone.bom.dao.HoneBaseSqlParameterSource;
import hone.bom.dao.core.AbstractDefaultDao;
import hone.bom.dao.core.HoneNamedParameterJdbcTemplate;
import hone.bom.dao.core.RowDataHandler;
import hone.bom.dao.hqml.model.HqmlSqlStatement;
import hone.bom.dao.hqml.model.HqmlStatement;
import hone.bom.dao.hqml.provider.StatementProvider;
import hone.bom.dao.record.RecordRowDataHandler;
import hone.bom.util.record.Record;
import hone.bom.util.record.RecordSet;
import htc.commons.paging.PagingSupport;
import htc.hone.utils.ContextUtil;
import htc.hone.utils.MapUtil;

public class AbstractHtcDao extends AbstractDefaultDao {
	protected static final String DEF_STMT_PROVIDER_BEANNAME = StatementProvider.class.getName();
	private static final String PAGING_SQL_PREFIX = "SELECT * FROM ( SELECT A.*, ROWNUM AS RNUM, COUNT(1) OVER() AS TOTCNT FROM ( \n";
	private static final String PAGING_SQL_POSTFIX = "\n ) A ) WHERE RNUM > :PAGING_OFFSET AND RNUM <= :PAGING_LIMIT ";
	

	private StatementProvider statementProvider;

	public void setSqlStatementProvider(StatementProvider sqlStatementProvider) {
		this.statementProvider = sqlStatementProvider;
	}

	public void afterPropertiesSet() throws Exception {
		super.afterPropertiesSet();

		if (statementProvider == null) {
			if (getBeanFactory().containsBean(DEF_STMT_PROVIDER_BEANNAME)) {
				statementProvider = getBeanFactory().getBean(DEF_STMT_PROVIDER_BEANNAME, StatementProvider.class);
			} else {
				throw new BeanInitializationException("StatementProvider가 지정되지 않았습니다.");
			}
		}
	}

	/**
	 * 주어진 HQML ID에 해당하는 sql 문을 반환하며 이때 주어진 파라미터를 이용 동적 SQL을 파싱해 반환한다
	 *
	 * @param qname HQML ID
	 * @param parameters 동적 SQL 파싱에 필요한 파라미터
	 * @return String
	 */
	protected String getSql(String qname, Object parameters) {
		HqmlSqlStatement sqlStatement = (HqmlSqlStatement)statementProvider.geStatement(qname);
		if (sqlStatement.isDynamicSql()) {
			return sqlStatement.parseDynamicSql(parameters);
		} else {
			return sqlStatement.getSql();
		}
	}

	protected String getSql(HqmlSqlStatement sqlStatement, Object parameters, Map<String, Object> paramMap) {
		if (sqlStatement.isDynamicSql()) {
			if(paramMap == null) {
				return sqlStatement.parseDynamicSql(parameters);
			} else {
				if(parameters != null) {
					Map<String, ?> map = DtoCopyUtils.toMap(parameters, false);
					paramMap.putAll(map);
					return sqlStatement.parseDynamicSql(paramMap);
				} else {
					return sqlStatement.parseDynamicSql(paramMap);
				}
			}
		} else {
			return sqlStatement.getSql();
		}
	}

	protected String getSql(HqmlSqlStatement sqlStatement, Object parameters) {
		return getSql(sqlStatement, parameters, null);
	}


	protected void initTemplate(DataSource dataSource) {
		jdbcTemplate = new HoneNamedParameterJdbcTemplate(dataSource);
	}

	public <T> void query(String statementId,
			Object paramObject,
			Class<T> resultClass, RowDataHandler<T> rowDataHandler) {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);

		String sql = getSql(statement, paramObject);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject);
		HoneBaseRowMapper<T> rowMapper = new HoneBaseRowMapper<T>(resultClass);

		getDaoTemplate().query(sql, paramSource, rowMapper, rowDataHandler);
	}

	public <T> void query(String statementId,
			Object paramObject,
			RecordRowDataHandler rowDataHandler) {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject);

		//TODO
//		getDaoTemplate().query(sql, paramSource, rowDataHandler, statement);

	}

	/**
	 * 단건 레코드 조회
	 * @param statementId
	 * @param paramObject
	 * @param resultSetExtractor
	 * @return
	 * @throws DataAccessException
	 */
	public <T> T query(String statementId,
			Object paramObject,
			ResultSetExtractor<T> resultSetExtractor)
			throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject);

		return getDaoTemplate().query(sql, paramSource, resultSetExtractor);
	}

	/**
	 * 단건 레코드 조회
	 * @param statementId
	 * @param paramMap
	 * @param resultSetExtractor
	 * @return
	 * @throws DataAccessException
	 */
	public <T> T query(String statementId, Map<String, ?> paramMap,
			ResultSetExtractor<T> resultSetExtractor)
			throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramMap);

		MapSqlParameterSource paramSource = new MapSqlParameterSource(paramMap);

		return getDaoTemplate().query(sql, paramSource, resultSetExtractor);
	}

	/**
	 * 단건 레코드 조회
	 * @param statementId
	 * @param resultSetExtractor
	 * @return
	 * @throws DataAccessException
	 */
	public <T> T query(String statementId,
			ResultSetExtractor<T> resultSetExtractor)
			throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, null);

		return getDaoTemplate().query(sql, resultSetExtractor);
	}

	/**
	 * 데이터 조회. 조회 결과는 RowCallbackHandler를 통해 처리
	 * @param statementId
	 * @param paramObject
	 * @param rowCallbackHandler
	 * @throws DataAccessException
	 */
	public void query(String statementId,
			Object paramObject,
			RowCallbackHandler rowCallbackHandler)
			throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject);

		getDaoTemplate().query(sql, paramSource, rowCallbackHandler);
	}

//	/**
//	 * 데이터 조회. 조회 결과는 RowCallbackHandler를 통해 처리
//	 * @param statementId
//	 * @param paramMap
//	 * @param rowCallbackHandler
//	 * @throws DataAccessException
//	 */
//	public void query(String statementId, Map<String, ?> paramMap,
//			RowCallbackHandler rowCallbackHandler)
//			throws DataAccessException {
//		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
//		String sql = getSql(statement, paramMap);
//
//		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramMap);
//
//		getDaoTemplate().query(sql, paramSource, rowCallbackHandler);
//	}

	/**
	 * 데이터 조회. 조회 결과는 RowCallbackHandler를 통해 처리
	 * @param statementId
	 * @param rowCallbackHandler
	 * @throws DataAccessException
	 */
	public void query(String statementId,
			RowCallbackHandler rowCallbackHandler)
			throws DataAccessException {

		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, null);

		getDaoTemplate().query(sql, rowCallbackHandler);
	}

	/**
	 * 다건 레코드 조회
	 * @param statementId
	 * @param paramObject
	 * @param resultClass
	 * @return
	 * @throws DataAccessException
	 */
	public <T> List<T> query(String statementId,
			Object paramObject,
			Class<T> resultClass) throws DataAccessException {

		return query(statementId, paramObject, null, resultClass);
	}

	/**
	 * 다건 레코드 조회
	 * @param statementId
	 * @param paramObject
	 * @param paramMap
	 * @param resultClass
	 * @return
	 * @throws DataAccessException
	 */
	public <T> List<T> query(String statementId,
			Object paramObject,
			Map<String, Object> paramMap,
			Class<T> resultClass) throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject, paramMap);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject, paramMap);
		HoneBaseRowMapper<T> rowMapper = new HoneBaseRowMapper<T>(resultClass);

		return getDaoTemplate().query(sql, paramSource, rowMapper);
	}


	/**
	 * 단건 레코드 조회
	 *
	 * @param statementId
	 * @param paramObject
	 * @param resultClass
	 * @return
	 * @throws DataAccessException
	 */
	public <T> T queryForObject(String statementId,
			Object paramObject,
			Class<T> resultClass) throws DataAccessException {
		return queryForObject(statementId, paramObject, null, resultClass);
	}

	/**
	 * 단건 레코드 조회
	 * @param statementId
	 * @param paramObject
	 * @param paramMap
	 * @param resultClass
	 * @return
	 * @throws DataAccessException
	 */
	public <T> T queryForObject(String statementId, Object paramObject, Map<String, Object> paramMap,
			Class<T> resultClass) throws DataAccessException {

		HqmlSqlStatement statement = statementProvider.geStatement(statementId);

		String sql = getSql(statement, paramObject, paramMap);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject, paramMap);
		HoneBaseRowMapper<T> rowMapper = new HoneBaseRowMapper<T>(resultClass);

		return getDaoTemplate().queryForObject(sql, paramSource, rowMapper);
	}

	/**
	 * Integer Type의 필드 1건 조회
	 *
	 * @param statementId
	 * @param paramObject
	 * @return
	 * @throws DataAccessException
	 */
	public Integer queryForInt(String statementId, Object paramObject) throws DataAccessException {
		return queryForInt(statementId, paramObject, null);
	}

	/**
	 * Integer Type의 필드 1건 조회
	 * @param statementId
	 * @param paramObject
	 * @param paramMap
	 * @return
	 * @throws DataAccessException
	 */
	public Integer queryForInt(String statementId, Object paramObject, Map<String, Object> paramMap) throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject, paramMap);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject, paramMap);

		return getDaoTemplate().queryForObject(sql, paramSource, Integer.class);
	}

	/**
	 * Long Type의 필드 1건 조회
	 * @param statementId
	 * @param paramObject
	 * @return
	 * @throws DataAccessException
	 */
	public Long queryForLong(String statementId, Object paramObject) throws DataAccessException {
		return queryForLong(statementId, paramObject, null);
	}

	/**
	 * Long Type의 필드 1건 조회
	 * @param statementId
	 * @param paramObject
	 * @param paramMap
	 * @return
	 * @throws DataAccessException
	 */
	public Long queryForLong(String statementId, Object paramObject, Map<String, Object> paramMap) throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject, paramMap);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject, paramMap);

		return getDaoTemplate().queryForObject(sql, paramSource, Long.class);
	}

	/**
	 * String Type의 필드 1건 조회
	 * @param statementId
	 * @param paramObject
	 * @return
	 * @throws DataAccessException
	 */
	public String queryForString(String statementId, Object paramObject) throws DataAccessException {

		return queryForString(statementId, paramObject, null);
	}

	/**
	 * String Type의 필드 1건 조회
	 * @param statementId
	 * @param paramObject
	 * @param paramMap
	 * @return
	 * @throws DataAccessException
	 */
	public String queryForString(String statementId, Object paramObject, Map<String, Object> paramMap) throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject, paramMap);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject, paramMap);

		return getDaoTemplate().queryForObject(sql, paramSource, String.class);
	}

	/**
	 * Double Type의 필드 1건 조회
	 * @param statementId
	 * @param paramObject
	 * @return
	 * @throws DataAccessException
	 */
	public Double queryForDouble(String statementId, Object paramObject) throws DataAccessException {

		return queryForDouble(statementId, paramObject, null);
	}

	/**
	 * Double Type의 필드 1건 조회
	 * @param statementId
	 * @param paramObject
	 * @param paramMap
	 * @return
	 * @throws DataAccessException
	 */
	public Double queryForDouble(String statementId, Object paramObject, Map<String, Object> paramMap) throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject, paramMap);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject, paramMap);

		return getDaoTemplate().queryForObject(sql, paramSource, Double.class);
	}

	/**
	 * BigDecimal Type의 필드 1건 조회
	 * @param statementId
	 * @param paramObject
	 * @return
	 * @throws DataAccessException
	 */
	public BigDecimal queryForBigDecimal(String statementId, Object paramObject) throws DataAccessException {

		return queryForBigDecimal(statementId, paramObject, null);
	}

	/**
	 * BigDecimal Type의 필드 1건 조회
	 * @param statementId
	 * @param paramObject
	 * @param paramMap
	 * @return
	 * @throws DataAccessException
	 */
	public BigDecimal queryForBigDecimal(String statementId, Object paramObject, Map<String, Object> paramMap) throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject, paramMap);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject, paramMap);

		return getDaoTemplate().queryForObject(sql, paramSource, BigDecimal.class);
	}

	public Date queryForDate(String statementId, Object paramObject) throws DataAccessException {
		return queryForDate(statementId, paramObject, null);
	}

	public Date queryForDate(String statementId, Object paramObject, Map<String, Object> paramMap) throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject, paramMap);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject, paramMap);

		return getDaoTemplate().queryForObject(sql, paramSource, Date.class);
	}

	/**
	 * 다건 단일 컬럼 조회
	 * @param statementId
	 * @param paramObject
	 * @param resultClass
	 * @return
	 * @throws DataAccessException
	 */
	public <T> List<T> queryForList(String statementId,
			Object paramObject, Class<T> resultClass)
			throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject);

		return getDaoTemplate().queryForList(sql, paramSource, resultClass);
	}

	/**
	 * 다건 단일 컬럼 조회
	 * @param statementId
	 * @param paramMap
	 * @param resultClass
	 * @return
	 * @throws DataAccessException
	 */
	public <T> List<T> queryForList(String statementId,
			Map<String, ?> paramMap, Class<T> resultClass)
			throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramMap);

		MapSqlParameterSource paramSource = new MapSqlParameterSource(paramMap);

		return getDaoTemplate().queryForList(sql, paramSource, resultClass);
	}

	/**
	 * 다건 단일 컬럼 조회
	 * @param statementId
	 * @param paramObject
	 * @return
	 * @throws DataAccessException
	 */
	public List<Map<String, Object>> queryForList(String statementId,
			Object paramObject)
			throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject);

		return getDaoTemplate().queryForList(sql, paramSource);
	}

	/**
	 * 다건 단일 컬럼 조회
	 * @param statementId
	 * @param paramMap
	 * @return
	 * @throws DataAccessException
	 */
	public List<Map<String, Object>> queryForList(String statementId,
			Map<String, ?> paramMap) throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramMap);

		MapSqlParameterSource paramSource = new MapSqlParameterSource(paramMap);

		return getDaoTemplate().queryForList(sql, paramSource);
	}

	/**
	 * 다건 단일 컬럼 조회
	 * @param statementId
	 * @param paramMap
	 * @return
	 * @throws DataAccessException
	 */
	public List<Map<String, Object>> queryForPagingList(String statementId,
			Map<String, ?> paramMap, PagingSupport paging) throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramMap);
		
		if(paging == null) {
			throw new BomException("Paging Object is not set.");
		}
		
		mergePagingParams(paramMap, paging);
		MapSqlParameterSource paramSource = new MapSqlParameterSource(paramMap);
		List<Map<String, Object>> list = getDaoTemplate().queryForList(makePagingSql(sql), paramSource);
		if(list.size() > 0) {
			int totCount = 0;
			if(Number.class.isAssignableFrom(list.get(0).get("TOTCNT").getClass())) {
				totCount = ((Number) list.get(0).get("TOTCNT")).intValue();
			}
			paging.setTotCount(totCount);
			if(paging.getPageSize() > 0) {
				paging.setTotPage(totCount/paging.getPageSize());
			}
		} else {
			paging.setTotCount(0);
			paging.setTotPage(0);
		}
		
		ContextUtil.setPaging(paging);
		return list;
	}
	
	private void mergePagingParams(Map paramMap, PagingSupport paging) {
		int offset = 0;
		int limit = 0;
		
		limit = paging.getPageNo() * paging.getPageSize();
		offset = limit - paging.getPageSize();
		
		if(offset < 0) {
			offset = 0;
		}
		if(offset > limit) {
			offset = limit;
		}
		paramMap.put("PAGING_OFFSET", new Integer(offset));
		paramMap.put("PAGING_LIMIT", new Integer(limit));
	}
	
	
	private String makePagingSql(String sql) {
		return new StringBuilder().append(PAGING_SQL_PREFIX).append(sql).append(PAGING_SQL_POSTFIX).toString();
	}

	public void setFetchSize(int fetchSize) {
		getDaoTemplate().setFetchSize(fetchSize);

	}

	public void setMaxRows(int maxRows) {
		getDaoTemplate().setMaxRows(maxRows);

	}

	public void setQueryTimeout(int queryTimeout) {
		getDaoTemplate().setQueryTimeout(queryTimeout);
	}

	public <T> T execute(String statementId,
			Object paramObject,
			PreparedStatementCallback<T> preparedStatementCallback)
			throws DataAccessException {

		String sql = getSql(statementId, paramObject);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject);
		return getDaoTemplate().execute(sql, paramSource, preparedStatementCallback);
	}

	public <T> T execute(String statementId,
			PreparedStatementCallback<T> preparedStatementCallback)
			throws DataAccessException {
		HqmlStatement statement = statementProvider.geStatement(statementId);
		String sql = statement.getSql();
		return getDaoTemplate().execute(sql, preparedStatementCallback);
	}

	/**
	 * 데이터 수정
	 * @param statementId
	 * @param paramObject
	 * @return
	 * @throws DataAccessException
	 */
	public int update(String statementId
			, Object paramObject)
			throws DataAccessException {
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject);
		return getDaoTemplate().update(sql, paramSource);
	}

	/**
	 * 데이터 수정
	 * @param statementId
	 * @param paramObject
	 * @return
	 * @throws DataAccessException
	 */
	public int update(String statementId
			, Map<String, Object> paramMap)
			throws DataAccessException {
		MapUtil.fillSysColumns(paramMap);
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramMap);

		MapSqlParameterSource paramSource = new MapSqlParameterSource(paramMap);
		return getDaoTemplate().update(sql, paramSource);
	}

	/**
	 * 데이터 수정
	 * @param statementId
	 * @param paramMap
	 * @return
	 * @throws DataAccessException
	 */
	public int update(String statementId
			, Object paramObject
			, Map<String, Object> paramMap)
			throws DataAccessException {
		MapUtil.fillSysColumns(paramMap);
		HqmlSqlStatement statement = statementProvider.geStatement(statementId);
		String sql = getSql(statement, paramObject, paramMap);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject, paramMap);
		return getDaoTemplate().update(sql, paramSource);
	}

	/**
	 * 데이터 수정
	 * @param statementId
	 * @param paramObject
	 * @param paramKeyHolder
	 * @return
	 * @throws DataAccessException
	 */
	public int update(String statementId,
			Object paramObject, KeyHolder paramKeyHolder)
			throws DataAccessException {
		HqmlSqlStatement sqlStatement = statementProvider.geStatement(statementId);

		String sql = getSql(sqlStatement, paramObject);

		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject);
		return getDaoTemplate().update(sql, paramSource, paramKeyHolder);
	}

	/**
	 * 데이터 수정
	 * @param statementId
	 * @param paramObject
	 * @param paramKeyHolder
	 * @param paramArrayOfString
	 * @return
	 * @throws DataAccessException
	 */
	public int update(String statementId,
			Object paramObject,
			KeyHolder paramKeyHolder, String[] paramArrayOfString)
			throws DataAccessException {
		HqmlSqlStatement sqlStatement = statementProvider.geStatement(statementId);
		String sql = getSql(sqlStatement, paramObject);
		HoneBaseSqlParameterSource paramSource = new HoneBaseSqlParameterSource(paramObject);
		return getDaoTemplate().update(sql, paramSource, paramKeyHolder, paramArrayOfString);
	}

	/**
	 * 다건 데이터 일괄 수정
	 * @param statementId
	 * @param paramArrayOfMap
	 * @return
	 */
	public int[] batchUpdate(String statementId,
			Map<String, ?>[] paramArrayOfMap) {
		HqmlStatement statement = statementProvider.geStatement(statementId);
		String sql = statement.getSql();
		return getDaoTemplate().batchUpdate(sql, paramArrayOfMap);
	}

	/**
	 * 다건 데이터 일괄 수정
	 * @param statementId
	 * @param paramObjectList
	 * @return
	 */
	public int[] batchUpdate(String statementId,
			List<Object> paramObjectList) {
		HqmlStatement statement = statementProvider.geStatement(statementId);
		String sql = statement.getSql();
		SqlParameterSource[] paramSourceArray = new SqlParameterSource[paramObjectList.size()];
		int i = 0;
		for (Object paramObject : paramObjectList){
			paramSourceArray[i] = new HoneBaseSqlParameterSource(paramObject);
		}
		return getDaoTemplate().batchUpdate(sql, paramSourceArray);
	}

	protected Map toMap(Record record) {
		Map map = new HashMap();
		for(String key : record.keySet()) {
			map.put(key, record.get(key));
		}
		
		return map;
	}
	
	protected List<Map> toList(RecordSet recordSet) {
		List<Map> list = new ArrayList<Map>();
		String[] keys = new String[recordSet.getColumnCount()];
		int keyIndex = 0;
		for(String key : recordSet.getColumns()) {
			keys[keyIndex++] = key;
		}
		
		for(Record record : recordSet) {
			Map map = new HashMap();
			for(String key : keys) {
				map.put(key, record.get(key));
			}
			list.add(map);
		}
		
		return list;
	}
}
