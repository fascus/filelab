package htc.commons.auth.dao;

import java.util.Map;

import htc.commons.auth.dto.UserDto;

public interface UserDetailDao {
	Map getUser(String loginId);
}
