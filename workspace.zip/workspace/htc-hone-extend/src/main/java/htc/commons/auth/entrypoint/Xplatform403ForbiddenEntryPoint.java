package htc.commons.auth.entrypoint;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

import com.tobesoft.xplatform.data.PlatformData;
import com.tobesoft.xplatform.tx.PlatformException;

import htc.xplatform.utils.XPlatformUtil;

public class Xplatform403ForbiddenEntryPoint implements AuthenticationEntryPoint {
	private static final Logger logger = LoggerFactory.getLogger(Xplatform403ForbiddenEntryPoint.class);
	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException, ServletException {
		PlatformData platformData = XPlatformUtil.initailizePlatformData();
		XPlatformUtil.setVariable(platformData, "ErrorCode", -403);
		XPlatformUtil.setVariable(platformData, "ErrorMsg", "권한이 없습니다. 로그인 후 이용하시기 바랍니다.!");
		try {
			XPlatformUtil.sendPlatformData(response, platformData);
		} catch (PlatformException e) {
			logger.error("PlatformData send failed", e);
			throw new RuntimeException("PlatformData send failed", e);
		}

	}

}
