package htc.commons.file.dao;

import java.util.List;

import htc.commons.file.dto.FileDto;
import htc.commons.file.dto.FileTypeDto;

public interface FileHandlerDao {
	String genFileno();
	int insertFile(FileDto dto);
	FileDto getFile(String fileno, int fileSeq);
	List<FileDto> listFile(FileDto dto);
	FileTypeDto getFileType(String fileKindCd);
	int genFileSeq(String fileno);
}
