package htc.commons.auth.service;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import htc.commons.auth.dao.UserDetailDao;
import htc.commons.auth.dto.UserDto;

@Component("userDetailsService")
public class UserDetailServiceImpl implements UserDetailsService {
	@Autowired
	UserDetailDao dao;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Map map = dao.getUser(username);
		if(map == null) {
			throw new UsernameNotFoundException("사용자가 존재하지 않거나 비밀번호가 일치하지 않습니다.");
		}
		
		if("N".equals(map.get("USE_YN"))) {
            throw new UsernameNotFoundException("사용자가 존재하지 않거나 비밀번호가 일치하지 않습니다.");
        }
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(new SimpleGrantedAuthority("USER"));
		boolean isValidUser = "Y".equals(map.get("USE_YN"));
		UserDto dto = new UserDto(username, (String) map.get("LOGIN_PW"), isValidUser, isValidUser,
				isValidUser, isValidUser, authorities);
		
		dto.setUserId((String)map.get("USER_ID"));
		dto.setOrgzno((String)map.get("ORGZNO"));
		dto.setUserNm((String)map.get("USER_NM"));
		dto.setUserIp((String)map.get("USER_IP"));
		dto.setUseStartdt((Timestamp)map.get("USE_STARTDT"));
		dto.setUseEnddt((Timestamp)map.get("USE_ENDDT"));
		dto.setUc((String)map.get("UC"));
		dto.setUnitNm((String)map.get("UNIT_NM"));
		dto.setSrvno((String)map.get("SRVNO"));
		dto.setEmpno((String)map.get("EMPNO"));
		dto.setClspstCd((String)map.get("CLSPST_CD"));
		dto.setClspstNm((String)map.get("CLSPST_NM"));
		dto.setEmail((String)map.get("EMAIL"));
		dto.setTelno((String)map.get("TELNO"));
		dto.setHpNo((String)map.get("HP_NO"));
		dto.setOrgzNm((String)map.get("ORGNZ_NM"));
		dto.setOrgz((String)map.get("ORGZ"));
		dto.setRoleNo((String)map.get("ROLENO"));
		dto.setBkmkMenuNm((String)map.get("BKMK_MENU_NM"));
		dto.setIndvInfoPrtcuseAgrYn((String)map.get("INDV_INFO_PRTCUSE_AGR_YN"));
		
		return dto;
	}
	
	

}
