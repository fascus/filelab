package htc.commons.auth.handler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

import com.tobesoft.xplatform.data.PlatformData;
import com.tobesoft.xplatform.tx.PlatformException;

import htc.xplatform.utils.XPlatformUtil;

public class XplatformAuthFailureHandler implements AuthenticationFailureHandler {
	private static final Logger logger = LoggerFactory.getLogger(AuthenticationFailureHandler.class);

	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {
		PlatformData platformData = XPlatformUtil.initailizePlatformData();
		XPlatformUtil.setVariable(platformData, "ErrorCode", -1);
		XPlatformUtil.setVariable(platformData, "ErrorMsg", "로그인이 실패하였습니다.");
		try {
			XPlatformUtil.sendPlatformData(response, platformData);
		} catch (PlatformException e) {
			logger.error("PlatformData send failed", e);
			throw new RuntimeException("PlatformData send failed", e);
		}
	}

}
