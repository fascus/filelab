package htc.commons.auth.handler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.sql.SQLException;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.tobesoft.xplatform.data.PlatformData;
import com.tobesoft.xplatform.tx.PlatformException;

import htc.commons.auth.dao.UserDetailDao;
import htc.commons.auth.dto.UserDto;
import htc.xplatform.utils.XPlatformUtil;
import htc.hone.dao.AbstractHtcDao;
import org.springframework.stereotype.Repository;
import hone.bom.dao.core.HoneBaseDaoOperations;


public class XplatformAuthSuccessHandler extends AbstractHtcDao implements AuthenticationSuccessHandler {
	private static final Logger logger = LoggerFactory.getLogger(XplatformAuthSuccessHandler.class);
	
    private static final String LOG_INSERT_QUERY = "INSERT INTO TSYLM001(LOGIN_SEQ,USER_ID,LOGIN_DTTM,INPUTPSN_ID,INPUT_DTTM) \n"
            + "VALUES ((SELECT NVL(MAX(LOGIN_SEQ)+1, 1) FROM TSYLM001),:USER_ID,SYSDATE,:USER_ID,SYSDATE) \n";
	
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		PlatformData platformData = XPlatformUtil.initailizePlatformData();
		List<Map> list = new ArrayList<Map>();
		int result = 0;
		
		HttpSession session = request.getSession();
		String sessionId = "";
		if(session != null) {
			sessionId = session.getId();		
		}
		UserDto userDto = (UserDto) authentication.getPrincipal();
		
		Map map = new HashMap();
		map.put("USER_ID", userDto.getUserId());
		map.put("USER_NM", userDto.getUserNm());
		map.put("ORGZNO", userDto.getOrgzno());
		map.put("ORGNZ_NM", userDto.getOrgzNm());
		map.put("ORGNZ", userDto.getOrgz());
		map.put("BKMK_MENU_NM", userDto.getBkmkMenuNm());
		map.put("SESSION_ID", sessionId);
		map.put("ROLENO", userDto.getRoleNo());
		map.put("INDV_INFO_PRTCUSE_AGR_YN", userDto.getIndvInfoPrtcuseAgrYn());
		list.add(map );
		
		MapSqlParameterSource sqlParameterSource = new MapSqlParameterSource(map);
		result = getDaoTemplate().update(LOG_INSERT_QUERY, sqlParameterSource);
       
		
		XPlatformUtil.setDataSet(platformData, "dsUser", list);
		if(logger.isDebugEnabled())
		{		
			logger.debug("tracing response");
			logger.debug(platformData.saveXml());
		}
		try {
			XPlatformUtil.sendPlatformData(response, platformData);
		} catch (PlatformException e) {
			logger.error("PlatformData send failed", e);
			throw new RuntimeException("PlatformData send failed", e);
		}
	}

    /**
     * @see htc.commons.auth.dao.UserDetailDao#getUser(java.lang.String)
     * @Method Name        : getUser
     * @Method description : 
     * @Date               : 2016. 11. 7.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 7.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param loginId
     * @return
    */


}
