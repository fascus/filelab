package htc.commons.auth.handler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

import com.tobesoft.xplatform.data.PlatformData;
import com.tobesoft.xplatform.tx.PlatformException;

import htc.xplatform.utils.XPlatformUtil;

public class XplatformAccessDeniedHandler implements AccessDeniedHandler {
	private String errorPage;
	
	private static final Logger logger = LoggerFactory.getLogger(XplatformAccessDeniedHandler.class);

	public XplatformAccessDeniedHandler(String errorPage) {
		super();
		this.errorPage = errorPage;
	}

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response,
			AccessDeniedException accessDeniedException) throws IOException, ServletException {
		PlatformData platformData = XPlatformUtil.initailizePlatformData();
		XPlatformUtil.setVariable(platformData, "ErrorCode", -403);
		XPlatformUtil.setVariable(platformData, "ErrorMsg", "권한이 없습니다. 로그인 후 이용하시기 바랍니다.");
		try {
			XPlatformUtil.sendPlatformData(response, platformData);
		} catch (PlatformException e) {
			logger.error("PlatformData send failed", e);
			throw new RuntimeException("PlatformData send failed", e);
		}

	}

	/**
	 * @return the errorPage
	 */
	public String getErrorPage() {
		return errorPage;
	}

	/**
	 * @param errorPage the errorPage to set
	 */
	public void setErrorPage(String errorPage) {
		this.errorPage = errorPage;
	}


}
