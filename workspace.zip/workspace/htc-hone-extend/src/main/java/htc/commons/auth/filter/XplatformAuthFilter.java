package htc.commons.auth.filter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.tobesoft.xplatform.data.DataSet;
import com.tobesoft.xplatform.data.PlatformData;
import com.tobesoft.xplatform.tx.HttpPlatformRequest;
import com.tobesoft.xplatform.tx.PlatformException;

import hone.bom.BomException;
import htc.xplatform.utils.XPlatformUtil;

public class XplatformAuthFilter extends UsernamePasswordAuthenticationFilter {
	private String userId;
	private String password;

	/* (non-Javadoc)
	 * @see org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter#obtainPassword(javax.servlet.http.HttpServletRequest)
	 */
	@Override
	protected String obtainPassword(HttpServletRequest request) {
		if(this.password != null) {
			return this.password;
		}
		return super.obtainPassword(request);
	}

	/* (non-Javadoc)
	 * @see org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter#obtainUsername(javax.servlet.http.HttpServletRequest)
	 */
	@Override
	protected String obtainUsername(HttpServletRequest request) {
		if(this.userId != null) {
			return this.userId;
		} 
		return super.obtainUsername(request);
	}

	/* (non-Javadoc)
	 * @see org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter#attemptAuthentication(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
			throws AuthenticationException {
		HttpPlatformRequest httpPlatformRequest = null;

		try {
			
			
			httpPlatformRequest = new HttpPlatformRequest(request);
			httpPlatformRequest.receiveData();
			
		} catch (Exception ex) {
			ex.getStackTrace();
			throw new RuntimeException("HttpPlatformRequest error");
		}
		
		PlatformData platformData = httpPlatformRequest.getData();
		
		DataSet dataSet = platformData.getDataSet("dsUser");
		userId = dataSet.getString(0, "USER_ID");
		password = dataSet.getString(0, "PASSWORD");
		try {
			return super.attemptAuthentication(request, response);
		} catch (Exception e) {
			try {
				XPlatformUtil.throwErrorMessage(-1, e.getMessage(), request, response);
			} catch (PlatformException e1) {
				throw new BomException("XPlatform Data Send failed.", e1);
			}
		}
		return null;
	}
	
	

}
