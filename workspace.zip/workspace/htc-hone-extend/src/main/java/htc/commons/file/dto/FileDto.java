package htc.commons.file.dto;

import java.io.File;
import java.util.Date;

import htc.hone.core.dto.AbstractDto;

public class FileDto extends AbstractDto {
	private static final long serialVersionUID = -8962509981199832416L;
	
	private String fileno;
	private int fileSeq;
	private String fileTypeCd;
	private String fileKindCd;
	private String svflNm;
	private String flnm;
	private String fileExtnsnNm;
	private int flszQnty;
	private String mgtNo;
	private String rfno;

	/**
	 * @return the fileno
	 */
	public String getFileno() {
		return fileno;
	}
	/**
	 * @param fileno the fileno to set
	 */
	public void setFileno(String fileno) {
		this.fileno = fileno;
	}
	/**
	 * @return the fileSeq
	 */
	public int getFileSeq() {
		return fileSeq;
	}
	/**
	 * @param fileSeq the fileSeq to set
	 */
	public void setFileSeq(int fileSeq) {
		this.fileSeq = fileSeq;
	}
	/**
	 * @return the fileTypeCd
	 */
	public String getFileTypeCd() {
		return fileTypeCd;
	}
	/**
	 * @param fileTypeCd the fileTypeCd to set
	 */
	public void setFileTypeCd(String fileTypeCd) {
		this.fileTypeCd = fileTypeCd;
	}
	/**
	 * @return the fileKindCd
	 */
	public String getFileKindCd() {
		return fileKindCd;
	}
	/**
	 * @param fileKindCd the fileKindCd to set
	 */
	public void setFileKindCd(String fileKindCd) {
		this.fileKindCd = fileKindCd;
	}
	/**
	 * @return the svflNm
	 */
	public String getSvflNm() {
		return svflNm;
	}
	/**
	 * @param svflNm the svflNm to set
	 */
	public void setSvflNm(String svflNm) {
		this.svflNm = svflNm;
	}
	/**
	 * @return the flnm
	 */
	public String getFlnm() {
		return flnm;
	}
	/**
	 * @param flnm the flnm to set
	 */
	public void setFlnm(String flnm) {
		this.flnm = flnm;
	}
	/**
	 * @return the fileExtnsnNm
	 */
	public String getFileExtnsnNm() {
		return fileExtnsnNm;
	}
	/**
	 * @param fileExtnsnNm the fileExtnsnNm to set
	 */
	public void setFileExtnsnNm(String fileExtnsnNm) {
		this.fileExtnsnNm = fileExtnsnNm;
	}
	/**
	 * @return the flszQnty
	 */
	public int getFlszQnty() {
		return flszQnty;
	}
	/**
	 * @param flszQnty the flszQnty to set
	 */
	public void setFlszQnty(int flszQnty) {
		this.flszQnty = flszQnty;
	}
	/**
	 * @return the mgtNo
	 */
	public String getMgtNo() {
		return mgtNo;
	}
	/**
	 * @param mgtNo the mgtNo to set
	 */
	public void setMgtNo(String mgtNo) {
		this.mgtNo = mgtNo;
	}
	/**
	 * @return the rfno
	 */
	public String getRfno() {
		return rfno;
	}
	/**
	 * @param rfno the rfno to set
	 */
	public void setRfno(String rfno) {
		this.rfno = rfno;
	}
	
	
}
