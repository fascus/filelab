package htc.commons.file.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import htc.commons.file.dao.FileHandlerDao;
import htc.commons.file.dto.FileDto;
import htc.commons.file.dto.FileTypeDto;

@Service
public class FileHandlerServiceImpl implements FileHandlerService {

	@Autowired
	FileHandlerDao fileHanderDao;
	
	@Override
	public String genFileno() {
		return fileHanderDao.genFileno();
	}
	
	@Override
	public FileDto getFile(String fileno, int fileSeq) {
		return fileHanderDao.getFile(fileno, fileSeq);
	}

	@Override
	public List<FileDto> listFiles(FileDto dto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FileDto saveFile(FileDto dtos) {
		fileHanderDao.insertFile(dtos);
		return fileHanderDao.getFile(dtos.getFileno(), dtos.getFileSeq());
	}

	@Override
	public void deleteFile(FileDto dtos) {
		// TODO Auto-generated method stub
	}

	@Override
	public FileTypeDto getFileType(String fileKindCd) {
		return fileHanderDao.getFileType(fileKindCd);
	}
	
	@Override
	public int genFileSeq(String fileno) {
		return fileHanderDao.genFileSeq(fileno);
	}

}
