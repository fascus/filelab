package htc.commons.auth.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import htc.xplatform.message.HtcXplatformMessage;
import htc.xplatform.utils.MessageUtil;

@Controller
public class LoginController {

	@RequestMapping("/loginSucc")
	public HtcXplatformMessage loginSucc() {
        HtcXplatformMessage message = new HtcXplatformMessage();
        Map userInfo = new HashMap();
        userInfo.put("userId", "TEST1");
        userInfo.put("userName", "한번해본사람");
        userInfo.put("orgCd", "13579");
        List<Map> userMap = new ArrayList<Map>();
		userMap.add(userInfo);
        Map<String, List<Map>> datasets = new HashMap<String, List<Map>>();
		datasets.put("user", userMap );
		message.setDatasets(datasets );
		return message;
	}

	@RequestMapping("/loginFail")
	public HtcXplatformMessage loginFail() {
        HtcXplatformMessage message = new HtcXplatformMessage();
        MessageUtil.setMessage("FFFF", "111");
		return message;
	}
}
