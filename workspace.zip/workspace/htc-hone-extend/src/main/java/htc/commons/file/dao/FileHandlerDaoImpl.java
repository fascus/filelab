package htc.commons.file.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.RowMapperResultSetExtractor;
import org.springframework.jdbc.core.namedparam.EmptySqlParameterSource;
import org.springframework.stereotype.Repository;

import hone.bom.dao.HoneBaseRowMapper;
import hone.bom.dao.HoneBaseSqlParameterSource;
import hone.bom.dao.core.HoneBaseDaoOperations;
import hone.bom.dao.record.BaseResultSetExtractor;
import htc.commons.file.dto.FileDto;
import htc.commons.file.dto.FileTypeDto;
import htc.hone.dao.AbstractHtcDao;

@Repository
public class FileHandlerDaoImpl extends AbstractHtcDao implements FileHandlerDao {
//	private static final String FILE_INSERT_QUERY = "INSERT INTO FILES "
//					+ "(FILE_ID , ORG_FILE_NAME, STORED_FILE_NAME, FILE_SIZE, FILE_EXT, USE_YN, REG_ID, REG_DTM) "
//					+ "VALUES(:fileId, :orgFileName, :storedFileName, :fileSize, :fileExt, :useYn, :regId, :regDtm) ";	
					
	private static final String FILE_INSERT_QUERY = "INSERT INTO TSYSC009 \n"
			 		+ "( FILENO, FILE_SEQ, FILE_TYPE_CD, FILE_KIND_CD, SVFL_NM \n"
			 		+ "  , FLNM, FILE_EXTNSN_NM, FLSZ_QNTY, MGT_NO, RFNO \n"
			 		+ "  , INPUTPSN_ID, INPUT_DTTM, MDFR_ID, MDFC_DTTM, USE_YN) \n"
			 		+ "VALUES(:fileno, :fileSeq, :fileTypeCd, :fileKindCd, :svflNm \n"
			 		+ "        , :flnm, :fileExtnsnNm, :flszQnty, :mgtNo, :rfno \n"
			 		+ "        , :inputpsnId, :inputDttm, :mdfrId, :mdfcDttm, :useYn) ";
	
	private static final String FILE_GET_QUERY = "SELECT FILENO, FILE_SEQ, FILE_TYPE_CD, FILE_KIND_CD, SVFL_NM, FLNM, FILE_EXTNSN_NM, FLSZ_QNTY, MGT_NO, RFNO , INPUTPSN_ID, INPUT_DTTM, MDFR_ID, MDFC_DTTM, USE_YN FROM TSYSC009 WHERE FILENO = :fileno AND FILE_SEQ = :fileSeq";
	
	private static final String FILE_TYPE_GET_QUERY = "SELECT FILE_TYPE_CD, FILE_TYPE_NM, FILE_ROUTE_NM, FILE_MAX_SIZE_QNTY, FILE_MAX_NUM, INPUTPSN_ID, INPUT_DTTM, MDFR_ID, MDFC_DTTM, USE_YN " 
					+ "FROM TSYSC008 WHERE FILE_TYPE_CD = :fileTypeCd";
	
	private static final String FILE_SEQ_GET_QUERY = "SELECT NVL(MAX(FILE_SEQ)+1, 1) FROM TSYSC009 WHERE FILENO = :fileno";
	@Override
	public String genFileno() {
		return getDaoTemplate().queryForObject("SELECT NVL(MAX(TO_NUMBER(FILENO)) + 1, 1) FROM TSYSC009", new HashMap(), String.class);
	}

	@Override
	public int insertFile(FileDto dto) {
		HoneBaseSqlParameterSource sqlParameterSource = new HoneBaseSqlParameterSource(dto);
		return getDaoTemplate().update(FILE_INSERT_QUERY, sqlParameterSource);
	}

	@Override
	public FileDto getFile(String fileno, int fileSeq) {
		FileDto dto = new FileDto();
		dto.setFileno(fileno);
		dto.setFileSeq(fileSeq);
		HoneBaseSqlParameterSource sqlParameterSource = new HoneBaseSqlParameterSource(dto);
		RowMapper<FileDto> rowMapper = new HoneBaseRowMapper<FileDto>(FileDto.class);
		List<FileDto> result = getDaoTemplate().query(FILE_GET_QUERY, sqlParameterSource, rowMapper);
		if(result == null || result.size() == 0) {
			return null;
		}
		return result.get(0);
	}

	@Override
	public List<FileDto> listFile(FileDto dto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FileTypeDto getFileType(String fileTypeCd) {
		FileTypeDto dto = new FileTypeDto();
		dto.setFileTypeCd(fileTypeCd);
		
		HoneBaseSqlParameterSource sqlParameterSource = new HoneBaseSqlParameterSource(dto);
		RowMapper<FileTypeDto> rowMapper = new HoneBaseRowMapper<FileTypeDto>(FileTypeDto.class);
		List<FileTypeDto> result = getDaoTemplate().query(FILE_TYPE_GET_QUERY, sqlParameterSource, rowMapper);
		if(result == null || result.size() == 0) {
			return null;
		}
		return result.get(0);
	}

	@Override
	public int genFileSeq(String fileno) {
		FileDto dto = new FileDto();
		dto.setFileno(fileno);
		return getDaoTemplate().queryForObject(FILE_SEQ_GET_QUERY, new HoneBaseSqlParameterSource(dto), Integer.class);
	}


}
