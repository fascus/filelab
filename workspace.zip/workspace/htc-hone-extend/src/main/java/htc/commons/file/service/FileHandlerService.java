package htc.commons.file.service;

import java.util.List;

import htc.commons.file.dto.FileDto;
import htc.commons.file.dto.FileTypeDto;

public interface FileHandlerService {
	String genFileno();
	FileDto getFile(String fileno, int fileSeq);
	List<FileDto> listFiles(FileDto dto);
	FileDto saveFile(FileDto dtos);
	void deleteFile(FileDto dtos);
	
	FileTypeDto getFileType(String fileTypeCd);
	int genFileSeq(String fileno);
}
