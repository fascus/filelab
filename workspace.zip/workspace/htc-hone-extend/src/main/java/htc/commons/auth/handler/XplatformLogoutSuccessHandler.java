package htc.commons.auth.handler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;

import com.tobesoft.xplatform.data.PlatformData;
import com.tobesoft.xplatform.tx.PlatformException;

import htc.xplatform.utils.XPlatformUtil;

public class XplatformLogoutSuccessHandler implements LogoutSuccessHandler {
	private static final Logger logger = LoggerFactory.getLogger(XplatformLogoutSuccessHandler.class);
	public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
			throws IOException, ServletException {
		PlatformData platformData = XPlatformUtil.initailizePlatformData();
		XPlatformUtil.setVariable(platformData, "ErrorCode", 200);
		XPlatformUtil.setVariable(platformData, "ErrorMsg", "Logout Success");
		try {
			XPlatformUtil.sendPlatformData(response, platformData);
		} catch (PlatformException e) {
			logger.error("PlatformData send failed", e);
			throw new RuntimeException("PlatformData send failed", e);
		}

	}

}
