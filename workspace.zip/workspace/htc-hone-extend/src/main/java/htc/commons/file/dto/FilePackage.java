package htc.commons.file.dto;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import htc.hone.core.dto.AbstractDto;

public class FilePackage extends AbstractDto {
	private static final long serialVersionUID = 2112293775520573905L;
	
	private List<MultipartFile> files;

	public List<MultipartFile> getFiles() {
		return files;
	}

	public void setFiles(List<MultipartFile> files) {
		this.files = files;
	}

	
}
