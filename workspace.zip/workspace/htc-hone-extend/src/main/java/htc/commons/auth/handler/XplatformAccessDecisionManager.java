package htc.commons.auth.handler;

import java.util.Arrays;
import java.util.Collection;

import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.FilterInvocation;

public class XplatformAccessDecisionManager implements AccessDecisionManager {
	private static final Logger logger = LoggerFactory.getLogger(XplatformAccessDecisionManager.class);
	
	private String[] permitUris;
	
	/**
	 * @return the permitUris
	 */
	public String[] getPermitUris() {
		return permitUris;
	}

	/**
	 * @param permitUris the permitUris to set
	 */
	public void setPermitUris(String[] permitUris) {
		this.permitUris = permitUris;
	}

	@Override
	public void decide(Authentication authentication, Object object, Collection<ConfigAttribute> configAttributes)
			throws AccessDeniedException, InsufficientAuthenticationException {
		if(object instanceof FilterInvocation) {
			String uri = ((FilterInvocation) object).getRequestUrl();
			
			if(ArrayUtils.contains(permitUris, uri)) {
				return;
			}
		}
		
		if(!authentication.isAuthenticated()) {
			throw new AccessDeniedException("인증되지 않은 사용자입니다.");
		}
		
		if(authentication.getAuthorities() == null || authentication.getAuthorities().isEmpty()) {
			throwNoRole();
		}
		
		boolean deny = true;
		for(GrantedAuthority authority : authentication.getAuthorities()) {
			if(authority.getAuthority().equals("USER")) {
				deny = false;
				break;
			}
		}
		
		if(deny) {
			throwNoRole();
		}
		
	}

	private void throwNoRole() {
		logger.error("권한이 없는 사용자입니다. USER권한이 필요합니다.");
		throw new AccessDeniedException("권한이 없는 사용자입니다.");
	}

	@Override
	public boolean supports(ConfigAttribute attribute) {
		return true;
	}

	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}

}
