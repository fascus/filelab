package htc.commons.paging;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import htc.hone.core.dto.AbstractDto;
import htc.xplatform.utils.XPlatformUtil;

/**
 * 페이지 정보를 담기 위한 객체
 * @author swa
 *
 */
public class PagingSupport implements Serializable {
	private static final long serialVersionUID = -632137592359190329L;
	public static final String DATASET_PAGE_SIZE_KEY = "PAGE_SIZE";
	public static final String DATASET_PAGE_NO_KEY = "PAGE_NO";
	public static final String DATASET_TOT_COUNT_KEY = "TOT_COUNT";
	public static final String DATASET_TOT_PAGE_KEY = "TOT_PAGE";
	
	
	private int pageSize;
	private int pageNo;
	private int totPage;
	private int totCount;
	/**
	 * @return the pageSize
	 */
	public int getPageSize() {
		return pageSize;
	}
	/**
	 * @param pageSize the pageSize to set
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	/**
	 * @return the pageNo
	 */
	public int getPageNo() {
		return pageNo;
	}
	/**
	 * @param pageNo the pageNo to set
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	/**
	 * @return the totPage
	 */
	public int getTotPage() {
		return totPage;
	}
	/**
	 * @param totPage the totPage to set
	 */
	public void setTotPage(int totPage) {
		this.totPage = totPage;
	}
	/**
	 * @return the totCount
	 */
	public int getTotCount() {
		return totCount;
	}
	/**
	 * @param totCount the totCount to set
	 */
	public void setTotCount(int totCount) {
		this.totCount = totCount;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PagingSupport [pageSize=" + pageSize + ", pageNo=" + pageNo + ", totPage=" + totPage + ", totCount="
				+ totCount + "]";
	}
	
	
	public List<Map> toDataList() {
		List<Map> list = new ArrayList<Map>();
		Map map = new HashMap();
		map.put(DATASET_PAGE_NO_KEY, pageNo);
		map.put(DATASET_PAGE_SIZE_KEY, pageSize);
		map.put(DATASET_TOT_COUNT_KEY, totCount);
		map.put(DATASET_TOT_PAGE_KEY, totPage);
		list.add(map);
		return list;
		
	}
	
}
