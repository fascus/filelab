package htc.commons.auth.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import htc.hone.dao.AbstractHtcDao;
import htc.hone.utils.MapUtil;

@Repository
public class UserDetailDaoImpl extends AbstractHtcDao implements UserDetailDao {
//	private static final String GET_USER_SQL = "select T1.USER_ID, T1.ORGZNO, T1.LOGIN_PW, T1.USER_NM ,T1.USER_IP  \n"
//			+ ", T1.USE_STARTDT, T1.USE_ENDDT, T1.UC, T1.UNIT_NM, T1.SRVNO \n" 
//			+ ", T1.EMPNO,T1.CLSPST_CD, T1.CLSPST_NM, T1.LOGIN_ID, T1.EMAIL \n"
//			+ ", T1.TELNO, T1.HP_NO , T1.USE_YN , T2.ORGNZ_NM, substr(T1.ORGZNO,0,3) as  ORGZ ,T3.BKMK_MENU_NM \n"
//			+ "from LTSOWN.TSYUM002 T1, LTSOWN.TSYUM001 T2 ,LTSOWN.TSYSC023 T3 where T1.USER_ID = :userId and T1.ORGZNO = T2.ORGZNO and T1.USER_ID = T3.MENUNO(+)";

    private static final String SQL = "SELECT T1.USER_ID,\n" 
            + "       T1.ORGZNO,                      \n"
            + "       T1.LOGIN_PW,                    \n"
            + "       T1.USER_NM ,                    \n"
            + "       T1.USER_IP,                     \n"
            + "       T1.USE_STARTDT,                 \n"
            + "       T1.USE_ENDDT,                   \n"
            + "       T1.UC,                          \n"
            + "       T1.UNIT_NM,                     \n"
            + "       T1.SRVNO,                       \n"
            + "       T1.EMPNO,                       \n"
            + "       T1.CLSPST_CD,                   \n"
            + "       T1.CLSPST_NM,                   \n"
            + "       T1.LOGIN_ID,                    \n"
            + "       T1.EMAIL,                       \n"
            + "       T1.TELNO,                       \n"
            + "       T1.HP_NO ,                      \n"
            + "       T1.USE_YN ,                     \n"
            + "       T2.ORGNZ_NM,                    \n"
            + "       T4.ROLENO,                      \n"
            + "       SUBSTR(T1.ORGZNO,0,3) AS ORGZ ,\n"
            + "       NVL(INDV_INFO_PRTCUSE_AGR_YN,'N') AS INDV_INFO_PRTCUSE_AGR_YN,\n"
            + "       T3.BKMK_MENU_NM                 \n"
            + "FROM   LTSOWN.TSYUM002 T1,             \n"
            + "       LTSOWN.TSYUM001 T2,             \n"
            + "       LTSOWN.TSYSC023 T3,             \n"
            + "       LTSOWN.TSYAM002 t4              \n"
            + "WHERE  T1.USER_ID = :userId            \n"
            + "AND    T1.ORGZNO  = T2.ORGZNO          \n"
            + "AND         T1.USER_ID = t4.USER_ID    \n"
            + "AND    T1.USER_ID = T3.MENUNO(+)       \n"
            + "ORDER BY decode(T4.ROLENO,'HSC_SYSADM' ,0,'HSC_ADMIN',1,'HSC_DEV',2 , 3 ) ASC    \n";

	@Override
	public Map getUser(String userId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("userId", userId);
		
		MapSqlParameterSource sqlParameterSource = new MapSqlParameterSource(map);
		
		List<Map<String, Object>> result = getDaoTemplate().queryForList(SQL, sqlParameterSource);
		

		if(result.size() > 0) {
		    MapUtil mapUtil = new MapUtil();
		    mapUtil.decryptMap(result.get(0),"EMAIL","TELNO","HP_NO");
		    
			return result.get(0);
		}
		
		return null;
	}

}
