package htc.commons.auth.dto;

import java.sql.Timestamp;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

public class UserDto extends User {
	private static final long serialVersionUID = -2180326421512943294L;

	private String orgzno;
	private String userId;
	private String userNm;
	private String userIp;
	private Timestamp useStartdt;
	private Timestamp useEnddt;
	private String uc;
	private String unitNm;
	private String srvno;
	private String empno;
	private String clspstCd;
	private String clspstNm;
	private String email;
	private String telno;
	private String hpNo;
	private String orgzNm;
	private String orgz;
	private String roleNo;
	private String bkmkMenuNm;
	private String indvInfoPrtcuseAgrYn;
	
	
	public String getIndvInfoPrtcuseAgrYn() {
        return indvInfoPrtcuseAgrYn;
    }


    public void setIndvInfoPrtcuseAgrYn(String indvInfoPrtcuseAgrYn) {
        this.indvInfoPrtcuseAgrYn = indvInfoPrtcuseAgrYn;
    }


    public String getBkmkMenuNm() {
        return bkmkMenuNm;
    }


    public void setBkmkMenuNm(String bkmkMenuNm) {
        this.bkmkMenuNm = bkmkMenuNm;
    }


    public UserDto(String username, String password, Collection<? extends GrantedAuthority> authorities) {
		super(username, password, authorities);
	}

	
	public UserDto(String username, String password, boolean enabled, boolean accountNonExpired,
			boolean credentialsNonExpired, boolean accountNonLocked,
			Collection<? extends GrantedAuthority> authorities) {
		super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
	}


	/**
	 * @return the orgzno
	 */
	public String getOrgzno() {
		return orgzno;
	}

	/**
	 * @param orgzno the orgzno to set
	 */
	public void setOrgzno(String orgzno) {
		this.orgzno = orgzno;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the userNm
	 */
	public String getUserNm() {
		return userNm;
	}

	/**
	 * @param userNm the userNm to set
	 */
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	/**
	 * @return the userIp
	 */
	public String getUserIp() {
		return userIp;
	}

	/**
	 * @param userIp the userIp to set
	 */
	public void setUserIp(String userIp) {
		this.userIp = userIp;
	}

	/**
	 * @return the useStartdt
	 */
	public Timestamp getUseStartdt() {
		return useStartdt;
	}

	/**
	 * @param useStartdt the useStartdt to set
	 */
	public void setUseStartdt(Timestamp useStartdt) {
		this.useStartdt = useStartdt;
	}

	/**
	 * @return the useEnddt
	 */
	public Timestamp getUseEnddt() {
		return useEnddt;
	}

	/**
	 * @param useEnddt the useEnddt to set
	 */
	public void setUseEnddt(Timestamp useEnddt) {
		this.useEnddt = useEnddt;
	}

	/**
	 * @return the uc
	 */
	public String getUc() {
		return uc;
	}

	/**
	 * @param uc the uc to set
	 */
	public void setUc(String uc) {
		this.uc = uc;
	}

	/**
	 * @return the unitNm
	 */
	public String getUnitNm() {
		return unitNm;
	}

	/**
	 * @param unitNm the unitNm to set
	 */
	public void setUnitNm(String unitNm) {
		this.unitNm = unitNm;
	}

	/**
	 * @return the srvno
	 */
	public String getSrvno() {
		return srvno;
	}

	/**
	 * @param srvno the srvno to set
	 */
	public void setSrvno(String srvno) {
		this.srvno = srvno;
	}

	/**
	 * @return the empno
	 */
	public String getEmpno() {
		return empno;
	}

	/**
	 * @param empno the empno to set
	 */
	public void setEmpno(String empno) {
		this.empno = empno;
	}

	/**
	 * @return the clspstCd
	 */
	public String getClspstCd() {
		return clspstCd;
	}

	/**
	 * @param clspstCd the clspstCd to set
	 */
	public void setClspstCd(String clspstCd) {
		this.clspstCd = clspstCd;
	}

	/**
	 * @return the clspstNm
	 */
	public String getClspstNm() {
		return clspstNm;
	}

	/**
	 * @param clspstNm the clspstNm to set
	 */
	public void setClspstNm(String clspstNm) {
		this.clspstNm = clspstNm;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the telno
	 */
	public String getTelno() {
		return telno;
	}

	/**
	 * @param telno the telno to set
	 */
	public void setTelno(String telno) {
		this.telno = telno;
	}

	/**
	 * @return the hpNo
	 */
	public String getHpNo() {
		return hpNo;
	}

	/**
	 * @param hpNo the hpNo to set
	 */
	public void setHpNo(String hpNo) {
		this.hpNo = hpNo;
	}
	
	/**
     * @return the orgzNm
     */
    public String getOrgzNm() {
        return orgzNm;
    }

    public String getOrgz() {
        return orgz;
    }


    public void setOrgz(String orgz) {
        this.orgz = orgz;
    }


    /**
     * @param orgzNm the orgzNm to set
     */
    public void setOrgzNm(String orgzNm) {
        this.orgzNm = orgzNm;
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	/**
     * @return the roleNo
     */
    public String getRoleNo() {
        return roleNo;
    }


    /**
     * @param roleNo the roleNo to set
     */
    public void setRoleNo(String roleNo) {
        this.roleNo = roleNo;
    }


    @Override
	public String toString() {
		return "UserDto [orgzno=" + orgzno + ", userId=" + userId + ", userNm=" + userNm + ", userIp=" + userIp
				+ ", useStartdt=" + useStartdt + ", useEnddt=" + useEnddt + ", uc=" + uc + ", unitNm=" + unitNm
				+ ", srvno=" + srvno + ", empno=" + empno + ", clspstCd=" + clspstCd + ", clspstNm=" + clspstNm
				+ ", email=" + email + ", telno=" + telno + ", hpNo=" + hpNo + ", orgzNm=" + orgzNm + ", orgz=" + orgz + ", roleNo=" + roleNo + "]";
	}

	

}
