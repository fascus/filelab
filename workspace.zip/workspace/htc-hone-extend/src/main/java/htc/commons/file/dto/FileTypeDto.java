package htc.commons.file.dto;

import htc.hone.core.dto.AbstractDto;

public class FileTypeDto extends AbstractDto {
	private static final long serialVersionUID = 6797046362851545267L;
	
	// 파일종류코드
	private String fileTypeCd;
	// 파일유형명
	private String fileTypeNm;
	// 파일경로명
	private String fileRouteNm;
	// 파일최대크기량
	private int fileMaxSizeQnty;
	// 파일최대개수
	private int fileMaxNum;
	/**
	 * @return the fileTypeCd
	 */
	public String getFileTypeCd() {
		return fileTypeCd;
	}
	/**
	 * @param fileTypeCd the fileTypeCd to set
	 */
	public void setFileTypeCd(String fileTypeCd) {
		this.fileTypeCd = fileTypeCd;
	}
	/**
	 * @return the fileTypeNm
	 */
	public String getFileTypeNm() {
		return fileTypeNm;
	}
	/**
	 * @param fileTypeNm the fileTypeNm to set
	 */
	public void setFileTypeNm(String fileTypeNm) {
		this.fileTypeNm = fileTypeNm;
	}
	/**
	 * @return the fileRouteNm
	 */
	public String getFileRouteNm() {
		return fileRouteNm;
	}
	/**
	 * @param fileRouteNm the fileRouteNm to set
	 */
	public void setFileRouteNm(String fileRouteNm) {
		this.fileRouteNm = fileRouteNm;
	}
	/**
	 * @return the fileMaxSizeQnty
	 */
	public int getFileMaxSizeQnty() {
		return fileMaxSizeQnty;
	}
	/**
	 * @param fileMaxSizeQnty the fileMaxSizeQnty to set
	 */
	public void setFileMaxSizeQnty(int fileMaxSizeQnty) {
		this.fileMaxSizeQnty = fileMaxSizeQnty;
	}
	/**
	 * @return the fileMaxNum
	 */
	public int getFileMaxNum() {
		return fileMaxNum;
	}
	/**
	 * @param fileMaxNum the fileMaxNum to set
	 */
	public void setFileMaxNum(int fileMaxNum) {
		this.fileMaxNum = fileMaxNum;
	}
	
	

}
