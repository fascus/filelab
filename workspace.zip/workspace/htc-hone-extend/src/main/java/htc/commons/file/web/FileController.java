package htc.commons.file.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import hone.bom.BomException;
import hone.bom.context.ApplicationContextHolder;
import htc.commons.file.dto.FileDto;
import htc.commons.file.dto.FileTypeDto;
import htc.commons.file.service.FileHandlerService;
import htc.hone.core.exception.MessageBusinessException;
import htc.hone.core.exception.MessageSystemException;
import htc.xplatform.message.HtcXplatformMessage;
import htc.xplatform.utils.XPlatformUtil;

@Controller
public class FileController {
	@Value(value="#{app['file.upload.path']}")
	private String fileUploadPath;
	
	@Autowired
	FileHandlerService service;
	
	private boolean isDataSetReturn = false;
	
	/*
	@RequestMapping(value="/download_old")
	@Deprecated
	public void download(HttpServletRequest request,
            HttpServletResponse response) throws IOException {
		String strFileId = request.getParameter("fileId");
		int fileId = Integer.parseInt(strFileId);
	
		FileHandlerService service = ApplicationContextHolder.getBean(FileHandlerService.class);
		FileDto dto = service.getFile(fileId);
		
		
        File downloadFile = new File(dto.getStoredFileName());
        FileInputStream inStream = new FileInputStream(downloadFile);
        
        String downloadFileName = dto.getOrgFileName();
        if(StringUtils.hasText(dto.getFileExt())) {
        	downloadFileName += "." + dto.getFileExt();
        }
         
        // obtains ServletContext
        ServletContext context = request.getServletContext();
         
        // gets MIME type of the file
        String mimeType = context.getMimeType(dto.getStoredFileName());
        if (mimeType == null) {        
            // set to binary type if MIME mapping not found
            mimeType = "application/octet-stream";
        }
         
        // modifies response
        response.setContentType(mimeType);
        response.setContentLength((int) downloadFile.length());
         
        // forces download
        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=\"%s\""
        		, cleanFileName(request, downloadFileName)
        		);
        response.setHeader(headerKey, headerValue);
         
        // obtains response's output stream
        OutputStream outStream = response.getOutputStream();
         
        byte[] buffer = new byte[4096];
        int bytesRead = -1;
         
        while ((bytesRead = inStream.read(buffer)) != -1) {
            outStream.write(buffer, 0, bytesRead);
        }
         	
        inStream.close();
        outStream.close();     

	}
	*/
	
	private String cleanFileName(HttpServletRequest request, String fileName) throws UnsupportedEncodingException {
		if(isIERequest(request)) {
			return URLEncoder.encode(fileName, "UTF-8").replaceAll("\\+", "%20");
		} else {
			return new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
		}
	}

	private boolean isIERequest(HttpServletRequest request) {
		String userAgent = request.getHeader(HttpHeaders.USER_AGENT);
		
		// Internet Explorer Check
		if(userAgent.indexOf("MSIE") > -1) {
			return true;
		}
		
		// Internet Explorer 11 With Windows 7 Check
		if("Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko".equals(userAgent)) {
			return true;
		}
		return false;
	}

	@RequestMapping(value="/download")
	public ResponseEntity<InputStreamResource> download(HttpServletRequest request) throws FileNotFoundException, UnsupportedEncodingException {
		String strFileno = request.getParameter("fileno");
		String strFileSeq = request.getParameter("fileSeq");
		return downloadInternal(request, strFileno, strFileSeq);
	}

	@RequestMapping(value="/download/{fileno}/{fileSeq}")
	public ResponseEntity<InputStreamResource> download(HttpServletRequest request
			, @PathVariable("fileno") String fileno
			, @PathVariable("fileSeq") String fileSeq) throws FileNotFoundException, UnsupportedEncodingException {
		return downloadInternal(request, fileno, fileSeq);
	}

	
	public ResponseEntity<InputStreamResource> downloadInternal(HttpServletRequest request, String fileno, String strFileSeq) throws FileNotFoundException, UnsupportedEncodingException {
		if(!StringUtils.hasText(fileno)) {
			throw new MessageSystemException("File Number is empty.");
		}

		int fileSeq = Integer.parseInt(strFileSeq);
		
		FileDto fileDto = service.getFile(fileno, fileSeq);
		if(fileDto == null) {
			throw new MessageSystemException(String.format("Cannot find file [%s-%s]", fileno, fileSeq));
		}
		FileTypeDto fileTypeDto = service.getFileType(fileDto.getFileTypeCd());
		
		if(fileTypeDto == null) {
			throw new MessageSystemException(String.format("Cannot find file type data[%]", fileDto.getFileTypeCd()));
		}
		
		File file = new File(fileTypeDto.getFileRouteNm() + File.separator + fileDto.getSvflNm());
		
		if(!file.exists()) {
			throw new MessageBusinessException("File not found");
		}
		
		String downloadFileName = fileDto.getFlnm();

		HttpHeaders respHeaders = new HttpHeaders();
	    respHeaders.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	    respHeaders.setContentLength(file.length());
	    respHeaders.setContentDispositionFormData("attachment", cleanFileName(request, downloadFileName));

	    InputStreamResource isr = new InputStreamResource(new FileInputStream(file));
	    return new ResponseEntity<InputStreamResource>(isr, respHeaders, HttpStatus.OK);
	}
	
	@RequestMapping(value="/upload")
	public HtcXplatformMessage upload(HttpServletRequest request) {
		return uploadCategory4(request
				, (String) request.getAttribute("fileTypeCd")
				, (String) request.getAttribute("mgtNo")
				, (String) request.getAttribute("rfno")
				, (String) request.getAttribute("fileno")
				);
	}
	
	@RequestMapping(value="/upload/{fileTypeCd}", method=RequestMethod.POST)
	public HtcXplatformMessage uploadCategory1(HttpServletRequest request
			, @PathVariable("fileTypeCd") String fileTypeCd
			, @RequestParam("fileno") String fileno
			) {
		return uploadCategory4(request, fileTypeCd, null, null, fileno);
	}
	
	@RequestMapping(value="/upload/{fileTypeCd}/{mgtNo}", method=RequestMethod.POST)
	public HtcXplatformMessage uploadCategory3(HttpServletRequest request
			, @PathVariable("fileTypeCd") String fileTypeCd
			, @PathVariable("mgtNo") String mgtNo
			, @RequestParam("fileno") String fileno
			) {
		return uploadCategory4(request, fileTypeCd, mgtNo, null, fileno);
	}
	
	@RequestMapping(value="/upload/{fileTypeCd}/{mgtNo}/{rfno}", method=RequestMethod.POST)
	public HtcXplatformMessage uploadCategory4(HttpServletRequest request
			, @PathVariable("fileTypeCd") String fileTypeCd
			, @PathVariable("mgtNo") String mgtNo
			, @PathVariable("rfno") String rfno
			, @RequestParam("fileno") String fileno
			) {
		if(!HttpServletRequest.class.isAssignableFrom(request.getClass())) {
			throw new BomException("Multipart contents not found.");
		}
		
		MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest)request;
		
//        List<FileDto> files = new ArrayList<FileDto>();
        
        if(!StringUtils.hasText(fileTypeCd) || fileTypeCd.length() != 2) {
        	throw new RuntimeException("Invalid fileTypeCd [" + fileTypeCd + "]");
        }
        FileTypeDto fileTypeDto = service.getFileType(fileTypeCd);
        
        if(fileTypeDto == null) {
        	throw new RuntimeException("File Type [" + fileTypeCd + "] not found.");
        }
        
        String storePath = fileTypeDto.getFileRouteNm();

        if(!storePath.endsWith("/") && !storePath.endsWith("\\"))  {
        	storePath += File.separator;
        }
        
        
        File storePathFile = new File(storePath);
        if(!storePathFile.exists()) {
        	storePathFile.mkdirs();
        }
        
        if(!StringUtils.hasText(fileno)) {
        	fileno = service.genFileno();
        }
        
        if(mgtNo != null && "NaN".equals(mgtNo)) {
        	mgtNo = "";
        }
        
        Iterator<String> fileNames = multipartHttpServletRequest.getFileNames();
        List<Map> results = new ArrayList<Map>();
		while(fileNames.hasNext()) {
			String fileKey = fileNames.next();
			int fileSeq = service.genFileSeq(fileno);
			MultipartFile multipartFile = multipartHttpServletRequest.getFile(fileKey);
			
			String fileName = multipartFile.getOriginalFilename();
        	long fileSize = multipartFile.getSize();
        	String baseName = FilenameUtils.getBaseName(fileName);
        	String ext = FilenameUtils.getExtension(fileName);
        	String storeFileName = String.format("%s_%s_%s", fileno, fileSeq, fileName);
        	File file = new File(storePath + storeFileName);
			try {
				multipartFile.transferTo(file);
			} catch (IllegalStateException e) {
				throw new RuntimeException("Multipart transfer failed.", e);
			} catch (IOException e) {
				throw new RuntimeException("Multipart transfer failed.", e);
			}
            
            FileDto dto = new FileDto();
            dto.setFileno(fileno);
            dto.setFileSeq(fileSeq);
            dto.setFileTypeCd(fileTypeCd);
            dto.setSvflNm(storeFileName);
            dto.setFlnm(fileName);
            dto.setFileExtnsnNm(ext);
            dto.setFlszQnty(new Long(fileSize).intValue());
            dto.setMgtNo(mgtNo);
            dto.setRfno(rfno);
            dto.fillDefaultSystemColumns();
//            files.add(dto);

            service.saveFile(dto);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("FILENO", dto.getFileno());
            map.put("FILE_SEQ", dto.getFileSeq());
            map.put("FLNM", dto.getFlnm());
            results.add(map);
		}

        HtcXplatformMessage message = new HtcXplatformMessage();
        if(isDataSetReturn) {
            Map<String, List<Map>> datasets= new HashMap<String, List<Map>>();
            datasets.put("file", results);
        	message.setDatasets(datasets);
        } else {
        	Map<String, Object> variables = new HashMap<String, Object>();
        	String rtn = fileno + "-";
        	for(int i = 0; i < results.size(); i++) {
        		rtn += results.get(i).get("FILE_SEQ");
        		if(i < results.size() - 1) {
        			rtn += "_";
        		}
        	}
        	variables.put("fileKey", rtn);
        	variables.put("ErrorCode", 200);
        	variables.put("ErrorMsg", rtn);
        	message.setVariables(variables);
        }
		
		
		return message;
	}
	

	@ExceptionHandler({Exception.class})
	public HtcXplatformMessage exceptionHandler(HttpServletRequest req, Exception ex) {
		System.err.println(ex.getMessage());
		return null;
	}
	
}
