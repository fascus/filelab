package htc.xplatform.message;

import java.util.HashMap;

@Deprecated
public class XPlatformVariable extends HashMap<String, Object> {
	
}