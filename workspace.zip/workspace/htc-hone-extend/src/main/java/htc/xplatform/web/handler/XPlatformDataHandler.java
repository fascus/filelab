package htc.xplatform.web.handler;

import java.util.Map;

import com.tobesoft.xplatform.data.DataSetList;
import com.tobesoft.xplatform.data.VariableList;

public interface XPlatformDataHandler {
	
	public void preHandle(VariableList variableList, DataSetList dataSetList);
	
	public void postHandle(Map model, VariableList variableList, DataSetList dataSetList);
}
