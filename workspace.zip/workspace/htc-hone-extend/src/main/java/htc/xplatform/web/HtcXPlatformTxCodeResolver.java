package htc.xplatform.web;

import java.util.HashMap;
import java.util.Map;

import hone.bom.web.dispatcher.DispatchException;
import hone.bom.web.dispatcher.TxCodeResolver;
import htc.xplatform.message.HtcXplatformMessage;

public class HtcXPlatformTxCodeResolver implements TxCodeResolver<HtcXplatformMessage> {

	@Override
	public String resolveTxCode(HtcXplatformMessage data) throws DispatchException {
		return data.getHeader().getServiceId();
	}

	@Override
	public Map<String, Object> resolveAdditionalData(HtcXplatformMessage data) {
		return new HashMap<String, Object>();
	}

}
