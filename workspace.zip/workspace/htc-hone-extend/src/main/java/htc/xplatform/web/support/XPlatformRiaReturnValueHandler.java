package htc.xplatform.web.support;

import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.tobesoft.xplatform.data.ColumnHeader;
import com.tobesoft.xplatform.data.DataSet;
import com.tobesoft.xplatform.data.DataSetList;
import com.tobesoft.xplatform.data.DataTypes;
import com.tobesoft.xplatform.data.PlatformData;
import com.tobesoft.xplatform.data.VariableList;
import com.tobesoft.xplatform.tx.HttpPlatformResponse;
import com.tobesoft.xplatform.tx.PlatformType;

import hone.bom.binding.utils.DtoCopyUtils;
import htc.hone.core.message.SystemHeader;
import htc.xplatform.message.HtcXplatformMessage;
import htc.xplatform.web.HtcConstants;
import htc.xplatform.web.handler.XPlatformDataHandler;

@Deprecated

public class XPlatformRiaReturnValueHandler implements HandlerMethodReturnValueHandler {
	private XPlatformDataHandler dataHandler;
	private static final Logger logger = LoggerFactory.getLogger(XPlatformRiaReturnValueHandler.class);

	public void setDataHandler(XPlatformDataHandler dataHandler) {
		this.dataHandler = dataHandler;
	}

	@Override
	public boolean supportsReturnType(MethodParameter returnType) {
		return HtcXplatformMessage.class.isAssignableFrom(returnType.getParameterType());
	}

	@Override
	public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer,
			NativeWebRequest webRequest) throws Exception {
		HtcXplatformMessage message = (HtcXplatformMessage) returnValue;
		
		HttpServletResponse response = webRequest.getNativeResponse(HttpServletResponse.class);
		
		PlatformData platformData = new PlatformData();
		
		
		convertVariables(platformData, message.getHeader(), message.getVariables());
		convertDatasets(platformData, message.getDatasets());
		
		dataHandler.postHandle(null, platformData.getVariableList(), platformData.getDataSetList());

		HttpPlatformResponse hPlatformRsp = new HttpPlatformResponse(response);
		hPlatformRsp.setCharset(PlatformType.DEFAULT_CHAR_SET);
		hPlatformRsp.setData(platformData);
		hPlatformRsp.sendData();


//		HttpServletResponse response = webRequest.getNativeResponse(HttpServletResponse.class);
////		HttpOutputMessage outputMessage = new ServletServerHttpResponse(response);
//
//		PlatformResponse platformResponse = new PlatformResponse(re)
//		PlatformData platformData = new PlatformData();
//		
//		
//		convertVariables(platformData, message.getHeader(), message.getVariables());
//		convertDatasets(platformData, message.getDatasets());
//		
//		dataHandler.postHandle(null, platformData.getVariableList(), platformData.getDataSetList());
//		
//		platformResponse.setData(platformData);
//		platformResponse.sendData();
	}

	private void convertVariables(PlatformData platformData, SystemHeader header, Map<String, Object> variables) {
		VariableList variableList = new VariableList();
		Map<String, Object> mergedVariables = DtoCopyUtils.toMap(header);
		mergedVariables.putAll(variables);
		
		for(String key : mergedVariables.keySet()) {
			variableList.add(key, mergedVariables.get(key));
		}
		
		platformData.setVariableList(variableList);
	}

	private void convertDatasets(PlatformData platformData, Map<String, List<Map>> datasets) {
		DataSetList dataSetList = new DataSetList();
		
		for(String key : datasets.keySet()) {
			dataSetList.add(convertDataset(key, datasets.get(key)));
		}
		
		platformData.setDataSetList(dataSetList);
	}

	private DataSet convertDataset(String key, List<Map> list) {
		DataSet dataSet = new DataSet(key);
		if(list.size() < 1) {
			return dataSet;
		}
		for(Object columnName : list.get(0).keySet()) {
			int type = findColumnTypeNumber(list.get(0).get(columnName).getClass());
			ColumnHeader columnHeader = new ColumnHeader((String) columnName, type);
			dataSet.addColumn(columnHeader);
		}
		
		// rowType Column 정의를 위하여 모든 DataSet의 Column 에 rowType 선정의
		if(!dataSet.containsColumn(HtcConstants.DATASET_ROW_TYPE_KEY)) {
			ColumnHeader columnHeader = new ColumnHeader(HtcConstants.DATASET_ROW_TYPE_KEY, DataTypes.STRING);
			dataSet.addColumn(columnHeader);
		}
		

		
		for(int i = 0; i < list.size(); i++) { 
			Map map  = list.get(i);
			dataSet.newRow();
			for(Object columnName : map.keySet()) {
				dataSet.set(i, (String) columnName, map.get(columnName));
			}
		}
		
		return dataSet;
	}

	private int findColumnTypeNumber(Class clazz) {
		if(clazz == String.class) {
			return DataTypes.STRING;
		} else if (clazz == Integer.class) {
			return DataTypes.INT;
		} else if (clazz == Boolean.class) {
			return DataTypes.BOOLEAN;
		} else if (clazz == Long.class) {
			return DataTypes.LONG;
		} else if (clazz == Float.class) {
			return DataTypes.FLOAT;
		} else if (clazz == Double.class) {
			return DataTypes.DOUBLE;
		} else if (clazz == BigDecimal.class) {
			return DataTypes.BIG_DECIMAL;
		} else if (clazz == Date.class || clazz == java.sql.Date.class) {
			return DataTypes.DATE;
		} else if (clazz == Time.class) {
			return DataTypes.TIME;
		} else if (clazz == Timestamp.class) {
			return DataTypes.DATE_TIME;
		} else if (clazz == Blob.class) {
			return DataTypes.BLOB;
		} else {
			return DataTypes.UNDEFINED;
		}
	}
	

}
