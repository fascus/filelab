package htc.xplatform.web.exception;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;

import com.tobesoft.xplatform.data.DataSet;
import com.tobesoft.xplatform.data.DataSetList;
import com.tobesoft.xplatform.data.DataTypes;
import com.tobesoft.xplatform.data.Debugger;
import com.tobesoft.xplatform.data.PlatformData;
import com.tobesoft.xplatform.data.VariableList;
import com.tobesoft.xplatform.data.datatype.DataType;
import com.tobesoft.xplatform.tx.PlatformException;
import com.tobesoft.xplatform.tx.PlatformResponse;
import com.tobesoft.xplatform.tx.PlatformType;

import hone.bom.web.request.BomRequestHolder;
import hone.bom.web.request.ClientType;
import htc.hone.core.message.SystemHeader;
import htc.hone.utils.ContextUtil;
import htc.xplatform.utils.MessageUtil;
import htc.xplatform.utils.XPlatformUtil;
import htc.xplatform.web.HtcConstants;
import htc.xplatform.web.handler.XPlatformDataHandler;
import htc.xplatform.web.support.XplatformDataParser;

public class XplatformExceptionResolver extends AbstractHandlerExceptionResolver {

	private XPlatformDataHandler xplatformDataHandler;
	private XplatformDataParser xplatformDataParser;
	private static final boolean HANDLE_WITH_DEFAULT_XPLATFORM_MESSAGE = true;

	@Override
	protected boolean shouldApplyTo(HttpServletRequest arg0, Object arg1) {
		ClientType clientType = BomRequestHolder.getRequestInfo() == null ? null : BomRequestHolder.getRequestInfo().getClientType();
		
		if(clientType != null && clientType.equals(ClientType.get(HtcConstants.XPLATFORM_CLIENT_TYPE))) {
			return true;
		}
		return false;
	}

	@Override
	protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object obj,
			Exception ex) {
		if(HANDLE_WITH_DEFAULT_XPLATFORM_MESSAGE) {
			handleWithXPlatformDefaultMessage(request, response);
		} else {
			handleWithCustomMessage(request, response);
		}
		
		return new ModelAndView();
	}

	private void handleWithXPlatformDefaultMessage(HttpServletRequest request, HttpServletResponse response) {
		PlatformData platformData = XPlatformUtil.initailizePlatformData();
		XPlatformUtil.setVariable(platformData, "ErrorCode", MessageUtil.DEFAULT_ERROR_CODE);
		XPlatformUtil.setVariable(platformData, "ErrorMsg", MessageUtil.DEFAULT_ERROR_MESSAGE);
		try {
			XPlatformUtil.sendPlatformData(response, platformData);
		} catch (PlatformException e) {
			logger.error("PlatformData send failed", e);
			throw new RuntimeException("PlatformData send failed", e);
		}
		
	}

	private void handleWithCustomMessage(HttpServletRequest request, HttpServletResponse response) {
		try {
			String platformType = PlatformType.CONTENT_TYPE_XML;
			
			PlatformResponse platformResponse 
				= new PlatformResponse(response.getOutputStream(), platformType);
			/*
			PlatformResponse platformResponse 
				= new HonePlatformResponse(response, platformType,this.encoding);
			*/
			
			SystemHeader header = ContextUtil.getHeader();
			
			if(header == null) {
				header = initializeHeader(request);
			}
			
			PlatformData platformData = new PlatformData();
			DataSetList dsList = MessageUtil.makeMessageDataSetList(MessageUtil.DEFAULT_ERROR_ID, MessageUtil.DEFAULT_ERROR_MESSAGE);
			platformData.setDataSetList(dsList);
	        
	        platformData.setSaveType(DataSet.SAVE_TYPE_ALL);
	
	        if(logger.isDebugEnabled()) {
	        	Debugger debugger = new Debugger();
	        	logger.debug(debugger.detail(platformData));
	        	logger.debug(platformData.saveXml());
	         }
	        
	    	platformResponse.setData(platformData);
	    	platformResponse.sendData();            
		} catch (IOException ioe) {
			throw new RuntimeException("Failed to make PlatformResponse",ioe);
		} catch (PlatformException pe) {
			throw new RuntimeException("Failed to send PlatformResponse",pe);
		}
	}


	private SystemHeader initializeHeader(HttpServletRequest request) {
		return new SystemHeader();
	}

	public void setXplatformDataParser(XplatformDataParser xplatformDataParser) {
		this.xplatformDataParser = xplatformDataParser;
	}

	public XPlatformDataHandler getXplatformDataHandler() {
		return xplatformDataHandler;
	}

	public void setXplatformDataHandler(XPlatformDataHandler xplatformDataHandler) {
		this.xplatformDataHandler = xplatformDataHandler;
	}

}
