package htc.xplatform.web.mav;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.view.AbstractView;

import com.tobesoft.xplatform.data.DataSetList;
import com.tobesoft.xplatform.data.PlatformData;
import com.tobesoft.xplatform.data.VariableList;
import com.tobesoft.xplatform.tx.HttpPlatformResponse;
import com.tobesoft.xplatform.tx.PlatformException;
import com.tobesoft.xplatform.tx.PlatformType;

import hone.bom.binding.utils.DtoCopyUtils;
import htc.hone.core.message.SystemHeader;
import htc.xplatform.message.HtcXplatformMessage;
import htc.xplatform.utils.XPlatformUtil;
import htc.xplatform.web.HtcConstants;
import htc.xplatform.web.handler.XPlatformDataHandler;

public class XPlatformMapView extends AbstractView {
	private XPlatformDataHandler dataHandler;
	private static final Logger logger = LoggerFactory.getLogger(XPlatformMapView.class);

	public void setDataHandler(XPlatformDataHandler dataHandler) {
		this.dataHandler = dataHandler;
	}

	@Override
	protected void renderMergedOutputModel(Map<String, Object> model,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		PlatformData platformData = new PlatformData();
		
		HtcXplatformMessage message = (HtcXplatformMessage) model.get(HtcConstants.HONE_MESSAGE_MAV_KEY);
		
		XPlatformUtil.convertVariables(platformData, message.getHeader(), message.getVariables());
		XPlatformUtil.convertDatasets(platformData, message.getDatasets());
		
		dataHandler.postHandle(null, platformData.getVariableList(), platformData.getDataSetList());
		if(logger.isDebugEnabled()) {
			logger.debug(platformData.saveXml());
		}

		XPlatformUtil.sendPlatformData(response, platformData);
	}



}