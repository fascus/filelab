package htc.xplatform.web;

public enum XPlatformRowType {
	NORMAL(HtcConstants.DATASET_ROW_TYPE_NORMAL)
	, INSERT(HtcConstants.DATASET_ROW_TYPE_NORMAL)
	, DELETE(HtcConstants.DATASET_ROW_TYPE_NORMAL)
	, REMOVE(HtcConstants.DATASET_ROW_TYPE_NORMAL)
	, UPDATE(HtcConstants.DATASET_ROW_TYPE_NORMAL);
	
	
	private String rowType;
	
	XPlatformRowType(String rowType) {
		this.rowType = rowType;
	}
	
	public String value() {
		return rowType;
	}
}
