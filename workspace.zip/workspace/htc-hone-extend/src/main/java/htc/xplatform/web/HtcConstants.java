package htc.xplatform.web;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.prefs.Preferences;

import com.tobesoft.xplatform.data.DataSet;

import htc.xplatform.message.HtcXplatformMessage;

public class HtcConstants {
	/*
	 * XPlatform Row Status Types
	 */
	public static final String DATASET_ROW_TYPE_KEY = "rowType";
	public static final String DATASET_ROW_TYPE_NORMAL = "N";
	public static final String DATASET_ROW_TYPE_INSERTED = "I";
	public static final String DATASET_ROW_TYPE_UPDATED = "U";
	public static final String DATASET_ROW_TYPE_DELETED = "D";
	@Deprecated
	public static final String DATASET_ROW_TYPE_REMOVED = "R";
	
	public static final String XPLATFORM_CLIENT_TYPE = "XPLATFORM";
	
	public static final String DEFAULT_CHARSET_NAME = "UTF-8";
	
	public static final String RESPONSE_CODE_SUCCESS = "S001";
	public static final String RESPONSE_CODE_ERROR = "E001";
	
	public static final String HONE_MESSAGE_MAV_KEY = HtcXplatformMessage.class.getSimpleName().substring(0, 1).toLowerCase() + HtcXplatformMessage.class.getSimpleName().substring(1);
	public static final String HEADER_KEY = "__HEADER";
	public static final String HTTP_SERVLET_REQUEST_KEY = "__HTTP_SERVLET_REQUEST";
	public static final String PAGING_KEY = "__PAGING";
	public static final String XPLATFORM_DATASET_PAGING_NAME = "dsPage";
	public static final String XPLATFORM_BIND_PAGING_NAME = "page";
	
	public static final String GLOBAL_VARIABLE_PREFIX = "gv";
	public static final String LOCAL_VARIABLE_PREFIX = "v";
	public static final String GLOBAL_DATASET_PREFIX = "gds";
	public static final String LOCAL_DATASET_PREFIX = "ds";
	public static final String VARIABLE_MAP_NAME = "__VARIABLE_BIND_MAP__";
	public static final String DATASET_MAP_NAME = "__DATASET_BIND_MAP__";
	
	public static final boolean IS_CAPITALIZE_FIRST_CHARACTER = true;
	public static final String SYSTEM_ROOT_PATH = Preferences.systemRoot().absolutePath();
	
	
	public static final String SYSCOL_INPUTPSN_ID = "INPUTPSN_ID";
	public static final String SYSCOL_INPUT_DTTM = "IMPUT_DTTM";
	public static final String SYSCOL_MDFR_ID = "MDFR_ID";
	public static final String SYSCOL_MDFC_DTTM = "MDFC_DTTM";
	public static final String SYSCOL_USE_YN = "USE_YN";
	
	
	@Deprecated
	public static final String[] GLOBAL_VARIABLE_NAMES = {"gv_userId", "gv_menuType", "gv_openCnt"};
	@Deprecated
	public static final String[] GLOBAL_DATASET_NAMES = {"gds_Menu", "gds_OpenMenu"};
	@Deprecated
	public static final Map<String, String> GLOBAL_VARIABLES_META;
	public static final String APP_PROPERTIES_LOCATION = "/config/app.properties";
	static {
		Map<String, String> map = new HashMap<String, String>();
		map.put("gv_userId", "userId");
		map.put("gv_menuType", "menuType");
		map.put("gv_openCnt", "openCnt");
		GLOBAL_VARIABLES_META = map;
	}
	@Deprecated
	public static final Map<String, String> GLOBAL_DATASET_META;
	static {
		Map<String, String> map = new HashMap<String, String>();
		map.put("gds_Menu", "menu");
		map.put("gds_OpenMenu", "openMenu");
		GLOBAL_DATASET_META = map;
	}
	
}
