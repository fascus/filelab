package htc.xplatform.web.handler;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.tobesoft.xplatform.data.DataSet;
import com.tobesoft.xplatform.data.DataSetList;
import com.tobesoft.xplatform.data.Variable;
import com.tobesoft.xplatform.data.VariableList;

import hone.bom.context.request.RequestContext;
import hone.bom.context.request.RequestContextHolder;
import htc.xplatform.web.HtcConstants;

public class XPlatformRiaDataHandler implements XPlatformDataHandler {
	private static final Logger logger = LoggerFactory.getLogger(XPlatformRiaDataHandler.class);
	
	@Override
	public void preHandle(VariableList variableList, DataSetList dataSetList) {
		RequestContext requestContext = RequestContextHolder.getRequestContext();

		Map<String, String> variableBindMap = new HashMap<String, String>();
		for(int i = 0; i < variableList.size(); i++) {
			Variable variable = variableList.get(i);
			String newName = null;
			if(StringUtils.hasText(HtcConstants.GLOBAL_VARIABLE_PREFIX) && variable.getName().startsWith(HtcConstants.GLOBAL_VARIABLE_PREFIX)) {
				newName = detachPrefix(variable.getName(), HtcConstants.GLOBAL_VARIABLE_PREFIX);
			} else if(StringUtils.hasText(HtcConstants.LOCAL_VARIABLE_PREFIX) && variable.getName().startsWith(HtcConstants.LOCAL_VARIABLE_PREFIX)) {
				newName = detachPrefix(variable.getName(), HtcConstants.LOCAL_VARIABLE_PREFIX);
			} else if(StringUtils.hasText(HtcConstants.GLOBAL_VARIABLE_PREFIX) || StringUtils.hasText(HtcConstants.LOCAL_VARIABLE_PREFIX)) {
				logger.warn(String.format("Variable [%s] cannot bind. Use correct prefix", variable.getName()));
			}
			if(StringUtils.hasText(newName)) {
				variableBindMap.put(newName, variable.getName());
				variable.setName(newName);
			}
		}
		requestContext.setAttribute(HtcConstants.VARIABLE_MAP_NAME, variableBindMap);
		
		Map<String, String> datasetBindMap = new HashMap<String, String>();
		for(int i = 0; i < dataSetList.size(); i++) {
			DataSet dataSet = dataSetList.get(i);
			String newName = null;
			if(StringUtils.hasText(HtcConstants.GLOBAL_DATASET_PREFIX) && dataSet.getName().startsWith(HtcConstants.GLOBAL_DATASET_PREFIX)) {
				newName = detachPrefix(dataSet.getName(), HtcConstants.GLOBAL_DATASET_PREFIX);
			} else if(StringUtils.hasText(HtcConstants.LOCAL_DATASET_PREFIX) && dataSet.getName().startsWith(HtcConstants.LOCAL_DATASET_PREFIX)) {
				newName = detachPrefix(dataSet.getName(), HtcConstants.LOCAL_DATASET_PREFIX);
			} else if(StringUtils.hasText(HtcConstants.GLOBAL_DATASET_PREFIX) || StringUtils.hasText(HtcConstants.LOCAL_DATASET_PREFIX)) {
				logger.warn(String.format("DataSet [%s] cannot bind. Use correct prefix", dataSet.getName()));
			}
			if(StringUtils.hasText(newName)) {
				datasetBindMap.put(newName, dataSet.getName());
				dataSet.setName(newName);
			}

		}
		requestContext.setAttribute(HtcConstants.DATASET_MAP_NAME, datasetBindMap);

	}

	private String detachPrefix(String name, String prefix) {
		if(name.length() == 0) {
			return name;
		} else if (name.length() == 1) {
			return name.toLowerCase();
		} else {
			return name.substring(prefix.length(), prefix.length() + 1).toLowerCase() + name.substring(prefix.length() + 1);
		}
	}
	
	@Override
	public void postHandle(Map model, VariableList variableList, DataSetList dataSetList) {
		Map<String, String> variableBindMap = (Map<String, String>) RequestContextHolder.getRequestContext().getAttribute(HtcConstants.VARIABLE_MAP_NAME);
		Map<String, String> datasetBindMap = (Map<String, String>) RequestContextHolder.getRequestContext().getAttribute(HtcConstants.DATASET_MAP_NAME);
//		Map<String, String> datasetBindMap = (Map<String, String>) RequestContextHolder.getRequestContext().getAttribute(HtcConstants.VARIABLE_MAP_NAME);
		
		
		if(variableBindMap != null) {
			int unknownIndex = 1;
			for(int i = 0; i < variableList.size(); i++) {
				String name = variableList.get(i).getName();
				if("ErrorCode".equals(name) || "ErrorMsg".equals(name)) {
					variableList.get(i).setName(name);
				} else if(variableBindMap.containsKey(name)) {
					variableList.get(i).setName(variableBindMap.get(name));
				} else {
					String newName = HtcConstants.LOCAL_VARIABLE_PREFIX;
					if(name == null || name.length() == 0) {
						if(HtcConstants.IS_CAPITALIZE_FIRST_CHARACTER) {
							newName += "Unknown" + (unknownIndex++);
						} else {
							newName += "unknown" + (unknownIndex++);
						}
						logger.warn("Invalid Variable name [" + variableList.get(i).getName() + "]. Mapping at [" + newName + "]");
					} else {
						if(HtcConstants.IS_CAPITALIZE_FIRST_CHARACTER) {
							if(variableList.get(i).getName().length() == 1) {
								newName += name.toUpperCase();
							} else {
								newName += name.substring(0, 1).toUpperCase() + name.substring(1);
							}
						} else {
							newName += name;
						}
					}
					variableList.get(i).setName(newName);
				}
			}
		}
		if(datasetBindMap != null) {
			int unknownIndex = 1;
			for(int i = 0; i < dataSetList.size(); i++) {
				String name = dataSetList.get(i).getName();
				
				if(datasetBindMap.containsKey(name)) {
					dataSetList.get(i).setName(datasetBindMap.get(name));
				} else {
					String newName = HtcConstants.LOCAL_DATASET_PREFIX;
					
					if(dataSetList.get(i).getName() == null || dataSetList.get(i).getName().length() == 0) {
						if(HtcConstants.IS_CAPITALIZE_FIRST_CHARACTER) {
							newName += "Unknown" + (unknownIndex++);
						} else {
							newName += "unknown" + (unknownIndex++);
						}
						logger.warn("Invalid DataSet name [" + dataSetList.get(i).getName() + "]. Mapping at [" + newName + "]");
					} else {
						if(HtcConstants.IS_CAPITALIZE_FIRST_CHARACTER) {
							if(dataSetList.get(i).getName().length() == 1) {
								newName += dataSetList.get(i).getName().toUpperCase();
							} else {
								newName += dataSetList.get(i).getName().substring(0, 1).toUpperCase() + dataSetList.get(i).getName().substring(1);
							}
						} else {
							newName += dataSetList.get(i).getName();
						}
					}
					
					dataSetList.get(i).setName(newName);
				}
			}
		}
	}

}
