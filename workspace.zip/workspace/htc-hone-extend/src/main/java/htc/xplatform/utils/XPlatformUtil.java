package htc.xplatform.utils;

import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.tobesoft.xplatform.data.ColumnHeader;
import com.tobesoft.xplatform.data.DataSet;
import com.tobesoft.xplatform.data.DataSetList;
import com.tobesoft.xplatform.data.DataTypes;
import com.tobesoft.xplatform.data.PlatformData;
import com.tobesoft.xplatform.data.Variable;
import com.tobesoft.xplatform.data.VariableList;
import com.tobesoft.xplatform.tx.HttpPlatformResponse;
import com.tobesoft.xplatform.tx.PlatformException;
import com.tobesoft.xplatform.tx.PlatformType;

import hone.bom.binding.utils.DtoCopyUtils;
import hone.bom.context.request.RequestContextHolder;
import htc.hone.core.message.SystemHeader;
import htc.hone.utils.ContextUtil;
import htc.xplatform.web.HtcConstants;

public class XPlatformUtil {
	private static final Logger logger = LoggerFactory.getLogger(XPlatformUtil.class);
	/*
	 * XPlatform Row Status Types
	 */
	public static final String DATASET_ROW_TYPE_KEY = "rowType";
	public static final String DATASET_ROW_TYPE_NORMAL = "N";
	public static final String DATASET_ROW_TYPE_INSERTED = "I";
	public static final String DATASET_ROW_TYPE_UPDATED = "U";
	public static final String DATASET_ROW_TYPE_DELETED = "D";
	@Deprecated
	public static final String DATASET_ROW_TYPE_REMOVED = "R";
	
	private static final int DEFAULT_DATA_TYPE_NUMBER = DataTypes.UNDEFINED;

	public static String getDataRowType(Map dataMap) {
		String rowType = (String) dataMap.get(DATASET_ROW_TYPE_KEY);
		return StringUtils.hasText(rowType) ? rowType : "N";
	}
	
	public static void setDataRowType(Map dataMap, String rowType) {
		dataMap.put(DATASET_ROW_TYPE_KEY, rowType);
	}

	/**
	 * 현재 Thread Local에 저장된 SystemHeader 를 기준으로 PlatformData 초기 생성해준다.
	 * @return
	 */
	public static PlatformData initailizePlatformData() {
		PlatformData platformData = new PlatformData();
		try {
			SystemHeader header = (SystemHeader) RequestContextHolder.getRequestContext().getAttribute(HtcConstants.HEADER_KEY);
			VariableList variableList = new VariableList();
			Map<String, Object> variables = null;
			if(header != null) {
				variables = DtoCopyUtils.toMap(header);
			} else {
				variables = new HashMap<String, Object>();
			}
			

		} catch (Exception e) {
			logger.error("Initializing platformData with default data failed. It will initialize empty PlatformData.", e);
		}
		
		return platformData;
	}

	public static void setVariable(PlatformData platformData, String key, Object value) {
		Variable variable = new Variable(key);
		variable.set(value);
		platformData.addVariable(variable);
	}
	
	public static void setDataSet(PlatformData platformData, String key,  List<Map> list) {
		DataSet dataSet =convertDataset(key, list);
		platformData.addDataSet(dataSet);
	}
	
	/**
	 * 개별 데이터 셋을 변환해준다.
	 * @param key
	 * @param list
	 * @return
	 */
	public static DataSet convertDataset(String key, List<Map> list) {
		// 데이터 타입이 확인되지 않는 컬럼들을 저장
		List undefinedColumnTypes = new ArrayList();
		DataSet dataSet = new DataSet(key);
		if(list.size() < 1) {
			return dataSet;
		}
		
		// 데이터의 첫번 째 Row를 기준으로 컬럼들의 Type을 정의한다. 우선 확인 안되면 UNDEFINDED로 선지정
		for(Object columnName : list.get(0).keySet()) {
			int type = findColumnTypeNumber(list.get(0).get(columnName));
			if(type == DataTypes.UNDEFINED) {
				undefinedColumnTypes.add(columnName);
			}
			ColumnHeader columnHeader = new ColumnHeader((String) columnName, type);
			dataSet.addColumn(columnHeader);
		}
		
		// rowType Column 정의를 위하여 모든 DataSet의 Column 에 rowType 선정의
		if(!dataSet.containsColumn(HtcConstants.DATASET_ROW_TYPE_KEY)) {
			ColumnHeader columnHeader = new ColumnHeader(HtcConstants.DATASET_ROW_TYPE_KEY, DataTypes.STRING);
			dataSet.addColumn(columnHeader);
		}
		
		// 전체 DataSet 데이터 세팅
		for(int i = 0; i < list.size(); i++) { 
			Map map  = list.get(i);
			dataSet.newRow();
			for(Object columnName : map.keySet()) {
				Object value = map.get(columnName);
				// 첫 Row에서 컬럼Type 학인 안되었으나 추후 확인 가능한 경우 새로 지정
				if(value != null && undefinedColumnTypes.contains(columnName) ) {
					int type = findColumnTypeNumber(value);
					if(type != DataTypes.UNDEFINED) {
						dataSet.setColumnDataType((String) columnName, type);
						undefinedColumnTypes.remove(columnName);
					}
				}
				dataSet.set(i, (String) columnName, value);
			}
		}
		
		// 마지막까지 DATA_TYPE 못찾은 컬럼은 DEFAULT 값으로 타입 재정의
		for(Object columnName : undefinedColumnTypes) {
			dataSet.setColumnDataType((String) columnName, DEFAULT_DATA_TYPE_NUMBER);
		}
		
		return dataSet;
	}


	/**
	 * 현재 Object 클래스 기준으로 XPlatform 데이터 타입 리턴 
	 * @param obj
	 * @return
	 */
	private static int findColumnTypeNumber(Object obj) {
		if(obj == null) {
			return DataTypes.UNDEFINED;
		}
		
		Class clazz = obj.getClass();
		if(clazz == String.class) {
			return DataTypes.STRING;
		} else if (clazz == Integer.class) {
			return DataTypes.INT;
		} else if (clazz == Boolean.class) {
			return DataTypes.BOOLEAN;
		} else if (clazz == Long.class) {
			return DataTypes.LONG;
		} else if (clazz == Float.class) {
			return DataTypes.FLOAT;
		} else if (clazz == Double.class) {
			return DataTypes.DOUBLE;
		} else if (clazz == BigDecimal.class) {
			return DataTypes.BIG_DECIMAL;
		} else if (clazz == Date.class || clazz == java.sql.Date.class) {
			return DataTypes.DATE;
		} else if (clazz == Time.class) {
			return DataTypes.TIME;
		} else if (clazz == Timestamp.class) {
			return DataTypes.DATE_TIME;
		} else if (clazz == Blob.class) {
			return DataTypes.BLOB;
		} else {
			return DataTypes.UNDEFINED;
		}
	}
	
	/**
	 * 변수 및 Header 값들을 PlatformData Variables 로 변환
	 * @param platformData
	 * @param header
	 * @param variables
	 */
	public static  void convertVariables(PlatformData platformData, SystemHeader header, Map<String, Object> variables) {
		VariableList variableList = new VariableList();
		Map<String, Object> mergedVariables = header == null ? new HashMap<String, Object>() : DtoCopyUtils.toMap(header);
		mergedVariables.putAll(variables);
		
		for(String key : mergedVariables.keySet()) {
			variableList.add(key, mergedVariables.get(key));
		}
		
		platformData.setVariableList(variableList);
	}

	
	/**
	 * <pre>
	 * DataSet 리스트를 PlatformData DataSets 로 변환해준다.
	 * </pre>
	 * @param platformData
	 * @param datasets
	 */
	public static void convertDatasets(PlatformData platformData, Map<String, List<Map>> datasets) {
		DataSetList dataSetList = new DataSetList();
		
		for(String key : datasets.keySet()) {
			dataSetList.add(XPlatformUtil.convertDataset(key, datasets.get(key)));
		}
		
		if(ContextUtil.hasPaging()) {
			dataSetList.add((XPlatformUtil.convertDataset(HtcConstants.XPLATFORM_BIND_PAGING_NAME, ContextUtil.getPaging().toDataList())));
		}
		
		platformData.setDataSetList(dataSetList);
	}


	
	/**
	 * PlatformData 를 XPlatform에 맞춰 response로 보내준다.
	 * @param response
	 * @param platformData
	 * @throws PlatformException
	 */
	public static void sendPlatformData(HttpServletResponse response, PlatformData platformData) throws PlatformException {
		HttpPlatformResponse hPlatformRsp = new HttpPlatformResponse(response);
		hPlatformRsp.setCharset(PlatformType.DEFAULT_CHAR_SET);
		hPlatformRsp.setData(platformData);
		hPlatformRsp.sendData();
	}

	public static void throwErrorMessage(int errorCode ,String errorMsg, HttpServletRequest request, HttpServletResponse response) throws PlatformException {
		PlatformData platformData = XPlatformUtil.initailizePlatformData();
		XPlatformUtil.setVariable(platformData, "ErrorCode", errorCode);
		XPlatformUtil.setVariable(platformData, "ErrorMsg", errorMsg);
		XPlatformUtil.sendPlatformData(response, platformData);
	}
	
}
