package htc.xplatform.web;

import java.lang.annotation.Annotation;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.MDC;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import hone.bom.binding.utils.DtoCopyUtils;
import hone.bom.context.request.RequestContextHolder;
import hone.bom.interceptor.Position;
import hone.bom.web.dispatcher.ServiceMethod;
import hone.bom.web.handler.MDCValue;
import hone.bom.web.handler.MessageRequestHandlerSupport;
import hone.bom.web.message.TxMessageException;
import hone.bom.web.request.BomRequestHolder;
import hone.bom.web.request.BomRequestInfo;
import hone.bom.web.request.ClientType;
import hone.bom.web.request.RequestContextUtil;
import htc.commons.paging.PagingSupport;
import htc.hone.annotation.ParamBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.dto.AbstractDto;
import htc.hone.core.message.SystemHeader;
import htc.hone.core.user.UserInfo;
import htc.hone.utils.ContextUtil;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.annotation.VariableBind;
import htc.xplatform.message.HtcXplatformMessage;
import htc.xplatform.utils.MessageUtil;
import htc.xplatform.utils.XPlatformUtil;

@Controller
public class XPlatformRequestHandler extends MessageRequestHandlerSupport<HtcXplatformMessage> {
	private static final ClientType XPLATFORM = ClientType.get(HtcConstants.XPLATFORM_CLIENT_TYPE);
	
	/**
	 * <pre>
	 * XPlatform 요청 처리 
	 * 모든 요청은 /ria/{서비스ID} 의 형태로 호출되어야 한다.
	 * </pre>
	 * @param requestMessage
	 * @param serviceId
	 * @return
	 */
	@RequestMapping(value="/ria/{serviceId}")
	public HtcXplatformMessage handler(HtcXplatformMessage requestMessage
				, @PathVariable("serviceId") String serviceId) {
		// 시스템 헤더 획득
		SystemHeader header = requestMessage.getHeader();
		if(header == null) {
			throw new RuntimeException("Header is null");
		}
		// URI 패턴에 의하여 서비스 아이디 획득 후 세팅
		header.setServiceId(serviceId);

		
		// Framework 내부에서 요청 정보를 처리하기 위한 RequestInfo 초기화
		BomRequestInfo bomRequestInfo = BomRequestHolder.getRequestInfo();
		bomRequestInfo.setUserId(header.getUserId());
		bomRequestInfo.setClientIp(header.getUserIp());
		bomRequestInfo.setClientType(XPLATFORM);
		bomRequestInfo.setTxCode(serviceId);

		// Context 에 생성된 Header 적재 (Thread Local 에 저장됨)
		RequestContextHolder.getRequestContext().setAttribute(HtcConstants.HEADER_KEY, header);
		return (HtcXplatformMessage) super.handle(requestMessage);
	}

	/* (non-Javadoc)
	 * @see hone.bom.web.handler.MessageRequestHandlerSupport#resolveParameters(java.lang.Object, hone.bom.web.dispatcher.ServiceMethod)
	 */
	@Override
	protected Object[] resolveParameters(HtcXplatformMessage message, ServiceMethod serviceMethod)
			throws TxMessageException {
		return parseParameters(message.getHeader(), message.getVariables(), message.getDatasets(), serviceMethod, ContextUtil.getHttpServletRequest());
	}


	/**
	 * <pre>
	 * XPlatform 의 PlatformData 를 서비스에서 사용가능한 Java 객체로 변환하여 Parameter로 넘겨준다.
	 * </pre>
	 * @param header
	 * @param variables
	 * @param datasets
	 * @param serviceMethod
	 * @param request
	 * @return
	 */
	private Object[] parseParameters(SystemHeader header, Map<String, Object> variables,
			Map<String, List<Map>> datasets, ServiceMethod serviceMethod, HttpServletRequest request) {
		
		// Service Method 파라메터에서 정의한 파라메터의 변수 명 배열
		String[] parameterNames = serviceMethod.getParameterNames();
		// Service Method 파라메터에서 정의한 파라메터 클래스 타입 배열
		Class[] parameterTypes  = serviceMethod.getParamerTypes();
		// 실제 Service Method로 넘겨줄 변환된 파라메터 배열
		Object[] params = new Object[parameterNames .length];
		
		// 전체 파라메터를 순차적으로 규칙에 의하여 변환
		for(int i = 0; i < parameterNames.length; i++) {
			Class paramType = parameterTypes[i];
			if (SystemHeader.class.isAssignableFrom(paramType)) { // 파라메터 타입이 SystemHeader 일 경우
				params[i] = header;
			} else if(List.class.isAssignableFrom(paramType)) { // 파라메터 타입이 java.util.List 일 경우
				params[i] = resolveListParam(serviceMethod.getMethod().getGenericParameterTypes()[i], serviceMethod.getParameterAnnotations(i), parameterNames[i], datasets);
			} else if (Map.class.isAssignableFrom(paramType)) { // 파라메터 타입이 java.util.Map 일 경우
				params[i] = resolveMapParam(serviceMethod.getParameterAnnotations(i), parameterNames[i], variables, datasets);
			} else if (AbstractDto.class.isAssignableFrom(paramType)) { // 파라메터 타입이 DTO일 경우
				params[i] = resolveDtoParam(paramType, serviceMethod.getParameterAnnotations(i), parameterNames[i], variables, datasets);
			} else if (HttpServletRequest.class.isAssignableFrom(paramType)) { // 파라메터 타입이 HttpServletRequest 일 경우
				params[i] = request;
			} else if (PagingSupport.class.isAssignableFrom(paramType)) { // 파라메터 타입이 페이징 객체일 경우
				params[i] = ContextUtil.getPaging();
			} else  { // 그  외의 경우는 Xplatform에서 Variable 만을 처리하여 각종 타입으로 자동 바인딩
				params[i] = resolveSingleParam(serviceMethod.getParameterAnnotations(i), parameterNames[i], variables);
			}
			
		}
		return params;
	}

	private Object resolveSingleParam(Annotation[] parameterAnnotations, String paramaterName, Map<String, Object> variables) {
		String variableName = paramaterName;
		for(Annotation annotation : parameterAnnotations) {
			if(annotation instanceof DatasetBind) {
				logger.warn(String.format("[%s] cannot bind with DatasetBind Annotation", paramaterName));
				return null;
			} else if (annotation instanceof VariableBind) {
				VariableBind bind = (VariableBind)annotation;
				variableName = bind.value();
			} else if (annotation instanceof ParamBind) {
				ParamBind bind = (ParamBind)annotation;
				variableName = bind.value();
			}
		}

		return variables.get(variableName);
	}

	private Object resolveDtoParam(Class paramType, Annotation[] parameterAnnotations, String paramaterName,
			Map<String, Object> variables, Map<String, List<Map>> datasets) {
		return DtoCopyUtils.fromMap(resolveMapParam(parameterAnnotations, paramaterName, variables, datasets), paramType);
	}

	private Map resolveMapParam(Annotation[] parameterAnnotations, String paramaterName, Map<String, Object> variables,
			Map<String, List<Map>> datasets) {

		String datasetName = paramaterName;
		XPlatformRowType[] rowTypes = null;

		for(Annotation annotation : parameterAnnotations) {
			if(annotation instanceof DatasetBind) {
				DatasetBind bind = (DatasetBind) annotation;
				datasetName = bind.value();
				rowTypes = bind.rowTypeFilter();
				break;
			} else if (annotation instanceof VariableBind) {
				return variables;
			} else if (annotation instanceof ParamBind) {
				ParamBind bind = (ParamBind)annotation;
				datasetName = bind.value();
			}
		}

		
		if(datasets.get(datasetName) == null) {
			return null;
		} else if (datasets.get(datasetName).size() < 1) {
			logger.warn(String.format("DataSet [%s] is Empty. Could not return top 1 row.", paramaterName));
			return new HashMap();
		}
		
		
		if(rowTypes == null || rowTypes.length < 1) {
			return datasets.get(datasetName).get(0);
		} else {
			for(Map map : datasets.get(datasetName)) {
				for(XPlatformRowType rowType : rowTypes) {
					if(XPlatformUtil.getDataRowType(map).equals(rowType.name())) {
						return map;
					}
				}
			}
			logger.warn(String.format("Filtered DataSet [%s] is Empty. Could not return top 1 row.", paramaterName));
			return new HashMap();
		}
	}

	private List resolveListParam(Type paramType, Annotation[] parameterAnnotations, String paramaterName, Map<String, List<Map>> datasets) {
		String datasetName = paramaterName;
		XPlatformRowType[] rowTypes = null;
		
		for(Annotation annotation : parameterAnnotations) {
			if(annotation instanceof VariableBind) {
				logger.warn(String.format("[%s] cannot bind with VariableBind Annotation", paramaterName));
				return null;
			} else if (annotation instanceof DatasetBind) {
				DatasetBind bind = (DatasetBind)annotation;
				datasetName = bind.value();
				rowTypes = bind.rowTypeFilter();
				break;
			} else if (annotation instanceof ParamBind) {
				ParamBind bind = (ParamBind)annotation;
				datasetName = bind.value();
			}
		}

		if(datasets.get(datasetName) == null) {
			return null;
		}
		
		ParameterizedType type = (ParameterizedType)paramType;
		Class genericType = genericType = (Class) (type.getActualTypeArguments().length > 0 ? type.getActualTypeArguments()[0] : null);;
		if(rowTypes == null || rowTypes.length < 1) {
			if(Map.class.isAssignableFrom(genericType)) {
				return datasets.get(datasetName);
			} else if (AbstractDto.class.isAssignableFrom(genericType)) {
				List listParam = new ArrayList();
				for(Map map : datasets.get(datasetName)) {
					listParam.add(DtoCopyUtils.fromMap(map, genericType));
				}
				return listParam;
			} else {
				logger.warn(String.format("DataSet [%s] generic argument must implements java.util.Map or extends AbstractDto.", paramaterName));
				return null;
			}
		} else {
			List<Map> filteredList = new ArrayList<Map>();
			
			for(Map map : datasets.get(datasetName)) {
				for(XPlatformRowType rowType : rowTypes) {
					if(XPlatformUtil.getDataRowType(map).equals(rowType.value())) {
						filteredList.add(map);
						continue;
					}
				}
			}
			
			if(Map.class.isAssignableFrom(genericType)) {
				
				return filteredList;
			} else if (AbstractDto.class.isAssignableFrom(genericType)) {
				List listParam = new ArrayList();
				for(Map map : filteredList) {
					listParam.add(DtoCopyUtils.fromMap(map, genericType));
				}
				return listParam;
			} else {
				logger.warn(String.format("DataSet [%s] generic argument must implements java.util.Map or AbstractDto.", paramaterName));
				return null;
			}
		}
	}

	@Override
	protected ClientType getClientType(BomRequestInfo reqInfo) {
		return XPLATFORM;
	}
	
	

	@Override
	protected HtcXplatformMessage handleError(Position position, HtcXplatformMessage requestMessage,
			BomRequestInfo requestInfo, Throwable e) {
		return super.handleError(position, requestMessage, requestInfo, e);
	}

	@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected HtcXplatformMessage buildMessage(Object... params) throws TxMessageException {
		HtcXplatformMessage requestMessage = (HtcXplatformMessage)params[0];
		Object returnObj = params[2];
		ServiceMethod serviceMethod = (ServiceMethod)params[3];
		
		
		HtcXplatformMessage responseMessage = new HtcXplatformMessage();
		SystemHeader header = requestMessage.getHeader();
		header.setResponseCode(HtcConstants.RESPONSE_CODE_SUCCESS);
		responseMessage.setHeader(header);
		
		resolveMessageReturn(responseMessage);
		
		if(returnObj == null) {
			return responseMessage;
		}
		ReturnBind bind = serviceMethod.getMethod().getAnnotation(ReturnBind.class);
		
		if(Collection.class.isAssignableFrom(returnObj.getClass()) || Map.class.isAssignableFrom(returnObj.getClass())) {
			if(bind != null && StringUtils.hasText(bind.value())) {
				if(List.class.isAssignableFrom(returnObj.getClass())) {
					List list = (List) returnObj;
					for(int i = 0; i < list.size(); i++) {
						Object obj = list.get(i);
						if(!Map.class.isAssignableFrom(obj.getClass()) && AbstractDto.class.isAssignableFrom(obj.getClass())) {
							list.set(i, DtoCopyUtils.toMap(list.get(i)));
						}
					}
					responseMessage.getDatasets().put(bind.value(), (List) returnObj);
				} else if (Map.class.isAssignableFrom(returnObj.getClass())) {
					List list = new ArrayList();
					list.add(returnObj);
					responseMessage.getDatasets().put(bind.value(), list);
				} else if (AbstractDto.class.isAssignableFrom(returnObj.getClass())) {
					Map dataMap = DtoCopyUtils.toMap(returnObj);
					List list = new ArrayList();
					list.add(dataMap);
					responseMessage.getDatasets().put(bind.value(), list);
				} else {
					throw new RuntimeException(String.format("Cannot Resolve return type.", returnObj.getClass().getCanonicalName()));
				}
			} else if(Map.class.isAssignableFrom(returnObj.getClass())){
				try {
					responseMessage.setDatasets((Map<String, List<Map>>) returnObj);
				} catch (ClassCastException e) {
					logger.error("Cannot Resolve return value.", e);
					throw e;
				}
			} else {
				throw new RuntimeException(String.format("Cannot Resolve return type.", returnObj.getClass().getCanonicalName()));
			}
		} else if(AbstractDto.class.isAssignableFrom(returnObj.getClass())) {
			if(bind != null && StringUtils.hasText(bind.value())) {
				if(List.class.isAssignableFrom(returnObj.getClass())) {
					responseMessage.getDatasets().put(bind.value(), (List) returnObj);
				} else if (Map.class.isAssignableFrom(returnObj.getClass())) {
					List list = new ArrayList();
					list.add(returnObj);
					responseMessage.getDatasets().put(bind.value(), list);
				}
			}
		} else {
			if(bind != null && StringUtils.hasLength(bind.value())) {
				responseMessage.getVariables().put(bind.value(), returnObj);
			}
		}
		
		return responseMessage;
	}

	private void resolveMessageReturn(HtcXplatformMessage responseMessage) {
		String messageId = (String) RequestContextHolder.getRequestContext().getAttribute(MessageUtil.MESSAGE_ID_KEY);
		if(messageId == null) {
			return;
		}
		String[] messageParams = (String[]) RequestContextHolder.getRequestContext().getAttribute(MessageUtil.MESSAGE_PARAMS_KEY);
		String message = (String) RequestContextHolder.getRequestContext().getAttribute(MessageUtil.MESSAGE_KEY);
		
		if(message == null || "".equals(message)) {
			message = MessageUtil.makeMessage(messageId, messageParams);
		}

		List<Map> messageList = MessageUtil.toMassageList(messageId, message);
		
		responseMessage.getDatasets().put(MessageUtil.MESSAGE_DATASET_NAME, messageList);
	}

	@Override
	protected HtcXplatformMessage buildErrorMessage(Object... params) throws TxMessageException {
		HtcXplatformMessage requestMessage = (HtcXplatformMessage) params[1];
		Exception ex = (Exception)params[2];
		
		HtcXplatformMessage responseMessage = new HtcXplatformMessage();
		responseMessage.setHeader(requestMessage.getHeader());
//		responseMessage.getHeader().setResponseCode(MessageUtil.DEFAULT_ERROR_ID);
//		responseMessage.getHeader().setResponseMessage(ex.getMessage());
		responseMessage.setVariables(requestMessage.getVariables());
		
		/**
		 * dsMessage 방식에서 ERROR_CODE 방식으로 변경하기로 함.
		Map<String, List<Map>> dsList = new HashMap<String, List<Map>>();
		dsList.put(MessageUtil.MESSAGE_DATASET_NAME, MessageUtil.toMassageList(MessageUtil.DEFAULT_ERROR_ID, MessageUtil.DEFAULT_ERROR_MESSAGE));
		responseMessage.setDatasets(dsList);
		**/
		
		Map<String, Object> variables = new HashMap<String, Object>();
		String errorMessage = null;
		if(StringUtils.hasText(BomRequestHolder.getRequestInfo().getTxCode())) {
			errorMessage = MessageUtil.DEFAULT_ERROR_MESSAGE + " [" + BomRequestHolder.getRequestInfo().getTxCode() + "]";
		} else {
			errorMessage = MessageUtil.DEFAULT_ERROR_MESSAGE;
		}
		variables.put("ErrorCode", MessageUtil.DEFAULT_ERROR_CODE);
		variables.put("ErrorMsg", errorMessage);
		responseMessage.setVariables(variables);
		return responseMessage;
	}

	@Override
	protected void handlePostExecution(Object rtn, BomRequestInfo requestInfo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void handlePreExecution(Object[] parameters, BomRequestInfo requestInfo,
			HtcXplatformMessage requestMessage) {
		// TODO Auto-generated method stub
		
	}

}
