package htc.xplatform.message;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.tobesoft.xplatform.data.DataSet;
import com.tobesoft.xplatform.data.Variable;

import htc.hone.core.message.HtcMessageEnvelop;
import htc.hone.core.message.SystemHeader;

public class HtcXplatformMessage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1982443166925449206L;

	private SystemHeader header;
	private Map<String, Object> variables;
	private Map<String, List<Map>> datasets;
	
	public HtcXplatformMessage() {
		this.variables = new HashMap<String, Object>();
		this.datasets = new HashMap<String, List<Map>>();
	}
	
	public SystemHeader getHeader() {
		return header;
	}
	public void setHeader(SystemHeader header) {
		this.header = header;
	}
	public Map<String, Object> getVariables() {
		return variables;
	}
	public void setVariables(Map<String, Object> variables) {
		this.variables = variables;
	}
	public Map<String, List<Map>> getDatasets() {
		return datasets;
	}
	public void setDatasets(Map<String, List<Map>> datasets) {
		this.datasets = datasets;
	}
}
