package htc.xplatform.web.support;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tobesoft.xplatform.data.DataSet;
import com.tobesoft.xplatform.data.DataSetList;
import com.tobesoft.xplatform.data.PlatformData;
import com.tobesoft.xplatform.data.VariableList;
import com.tobesoft.xplatform.tx.HttpPlatformRequest;
import com.tobesoft.xplatform.util.PlatformGlobals;

import hone.bom.binding.utils.DtoCopyUtils;
import hone.bom.context.request.RequestContext;
import hone.bom.context.request.RequestContextHolder;
import htc.commons.paging.PagingSupport;
import htc.hone.core.message.SystemHeader;
import htc.hone.utils.ContextUtil;
import htc.xplatform.XplatformConstants;
import htc.xplatform.message.HtcXplatformMessage;
import htc.xplatform.web.HtcConstants;
import htc.xplatform.web.handler.XPlatformDataHandler;

public class XplatformDataParser {
	private static final Logger logger = LoggerFactory.getLogger(XplatformDataParser.class);
	private boolean camelizeMode = false;//client에서 사용하는 필드명이 camelcase 규칙이 아니라서 변환이 필요한 경우 true
//	private boolean onlyLogWhenError = false;//bind error 발생시 에러를 전달할것인지 에러 로깅만 남길것인지 여부. 기본값은 에러 발생.
//	
	private XPlatformDataHandler dataHandler;
	
	/**
	 * '_'를 구분자로 사용해 규칙을 적용한 컬럼의 변환 설정을 할것인지 여부 
	 * ex) user_id => userid
	 * @param underscoreMode
	 */
	public void setCamelizeMode(boolean camelizeMode) {
		this.camelizeMode = camelizeMode;
	}	
	
	public void setDataHandler(XPlatformDataHandler dataHandler) {
		this.dataHandler = dataHandler;
	}	
	

	
	public Object parse(HttpPlatformRequest httpPlatformRequest,
			HttpServletRequest request) {
		PlatformData platformData = httpPlatformRequest.getData();
		if(logger.isDebugEnabled()) {
			logger.debug("    Request Variable & DataSet debug");
			logger.debug(platformData.saveXml());
		}
		
		RequestContext requestContext = RequestContextHolder.getRequestContext();
		requestContext.setAttribute(XplatformConstants.XPLATFORM_DATA_NAME, platformData);
		requestContext.setAttribute("requestUri", request.getRequestURI());
		
		HtcXplatformMessage dto = new HtcXplatformMessage();
		SystemHeader header = new SystemHeader();
		Map<String, Object> variableMap = new HashMap<String, Object>();
		Map<String, List<Map>> datasetMap = new HashMap<String, List<Map>>();
		
		if (dataHandler != null) {
			dataHandler.preHandle(platformData.getVariableList(), platformData.getDataSetList());
		}
		
		convertVariables(platformData.getVariableList(), header, variableMap);
		convertDatasets(platformData.getDataSetList(), datasetMap);
		ContextUtil.setHeader(header);
		ContextUtil.setHttpServletRequest(request);
		
		if(platformData.getDataSet(HtcConstants.XPLATFORM_BIND_PAGING_NAME) != null) {
			PagingSupport paging = new PagingSupport();
			DataSet dsPage = platformData.getDataSet(HtcConstants.XPLATFORM_BIND_PAGING_NAME);
			int pageNo = dsPage.getInt(0, PagingSupport.DATASET_PAGE_NO_KEY);
			int pageSize = dsPage.getInt(0, PagingSupport.DATASET_PAGE_SIZE_KEY);
			paging.setPageNo(pageNo);
			paging.setPageSize(pageSize);
			
			ContextUtil.setPaging(paging);
		}
		

		dto.setHeader(header);
		dto.setVariables(variableMap);
		dto.setDatasets(datasetMap);
		return dto;
	}

	private void convertDatasets(DataSetList dataSetList, Map<String, List<Map>> datasetMap) {
		for(int i = 0; i < dataSetList.size(); i++) {
			String name = dataSetList.get(i).getName();
			datasetMap.put(name, convertDatasetToMap(dataSetList.get(i)));
		}
		
	}

	private void convertVariables(VariableList variableList, SystemHeader header, Map<String, Object> variableMap) {
		for(int i = 0; i < variableList.size(); i++) {
			variableMap.put(variableList.get(i).getName(), variableList.get(i).getObject());
			/*
			String key = platformData.getVariableList().get(i).getName();
			if(!HtcConstants.GLOBAL_VARIABLES_META.containsKey(key)) {
				variableMap.put(platformData.getVariableList().get(i).getName(), platformData.getVariableList().get(i).getObject());
				continue;
			}
			
			String fieldName = HtcConstants.GLOBAL_VARIABLES_META.get(key);
			Field field = ReflectionUtils.findField(SystemHeader.class, fieldName);
			if(field == null) {
				variableMap.put(platformData.getVariableList().get(i).getName(), platformData.getVariableList().get(i).getObject());
				continue;
			}
			
			ReflectionUtils.makeAccessible(field);
			ReflectionUtils.setField(field, header, platformData.getVariableList().get(i).getObject());
			*/
		}
		DtoCopyUtils.fromMap(variableMap, header, false);
	}


	private List<Map> convertDatasetToMap(DataSet dataSet) {
		List<String> keys = new ArrayList<String>();
		List<Map> datas = new ArrayList<Map>();
		
		for(int i = 0; i < dataSet.getColumnCount(); i++) {
			keys.add(dataSet.getColumn(i).getName());
		}
		
		// NORMAL, INSERTED, UPDATED Row 가져오기
		for(int rowIndex = 0; rowIndex < dataSet.getRowCount(); rowIndex++) {
			Map<String, Object> ds = new HashMap<String, Object>();
			for(int j = 0; j < keys.size(); j++) {
				ds.put(keys.get(j), dataSet.getObject(rowIndex, j));
			}
			String rowType = convertRowType(dataSet.getRowType(rowIndex));
			ds.put(HtcConstants.DATASET_ROW_TYPE_KEY, rowType);
			datas.add(ds);
		}
		
		// DELETED Column은 다른 방법으로 가져와야 함.
		for(int rowIndex = 0; rowIndex < dataSet.getRemovedRowCount(); rowIndex++) {
			Map<String, Object> ds = new HashMap<String, Object>();
			for(int j = 0; j < keys.size(); j++) {
				ds.put(keys.get(j), dataSet.getRemovedData(rowIndex, j));
			}
			String rowType = HtcConstants.DATASET_ROW_TYPE_DELETED;
			ds.put(HtcConstants.DATASET_ROW_TYPE_KEY, rowType);
			datas.add(ds);
		}
		
		return datas;
	}

	
	private String convertRowType(int rowTypeKey) {
		String rowType;
		switch (rowTypeKey) {
			case DataSet.ROW_TYPE_NORMAL:
				rowType = HtcConstants.DATASET_ROW_TYPE_NORMAL;
				break;
			case DataSet.ROW_TYPE_INSERTED:
				rowType = HtcConstants.DATASET_ROW_TYPE_INSERTED;
				break;
			case DataSet.ROW_TYPE_UPDATED:
				rowType = HtcConstants.DATASET_ROW_TYPE_UPDATED;
				break;
			case DataSet.ROW_TYPE_DELETED:
				rowType = HtcConstants.DATASET_ROW_TYPE_DELETED;
				break;
			default:
				rowType = HtcConstants.DATASET_ROW_TYPE_NORMAL;
		}

		return rowType;
	}

}
