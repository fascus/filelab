package htc.xplatform.message;

import java.util.HashMap;

import com.tobesoft.xplatform.data.DataSet;

@Deprecated
public class XPlatformDataSet extends HashMap<String, Object> {
	public enum RowType {
		NORMAL(DataSet.ROW_TYPE_NORMAL)
		, INSERT(DataSet.ROW_TYPE_INSERTED)
		, DELETE(DataSet.ROW_TYPE_DELETED)
		, REMOVE(DataSet.ROW_TYPE_REMOVED)
		, UPDATE(DataSet.ROW_TYPE_UPDATED);
		
		
		private int rowType;
		
		RowType(int rowType) {
			this.rowType = rowType;
		}
		
		public int getRowType() {
			return rowType;
		}
		
		public static RowType valueOf(int i) {
			 for(RowType rt : values()) {
				 if(rt.getRowType() == i) {
					 return rt;
				 }
			 }
			 return RowType.NORMAL;
		}
	}
	
	private RowType rowType;
	
	
	public XPlatformDataSet() {
		this.rowType = RowType.NORMAL;
	}
	
	public RowType getRowType() {
		return this.rowType;
	}
	
	public void setRowType(RowType rowType) {
		this.rowType = rowType;
	}
	
	public void setRowType(int rowType) {
		this.rowType = RowType.valueOf(rowType);
	}
}
