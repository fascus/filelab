package htc.xplatform.web.support;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.tobesoft.xplatform.data.DataSet;
import com.tobesoft.xplatform.data.DataSetList;
import com.tobesoft.xplatform.data.PlatformData;
import com.tobesoft.xplatform.data.Variable;
import com.tobesoft.xplatform.data.VariableList;
import com.tobesoft.xplatform.tx.HttpPlatformRequest;

import hone.bom.BomException;
import hone.bom.binding.utils.DtoCopyUtils;
import hone.bom.context.request.RequestContext;
import hone.bom.context.request.RequestContextHolder;
import htc.hone.core.message.SystemHeader;
import htc.hone.utils.ContextUtil;
import htc.xplatform.XplatformConstants;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.message.HtcXplatformMessage;
import htc.xplatform.web.HtcConstants;
import htc.xplatform.web.handler.XPlatformDataHandler;

/**
 * @author swa
 *
 */
public class XPlatformRiaArgumentResolver implements HandlerMethodArgumentResolver {
	
	
	
	private static final Logger logger = LoggerFactory.getLogger(XPlatformRiaArgumentResolver.class);
	private XplatformDataParser parser = null;
	
	public boolean supportsParameter(MethodParameter parameter) {
		return HtcXplatformMessage.class.isAssignableFrom(parameter.getParameterType());
	}

	public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer,
			NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
		
		Class<?> type = parameter.getParameterType();
		HttpServletRequest request = (HttpServletRequest) webRequest.getNativeRequest();
		
		HttpPlatformRequest httpPlatformRequest = null;

		try {
			
			
			httpPlatformRequest = new HttpPlatformRequest(request);
			httpPlatformRequest.receiveData();
			
		} catch (Exception ex) {
			ex.getStackTrace();
			throw new Exception("HttpPlatformRequest error");
		}

		/*
		 * HttpPlatformRequest 에서 VariableList 와 DatasetList 를 뽑아 결정된 Map
		 * 형태(example : ModelMap) 또는 VO 객체에 담아 return 한다.
		 */
		if(parser == null) {
			throw new BomException("XPlatform Data Parser is not initilized");
		}
		Object dto = parser.parse(httpPlatformRequest, request);
//		Object dto = parseMessageDto(httpPlatformRequest, request);

		return dto;
	}


	public void setParser(XplatformDataParser parser) {
		this.parser = parser;
	}
}
