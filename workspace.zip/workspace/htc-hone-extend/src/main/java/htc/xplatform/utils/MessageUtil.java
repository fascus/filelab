package htc.xplatform.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.tobesoft.xplatform.data.DataSet;
import com.tobesoft.xplatform.data.DataSetList;
import com.tobesoft.xplatform.data.DataTypes;

import hone.bom.context.ApplicationContextHolder;
import hone.bom.context.request.RequestContextHolder;
import htc.hone.core.message.support.MessageSupport;

/**
 * 각종 메세지를 처리하기 위한 Util 
 * @author taehoon
 *
 */
public class MessageUtil {
	public static final String MESSAGE_ID_KEY = "__MESSAGE__ID";
	public static final String MESSAGE_PARAMS_KEY = "__MESSAGE__PARAMS";
	public static final String MESSAGE_KEY = "__MESSAGE";
	
	public static final String DEFAULT_INFO_ID = "I0001";
	public static final String DEFAULT_ERROR_ID = "E0001";
	public static final int DEFAULT_ERROR_CODE = -100;
	public static final String DEFAULT_ERROR_MESSAGE = "시스템 오류입니다. 담당자에게 문의시하기 바랍니다.";
	
	public static final String MESSAGE_DATASET_NAME = "message";
	public static final String MESSAGE_DATASET_MESSAGE_ID_KEY = "MESSAGE_ID";
	public static final String MESSAGE_DATASET_MESSAGE_KEY = "MESSAGE";
	/**
	 * UI에 전달할 메세지를 Thread Local 객체에 담아준다. 
	 * @param messageId
	 * @param messageParams
	 */
	public static void setMessage(String messageId, String... messageParams) {
		RequestContextHolder.getRequestContext().setAttribute(MESSAGE_ID_KEY, messageId);
		RequestContextHolder.getRequestContext().setAttribute(MESSAGE_PARAMS_KEY, messageParams);
	}
	
	/**
	 * Thread Local에 담긴 메세지를 제거하여 UI에 전달하지 않도록 한다. 
	 */
	public static void removeMessage() {
		RequestContextHolder.getRequestContext().removeAttribute(MESSAGE_ID_KEY);
		RequestContextHolder.getRequestContext().removeAttribute(MESSAGE_PARAMS_KEY);
	}
	
	/**
	 * 메세지를 조립해준다.
	 * @param messageId
	 * @param messageParams
	 * @return
	 */
	public static String makeMessage(String messageId, String... messageParams) {
		return ApplicationContextHolder.getBean(MessageSupport.class).buildMessage(messageId, messageParams);
	}
	
	/**
	 * 사전 정의되어 있지 않은 Info성 메세지 등록
	 * @param message
	 */
	public static void setCustomInfoMessage(String message) {
		setCustomMessage(MessageUtil.DEFAULT_INFO_ID, message);
	}
	
	/**
	 * 사전 정의되어 있지 않은 Error성 메세지 등록
	 * @param message
	 */
	public static void setCustomErrorMessage(String message) {
		setCustomMessage(MessageUtil.DEFAULT_ERROR_ID, message);
	}
	
	/**
	 * 사용자가 직접 지정한 메세지코드 및 메세지를 담는다. 해당 기능은 직접 사용을 지양하도록 한다.
	 * @param messageId
	 * @param message
	 */
	public static void setCustomMessage(String messageId, String message) {
		RequestContextHolder.getRequestContext().setAttribute(MESSAGE_ID_KEY, messageId);
		RequestContextHolder.getRequestContext().removeAttribute(MESSAGE_PARAMS_KEY);
		RequestContextHolder.getRequestContext().setAttribute(MESSAGE_KEY, message);
	}

	public static List<Map> toMassageList(String messageId, String message) {
		List<Map> messageList = new ArrayList<Map>();
		Map<String, Object> messageMap = new HashMap<String, Object>();
		messageMap.put(MESSAGE_DATASET_MESSAGE_ID_KEY, messageId);
		messageMap.put(MESSAGE_DATASET_MESSAGE_KEY, message);
		messageList.add(messageMap);
		return messageList;
	}
	
	public static DataSetList makeMessageDataSetList(String messageId, String message) {
		DataSet dataSet = new DataSet("ds" + MessageUtil.MESSAGE_DATASET_NAME.substring(0, 1).toUpperCase() + MessageUtil.MESSAGE_DATASET_NAME.substring(1));
		dataSet.addColumn(MessageUtil.MESSAGE_DATASET_MESSAGE_ID_KEY, DataTypes.STRING);
		dataSet.addColumn(MessageUtil.MESSAGE_DATASET_MESSAGE_KEY, DataTypes.STRING);
		
		dataSet.newRow();
		dataSet.set(0, MessageUtil.MESSAGE_DATASET_MESSAGE_ID_KEY, messageId);
		dataSet.set(0, MessageUtil.MESSAGE_DATASET_MESSAGE_KEY, message);
		
		DataSetList dsList = new DataSetList();
		dsList.add(dataSet);
		return dsList;
	}
	
	
}
