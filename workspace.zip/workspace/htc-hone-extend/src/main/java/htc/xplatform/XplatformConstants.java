package htc.xplatform;

public class XplatformConstants {
	public static final String CLIENT_KEY = "XPLATFORM";
	
	public static final String DEFAULT_ENCODING = "utf-8";
	
	public static final String PLATFORM_DATA_SESSION_KEY = "_platform_data";
	
	public static final String CLIENT_TYPE = "XPLATFORM";
	public static final String VIEW_NAME = "xplatformView";
	
	public static final String DS_ROW_TYPE_INS = "ins";//DataSet.ROW_TYPE_INSERTED  
	public static final String DS_ROW_TYPE_UPD = "upd";//DataSet.ROW_TYPE_UPDATED
	public static final String DS_ROW_TYPE_DEL = "del";//DataSet.ROW_TYPE_DELETED
	
	public static final String DS_IN_SEARCH_PARAMS = "inds_paramInfo";//검색,페이징정보가 전달되는 IN 데이터셋
	public static final String DS_OUT_SEARCH_PARAMS = "outds_paramInfo";//검색,페이징정보가 전달되는 OUT 데이터셋
	public static final String DS_PAGE_CURRENT_PAGE_ID = "currentPage";//현재페이지정보 컬럼 아이디
	public static final String DS_PAGE_TOT_CNT_ID = "totalCount";//현재페이지정보 컬럼 아이디
	public static final String DS_PAGE_ROW_SIZE_ID = "volumePerPage";//현재페이지정보 컬럼 아이디
	
	public static final String XPLATFORM_DATA_NAME = "XPLATFORM_DATA";
}
