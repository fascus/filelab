drop table if exists USERS;
CREATE TABLE USERS (
	USER_ID VARCHAR(100) PRIMARY KEY
	, USER_NAME VARCHAR(100)
	, PASSWORD VARCHAR(100)
	, EMAIL VARCHAR(100)
	, AUTHORITY VARCHAR(100)
	
);
INSERT INTO USERS VALUES('admin', 'ADMIN', 'admin', 'admin@hanwha.com', 'ROLE_ADMIN');
INSERT INTO USERS VALUES('user', '사용자', 'user', 'user@hanwha.com', 'ROLE_USER');

DROP TABLE IF EXISTS ARTICLES;
CREATE TABLE ARTICLES (
	TITLE VARCHAR(200) PRIMARY KEY
	, CONTENT VARCHAR(2000)
	, POST_DATE DATE
);

INSERT INTO ARTICLES VALUES ('Title', '글의내용이 길게 써질텐데 아직 잘 모름', CURRENT_DATE);

drop table if exists oauth_access_token;
create table oauth_access_token (
  token_id VARCHAR(255),
  token BLOB,
  authentication_id VARCHAR(255),
  user_name VARCHAR(255),
  client_id VARCHAR(255),
  authentication BLOB,
  refresh_token VARCHAR(255)
);

drop table if exists oauth_refresh_token;
create table oauth_refresh_token (
  token_id VARCHAR(255),
  token BLOB,
  authentication BLOB
);

DROP TABLE IF EXISTS CATEGORY;
CREATE TABLE CATEGORY (
	ID VARCHAR(100),
	NAME VARCHAR(100),
	DESCRIPTION VARCHAR(2000),
	VIEW_ORDER INTEGER, 
	USE_YN CHAR(1),
	REG_USER VARCHAR(100), 
	REG_DTM DATE
)
;

INSERT INTO CATEGORY
VALUES('NEWS', '뉴스', null,  null, 'Y', 'minji', CURRENT_DATE);
INSERT INTO CATEGORY
VALUES('BLOG', '블로그', '올록블록', 99, 'Y', 'minji', NULL);

DROP TABLE IF EXISTS MESSAGE;
CREATE TABLE MESSAGE (
	MESSAGE_ID VARCHAR(100),
	MESSAGE VARCHAR(300)
)
;

INSERT INTO MESSAGE
VALUES('I0001', '샘플 인포 ''{}''');
INSERT INTO MESSAGE
VALUES('E0001', '{}랑 {} 때문에 아파요.');
