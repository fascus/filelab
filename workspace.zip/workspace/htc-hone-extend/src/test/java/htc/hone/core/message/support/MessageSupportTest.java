package htc.hone.core.message.support;

import org.junit.Test;

public class MessageSupportTest {

	@Test
	public void testBuildMessage() throws Exception {
		MessageSupport messageSupport = new MessageSupport();
		messageSupport.setRepository(new MessageRepository() {
			@Override
			public String getMessage(String messageId) {
				return "안녕하세요 '{}'입니다. 그래서 '{}'합니다.";
			}
		});
		
		
		printTest(messageSupport, "물개", "짝짝");
		printTest(messageSupport, "호랭이");
		printTest(messageSupport, "오리", "꽦", "꽥");
		printTest(messageSupport, null);
		printTest(messageSupport, new String[0]);
		printTest(messageSupport, new String[1]);
		printTest(messageSupport, new String[2]);
		printTest(messageSupport, new String[3]);
	}

	private void printTest(MessageSupport messageSupport, String...strings ) {
		String val = "";
		if(strings == null) {
			val = "null";
		} else if (strings.length < 1) {
			val = "[]";
		} else {
			for(String s : strings) {
				val += "[" + s + "]";
			}
		}
		
		val += " ===> " + messageSupport.buildMessage("", strings);
		System.out.println(val);
	}
}
