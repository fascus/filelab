package htc.hone.web.servlet;

import static org.junit.Assert.*;

import org.apache.commons.io.FilenameUtils;
import org.junit.Test;

public class FileUploadServletTest {

	@Test
	public void testFileNameUtils() throws Exception {
		String fname = "D:\\aswdf\\dddd/FIFIFI\\gogi.jp";
		String f2name = "/whoaim\\mall";
		print("[" + fname + "]");
		print("getBaseName="+FilenameUtils.getBaseName(fname));
		print("getExtension="+FilenameUtils.getExtension(fname));
		print("getFullPath="+FilenameUtils.getFullPath(fname));
		print("getFullPathNoEndSeparator="+FilenameUtils.getFullPathNoEndSeparator(fname));
		print("getName="+FilenameUtils.getName(fname));
		print("getPathNoEndSeparator="+FilenameUtils.getPathNoEndSeparator(fname));
		print("getPrefix="+FilenameUtils.getPrefix(fname));
		print("getPrefixLength="+FilenameUtils.getPrefixLength(fname)+"");
		print("[" + f2name + "]");
		print("getBaseName="+FilenameUtils.getBaseName(f2name));
		print("getExtension="+FilenameUtils.getExtension(f2name));
		print("getFullPath="+FilenameUtils.getFullPath(f2name));
		print("getFullPathNoEndSeparator="+FilenameUtils.getFullPathNoEndSeparator(f2name));
		print("getName="+FilenameUtils.getName(f2name));
		print("getPathNoEndSeparator="+FilenameUtils.getPathNoEndSeparator(f2name));
		print("getPrefix="+FilenameUtils.getPrefix(f2name));
		print("getPrefixLength="+FilenameUtils.getPrefixLength(f2name)+"");
	}

	private void print(String baseName) {
		System.out.println(baseName);
	}
}
