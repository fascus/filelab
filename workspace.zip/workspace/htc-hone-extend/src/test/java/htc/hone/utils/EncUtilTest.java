package htc.hone.utils;

import static org.junit.Assert.*;

import org.junit.Test;

public class EncUtilTest {
	@Test
	public void testEncrypt() throws Exception {
		String s = "고기말알";
		System.err.println(s);
		String t = EncUtil.encrypt(s);
		System.err.println(t);
		String u = EncUtil.encryptPassword(s);
		System.err.println(u);
	}
}
