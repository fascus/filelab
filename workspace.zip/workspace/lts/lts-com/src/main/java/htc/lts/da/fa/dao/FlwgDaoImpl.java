/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.fa.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 28. 오후 5:19:47
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 28.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class FlwgDaoImpl extends AbstractHtcDao implements FlwgDao {

    @Override
    public List inqureFlwgList(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.FlwgQuery.selectFlwgList", argument);
    }
    
    @Override
    public int updateFlwg(Map flwg) {
        return  update("htc.lts.da.fa.hqml.FlwgQuery.updateFlwg", flwg);
    }
    
    @Override
    public List inqureResultList(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.FlwgQuery.selectResultList", argument);
    }
    
    @Override
    public int insertFlwgPn(Map flwgPn) {
        return  update("htc.lts.da.fa.hqml.FlwgQuery.insertFlwgPn", flwgPn);
    }
    
    @Override
    public int deleteFlwgPn(Map flwgPn) {
        return  update("htc.lts.da.fa.hqml.FlwgQuery.deleteFlwgPn", flwgPn);
    }
    
    @Override
    public List inqureFlwgPnList(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.FlwgQuery.selectFlwgPnList", argument);
    }
    
    @Override
    public int insertFlwgPrplsPlan(Map flwgPrplsPlan) {
        return  update("htc.lts.da.fa.hqml.FlwgQuery.insertFlwgPrplsPlan", flwgPrplsPlan);
    }
    
    @Override
    public int updateFlwgPrplsPlan(Map flwgPrplsPlan) {
        return  update("htc.lts.da.fa.hqml.FlwgQuery.updateFlwgPrplsPlan", flwgPrplsPlan);
    }
    
    @Override
    public int deleteFlwgPrplsPlan(Map flwgPrplsPlan) {
        return  update("htc.lts.da.fa.hqml.FlwgQuery.deleteFlwgPrplsPlan", flwgPrplsPlan);
    }
    
    @Override
    public List inqureyFlwgPrplsplan(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.FlwgQuery.selectFlwgPrplsplan", argument);
    }
    
    @Override
    public int insertFlwgPrplsPrsts(Map flwgPrplsPlan) {
        return  update("htc.lts.da.fa.hqml.FlwgQuery.insertFlwgPrplsPrsts", flwgPrplsPlan);
    }
    
    @Override
    public int updateFlwgPrplsPrsts(Map flwgPrplsPlan) {
        return  update("htc.lts.da.fa.hqml.FlwgQuery.updateFlwgPrplsPrsts", flwgPrplsPlan);
    }
    
    @Override
    public int deleteFlwgPrplsPrsts(Map flwgPrplsPlan) {
        return  update("htc.lts.da.fa.hqml.FlwgQuery.deleteFlwgPrplsPrsts", flwgPrplsPlan);
    }
    
    @Override
    public List inqureyFlwgPrplsPrsts(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.FlwgQuery.inqureyFlwgPrplsPrsts", argument);
    }
    
    @Override
    public List inqureSysTestResultList(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.FlwgQuery.inqureSysTestResultList", argument);
    }
    
    @Override
    public List inqureFlwgActitm(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.FlwgQuery.inqureFlwgActitm", argument);
    }
    
    @Override
    public List inqureSpvsnDept(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.FlwgQuery.inqureSpvsnDept", argument);
    }
    
    @Override
    public List inqureCoprDept(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.FlwgQuery.inqureCoprDept", argument);
    }
    
    @Override
    public List inqureFollowAct(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.FlwgQuery.inqureFollowAct", argument);
    }
    
}
