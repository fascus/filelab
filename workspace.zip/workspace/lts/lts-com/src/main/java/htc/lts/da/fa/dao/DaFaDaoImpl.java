/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.fa.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 10:05:06
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class DaFaDaoImpl extends AbstractHtcDao implements DaFaDao {

    @Override
    public List inqureMtnList(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.DaFaQuery.inqureMtnList", argument);
    }
    
    @Override
    public List inqureCmplRptList(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.DaFaQuery.selectCmplRptList", argument);
    }
    
    @Override
    public List inqureSysTestList(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.DaFaQuery.selectSysTestList", argument);
    }

    @Override
    public int insertFollowActTask(Map argument) {
        return update("htc.lts.da.fa.hqml.DaFaQuery.insertFollowActTask", argument);
    }
    
    @Override
    public int updateFollowActTask(Map argument) {
        return update("htc.lts.da.fa.hqml.DaFaQuery.updateFollowActTask", argument);
    }
    
    @Override
    public int insertSpvsnDept(Map argument) {
        return update("htc.lts.da.fa.hqml.DaFaQuery.insertSpvsnDept", argument);
    }
    
    @Override
    public int deleteSpvsnDept(Map argument) {
        return update("htc.lts.da.fa.hqml.DaFaQuery.deleteSpvsnDept", argument);
    }
    
    @Override
    public int insertCoprDept(Map argument) {
        return update("htc.lts.da.fa.hqml.DaFaQuery.insertCoprDept", argument);
    }
    
    @Override
    public int deleteCoprDept(Map argument) {
        return update("htc.lts.da.fa.hqml.DaFaQuery.deleteCoprDept", argument);
    }
    
    @Override
    public List inqureFollowActTask(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.DaFaQuery.inqureFollowActTask", argument);
    }
    
    @Override
    public List inqureUserList(Map argument) {
        return queryForList("htc.lts.da.fa.hqml.DaFaQuery.selectUserList", argument);
    }
    
    @Override
    public List selectMimmIng(Map mngNo) {
        return queryForList("htc.lts.da.fa.hqml.DaFaQuery.selectMimmIng", mngNo);
    }
    
    @Override
    public int deleteFollowActTask(Map argument) {
        return update("htc.lts.da.fa.hqml.DaFaQuery.deleteFollowActTask", argument);
    }
    
    @Override
    public int updateYn(Map argument) {
        return update("htc.lts.da.fa.hqml.DaFaQuery.updateYn", argument);
    }
    
}
