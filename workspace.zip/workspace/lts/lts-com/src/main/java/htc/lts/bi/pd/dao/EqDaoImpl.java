/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 27. 오후 4:27:53
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 27.		변용수						CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class EqDaoImpl extends AbstractHtcDao implements EqDao {

	/**
	 * @see htc.lts.bi.pd.dao.EqDao#insertEq(java.util.Map)
	 * @Method Name        : insertEq
	 * @Method description : 
	 * @Date               : 2016. 9. 27.
	 * @Author             : 변용수
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 9. 27.		변용수						CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param eq
	*/

	@Override
	public int insertEq(Map eq) {
		return update("htc.lts.bi.pd.hqml.EqQuery.insertEq", eq);
	}
	
	/**
	 * @see htc.lts.bi.pd.dao.EqDao#updateEq(java.util.Map)
	 * @Method Name        : updateEq
	 * @Method description : 
	 * @Date               : 2016. 9. 27.
	 * @Author             : 변용수
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 9. 27.		변용수						CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param eq
	*/
	@Override
    public int updateEq(Map eq) {
        return update("htc.lts.bi.pd.hqml.EqQuery.updateEq", eq);
    }
	
	
	/**
     * @see htc.lts.bi.pd.dao.WrshpDao#inqureUserList(java.util.Map)
     * @Method Name        : inqureWrshpList
     * @Method description : 
     * @Date               : 2016. 9. 26.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 9. 26.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param user
     * @return
    */

    @Override
    public List inqureEqList(Map eq) {
        return queryForList("htc.lts.bi.pd.hqml.EqQuery.selectEqList", eq);
    }
    
    @Override
    public int deleteEq(Map eq) {
        return update("htc.lts.bi.pd.hqml.EqQuery.deleteEq", eq);
    }
    
    @Override
    public int deleteWrshpEq(Map eq) {
        return update("htc.lts.bi.pd.hqml.EqQuery.deleteWrshpEq", eq);
    }
}
