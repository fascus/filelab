package htc.lts.mi.om.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.mi.mm.service.UsePnServiceImpl;
import htc.lts.mi.om.dao.DsctnIdtfPlanDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:21:01
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class DsctnIdtfPlanServiceImpl implements DsctnIdtfPlanService {

    private static final Logger logger = LoggerFactory.getLogger(UsePnServiceImpl.class);
    
    @Autowired
    DsctnIdtfPlanDao dsctnIdtfPlanDao;
    

    @Override
    @ServiceId("MIOMS006")
    @ServiceName("단종관리계획서조회")
    @ReturnBind("output")
    public List<Map> inqureyDsctnIdtfPlan(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureyDsctnIdtfPlan, Input Param={}", searchParam); 
        }
        
            List<Map> dsctnIdtfPlanList = dsctnIdtfPlanDao.inqureyDsctnIdtfPlanList(searchParam);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureyDsctnIdtfPlan Output ={}", dsctnIdtfPlanList);
        }
        
        return dsctnIdtfPlanList;
    }
    
    @Override
    @ServiceId("MIOMX004")
    @ServiceName("단종관리완료보고저장")
    @ReturnBind("output")
    public int saveDsctnIdtfPlan(@DatasetBind("input") List<Map> DsctnIdtfPlanList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveDsctnIdtfCmplRpt, Input Param={}", DsctnIdtfPlanList); 
        }
        
        int result = 0;
        for (Map dsctnIdtfPlan : DsctnIdtfPlanList) {
                result += dsctnIdtfPlanDao.updateDsctnIdtfPlan(dsctnIdtfPlan);
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveDsctnIdtfCmplRpt Output ={}", result);
        }

        return result; 
    }
    
}
