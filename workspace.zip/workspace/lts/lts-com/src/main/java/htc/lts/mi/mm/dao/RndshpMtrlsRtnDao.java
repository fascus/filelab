/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.mm.dao;

import java.util.List;
import java.util.Map;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:59:07
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface RndshpMtrlsRtnDao {

    public List inqureRndshpMtrlsRtnPopList(Map rndshpMtrlsRtnPop);
    
    public List inqureRndshpMtrlsRtnList(Map rndshpMtrlsRtn);
    
    public List inqureMntEntpList(Map mntEntp);
    
    public int insertRndshpMtrlsRtn(Map rndshpMtrlsRtn);
    
    public int updateRndshpMtrlsRtn(Map rndshpMtrlsRtn);
  
    public int deleteRndshpMtrlsRtn(Map rndshpMtrlsRtn);
    
    public int updateMtnStartDt(Map rndshpMtrlsRtn);

    
}
    