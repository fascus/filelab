/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.bp.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 3:22:14
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class BreakDnDaoImpl extends AbstractHtcDao implements BreakDnDao {

    
    
    @Override
    public List searchOrgnz(Map searchParam) {
        return queryForList("htc.lts.mi.bp.hqml.BreakDnQuery.searchOrgnzList", searchParam);
    }
    
    @Override
    public int insertBreakDnDetail(Map bdList) {
        return  update("htc.lts.mi.bp.hqml.BreakDnQuery.insertBreakDnDetail", bdList);
    }
    
    @Override
    public List inqureRfnoCrtnAndDel(Map searchParam) {
        return queryForList("htc.lts.mi.bp.hqml.BreakDnQuery.inqureRfnoCrtnAndDel", searchParam);
    }
    
    @Override
    public int deleteBreakDnDetail(Map bdList) {
        return  update("htc.lts.mi.bp.hqml.BreakDnQuery.deleteBreakDnDetail", bdList);
    }
    
}
