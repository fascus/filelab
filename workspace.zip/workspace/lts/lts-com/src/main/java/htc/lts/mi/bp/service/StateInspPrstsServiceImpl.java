/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.bp.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.mi.bp.dao.MiBpDao;
import htc.lts.mi.bp.dao.StateInspPrstsDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 10:04:40
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class StateInspPrstsServiceImpl implements StateInspPrstsService {

    private static final Logger logger = LoggerFactory.getLogger(StateInspPrstsServiceImpl.class);
    
    @Autowired
    StateInspPrstsDao stateInspPrstsDao;
    
    @Override
    @ServiceId("MIBPS900")
    @ServiceName("완료보고조회")
    @ReturnBind("output")
    public List<Map> inqureStateInspPrsts(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureStateInspPrsts, Input Param={}", argument); 
        }
        
        List<Map> result = stateInspPrstsDao.inqureStateInspPrstsList(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureStateInspPrsts Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("MIBPS901")
    @ServiceName("완료보고조회")
    @ReturnBind("output")
    public List<Map> inqureyStateInspPrstsImg(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureStateInspPrsts, Input Param={}", argument); 
        }
        
        List<Map> result = stateInspPrstsDao.inqureyStateInspPrstsImgList(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureStateInspPrsts Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("MIBPX900")
    @ServiceName("사용부품증빙 저장")
    @ReturnBind("output")
    public int saveStateInspPrsts(@DatasetBind("input") List<Map> usePnList) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : saveUsePn, Input Param={}", usePnList); 
          }
        
          int result = 0;
          
          for (Map usePn : usePnList) {
      
                result += stateInspPrstsDao.updateStateInspPrsts2(usePn);
                //result += stateInspPrstsDao.updateStateInspPrsts3(usePn);

          }
                 

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : saveUsePn Output ={}", result);
          }

          return result; 
    }
    
}