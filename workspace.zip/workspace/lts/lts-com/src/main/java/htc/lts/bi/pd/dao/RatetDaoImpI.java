/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.dao;

import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 11. 5. 오전 11:12:22
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 11. 5.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class RatetDaoImpI extends AbstractHtcDao implements RateDao {

   
    /**
     * @see htc.lts.bi.pd.dao.RateDao#insertRateList(java.util.Map)
     * @Method Name        : insertRateList
     * @Method description : 
     * @Date               : 2016. 11. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param RateList
     * @return
    */
    @Override
    public List inqureStandard(Map StandardList) {
        return  queryForList("htc.lts.bi.pd.hqml.RateQuery.selectStandardList", StandardList);
    }
    @Override
    public List inqureCost(Map CostList) {
        return  queryForList("htc.lts.bi.pd.hqml.RateQuery.selectCostList", CostList);
    }
    @Override
    public List inqureManday(Map MandayList) {
        return  queryForList("htc.lts.bi.pd.hqml.RateQuery.selectManday", MandayList);
    }
    @Override
    public List inqureRate(Map RateList) {
        return  queryForList("htc.lts.bi.pd.hqml.RateQuery.selectRateList", RateList);
    }
    @Override
    public List inqureLbcst(Map LbcstList) {
        return  queryForList("htc.lts.bi.pd.hqml.RateQuery.selectLbcstList", LbcstList);
    }@Override
    public List inqureOutsc(Map outscList) {
        return  queryForList("htc.lts.bi.pd.hqml.RateQuery.selectOutscList", outscList);
    }
    @Override
    public List inqureCostMain(Map CostMainList) {
        return  queryForList("htc.lts.bi.pd.hqml.RateQuery.selectCostMainList", CostMainList);
    }
    @Override
    public List inqureApply(Map applyList) {
        return  queryForList("htc.lts.bi.pd.hqml.RateQuery.selectApplyList", applyList);
    }
    @Override
    public List inqueryMfgTimeList(Map mfgTimeList) {
        return  queryForList("htc.lts.bi.pd.hqml.RateQuery.selectMfgTimeList", mfgTimeList);
    }
    
    
    @Override
    public int insertCostMain(Map costmain) {
        return  update("htc.lts.bi.pd.hqml.RateQuery.insertCostMain", costmain);
    }
    @Override
    public int updateCostMain(Map costmain) {
        return  update("htc.lts.bi.pd.hqml.RateQuery.updateCostMain", costmain);
    }
    @Override
    public int updateAmount(Map amount) {
        return  update("htc.lts.bi.pd.hqml.RateQuery.updateAmount", amount);
    }
    
}
