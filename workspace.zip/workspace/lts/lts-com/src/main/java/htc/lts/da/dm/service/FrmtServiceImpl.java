package htc.lts.da.dm.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;
import htc.lts.da.dm.dao.DataDao;
import htc.lts.da.dm.dao.FrmtDao;


/**
 * @Class KorName : 양식함관리
 * @Date		  : 2016. 10. 14. 오후 1:27:19
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 14.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class FrmtServiceImpl implements FrmtService{

    private static final Logger logger = LoggerFactory.getLogger(FrmtServiceImpl.class);
    
    @Autowired
    private FrmtDao frmtDao;
    
    @Autowired
    private DataDao dataDao;
    
    /**
     * @see htc.lts.da.dm.service.FrmtService#inqureFrmt(java.util.Map)
     * @Method Name        : inqureFrmt
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("DADMS301")
    @ServiceName("오류보고내역 조회")
    @ReturnBind("output")
    public List<Map> inqureFrmt(@DatasetBind("input")Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureFrmt, Input Param={}", searchParam);
        } 
        
        List<Map> FrmtList = frmtDao.inqureFrmtList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFrmt Output ={}", FrmtList);
        }
        
        return FrmtList;
    }
    
 
    /**
     * @see htc.lts.da.dm.service.FrmtService#insertFrmtList(java.util.List)
     * @Method Name        : insertFrmtList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("DADMS302")
    @ServiceName("회의자료저장")
    @ReturnBind("output")
    public int insertFrmtList(@DatasetBind("input") List<Map> searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : insertFrmtList, Input Param={}", searchParam); 
        }
        
        int result = 0;
        for (Map FrmtList : searchParam) {
            String rowType = XPlatformUtil.getDataRowType(FrmtList);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    result += frmtDao.insertFrmtList(FrmtList);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += frmtDao.updateFrmtList(FrmtList);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += frmtDao.deleteFrmtList(FrmtList);
            }
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertFrmtList Output ={}", result);
        }
        return result; 
    }
    
    /**
     * @see htc.lts.da.dm.service.FrmtService#inqureFile(java.util.Map)
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("DADMS303")
    @ReturnBind("output")
    public List<Map> inqureFile(@DatasetBind("input") Map argument) {
        
        argument.put("FILENO", argument.get("FRMT_ATCHFL_NO"));
        List<Map> result = dataDao.inqureFile(argument);
        
        return result;
    }

}
