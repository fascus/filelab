/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.dao;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 11. 11. 오후 7:22:35
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 11. 11.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface PrdcstDao {

	/**
     * @Method Name        : insertPrdcst
     * @Method description : 
     * @Date               : 2016. 11. 11.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 11.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param prdcst
     * @return
    */
    public int insertPrdcst(Map prdcst);
    

    /**
     * @Method Name        : updateResident
     * @Method description : 
     * @Date               : 2016. 11. 11.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 11.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param prdcst
     * @return
    */
    public int updatePrdcst(Map prdcst);
    

    /**
     * @Method Name        : deleteResident
     * @Method description : 
     * @Date               : 2016. 11. 11.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 11.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param prdcst
     * @return
    */
    public int deletePrdcst(Map prdcst);
    
    /**
     * @Method Name        : inqureUserList
     * @Method description : 
     * @Date               : 2016. 11. 11.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 11.		변용수						CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param resident
     * @return
    */
    public List inqurePrdcst(Map prdcst);
}
