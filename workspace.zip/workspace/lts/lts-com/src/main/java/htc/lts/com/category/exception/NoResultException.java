package htc.lts.com.category.exception;

import htc.hone.core.exception.BusinessException;

public class NoResultException extends BusinessException {
	private static final long serialVersionUID = 3794793226955561879L;
	private static final String ERROR_CODE = "I0007";
	
	public NoResultException() {
		super(null ,ERROR_CODE);
	}

	public NoResultException(String errorMessage) {
		super(errorMessage, ERROR_CODE);
	}
}
