/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.bi.pd.dao.ApplyDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;


@Service
public class ApplyServiceImpI implements ApplyService{

    private static final Logger logger = LoggerFactory.getLogger(ApplyServiceImpI.class);
    
    @Autowired
    ApplyDao applyDao;
    
    @Override
    @ServiceId("BIPDS701")
    @ServiceName("이윤산정 적용지표")
    @ReturnBind("output")
    public List<Map> inqureApply(@DatasetBind("input") Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureApply, Input Param={}", searchParam);
        }
        
        List<Map> applyList = applyDao.inqureApply(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureApply Output ={}", applyList);
        }
        
        return applyList;
    }
    
    @Override
    @ServiceId("BIPDS702")
    @ServiceName("이윤산정 적용지표 저장")
    @ReturnBind("output")
    public int saveApply(@DatasetBind("input") List<Map> applyList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveApply, Input Param={}", applyList); 
        }
        
        int result = 0;
        for (Map Apply : applyList) {
            String rowType = XPlatformUtil.getDataRowType(Apply);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
               result += applyDao.insertApply(Apply);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += applyDao.updateApply(Apply);
            } 
            else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += applyDao.deleteApply(Apply);
            }
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveApply Output ={}", result);
        }

        return result; 
    }
  
      
}