package htc.lts.mi.om.dao;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:28:41
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface DsctnIdtfPlanDao {

    public List inqureyDsctnIdtfPlanList(Map param);
    
    public int updateDsctnIdtfPlan(Map dsctnIdtfPlan);
    
}
