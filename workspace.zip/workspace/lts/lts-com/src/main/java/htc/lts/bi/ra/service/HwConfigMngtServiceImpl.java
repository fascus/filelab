/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.ra.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.bi.ra.dao.HwConfigMngtDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 11. 17. 오전 8:25:13
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 11. 17.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class HwConfigMngtServiceImpl implements HwConfigMngtService {
	
	private static final Logger logger = LoggerFactory.getLogger(HwConfigMngtServiceImpl.class);

	@Autowired
	private HwConfigMngtDao hwConfigMngtDao;
	

    @Override
    @ServiceId("BIRAS006")
    @ServiceName("MgtNo조회")
    @ReturnBind("output")
    public List<Map> inqureMgtNo(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){
            
            logger.debug("Service Method : inqureSwVer, Input Param={}", argument);
        } 
        
        List<Map> result = hwConfigMngtDao.inqureMgtNo(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureMaxEqVer Output ={}", result);
        }
            
        return result;
    }
    
    @Override
    @ServiceId({"BIRAX004"})
    @ServiceName("mergeHwConfigMngt저장")
    @ReturnBind("output")
    public int mergeHwConfigMngt(@DatasetBind("input") List<Map> arguments) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : SwConfigMngtList, Input Param={}", arguments); 
          }
        
          int result = 0; 
          for (Map argument : arguments) {
            String rowType = XPlatformUtil.getDataRowType(argument);
            if(logger.isDebugEnabled()){
                logger.debug(rowType);
            }
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    result += hwConfigMngtDao.insertHwConfigMngt(argument);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += hwConfigMngtDao.updateHwConfigMngt(argument);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += hwConfigMngtDao.deleteHwConfigMngt(argument);
            }
          }

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : mergeSwConfigMngt Output ={}", result);
          }

          return result; 
    }
    
    @Override
    @ServiceId("BIRAS007")
    @ServiceName("HwConfigMngt조회")
    @ReturnBind("output")
    public List<Map> inqureHwConfigMngt(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){
            
            logger.debug("Service Method : inqureHwConfigMngt, Input Param={}", argument);
        } 
        
        List<Map> result;
        if("1".equals(argument.get("TYPE")))
        {
             result = hwConfigMngtDao.inqureHwLastConfigMngt(argument);
        }else{
             result = hwConfigMngtDao.inqureHwConfigMngt(argument);
        }
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureHwConfigMngt Output ={}", result);
        }
            
        return result;
    }
    
    @Override
    @ServiceId("BIRAS008")
    @ServiceName("HwSwMgtNo조회")
    @ReturnBind("output")
    public List<Map> inqureHwSwMgtNo(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){
            
            logger.debug("Service Method : inqureHwSwMgtNo, Input Param={}", argument);
        }
        
        List<Map> result = hwConfigMngtDao.inqureHwSwMgtNo(argument);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureHwSwMgtNo Output ={}", result);
        }
            
        return result;
    }
    
    @Override
    @ServiceId("BIRAS009")
    @ServiceName("HwInfo조회")
    @ReturnBind("output")
    public List<Map> inqureWrshpNo(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){
            
            logger.debug("Service Method : inqureHwInfo, Input Param={}", argument);
        }
        
        List<Map> result = hwConfigMngtDao.inqureWrshpNo(argument);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureHwInfo Output ={}", result);
        }
            
        return result;
    }
    
    @Override
    @ServiceId({"BIRAX005"})
    @ServiceName("mergeHwWrkDt저장")
    @ReturnBind("output")
    public int mergeHwWrkDt(@DatasetBind("input") List<Map> arguments) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : mergeHwWrkDt, Input Param={}", arguments); 
          }
        
          int result = 0; 
          for (Map argument : arguments) {
            String rowType = XPlatformUtil.getDataRowType(argument);
            if(logger.isDebugEnabled()){
                logger.debug(rowType);
            }
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    result += hwConfigMngtDao.deleteHwWrkDt(argument);
                    result += hwConfigMngtDao.insertHwWrkDt(argument);
            }/* else if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_UPDATED)) {
                result += hwConfigMngtDao.updateHwWrkDt(argument);
            }*/
            else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += hwConfigMngtDao.deleteHwWrkDt(argument);
            }
          }

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : mergeHwWrkDt Output ={}", result);
          }

          return result; 
    }
    
    @Override
    @ServiceId("BIRAS010")
    @ServiceName("inqureHwWrkDt조회")
    @MultiReturnBind
    //public Map<String, List> inqureMtn(@DatasetBind("input") Map searchParam) {
    public Map<String, List> inqureHwWrkDt(SystemHeader header, @DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureHwWrkDt, Input Param={}", argument); 
        }
        
        List<Map> allList = hwConfigMngtDao.inqureHwWrkDt(argument);
        
        List<Map> rowList = hwConfigMngtDao.inqureHwWrkDt2(argument);
        
        Map<String, List> data = new HashMap<>();
        
        data.put("output1", allList);
        data.put("output2", rowList);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureHwWrkDt Output ={}", data);
        }
        
        return data;
    }
    
    
    
    @Override
    @ServiceId("BIRAS011")
    @ServiceName("inqureSwVer조회")
    @ReturnBind("output")
    public List<Map> inqureSwVer(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){
            
            logger.debug("Service Method : inqureSwVer, Input Param={}", argument);
        }
        
        List<Map> result = hwConfigMngtDao.inqureSwVer(argument);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureSwVer Output ={}", result);
        }
            
        return result;
    }
    
    @Override
    @ServiceId("BIRAS012")
    @ServiceName("inqureSwVerWrshpNo조회")
    @ReturnBind("output")
    public List<Map> inqureSwVerWrshpNo(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){
            
            logger.debug("Service Method : inqureSwVerWrshpNo, Input Param={}", argument);
        }
        
        List<Map> result = hwConfigMngtDao.inqureSwVerWrshpNo(argument);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureSwVerWrshpNo Output ={}", result);
        }
            
        return result;
    }
    
    @Override
    @ServiceId({"BIRAX006"})
    @ServiceName("mergeSwWrkDt저장")
    @ReturnBind("output")
    public int mergeSwWrkDt(@DatasetBind("input") List<Map> arguments) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : mergeSwWrkDt, Input Param={}", arguments); 
          }
        
          int result = 0; 
          for (Map argument : arguments) {
            String rowType = XPlatformUtil.getDataRowType(argument);
            if(logger.isDebugEnabled()){
                logger.debug(rowType);
            }
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    result += hwConfigMngtDao.deleteSwWrkDt(argument);
                    result += hwConfigMngtDao.insertSwWrkDt(argument);
            }/* else if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_UPDATED)) {
                result += hwConfigMngtDao.updateHwWrkDt(argument);
            }*/ 
            else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += hwConfigMngtDao.deleteSwWrkDt(argument);
            }
            
          }

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : mergeSwWrkDt Output ={}", result);
          }

          return result; 
    }
    
    @Override
    @ServiceId("BIRAS013")
    @ServiceName("inqureSwWrkDt조회")
    @MultiReturnBind
    //public Map<String, List> inqureMtn(@DatasetBind("input") Map searchParam) {
    public Map<String, List> inqureSwWrkDt(SystemHeader header, @DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureSwWrkDt, Input Param={}", argument); 
        }
        
        List<Map> allList = hwConfigMngtDao.inqureSwWrkDt(argument);
        
        List<Map> rowList = hwConfigMngtDao.inqureSwWrkDt2(argument);
        
        Map<String, List> data = new HashMap<>();
        
        data.put("output1", allList);
        data.put("output2", rowList);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureSwWrkDt Output ={}", data);
        }
        
        return data;
    }
}
