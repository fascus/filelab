/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.dao;

import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

@Repository
public class ApplyDaoImpI extends AbstractHtcDao implements ApplyDao {

   
    @Override
    public int insertApply(Map apply) {
        return  update("htc.lts.bi.pd.hqml.ApplyQuery.insertApply", apply);
    }
    @Override
    public int updateApply(Map apply) {
        return  update("htc.lts.bi.pd.hqml.ApplyQuery.updateApply", apply);
    }
    @Override
    public int deleteApply(Map apply) {
        return  update("htc.lts.bi.pd.hqml.ApplyQuery.deleteApply", apply);
    }
    
    @Override
    public List inqureApply(Map applyList) {
        return  queryForList("htc.lts.bi.pd.hqml.ApplyQuery.selectApplyList", applyList);
    }
        
}
