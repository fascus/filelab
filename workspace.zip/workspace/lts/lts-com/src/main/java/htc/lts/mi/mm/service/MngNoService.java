/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.mm.service;

import java.util.List;
import java.util.Map;

import htc.hone.core.message.SystemHeader;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:55:18
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface MngNoService {

   
    public List<Map> inqureMngNo(Map argument);
    
   
    public int saveMngNo(List<Map> mngNoList);
    
    //public int saveScreenObj(List<Map> screenObjList);
    
    public List<Map> searchCtrNoList(Map argument);


    public List<Map> inqureCmplRpt(Map searchParam);
    
    public List<Map> inqureShipInfo(Map searchParam);
    
    public int saveCmplRpt(List<Map> cmplRptList);
    
   // public List<Map> inqureCmplRpt(Map argument);
    
    public List<Map> seachEqNm(Map searchParam);

    public List<Map> inqureRsptAmt(Map searchParam);
    /**
     * @Method Name        : inqureMtn
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param header
     * @param searchParam
     * @return
    */
    
    Map<String, List> inqureMtn(SystemHeader header, Map searchParam);
    
    public List<Map> inqureFile(Map argument);

    public List<Map> inqureRfnoCrtnAndDel(Map argument);

    public int saveRfNo(List<Map> mngNoList);

    public List<Map> inqureLbAmt(Map argument);

    public List<Map> inqureRsptAmt2(Map argument);

    public int saveCmplRpt2(Map cmplRptList);   
    
    public int saveTrfctr(List<Map> mngNoList);
    
    public int saveOfcdocNo(Map mngNoList);
    
}
