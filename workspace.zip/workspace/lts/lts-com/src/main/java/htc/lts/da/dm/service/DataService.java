package htc.lts.da.dm.service;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : 일반자료관리
 * @Date		  : 2016. 10. 12. 오후 7:14:06
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 12.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface DataService {
    
    /**
     * @Method Name        : inqureData
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 12.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    public List<Map> inqureData(Map searchParam);
    
    /**
     * @Method Name        : insertDataList
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 12.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public int insertDataList(List<Map> DataList);
    
    /**
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 13.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 13.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureFile(Map argument);
    
    public int deleteFile(List<Map> deleteFileList);
}
