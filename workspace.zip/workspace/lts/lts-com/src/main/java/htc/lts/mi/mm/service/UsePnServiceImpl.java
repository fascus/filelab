/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.mm.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.mi.bp.dao.StateInspPrstsDao;
import htc.lts.mi.mm.dao.DuseMtrlsRtnDao;
import htc.lts.mi.mm.dao.PrtsplMtrlsDao;
import htc.lts.mi.mm.dao.RndshpMtrlsRtnDao;
import htc.lts.mi.mm.dao.UsePnDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:59:12
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class UsePnServiceImpl implements UsePnService {

    private static final Logger logger = LoggerFactory.getLogger(UsePnServiceImpl.class);

    @Autowired
    UsePnDao usePnDao;
    
    @Autowired
    DuseMtrlsRtnDao duseMtrlsRtnDao;
    
    @Autowired
    PrtsplMtrlsDao prtsplMtrlsDao;
    
    @Autowired
    RndshpMtrlsRtnDao rndshpMtrlsRtnDao;
    
    @Autowired
    StateInspPrstsDao stateInspPrstsDao;

   
    @Override
    @ServiceId("MIMMS004")
    @ServiceName("부품조회")
    @ReturnBind("output")
    public List<Map> inqurePn(@DatasetBind("input") Map searchParam) {
    	
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqurePn, Input Param={}", searchParam); 
        }
        
        List<Map> pnList = usePnDao.inqurePnList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqurePn Output ={}", pnList);
        }
        
        return pnList;
    }
    
    @Override
    @ServiceId("MIMMS005")
    @ServiceName("부품조회")
    @ReturnBind("output")
    public List<Map> inqureUsePn(@DatasetBind("input") Map searchParam) {
    	
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqurePn, Input Param={}", searchParam); 
        }
        
        List<Map> pnList = usePnDao.inqureUsePnList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqurePn Output ={}", pnList);
        }
        
        return pnList;
    }
    
    @Override
    @ServiceId("MIMMS006")
    @ServiceName("부품조회")
    @ReturnBind("output")
    public List<Map> inqureUsePnOut(@DatasetBind("input") Map searchParam) {
    	
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqurePn, Input Param={}", searchParam); 
        }
        
        List<Map> pnList = usePnDao.inqureUsePnOutList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqurePn Output ={}", pnList);
        }
        
        return pnList;
    }
    
  @Override
  @ServiceId("MIMMX003")
  @ServiceName("사용부품저장")
  @ReturnBind("output")
  public int saveUsePn(@DatasetBind("input") List<Map> usePnList) {
      if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveUsePn, Input Param={}", usePnList); 
        }
      

      int result = 0;
        
        Map param = new HashMap();
        
        String strUntprc;
        int intUntprc;
        String mgt;
        
        for (Map usePn : usePnList) {
          String rowType = XPlatformUtil.getDataRowType(usePn);
          
          
          if (XPlatformUtil.DATASET_ROW_TYPE_NORMAL.equals(rowType)) {
	                 
              List<Map> duseMtrlsRtnList = duseMtrlsRtnDao.inqureDuseMtrlsRtnList(usePn);
              
              if(duseMtrlsRtnList.size() == 0){

            	  result += duseMtrlsRtnDao.insertDuseMtrlsRtn(usePn);
              }else{
            	  result += duseMtrlsRtnDao.updateDuseMtrlsRtn2(usePn);
              }

          }else if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
        	 if(usePn.get("PN")!="" && usePn.get("PN")!=null){
                  
                  if("1".equals(usePn.get("TKNGV_METHD_CD"))){
                      usePn.put("ORDRGDT", null);
                      usePn.put("WRHSDT", null);
                  }
                  
                  List<Map> searchSeq = usePnDao.searchSeq(usePn);              //Max Seq를 구한다
                  String seq = searchSeq.get(0).get("SEQ").toString();
                  usePn.put("SEQ", seq);
                  
                  result += usePnDao.insertUsePn(usePn);
                  
                  result += duseMtrlsRtnDao.insertDuseMtrlsRtn(usePn);
                  
                 strUntprc = String.valueOf(usePn.get("UNTPRC"));

                  intUntprc =  Integer.parseInt(strUntprc);
                  
                  mgt = usePn.get("MGT_NO").toString();
                  mgt = mgt.substring(2,4);
                  
                  if(intUntprc >= 500000)
                  {
                	  if(!"MR".equals(mgt) && !"MC".equals(mgt) && !"LS".equals(mgt)){
                		  result +=prtsplMtrlsDao.insertPrtsplMtrls(usePn);		//사급
                	  }
                	  if("MR".equals(mgt) || "MC".equals(mgt)){
                		  stateInspPrstsDao.insertStateInspPrsts(usePn);
                	  }
                  }
                  if(intUntprc >= 10000000 && !("SD".equals(mgt) || "HS".equals(mgt) || "TS".equals(mgt) || "LS".equals(mgt)))
                  {
                          result += rndshpMtrlsRtnDao.insertRndshpMtrlsRtn(usePn);		//원형
                  }
                  
              }
          } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
              
            if("1".equals(usePn.get("TKNGV_METHD_CD"))){
                  usePn.put("ORDRGDT", null);
                  usePn.put("WRHSDT", null);
              }
              
              result += usePnDao.updateUsePn(usePn);
              
              List<Map> duseMtrlsRtnList = duseMtrlsRtnDao.inqureDuseMtrlsRtnList(usePn);
              
              if(duseMtrlsRtnList.size() == 0){
                  result += duseMtrlsRtnDao.insertDuseMtrlsRtn(usePn);
              }else{
            	 result += duseMtrlsRtnDao.updateDuseMtrlsRtn2(usePn);
              }
	            
            
			strUntprc = String.valueOf(usePn.get("UNTPRC"));
			
			intUntprc =  Integer.parseInt(strUntprc);
			
			mgt = usePn.get("MGT_NO").toString();
			mgt = mgt.substring(2,4);
			
			if(intUntprc >= 500000)
			{
			  if(!"MR".equals(mgt) && !"MC".equals(mgt) && !"LS".equals(mgt)){
				  result +=prtsplMtrlsDao.updatePrtsplMtrls(usePn);		//사급
			  }
			  if("MR".equals(mgt) || "MC".equals(mgt)){
				  stateInspPrstsDao.updateStateInspPrsts(usePn);
			  }
			}
			if(intUntprc >= 10000000 && !("SD".equals(mgt) || "HS".equals(mgt) || "TS".equals(mgt) || "LS".equals(mgt)))
			{
			    result += rndshpMtrlsRtnDao.updateRndshpMtrlsRtn(usePn);		//원형
			}
             
              
          } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
              result +=  prtsplMtrlsDao.deletePrtsplMtrls(usePn);
              result +=  duseMtrlsRtnDao.deleteDuseMtrlsRtn(usePn);
              result +=  rndshpMtrlsRtnDao.deleteRndshpMtrlsRtn(usePn);
              result += usePnDao.deleteUsePn(usePn);
              result += stateInspPrstsDao.deleteStateInspPrsts(usePn);
              
          } 
          
        }
        
        
        for (Map usePn : usePnList) {
        	
        	param.clear();
            param.put("MGT_NO", usePn.get("MGT_NO"));
            param.put("RFNO", usePn.get("RFNO"));
            param.put("PN", usePn.get("PN"));
           
            List<Map> duseMtrlsRtnList2 = duseMtrlsRtnDao.inqureDuseMtrlsRtnList(param);
            
            if(duseMtrlsRtnList2.size()>0){
            String RTN_QTY = String.valueOf(duseMtrlsRtnList2.get(0).get("RTN_QTY"));
            	if("0".equals(RTN_QTY)){
            		result +=  duseMtrlsRtnDao.deleteDuseMtrlsRtn(param);
            	}
            }
        
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveUsePn Output ={}", result);
        }

        return result; 
  }
  
  @Override
  @ServiceId("MIMMX004")
  @ServiceName("사용부품저장")
  @ReturnBind("output")
  public int saveOutUsePn(@DatasetBind("input") List<Map> usePnOutList) {
      if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveOutUsePn, Input Param={}", usePnOutList); 
        }
      
        int result = 0;
        
        //Map param = new HashMap();
        
        //String strUntprc;
        //int intUntprc;
        
        for (Map usePnOut : usePnOutList) {
          String rowType = XPlatformUtil.getDataRowType(usePnOut);
          if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
              if(usePnOut.get("PN")!="" && usePnOut.get("PN")!=null){
                  
                  List<Map> searchSeq = usePnDao.searchSeq(usePnOut);              //Max Seq를 구한다
                  String seq = searchSeq.get(0).get("SEQ").toString();
                  usePnOut.put("SEQ", seq);
                  
                  List<Map> usePn = usePnDao.inqureUsePn(usePnOut);

                  if(usePn.size()==0){
                	  result += usePnDao.insertUsePn(usePnOut);
                  }
                  
              }
          } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
              
              if(usePnOut.get("TKNGV_METHD_CD")==null){
                  /****/
              }
              else if("1".equals(usePnOut.get("TKNGV_METHD_CD"))){
            	  usePnOut.put("ORDRGDT", null);
            	  usePnOut.put("WRHSDT", null);
              }
              
              result += usePnDao.updateUsePn(usePnOut);
              
              
//              if(usePnOut.get("ULMTRLS_RTN_QTY")==null || usePnOut.get("ULMTRLS_RTN_QTY").toString().equals("0")){
//            	  result +=  duseMtrlsRtnDao.deleteDuseMtrlsRtn(usePnOut);
//              }else if(usePnOut.get("ITSLF_OUTSC_DVCD").equals("1") && !usePnOut.get("ULMTRLS_RTN_QTY").equals("") && usePnOut.get("ULMTRLS_RTN_QTY")!=null){
//                  
//                  param.put("MGT_NO", usePnOut.get("MGT_NO"));
//                  param.put("RFNO", usePnOut.get("RFNO"));
//                  param.put("PN", usePnOut.get("PN"));
//                 
//                  List<Map> duseMtrlsRtnList = duseMtrlsRtnDao.inqureDuseMtrlsRtnList(param);
//                  
//                  if(duseMtrlsRtnList.size() == 0){
//                      result += duseMtrlsRtnDao.insertDuseMtrlsRtn(usePnOut);
//                  }else{
//                	  if(usePnOut.get("ULMTRLS_RTN_QTY").toString().equals("0")){
//                		  result +=  duseMtrlsRtnDao.deleteDuseMtrlsRtn(usePnOut);
//                	  }else{                		  
//                		  result += duseMtrlsRtnDao.updateDuseMtrlsRtn2(usePnOut);
//                	  }
//                  }
//              }
              
//              strUntprc = String.valueOf(usePnOut.get("UNTPRC"));
//
//              intUntprc =  Integer.parseInt(strUntprc);
              /*
              if(intUntprc >= 500000 && intUntprc < 10000000){
                  result +=prtsplMtrlsDao.updatePrtsplMtrls(usePnOut);
              }else if(intUntprc >= 10000000){
                  result += rndshpMtrlsRtnDao.updateRndshpMtrlsRtn(usePnOut);
              }
              */
             
              
          } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
              //result +=  prtsplMtrlsDao.deletePrtsplMtrls(usePnOut);
//              result +=  duseMtrlsRtnDao.deleteDuseMtrlsRtn(usePnOut);
              //result +=  rndshpMtrlsRtnDao.deleteRndshpMtrlsRtn(usePnOut);
              result += usePnDao.deleteUsePn(usePnOut);
          }
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveOutUsePn Output ={}", result);
        }

        return result; 
  }
  
  @Override
  @ServiceId("MIMMX013")
  @ServiceName("주요수리내역저장")
  @ReturnBind("output")
  public int deleteFile(@DatasetBind("input") List<Map> deleteFileList) {
      if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : deleteFile, Input Param={}", deleteFileList); 
        }
      

      int result = 0;
        
        for (Map deleteFile : deleteFileList) {
            
                String rowType = XPlatformUtil.getDataRowType(deleteFile);
                if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                   
                    result +=usePnDao.deleteFile(deleteFile);
                    
                }
        }

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : deleteFile Output ={}", result);
        }

        return result; 
  }
}