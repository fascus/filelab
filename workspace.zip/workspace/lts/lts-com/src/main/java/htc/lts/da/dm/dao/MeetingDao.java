package htc.lts.da.dm.dao;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 14. 오후 1:21:04
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 14.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface MeetingDao {
    /**
     * @Method Name        : inqureMeetingList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param data
     * @return
    */
    public List inqureMeetingList(Map data);
    
    /**
     * @Method Name        : insertMeetingList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DataList
     * @return
    */
    public int insertMeetingList(Map DataList);

    /**
     * @Method Name        : updateMeetingList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DataList
     * @return
    */
    public int updateMeetingList(Map DataList);

    /**
     * @Method Name        : deleteMeetingList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DataList
     * @return
    */
    public int deleteMeetingList(Map DataList);
    
    /**
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureFile(Map argument);
}
