/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.mm.dao;

import java.util.List;
import java.util.Map;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:59:07
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface MngNoDao {

    public List inqureMngNoList(Map mngNo);
    
   
    //public List inqureScreenObjList(Map screenObj);
    
   
    public int insertMngNoMaster(Map mngNo);
    
    public int insertMngNoDetail(Map mngNo);
    
    public int insertWrk(Map mngNo);
    
    public List searchMngNoList(Map mngNo);
    
    
    public List searchCtrNoList(Map mngNo);
    
    public List searchCtrNoList2(Map mngNo);
    
    public List searchMasterList(Map mngNo);
    
    public List searchDetailList(Map mngNo);
    
    /**
     * @Method Name        : inqureMtnList
     * @Method description : 
     * @Date               : 2016. 9. 28.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 9. 28.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mtn
     * @return
    */
    public List inqureMtnList(Map mtn);
    
    /**
     * @Method Name        : inqureCmplRptList
     * @Method description : 
     * @Date               : 2016. 9. 28.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 9. 28.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param ㅊmplRpt
     * @return
    */
    public List inqureCmplRptList(Map cmplRpt);
    
    public int insertCmplRpt(Map cmplRpt);
    
    public int updateCmplRpt(Map cmplRpt);
    
    public List inqureShipNmList(Map mngNo);
    
    public List inqureEqNmList(Map mngNo);
    
    public List inqureHwEqcdList(Map mngNo);
    
    public List inqureEqcdList(Map mngNo);
    
    public List inqureBpEqcdList(Map mngNo);
    
    public List inqureBpEqcdList2(Map mngNo);
    
    public List inqureHwMtnCdList(Map mngNo);
    
    public List inqureAiMtnCdList(Map mngNo);
    
    public List inqureAiEqCdList(Map mngNo);

    public List seachEqNm(Map mtn);
    
    public List selectMimmIng(Map mtn);

    public int insertMtnPlan(Map mngNo);
    
    public int insertTestList(Map bdList);
    
    public List<Map> inqureFile(Map argument);

    public List inqureRfnoCrtnAndDel(Map argument);

    public int deleteMngNoDetail(Map argument);

    public int deleteTestList(Map argument);

    public int deleteWrk(Map argument);
    
    public List<Map> inqureRsptAmt(Map argument);

    public List<Map> inqureLbAmt(Map argument); 
    
    public List selectUgcyMtnRqstno(Map mngNo);
    
    public int insertUgcyMtn(Map mngNo);

    public int updateMngNoDetail(Map mngNo);

    public List<Map> inqureRsptAmt2(Map argument);

    public int updateOfcdocNoMngNoDetail(Map mngNo);
    
    public int updateOfcdocNoUgcyMtn(Map mngNo);


    public int deleteMtnPlan(Map argument);
    
    
    
}
