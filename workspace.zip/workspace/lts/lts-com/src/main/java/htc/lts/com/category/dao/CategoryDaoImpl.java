package htc.lts.com.category.dao;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import hone.bom.dao.hqml.support.SimpleHqmlDao;
import hone.bom.util.record.Record;
import hone.bom.util.record.RecordSet;
import htc.commons.paging.PagingSupport;
import htc.hone.dao.AbstractHtcDao;
import htc.lts.com.category.dto.CategoryDto;

@Repository
public class CategoryDaoImpl extends AbstractHtcDao implements CategoryDao {

	

	@Override
	public List listCategory(Map category) {
		return queryForList("htc.lts.com.category.hqml.CategoryQuery.selectCategory", category);
//		SqlParameterSource src = new MapSqlParameterSource(category);
//		return toList(getDaoTemplate().queryForRecordSet(getSql("htc.lts.com.category.dao.CategoryQuery.listCategory", category)
//				, src));
	}

	@Override
	public List listCategory(Map category, PagingSupport paging) {
		return queryForPagingList("htc.lts.com.category.hqml.CategoryQuery.selectCategory", category, paging);
//		SqlParameterSource src = new MapSqlParameterSource(category);
//		return toList(getDaoTemplate().queryForRecordSet(getSql("htc.lts.com.category.dao.CategoryQuery.listCategory", category)
//				, src));
	}

	@Override
	public int insertCategory(Map category) {
		return update("htc.lts.com.category.hqml.CategoryQuery.insertCategory",  category);
//		return getDaoTemplate().update(getSql("htc.lts.com.category.hqml.CategoryQuery.insertCategory", category), new MapSqlParameterSource(category));
	}

	@Override
	public int updateCategory(Map category) {
		return update("htc.lts.com.category.hqml.CategoryQuery.updateCategory", category);
//		return getDaoTemplate().update(getSql("htc.lts.com.category.dao.CategoryQuery.updateCategory", category), new MapSqlParameterSource(category));
	}

	@Override
	public int deleteCategory(Map category) {
		return update("htc.lts.com.category.hqml.CategoryQuery.deleteCategory", category);
//		return getDaoTemplate().update(getSql("htc.lts.com.category.dao.CategoryQuery.deleteCategory", category), new MapSqlParameterSource(category));
	}

	@Override
	public Map getCategory(Map category) {
		List<Map<String, Object>> list = queryForList("htc.lts.com.category.hqml.CategoryQuery.getCategory", category);
		if(list.size() < 1) {
			return null;
		}
		return list.get(0);
//		return toMap(getDaoTemplate().queryForRecord(getSql("htc.lts.com.category.dao.CategoryQuery.listCategory", null)
//				, new MapSqlParameterSource(category)));
	}

	@Override
	public CategoryDto getCategory(CategoryDto category) {
		return queryForObject("htc.lts.com.category.hqml.CategoryQuery.getCategory", category, CategoryDto.class);
	}

}
