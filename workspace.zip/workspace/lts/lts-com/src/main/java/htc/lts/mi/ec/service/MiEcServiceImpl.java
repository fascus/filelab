/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.ec.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.lts.mi.ec.dao.MiEcDao;
import htc.lts.mi.mm.dao.MngNoDao;
import htc.lts.mi.om.dao.DsctnIdtfCmplRptDao;
import htc.lts.mi.om.dao.DsctnIdtfItemDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 10:04:40
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class MiEcServiceImpl implements MiEcService {

    private static final Logger logger = LoggerFactory.getLogger(MiEcServiceImpl.class);

    @Autowired
    MiEcDao miEcDao;

    @Autowired
    MngNoDao mngNoDao;
    
    @Autowired
    DsctnIdtfItemDao dsctnIdtfItemDao;
    
    @Autowired
    DsctnIdtfCmplRptDao dsctnIdtfCmplRptDao;
   
    @Override
    @ServiceId("MIECS001")
    @ServiceName("기술변경계획서조회")
    @ReturnBind("output")
    public List<Map> inqureGnrChgPlan(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureGnrChgPlan, Input Param={}", argument); 
        }
        
        List<Map> result = miEcDao.inqureGnrChgPlan(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureGnrChgPlan Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("MIECU001")
    @ServiceName("기술변경계획서수정")
    @ReturnBind("output")
    public int updateGnrChgPlan(@DatasetBind("input") Map argument) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateGnrChgPlan, Input Param={}", argument);
        }

        int result = miEcDao.updateGnrChgPlan(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateGnrChgPlan Output ={}", result);
        }

        return result;
    }
    
    @Override
    @ServiceId("MIECS002")
    @ServiceName("기술변경결과보고조회")
    @ReturnBind("output")
    public List<Map> inqureGnrChgRpt(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureGnrChgRpt, Input Param={}", argument); 
        }
        
        List<Map> result = miEcDao.inqureGnrChgRpt(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureGnrChgRpt Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("MIECU002")
    @ServiceName("기술변경결과보고수정")
    @ReturnBind("output")
    public int updateGnrChgRpt(@DatasetBind("input") Map argument) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateGnrChgRpt, Input Param={}", argument);
        }
        int result = 0;
        result += miEcDao.updateGnrChgRpt(argument);
        result += dsctnIdtfCmplRptDao.updateLbcst(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateGnrChgRpt Output ={}", result);
        }

        return result;
    }
    
    @Override
    @ServiceId("MIECX001")
    @ServiceName("이동정비생성")
    @ReturnBind("output")
    public int saveMngNo(@DatasetBind("input") List<Map> mngNoList) {
       
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveMngNo, Input Param={}", mngNoList); 
        }
        int result = 0;
        String preSHP = "";
        String preMgt = "";
        for (Map mngNo : mngNoList) {
            String mgt = preMgt;
            if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){    
                List<Map> searchMgtNo = mngNoDao.searchMngNoList(mngNo);
            
                mgt = searchMgtNo.get(0).get("MGT").toString();
                
            }
            
            String SHP_TP_CD = mngNo.get("SHP_TP_CD").toString();          //함형
            String ITM_CD =    mngNo.get("ITM_CD").toString();             //정비유형
            String EQCD =      mngNo.get("EQCD").toString();               //함 장비부호 
            String ENTP_CD =   mngNo.get("ENTP_CD").toString();            //정비업체부호
            
            String MGT_NO = SHP_TP_CD + ITM_CD + mgt;                      //관리번호 
            String RFNO   = ENTP_CD.trim() + EQCD.trim();                  //참조번호
            
            List<Map> searchCtrno = mngNoDao.searchCtrNoList(mngNo);       //공문번호로 계약번호 검색후 
            
            for (Map ctrno : searchCtrno) {                                //해당 함형에 따른 계약번호 추출  
                if(SHP_TP_CD.equals(ctrno.get("SHP_TP_CD"))){
                    mngNo.put("CTRNO", ctrno.get("CTRNO")); 
                    mngNo.put("CTR_CHNG_SRLNO", ctrno.get("CTR_CHNG_SRLNO"));
                    break;
                }
            }
            
            mngNo.put("MGT_NO", MGT_NO);
            mngNo.put("RFNO", RFNO);
            
            List<Map> mgtNoRfNoList = dsctnIdtfItemDao.inqureyMgtNoRfNo(mngNo); 
            
            List<Map> gnrChgPlanList = miEcDao.inqureGnrChgPlan(mngNo); 
            
            List<Map> gnrChgRptList = miEcDao.inqureGnrChgRpt(mngNo); 
            
            List<Map> hwSwList = miEcDao.inqureHwSw(mngNo); 
            
            if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){
                result += mngNoDao.insertMngNoMaster(mngNo);
            }
            
            if(mgtNoRfNoList.size()==0){
            	result += mngNoDao.insertMngNoDetail(mngNo);
            }
            
            if(gnrChgRptList.size()==0){
            	miEcDao.insertGnrChgCmplRpt(mngNo);
            }
            
            if(gnrChgPlanList.size()==0){
            	miEcDao.insertGnrChgPlan(mngNo);
            }

            if(hwSwList.size()==0){
            	miEcDao.insertHwSw(mngNo);
            }else{
	            for(Map hwSw : hwSwList){
	            	if(!hwSw.get("REL_HW_RMDL_SW_IMPR_MGT_NO").equals(mngNo.get("HWSW_MGT_NO")) || !hwSw.get("REL_HW_RMDL_SW_IMPR_RFNO").equals(mngNo.get("HWSW_RFNO"))){
	            		miEcDao.insertHwSw(mngNo);
	            	}
	            }
            }
            
            
            preMgt = mgt;
            preSHP = mngNo.get("SHP_TP_CD").toString();
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveScreen Output ={}", result);
        }

        return result; 
    }
    
    @Override
    @ServiceId("MIECS100")
    @ServiceName("기술변경계획서조회")
    @MultiReturnBind
    public Map<String, List> inqureGnrChg(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureGnrChgPlan, Input Param={}", argument); 
        }
        
        List<Map> result = miEcDao.inqureGnrChg(argument);
        
        List<Map> miotList = miEcDao.selectMiotIng(argument);
        
        Map<String, List> data = new HashMap<>();
        
        data.put("output", result);
        data.put("miotIng", miotList);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureGnrChgPlan Output ={}", result);
        }
        
        return data;
    }
    
    @Override
    @ServiceId("MIECS101")
    @ServiceName("기술변경계획서조회")
    @ReturnBind("output")
    public List<Map> inqureCmplRpt(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureGnrChgPlan, Input Param={}", argument); 
        }
        
        List<Map> result = miEcDao.inqureCmplRpt(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureGnrChgPlan Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("MIECS102")
    @ServiceName("기술변경계획서참조번호조회")
    @ReturnBind("output")
    public List<Map> inqureRfnoCrtnAndDel(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureRfnoCrtnAndDel, Input Param={}", searchParam); 
        }
        
        List<Map> result = miEcDao.inqureRfnoCrtnAndDel(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureRfnoCrtnAndDel Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("MIECX002")
    @ReturnBind("output")
    public int saveRfNo(@DatasetBind("input") List<Map> arguments) {
       
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveRfNo, Input Param={}", arguments); 
        }
        int result = 0;
            for (Map argument : arguments) {
                //argument.put("RFNO",argument.get("RFNO").toString().substring(10,2));
                String rowType = XPlatformUtil.getDataRowType(argument);
                
                if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    argument.put("RFNO",argument.get("ENTP_CD").toString().trim() + argument.get("EQCD").toString().trim());

                    List<Map> mgtNoRfNoList = dsctnIdtfItemDao.inqureyMgtNoRfNo(argument); 
                    
                    List<Map> gnrChgPlanList = miEcDao.inqureGnrChgPlan(argument); 
                    
                    List<Map> gnrChgRptList = miEcDao.inqureGnrChgRpt(argument); 
                    
                    List<Map> hwSwList = miEcDao.inqureHwSw(argument); 
                    
                    if(mgtNoRfNoList.size()==0){
                        result += mngNoDao.insertMngNoDetail(argument);
                    }
                    
                    if(gnrChgRptList.size()==0){
                        result += miEcDao.insertGnrChgCmplRpt(argument);
                    }
                    
                    if(gnrChgPlanList.size()==0){
                        result += miEcDao.insertGnrChgPlan(argument);
                    }

                    if(hwSwList.size()==0){
                        result += miEcDao.insertHwSw(argument);
                    }else{
                        for(Map hwSw : hwSwList){
                            if(!hwSw.get("REL_HW_RMDL_SW_IMPR_MGT_NO").equals(argument.get("HWSW_MGT_NO")) || !hwSw.get("REL_HW_RMDL_SW_IMPR_RFNO").equals(argument.get("HWSW_RFNO"))){
                                miEcDao.insertHwSw(argument);
                            }
                        }
                    }
                } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                    argument.put("RFNO",argument.get("ENTP_CD").toString().trim() + argument.get("EQCD").toString().trim());

                    List<Map> mgtNoRfNoList = dsctnIdtfItemDao.inqureyMgtNoRfNo(argument); 
                    
                    List<Map> gnrChgPlanList = miEcDao.inqureGnrChgPlan(argument); 
                    
                    List<Map> gnrChgRptList = miEcDao.inqureGnrChgRpt(argument); 
                    
                    List<Map> hwSwList = miEcDao.inqureHwSw(argument); 
                    
                    if(mgtNoRfNoList.size()!=0){
                        result += mngNoDao.deleteMngNoDetail(argument);
                    }
                    
                    if(gnrChgRptList.size()!=0){
                        result += miEcDao.deleteGnrChgCmplRpt(argument);
                    }
                    
                    if(gnrChgPlanList.size()!=0){
                        result += miEcDao.deleteGnrChgPlan(argument);
                    }

                    if(hwSwList.size()!=0){
                        for(Map hwSw : hwSwList){
                            //if(!hwSw.get("REL_HW_RMDL_SW_IMPR_MGT_NO").equals(argument.get("HWSW_MGT_NO")) || !hwSw.get("REL_HW_RMDL_SW_IMPR_RFNO").equals(argument.get("HWSW_RFNO"))){
                                argument.put("SEQ",hwSw.get("SEQ").toString());
                                miEcDao.deleteHwSw(argument);
                            //}
                        }
                    }
                }
            }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveRfNo Output ={}", result);
        }

        return result; 
    }
}