package htc.lts.mi.om.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:30:20
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class DsctnIdtfCmplRptDaoImpl extends AbstractHtcDao implements DsctnIdtfCmplRptDao {

    @Override
    public List inqueryDsctnIdtfCmplRptList(Map param) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfCmplRptQuery.selectDsctnIdtfCmplRptList", param);
    }
    
    @Override
    public List inqueryEqnm(Map param) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfCmplRptQuery.selectEqnm", param);
    }
    
    @Override
    public int insertDsctnIdtfCmplRpt(Map eqNm) {
        return update("htc.lts.mi.om.hqml.DsctnIdtfCmplRptQuery.insertDsctnIdtfCmplRpt", eqNm);
    }
    
    @Override
    public int updatedsctnIdtfCmplRpt(Map dsctnIdtfCmplRpt) {
        return update("htc.lts.mi.om.hqml.DsctnIdtfCmplRptQuery.updatedsctnIdtfCmplRpt", dsctnIdtfCmplRpt);
    }
    
    @Override
    public List inqureFile(Map argument) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfCmplRptQuery.inqureFile", argument);
    }
    
    @Override
    public List inqureFile2(Map argument) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfCmplRptQuery.inqureFile2", argument);
    }

    @Override
    public int updateLbcst(Map dsctnIdtfCmplRpt) {
        return update("htc.lts.mi.om.hqml.DsctnIdtfCmplRptQuery.updateLbcst", dsctnIdtfCmplRpt);
    }
}
