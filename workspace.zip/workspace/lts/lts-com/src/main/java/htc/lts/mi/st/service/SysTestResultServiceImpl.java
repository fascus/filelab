/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.st.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.mi.mm.dao.MngNoDao;
import htc.lts.mi.st.dao.SysTestDao;
import htc.lts.mi.st.dao.SysTestResultDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;
import htc.xplatform.web.XPlatformRowType;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:59:12
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class SysTestResultServiceImpl implements SysTestResultService {

    private static final Logger logger = LoggerFactory.getLogger(SysTestResultServiceImpl.class);
    
    @Autowired
    SysTestResultDao sysTestResultDao;
    @Autowired
    SysTestDao sysTestDao;
    @Autowired
    MngNoDao mngNoDao;
   
    @Override
    @ServiceId("MISTS050")
    @ServiceName("체계진단항목조회")
    @ReturnBind("output")
    public List<Map> inqureSysTestResult(@DatasetBind("input") Map searchParam) {
    	
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureSysTestResult, Input Param={}", searchParam); 
        }
        
        List<Map> sysTestList = sysTestResultDao.inqureSysTestResult(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureSysTestResult Output ={}", sysTestList);
        }
        
        return sysTestList;
    }
    
    
    /**
     * @Method Name        : saveSysTestResult
     * @Method description : 
     * @Date               : 2016. 9. 23.
     * @Author             : 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 9. 23.                             CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("MIOMX050")
    @ServiceName("체계진단항목저장")
    @ReturnBind("output")
    public int saveSysTestResult(@DatasetBind("input") List<Map> argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveMenu, Input Param={}", argument); 
        }
        
        int result = 0;
        for (Map sysTest : argument) {
            String rowType = XPlatformUtil.getDataRowType(sysTest);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += sysTestResultDao.insertResult(sysTest);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += sysTestResultDao.updateResult(sysTest);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += sysTestResultDao.deleteResult(sysTest);
            }
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveMenu Output ={}", result);
        }

        return result; 
    }
	
    
    @Override
    @ServiceId("MISTS600")
    @ServiceName("체계진단항목조회")
    @ReturnBind("output")
    public List<Map> inqureItemNo(@DatasetBind("input") Map searchParam) {
    	
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureSysTestResult, Input Param={}", searchParam); 
        }
        
        List<Map> itemNoList = sysTestResultDao.inqureItemNoList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureSysTestResult Output ={}", itemNoList);
        }
        
        return itemNoList;
    }

    
}