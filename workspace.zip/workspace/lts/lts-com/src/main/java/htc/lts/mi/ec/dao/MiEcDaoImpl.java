/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.ec.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 10:05:06
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class MiEcDaoImpl extends AbstractHtcDao implements MiEcDao {

    @Override
    public List inqureGnrChgPlan(Map argument) {
        return queryForList("htc.lts.mi.ec.hqml.MiEcQuery.inqureGnrChgPlan", argument);
    }
    
    @Override
    public int updateGnrChgPlan(Map argument) {
        return update("htc.lts.mi.ec.hqml.MiEcQuery.updateGnrChgPlan", argument);
    }
    
    @Override
    public List inqureGnrChgRpt(Map argument) {
        return queryForList("htc.lts.mi.ec.hqml.MiEcQuery.inqureGnrChgRpt", argument);
    }
    
    @Override
    public int updateGnrChgRpt(Map argument) {
        return update("htc.lts.mi.ec.hqml.MiEcQuery.updateGnrChgRpt", argument);
    }
    
    @Override
    public int insertGnrChgCmplRpt(Map argument) {
        return update("htc.lts.mi.ec.hqml.MiEcQuery.insertGnrChgCmplRpt", argument);
    }

    @Override
    public int insertGnrChgPlan(Map argument) {
        return update("htc.lts.mi.ec.hqml.MiEcQuery.insertGnrChgPlan", argument);
    }
    
    @Override
    public int insertHwSw(Map argument) {
        return update("htc.lts.mi.ec.hqml.MiEcQuery.insertHwSw", argument);
    }
    
    @Override
    public List inqureHwSw(Map argument) {
        return queryForList("htc.lts.mi.ec.hqml.MiEcQuery.inqureHwSw", argument);
    }
    
    @Override
    public List inqureGnrChg(Map argument) {
        return queryForList("htc.lts.mi.ec.hqml.MiEcQuery.selectGnrChgList", argument);
    }
    
    @Override
    public List inqureCmplRpt(Map argument) {
        return queryForList("htc.lts.mi.ec.hqml.MiEcQuery.inqureCmplRpt", argument);
    }
    
    @Override
    public List selectMiotIng(Map mtn) {
        return queryForList("htc.lts.mi.ec.hqml.MiEcQuery.selectMiotIng", mtn);
    }
    
    @Override
    public List inqureRfnoCrtnAndDel(Map mtn) {
        return queryForList("htc.lts.mi.ec.hqml.MiEcQuery.inqureRfnoCrtnAndDel", mtn);
    }
    
    @Override
    public int deleteGnrChgCmplRpt(Map argument) {
        return update("htc.lts.mi.ec.hqml.MiEcQuery.deleteGnrChgCmplRpt", argument);
    }
    
    @Override
    public int deleteGnrChgPlan(Map argument) {
        return update("htc.lts.mi.ec.hqml.MiEcQuery.deleteGnrChgPlan", argument);
    }
    
    @Override
    public int deleteHwSw(Map argument) {
        return update("htc.lts.mi.ec.hqml.MiEcQuery.deleteHwSw", argument);
    }
    
}
