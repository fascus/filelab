/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.qa.dao;

import java.util.List;
import java.util.Map;

import htc.commons.paging.PagingSupport;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 6. 오후 8:52:11
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 6.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface SwErrorDao {
	
	/**
     * @Method Name        : inqureSwErrorList
     * @Method description : 
     * @Date               : 2016. 10. 7.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 7.     변용수                                               CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param swError
     * @return
    */
    public List inqureSwErrorList(Map swError);
    
    
    public List inqureSwErrorList(Map swError, PagingSupport paging);
    
    /**
     * @Method Name        : insertSwErr
     * @Method description : 
     * @Date               : 2016. 10. 10.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 10.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int insertSwErr(Map swErr);
    
    /**
     * @Method Name        : updateSwErr
     * @Method description : 
     * @Date               : 2016. 10. 10.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 10.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int updateSwErr(Map swErr);
    
    /**
     * @Method Name        : inqureShpNmList
     * @Method description : 
     * @Date               : 2016. 10. 10.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 10.     변용수                                               CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param ShpTpCd
     * @return
    */
    public List inqureShpNmList(Map ShpTpCd);
    
    /**
     * @Method Name        : inqureFileList
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 12.     변용수                                               CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param swError
     * @return
    */
    public List inqureFileList(Map swError);
    
    /**
     * @Method Name        : deleteSwErr
     * @Method description : 
     * @Date               : 2016. 11. 16.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 16.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int deleteSwErr(Map swError);
    
    /**
     * @Method Name        : inqureMainNtcntList
     * @Method description : 
     * @Date               : 2016. 11. 17.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 11. 17.     변용수                                               CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @return
    */
	public List inqureMainSwErrorList(Map searchParam);
    
	/**
     * @Method Name        : insertCmnt
     * @Method description : 
     * @Date               : 2016. 12. 8.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 12. 8.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int insertCmnt(Map cmnt);
    
    /**
     * @Method Name        : updateCmnt
     * @Method description : 
     * @Date               : 2016. 12. 8.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 12. 8.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int updateCmnt(Map cmnt);
    
    /**
     * @Method Name        : deleteCmnt
     * @Method description : 
     * @Date               : 2016. 12. 8.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 12. 8.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int deleteCmnt(Map cmnt);
    

}
