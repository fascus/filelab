package htc.lts.com.category.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.commons.paging.PagingSupport;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.hone.utils.SMSUtil;
import htc.lts.com.category.dao.AlternateDao;
import htc.lts.com.category.dao.CategoryDao;
import htc.lts.com.category.dto.CategoryDto;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.annotation.VariableBind;
import htc.xplatform.utils.MessageUtil;
import htc.xplatform.utils.XPlatformUtil;
import htc.xplatform.web.XPlatformRowType;

@Service
public class CategoryServiceImpl implements CategoryService {
	private static final Logger LOGGER = LoggerFactory.getLogger(CategoryService.class);
	@Autowired
	private CategoryDao categoryDao;
	@Autowired
	private AlternateDao alternateDao;

	@Override
	@ServiceId("CCR001")
	@ReturnBind("output")
	public List<Map> listCategory(SystemHeader header, @VariableBind Map category, PagingSupport paging) {

	    LOGGER.debug("category 결과 : {}", category);
	    LOGGER.debug(header.toString());
		if (LOGGER.isInfoEnabled()) {
		    LOGGER.info("메세지 테스트 [철수][영이] => " + MessageUtil.makeMessage("E0001", "철수", "영이"));
		}
		MessageUtil.setMessage("SYE0001", "철수", "영이");
		category.put("CUSTOM_WHERE", "AND ID like 'I%' " );
		return categoryDao.listCategory(category, paging);
	}

	@Override
	@ServiceId({ "CCU001", "XXP007" })
	@ReturnBind("output")
	public int saveCategory(@DatasetBind(value="input", rowTypeFilter={XPlatformRowType.INSERT, XPlatformRowType.UPDATE, XPlatformRowType.DELETE}) List<Map> categories) {

		int result = 0;
		for (Map category : categories) {
			String rowType = XPlatformUtil.getDataRowType(category);
			if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
				result += categoryDao.insertCategory(category);
			} else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
				result += categoryDao.updateCategory(category);
			} else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
				result += categoryDao.deleteCategory(category);
			}
		}

		return result;
	}

	@Override
	public Map getCategory(@VariableBind String id) {
		Map param = new HashMap();
		param.put("ID", id);
		return categoryDao.getCategory(param);
	}

	@Override
	public CategoryDto getCategory(CategoryDto category) {
		return categoryDao.getCategory(category);
	}

	@Override
	@ServiceId("CCR002")
	@MultiReturnBind
	public Map getMultiCategory(@VariableBind("key1") String key1, @VariableBind("key2") String key2) {
		Map param = new HashMap();

		param.put("useYn", "Y");
		List<Map> list1 = categoryDao.listCategory(param);
		param.put("useYn", "Y");
		List<Map> list2 = categoryDao.listCategory(param);
		Map<String, List> data = new HashMap<>();
		data.put("input1", list1);
		data.put("input2", list2);
		return data;
	}

	@Override
	@ServiceId("CCC001")
	@ReturnBind("output")
	public List<Map> insertCategory(@DatasetBind("input") List<Map> categories) {
		for (Map category : categories) {
			categoryDao.insertCategory(category);
		}
		return categoryDao.listCategory(new HashMap());
	}

	@Override
	@ServiceId("CCU002")
	@ReturnBind("output")
	public int saveMultiCategory(@DatasetBind("input1") List<Map> categories1,
			@DatasetBind("input2") List<Map> categories2) {

		int result = 0;
		for (Map category : categories1) {
			String rowType = XPlatformUtil.getDataRowType(category);
			if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
				result += categoryDao.insertCategory(category);
			} else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
				result += categoryDao.updateCategory(category);
			} else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
				result += categoryDao.deleteCategory(category);
			}
		}
		for (Map category : categories2) {
			String rowType = XPlatformUtil.getDataRowType(category);
			if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
				result += categoryDao.insertCategory(category);
			} else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
				result += categoryDao.updateCategory(category);
			} else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
				result += categoryDao.deleteCategory(category);
			}
		}
		return result;
	}

	@Override
	@ServiceId("CCU003")
	@ReturnBind("output")
	public List<Map> updateCategory(@DatasetBind("input") List<Map> categories) {
		for (Map category : categories) {
			categoryDao.updateCategory(category);
		}
		return categoryDao.listCategory(new HashMap());
	}

	@Override
	@ServiceId("CCD001")
	@ReturnBind("output")
	public List<Map> deleteCategory(@DatasetBind("input") List<Map> categories) {
		for (Map category : categories) {
			categoryDao.deleteCategory(category);
		}
		return categoryDao.listCategory(new HashMap());
	}

	@Override
	@ServiceId("TRANS")
	@ServiceName("트랜잭션샘플")
	public void transactionSample(Map<String, Object> category) {
		int type = 2;
		if(type == 0) { // 정리
			Map<String, Object> param = new HashMap<>();
			param.put("ID", "FROMLTS");
			categoryDao.deleteCategory(param);
			param.put("ID", "FROMHONE");
			categoryDao.deleteCategory(param);
		} else{
			Map<String, Object> param1 = new HashMap<>();
			param1.put("DESCRIPTION", null);
			param1.put("USE_YN", null);
			param1.put("REG_USER", null);
			param1.put("VIEW_ORDER", null);
			param1.put("REG_DTM", null);
			categoryDao.insertCategory(param1);
			Map<String, Object> param2 = new HashMap<>();
            param2.putAll(param1);
            
			if(type == 1) { // 정상
			    param1.put("ID", "FROMHONE");
			    param1.put("NAME", "honeDatasource에서");
			    param2.put("ID", "FROMLTS");
	            param2.put("NAME", "ltsDatasource에서");
	            alternateDao.insertCategory(param2);
			}
			else if (type == 2 ){ //Transaction 분리
			    param1.put("ID", "FROMLTS");
			    param1.put("NAME", "ltsDatasource에서"); 
			    param2.put("ID", "FROMHONE");
	            param2.put("NAME", "honeDatasource에서");
	            alternateDao.insertSeperateCategory(param2); // 분리된 트랜잭션 
			}
		}
		
	}
	
	
    @Override
    @ServiceId("ZZZZ002")
    @ReturnBind("output")
    public void smsTest(@DatasetBind("input") List<Map> categories) {
       
       SMSUtil.sendSMS("01090594527", "0316287114", "운영반영 메시지 입니다. \n  이렇게 전송 됩니다.");
    }
	   
	   
}
