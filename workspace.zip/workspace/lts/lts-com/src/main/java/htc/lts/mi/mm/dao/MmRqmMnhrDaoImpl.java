/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.mm.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 3:22:14
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class MmRqmMnhrDaoImpl extends AbstractHtcDao implements MmRqmMnhrDao {
    
	@Override
    public int deleteRqmMnhr(Map rqmMnhr) {
        return  update("htc.lts.mi.mm.hqml.RqmMnhrQuery.deleteRqmMnhr", rqmMnhr);
    }
	
	@Override
    public int deleteRqmMnhr2(Map rqmMnhr) {
        return  update("htc.lts.mi.mm.hqml.RqmMnhrQuery.deleteRqmMnhr2", rqmMnhr);
    }
	
	@Override
    public int createRqmMnhr(Map rqmMnhr) {
        return  update("htc.lts.mi.mm.hqml.RqmMnhrQuery.createRqmMnhr", rqmMnhr);
    }
	
	@Override
    public int createRqmMnhr2(Map rqmMnhr) {
        return  update("htc.lts.mi.mm.hqml.RqmMnhrQuery.createRqmMnhr2", rqmMnhr);
    }

	@Override
    public List inqueryMmRqmMnhrList(Map rqmMnhr) {
        return queryForList("htc.lts.mi.mm.hqml.RqmMnhrQuery.selectMmRqmMnhrList", rqmMnhr);
    }
	
	@Override
    public List inqueryStRqmMnhrList(Map rqmMnhr) {
        return queryForList("htc.lts.mi.mm.hqml.RqmMnhrQuery.selectStRqmMnhrList", rqmMnhr);
    }
	
	@Override
    public List inqueryFaRqmMnhrList(Map rqmMnhr) {
        return queryForList("htc.lts.mi.mm.hqml.RqmMnhrQuery.selectFaRqmMnhrList", rqmMnhr);
    }
	
	@Override
    public List inqueryBpRqmMnhrList(Map rqmMnhr) {
        return queryForList("htc.lts.mi.mm.hqml.RqmMnhrQuery.selectBpRqmMnhrList", rqmMnhr);
    }
	
	/**
	 * @see htc.lts.mi.mm.dao.MmRqmMnhrDao#inqueryBpRqmMnhrOutList(java.util.Map)
	 * @Method Name        : inqueryBpRqmMnhrOutList
	 * @Method description : 
	 * @Date               : 2016. 11. 5.
	 * @Author             : 이창환 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 5.		이창환					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param rqmMnhr
	 * @return
	*/
	@Override
    public List inqueryBpRqmMnhrOutList(Map rqmMnhr) {
        return queryForList("htc.lts.mi.mm.hqml.RqmMnhrQuery.selectBpRqmMnhrOutList", rqmMnhr);
    }
	
	@Override
    public List inqueryMtRqmMnhrList(Map rqmMnhr) {
        return queryForList("htc.lts.mi.mm.hqml.RqmMnhrQuery.selectMtRqmMnhrList", rqmMnhr);
    }
	
	@Override
    public List inqueryCpRqmMnhrList(Map rqmMnhr) {
        return queryForList("htc.lts.mi.mm.hqml.RqmMnhrQuery.selectCpRqmMnhrList", rqmMnhr);
    }
	
	@Override
    public List inqueryEcRqmMnhrList(Map rqmMnhr) {
        return queryForList("htc.lts.mi.mm.hqml.RqmMnhrQuery.selectEcRqmMnhrList", rqmMnhr);
    }
	
	@Override
    public List inqueryOtRqmMnhrList(Map rqmMnhr) {
        return queryForList("htc.lts.mi.mm.hqml.RqmMnhrQuery.selectOtRqmMnhrList", rqmMnhr);
    }
	
	@Override
    public List inqueryHwRqmMnhrList(Map rqmMnhr) {
        return queryForList("htc.lts.mi.mm.hqml.RqmMnhrQuery.selectHwRqmMnhrList", rqmMnhr);
    }
	
	@Override
    public List inqueryIlRqmMnhrList(Map rqmMnhr) {
        return queryForList("htc.lts.mi.mm.hqml.RqmMnhrQuery.selectIlRqmMnhrList", rqmMnhr);
    }
	
	@Override
    public List inqueryMfgTimeList(Map rqmMnhr) {
        return queryForList("htc.lts.mi.mm.hqml.RqmMnhrQuery.selectMfgTimeList", rqmMnhr);
    }
	
	@Override
    public int insertRqmMnhr(Map rqmMnhr) {
        return  update("htc.lts.mi.mm.hqml.RqmMnhrQuery.insertRqmMnhr", rqmMnhr);
    }
	
	@Override
    public int updateRqmMnhr(Map rqmMnhr) {
        return  update("htc.lts.mi.mm.hqml.RqmMnhrQuery.updateRqmMnhr", rqmMnhr);
    }

	@Override
    public List inqueryRqmMnhr(Map rqmMnhr) {
        return queryForList("htc.lts.mi.mm.hqml.RqmMnhrQuery.inqueryRqmMnhr", rqmMnhr);
    }

}
