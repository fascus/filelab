/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.cp.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.mi.bp.dao.BreakDnDao;
import htc.lts.mi.mm.dao.MngNoDao;
import htc.lts.mi.st.dao.SysTestDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;
import htc.xplatform.web.XPlatformRowType;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:59:12
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class CyclePartServiceImpl implements CyclePartService {

    //private static final Logger logger = LoggerFactory.getLogger(CyclePartServiceImpl.class);

    @Autowired
    BreakDnDao breakDnDao;
    @Autowired
    MngNoDao mngNoDao;
    @Autowired
    SysTestDao sysTestDao;
   
   
   
  
}