package htc.lts.da.dm.dao;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 12. 오후 7:14:18
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 12.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface DataDao {
    
    /**
     * @Method Name        : inqureData
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 12.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param data
     * @return
    */
    public List inqureDataList(Map data);
    
    /**
     * @Method Name        : insertDataList
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 12.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DataList
     * @return
    */
    public int insertDataList(Map DataList);
    
    /**
     * @Method Name        : updateDataList
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 12.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DataList
     * @return
    */
    public int updateDataList(Map DataList);

    /**
     * @Method Name        : deleteDataList
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 12.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DataList
     * @return
    */
    public int deleteDataList(Map DataList);
    
    /**
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 13.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 13.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureFile(Map argument);
    
    public int deleteFile(Map deleteFile);

    public List inqureFile2(Map argument);
}
