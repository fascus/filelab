/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.qa.service;

import java.util.List;
import java.util.Map;

import htc.commons.paging.PagingSupport;
import htc.hone.core.message.SystemHeader;



/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 6:53:08
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface BoardService {
	/**
     * @Method Name        : inqureNtcnt
     * @Method description : 
     * @Date               : 2016. 10. 11.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 11.     변용수                                              CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param header
     * @param category
     * @param paging
     * @return
    */
//    public List<Map> inqureNtcnt(Map searchParam);
    public List<Map> inqureNtcnt(SystemHeader header,Map category, PagingSupport paging);
    
    /**
     * @Method Name        : inqureMainNtcnt
     * @Method description : 
     * @Date               : 2016. 11. 16.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 11. 16.     변용수                                              CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @return
    */
    public List<Map> inqureMainNtcnt(Map searchParam);
    
    
    /**
     * @Method Name        : saveNtcnt
     * @Method description : 
     * @Date               : 2016. 10. 11.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 11.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * ntcntParam 
    */
    public int saveNtcnt(List<Map> ntcntParam); 
    
    /**
     * @Method Name        : saveCmnt
     * @Method description : 
     * @Date               : 2016. 10. 13.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 13.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * cmntParam 
    */
    public int saveCmnt(List<Map> cmntParam); 
    
    /**
     * @Method Name        : deleteNtcnt
     * @Method description : 
     * @Date               : 2016. 11. 16.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 16.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * ntcntParam 
    */
    public int deleteNtcnt(List<Map> ntcntParam); 
    
    /**
     * @Method Name        : deleteCmnt
     * @Method description : 
     * @Date               : 2016. 11. 16.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 16.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * cmntParam 
    */
    public int deleteCmnt(List<Map> cmntParam); 
    
    /**
     * @Method Name        : addInqrySndngNumcs
     * @Method description : 
     * @Date               : 2016. 11. 16.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 16.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * cmntParam 
    */
    public int addInqrySndngNumcs(List<Map> cmntParam); 
}
