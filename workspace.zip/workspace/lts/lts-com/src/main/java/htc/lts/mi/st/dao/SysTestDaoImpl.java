/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.st.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 3:22:14
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class SysTestDaoImpl extends AbstractHtcDao implements SysTestDao {

    
    
    @Override
    public List inqureSysTestList(Map sysTest) {
        return queryForList("htc.lts.mi.st.hqml.SysTestQuery.selectSysTestList", sysTest);
    }
    
	
	@Override
	public int insertSysTestMaster(Map sysTest) {
		return  update("htc.lts.mi.st.hqml.SysTestQuery.insertSysTestMaster", sysTest);
	}
	
	/**
	 * @see htc.lts.mi.st.dao.SysTestDao#selectMistIng(java.util.Map)
	 * @Method Name        : selectMistIng
	 * @Method description : 
	 * @Date               : 2016. 10. 25.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 25.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param sysTest
	 * @return
	*/
	
	@Override
	public List selectMistIng(Map sysTest) {
		return queryForList("htc.lts.mi.st.hqml.SysTestQuery.selectMistIng", sysTest);
	}


	@Override
    public int insertSysTestDetail(Map sysTest) {
        return  update("htc.lts.mi.st.hqml.SysTestQuery.insertSysTestDetail", sysTest);
    }
	
	@Override
    public int insertCmplRpt(Map sysTest) {
        return  update("htc.lts.mi.st.hqml.SysTestQuery.insertCmplRpt", sysTest);
    }
	
	@Override
    public int updateCmplRpt(Map sysTest) {
        return  update("htc.lts.mi.st.hqml.SysTestQuery.updateCmplRpt", sysTest);
    }	
	
	@Override
    public List searchSysTestList(Map sysTest) {
	    return queryForList("htc.lts.mi.st.hqml.SysTestQuery.searchSysTestList", sysTest);
    }


	//@Override
	//public int insertScreenObj(Map screenObj) {
	//	return  update("htc.lts.mi.st.hqml.ScreenQuery.insertScreenObj", screenObj);
	//}
	
    /**
     * @see htc.lts.mi.st.dao.SysTestDao#inqureDmndMatr(java.util.Map)
     * @Method Name        : inqureDmndMatr
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    public List inqureDmndMatr(Map argument) {
        return queryForList("htc.lts.mi.st.hqml.SysTestQuery.inqureDmndMatr", argument);    //
    }
    
    /**
     * @see htc.lts.mi.st.dao.SysTestDao#insertDmndMatr(java.util.Map)
     * @Method Name        : insertDmndMatr
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    public int insertDmndMatr(Map argument) {
        return update("htc.lts.mi.st.hqml.SysTestQuery.insertDmndMatr", argument);
    }
    
    @Override
    public int updateDmndMatr(Map argument) {
        return update("htc.lts.mi.st.hqml.SysTestQuery.updateDmndMatr", argument);
    }
    
    @Override
    public int deleteDmndMatr(Map argument) {
        return update("htc.lts.mi.st.hqml.SysTestQuery.deleteDmndMatr", argument);
    }
    
    /**
     * @see htc.lts.mi.st.dao.SysTestDao#updateDmndMatrCtnt(java.util.Map)
     * @Method Name        : updateDmndMatrCtnt
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    public int updateDmndMatrCtnt(Map argument) {
        return update("htc.lts.mi.st.hqml.SysTestQuery.updateDmndMatrCtnt", argument);
    }
    
    /**
     * @see htc.lts.mi.st.dao.SysTestDao#inqureMtnList(java.util.Map)
     * @Method Name        : inqureMtnList
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    public List inqureMtnList(Map argument) {
        return queryForList("htc.lts.mi.st.hqml.SysTestQuery.inqureMtnList", argument);
    }
    
    /**
     * @see htc.lts.mi.st.dao.SysTestDao#inqureDmndMatrCtnt(java.util.Map)
     * @Method Name        : inqureDmndMatrCtnt
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    public List inqureDmndMatrCtnt(Map argument) {
        return queryForList("htc.lts.mi.st.hqml.SysTestQuery.inqureDmndMatrCtnt", argument);
    }
    
    @Override
    public int insertCsDgnssResultDtl(Map argument) {
        return update("htc.lts.mi.st.hqml.SysTestQuery.insertCsDgnssResultDtl", argument);
    }
    
    @Override
    public int deleteCsDgnssResultDtl(Map argument) {
        return update("htc.lts.mi.st.hqml.SysTestQuery.deleteCsDgnssResultDtl", argument);
    }
    
    @Override
    public List inqureCsDgnssResultDtl(Map argument) {
        return queryForList("htc.lts.mi.st.hqml.SysTestQuery.inqureCsDgnssResultDtl", argument);
    }
    
    @Override
    public int updateCsDgnssResultDtl(Map argument) {
        return update("htc.lts.mi.st.hqml.SysTestQuery.updateCsDgnssResultDtl", argument);
    }
    
    @Override
    public List inqureCsDgnssResultDtl2(Map argument) {
        return queryForList("htc.lts.mi.st.hqml.SysTestQuery.inqureCsDgnssResultDtl2", argument);
    }
    
    @Override
    public List inqureItemList(Map argument) {
        return queryForList("htc.lts.mi.st.hqml.SysTestQuery.inqureItemList", argument);
    }
    
    @Override
    public int deleteSysTestDetail(Map argument) {
        return update("htc.lts.mi.st.hqml.SysTestQuery.deleteSysTestDetail", argument);
    }
    
    @Override
    public int deleteCmplRpt(Map argument) {
        return update("htc.lts.mi.st.hqml.SysTestQuery.deleteCmplRpt", argument);
    }
    
    @Override
    public int mergeDgnssRslt(Map argument) {
        return update("htc.lts.mi.st.hqml.SysTestQuery.mergeDgnssRslt", argument);
    }
}
