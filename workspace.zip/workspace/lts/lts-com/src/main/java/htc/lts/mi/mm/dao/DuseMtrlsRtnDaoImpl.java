/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.mm.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 3:22:14
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class DuseMtrlsRtnDaoImpl extends AbstractHtcDao implements DuseMtrlsRtnDao {

    
    
    @Override
    public List inqureDuseMtrlsRtnList(Map duseMtrlsRtn) {
        return queryForList("htc.lts.mi.mm.hqml.DuseMtrlsRtnQuery.selectDuseMtrlsRtnList", duseMtrlsRtn);
    }
    
    @Override
    public int insertDuseMtrlsRtn(Map usePn) {
        return  update("htc.lts.mi.mm.hqml.DuseMtrlsRtnQuery.insertDuseMtrlsRtn", usePn);
    }
    
    @Override
    public int updateDuseMtrlsRtn(Map usePn) {
        return  update("htc.lts.mi.mm.hqml.DuseMtrlsRtnQuery.updateDuseMtrlsRtn", usePn);
    }
    
    @Override
    public int updateDuseMtrlsRtn2(Map usePn) {
        return  update("htc.lts.mi.mm.hqml.DuseMtrlsRtnQuery.updateDuseMtrlsRtn2", usePn);
    }
    
    @Override
    public int deleteDuseMtrlsRtn(Map usePn) {
        return  update("htc.lts.mi.mm.hqml.DuseMtrlsRtnQuery.deleteDuseMtrlsRtn", usePn);
    }
    
    @Override
    public int updateDuseMtrlsRtn3(Map usePn) {
        return  update("htc.lts.mi.mm.hqml.DuseMtrlsRtnQuery.updateDuseMtrlsRtn3", usePn);
    }
    
    @Override
    public int updateDuseMtrlsRtn4(Map usePn) {
        return  update("htc.lts.mi.mm.hqml.DuseMtrlsRtnQuery.updateDuseMtrlsRtn4", usePn);
    }
    
    @Override
    public List selectPnCnt(Map usePn) {
        return queryForList("htc.lts.mi.mm.hqml.DuseMtrlsRtnQuery.selectPnCnt", usePn);
    }
    @Override
    public int updateQtyMerge(Map usePn) {
        return  update("htc.lts.mi.mm.hqml.DuseMtrlsRtnQuery.updateQtyMerge", usePn);
    }
	
}
