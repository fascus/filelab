/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.service;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 4. 오후 9:34:03
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 4.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface ItemService {
	
	/**
     * @Method Name        : inqureItem
     * @Method description : 
     * @Date               : 2016. 10. 04.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 04.     변용수                                              CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    public List<Map> inqureItem(Map searchParam);
    
    /**
     * @Method Name        : inqureShpTpCdList
     * @Method description : 
     * @Date               : 2016. 10. 05.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 05.     변용수                                              CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    public List<Map> inqureShpTpCdList(Map searchParam);
    
    /**
     * @Method Name        : inqureEqList
     * @Method description : 
     * @Date               : 2016. 10. 05.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 05.     변용수                                              CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    public List<Map> inqureEqList(Map searchParam);
    
    /**
     * @Method Name        : saveItem
     * @Method description : 
     * @Date               : 2016. 10. 05.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 05.     변용수                                              CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param insertParam
     * @return
    */
    public int saveItem(List<Map> insertParam);
    
    /**
     * @Method Name        : insertItem
     * @Method description : 
     * @Date               : 2016. 10. 06.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 06.     변용수                                              CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param insertParam
     * @return
    */
    public int insertItem(List<Map> insertParam);
    
    /**
     * @Method Name        : saveItemShpTpCd
     * @Method description : 
     * @Date               : 2016. 10. 06.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 06.     변용수                                              CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param insertParam
     * @return
    */
    public int saveItemShpTpCd(List<Map> insertParam);
    
    /**
     * @Method Name        : saveItemEqList
     * @Method description : 
     * @Date               : 2016. 10. 06.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 06.     변용수                                              CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param insertParam
     * @return
    */
    public int saveItemEqList(List<Map> insertParam);

    public int deleteEq(Map insertParam);
    
    public int deleteItem(List<Map> shipNmList);
    

}
