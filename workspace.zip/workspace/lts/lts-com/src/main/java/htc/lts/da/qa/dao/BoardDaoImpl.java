/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.qa.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.commons.paging.PagingSupport;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 6:52:31
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class BoardDaoImpl extends AbstractHtcDao implements BoardDao {

	/**
	 * @see htc.lts.da.qa.dao.BoardDao#inqureNtcntList(java.util.Map)
	 * @Method Name        : inqureNtcntList
	 * @Method description : 
	 * @Date               : 2016. 10. 11.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 11.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
	//public List inqureNtcntList(Map searchParam) {
	public List inqureNtcntList(Map searchParam, PagingSupport paging) { 
		//return queryForList("htc.lts.da.qa.hqml.BoardQuery.selectNtcntList", searchParam);
		return queryForPagingList("htc.lts.da.qa.hqml.BoardQuery.selectNtcntList", searchParam, paging);
	}

	/**
	 * @see htc.lts.da.qa.dao.BoardDao#insertNtcnt(java.util.Map)
	 * @Method Name        : insertNtcnt
	 * @Method description : 
	 * @Date               : 2016. 10. 11.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 11.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param ctcnt
	 * @return
	*/
	
	
	
	@Override
	public int insertNtcnt(Map ntcnt) {
		return update("htc.lts.da.qa.hqml.BoardQuery.insertNtcnt", ntcnt);
	}

	/**
	 * @see htc.lts.da.qa.dao.BoardDao#inqureMainNtcntList()
	 * @Method Name        : inqureMainNtcntList
	 * @Method description : 
	 * @Date               : 2016. 11. 16.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 16.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @return
	*/
	
	@Override
	public List inqureMainNtcntList(Map searchParam) {
		return queryForList("htc.lts.da.qa.hqml.BoardQuery.selectMainNtcntList", searchParam);
	}

	/**
	 * @see htc.lts.da.qa.dao.BoardDao#updateNtcnt(java.util.Map)
	 * @Method Name        : updateNtcnt
	 * @Method description : 
	 * @Date               : 2016. 10. 11.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 11.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param ntcnt
	 * @return
	*/
	
	@Override
	public int updateNtcnt(Map ntcnt) {
		return update("htc.lts.da.qa.hqml.BoardQuery.updateNtcnt", ntcnt);
	}

	/**
	 * @see htc.lts.da.qa.dao.BoardDao#insertCmnt(java.util.Map)
	 * @Method Name        : insertCmnt
	 * @Method description : 
	 * @Date               : 2016. 10. 13.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 13.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmnt
	 * @return
	*/
	
	@Override
	public int insertCmnt(Map cmnt) {
		return update("htc.lts.da.qa.hqml.BoardQuery.insertCmnt", cmnt);
	}

	/**
	 * @see htc.lts.da.qa.dao.BoardDao#updateCmnt(java.util.Map)
	 * @Method Name        : updateCmnt
	 * @Method description : 
	 * @Date               : 2016. 10. 13.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 13.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmnt
	 * @return
	*/
	
	@Override
	public int updateCmnt(Map cmnt) {
		return update("htc.lts.da.qa.hqml.BoardQuery.updateCmnt", cmnt);
	}

	/**
	 * @see htc.lts.da.qa.dao.BoardDao#deleteNtcnt(java.util.Map)
	 * @Method Name        : deleteNtcnt
	 * @Method description : 
	 * @Date               : 2016. 11. 16.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 16.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param ntcnt
	 * @return
	*/
	
	@Override
	public int deleteNtcnt(Map ntcnt) {
		return update("htc.lts.da.qa.hqml.BoardQuery.deleteNtcnt", ntcnt);
	}

	/**
	 * @see htc.lts.da.qa.dao.BoardDao#deleteCmnt(java.util.Map)
	 * @Method Name        : deleteCmnt
	 * @Method description : 
	 * @Date               : 2016. 11. 16.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 16.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmnt
	 * @return
	*/
	
	@Override
	public int deleteCmnt(Map cmnt) {
		return update("htc.lts.da.qa.hqml.BoardQuery.deleteCmnt", cmnt);
	}

	/**
	 * @see htc.lts.da.qa.dao.BoardDao#addInqrySndngNumcs(java.util.Map)
	 * @Method Name        : addInqrySndngNumcs
	 * @Method description : 
	 * @Date               : 2016. 11. 16.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 16.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmnt
	 * @return
	*/
	
	@Override
	public int addInqrySndngNumcs(Map cmnt) {
		return update("htc.lts.da.qa.hqml.BoardQuery.addInqrySndngNumcs", cmnt);
	}
	
	
	
	
	

		

}
