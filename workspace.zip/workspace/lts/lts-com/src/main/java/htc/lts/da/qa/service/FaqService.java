/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.qa.service;

import java.util.List;
import java.util.Map;

import htc.commons.paging.PagingSupport;
import htc.hone.core.message.SystemHeader;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 12. 오후 2:45:54
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 12.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface FaqService {
	/**
     * @Method Name        : inqureFaq
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 12.     변용수                                              CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
//    public List<Map> inqureFaq(Map searchParam);
	public List<Map> inqureFaq(SystemHeader header, Map category, PagingSupport paging);
    
    /**
     * @Method Name        : saveFaq
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 12.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * ntcntParam 
    */
    public int saveFaq(List<Map> faqParam); 
    
    /**
     * @Method Name        : saveCmnt
     * @Method description : 
     * @Date               : 2016. 10. 17.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 17.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * cmntParam 
    */
    public int saveCmnt(List<Map> cmntParam); 
    


}
