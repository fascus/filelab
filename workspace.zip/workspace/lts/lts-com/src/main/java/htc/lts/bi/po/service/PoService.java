/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.po.service;

import java.util.List;
import java.util.Map;

import htc.hone.core.message.SystemHeader;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 22. 오전 8:25:28
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 22.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface PoService {
    
	public List<Map> inqurePo(Map argument);

    public int createPo(SystemHeader header, Map argument);

    public int isertPo(List<Map> arguments);
}
