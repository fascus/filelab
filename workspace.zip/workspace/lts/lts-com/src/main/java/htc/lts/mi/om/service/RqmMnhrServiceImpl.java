package htc.lts.mi.om.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.mi.mm.service.UsePnServiceImpl;
import htc.lts.mi.om.dao.RqmMnhrDao;
import htc.lts.mi.om.dao.WrkCtntDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:21:01
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class RqmMnhrServiceImpl implements RqmMnhrService {

    private static final Logger logger = LoggerFactory.getLogger(UsePnServiceImpl.class);
    
    @Autowired
    RqmMnhrDao rqmMnhrDao;
    @Autowired
    WrkCtntDao wrkCtntDao;

    @Override
    @ServiceId("MIOMS007")
    @ServiceName("단종관리계획서조회")
    @ReturnBind("output")
    public List<Map> inqureyRqmMnhr(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureyDsctnIdtfPlan, Input Param={}", searchParam); 
        }
        
            List<Map> dsctnIdtfPlanList = rqmMnhrDao.inqureyRqmMnhrList(searchParam);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureyDsctnIdtfPlan Output ={}", dsctnIdtfPlanList);
        }
        
        return dsctnIdtfPlanList;
    }
    
    @Override
    @ServiceId("MIOMX005")
    @ServiceName("단종관리완료보고저장")
    @ReturnBind("output")
    public int saveRqmMnhr(@DatasetBind("input") List<Map> rqmMnhrList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveDsctnIdtfCmplRpt, Input Param={}", rqmMnhrList); 
        }
        
        //String WRKDT;
        int result = 0;
        for (Map rqmMnhr : rqmMnhrList) {
            
//            WRKDT = rqmMnhr.get("WRKDT").toString().replace("-", "");
            
//            rqmMnhr.put("WRKDT", WRKDT);
            
            String rowType = XPlatformUtil.getDataRowType(rqmMnhr);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += rqmMnhrDao.insertRqmMnhr(rqmMnhr);
                result += rqmMnhrDao.insertDsctnIdtfWrkCtnt(rqmMnhr);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += rqmMnhrDao.updateRqmMnhr(rqmMnhr);
                result += rqmMnhrDao.updateDsctnIdtfWrkCtnt(rqmMnhr);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += rqmMnhrDao.deleteRqmMnhr(rqmMnhr);
                result += wrkCtntDao.deleteDsctnIdtfWrkCtnt(rqmMnhr);
            }
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveDsctnIdtfCmplRpt Output ={}", result);
        }

        return result; 
    }
    
    
}
