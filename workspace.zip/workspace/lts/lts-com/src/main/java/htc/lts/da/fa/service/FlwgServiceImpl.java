/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.fa.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.lts.da.fa.dao.FlwgDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 10:04:40
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class FlwgServiceImpl implements FlwgService {

    private static final Logger logger = LoggerFactory.getLogger(FlwgServiceImpl.class);

    @Autowired
    FlwgDao flwgDao;
   
    /**
     * @see htc.lts.da.fa.service.FlwgService#inqureFlwg(java.util.Map)
     * @Method Name        : inqureFlwg
     * @Method description : 
     * @Date               : 2016. 10. 27.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 27.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("DAFAS100")
    @ServiceName("후속조치조회")
    @ReturnBind("output")
    public List<Map> inqureFlwg(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureFlwg, Input Param={}", argument); 
        }
        
        List<Map> result = flwgDao.inqureFlwgList(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFlwg Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("DAFAX100")
    @ServiceName("후속조치저장")
    @ReturnBind("output")
    public int saveFlwg(@DatasetBind("input") List<Map> flwgList) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : saveFlwg, Input Param={}", flwgList); 
          }
        

        int result = 0;
          
          for (Map flwg : flwgList) {
             result +=flwgDao.updateFlwg(flwg);
          }

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : saveFlwg Output ={}", result);
          }

          return result; 
    }
    
    
    @Override
    @ServiceId("DAFAS101")
    @ServiceName("후속조치조회")
    @ReturnBind("output")
    public List<Map> inqureResult(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureFlwg, Input Param={}", argument); 
        }
        
        List<Map> result = flwgDao.inqureResultList(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFlwg Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("DAFAX101")
    @ServiceName("후속조치부품저장")
    @ReturnBind("output")
    public int saveFlwgPn(@DatasetBind("input") List<Map> flwgPnList) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : saveFlwgPn, Input Param={}", flwgPnList); 
          }
        

        int result = 0;
          
          for (Map flwgPn : flwgPnList) {
              
             String rowType = XPlatformUtil.getDataRowType(flwgPn);
             if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                 
                  result +=flwgDao.insertFlwgPn(flwgPn);
                  
//              }else if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_UPDATED)) {
//                 
//                  result +=flwgDao.updateFlwgPn(flwgPn);
                  
             } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                 
                  result +=flwgDao.deleteFlwgPn(flwgPn);
                  
              }
          }

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : saveFlwgPn Output ={}", result);
          }

          return result; 
    }
    
    @Override
    @ServiceId("DAFAS102")
    @ServiceName("후속조치부품조회")
    @ReturnBind("output")
    public List<Map> inqureFlwgPn(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureFlwg, Input Param={}", argument); 
        }
        
        List<Map> result = flwgDao.inqureFlwgPnList(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFlwg Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("DAFAX102")
    @ServiceName("후속조치부품저장")
    @ReturnBind("output")
    public int saveFlwgPrplsPlan(@DatasetBind("input") List<Map> flwgPrplsPlanList) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : saveFlwgPrplsPlan, Input Param={}", flwgPrplsPlanList); 
          }
        

        int result = 0;
          
          for (Map flwgPrplsPlan : flwgPrplsPlanList) {
              
             String rowType = XPlatformUtil.getDataRowType(flwgPrplsPlan);
             
             if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                 
                  result +=flwgDao.insertFlwgPrplsPlan(flwgPrplsPlan);
                  
             } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                 
                  result +=flwgDao.updateFlwgPrplsPlan(flwgPrplsPlan);
                  
              } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                 
                  result +=flwgDao.deleteFlwgPrplsPlan(flwgPrplsPlan);
                  
              }
          }

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : saveFlwgPrplsPlan Output ={}", result);
          }

          return result; 
    }
    
    @Override
    @ServiceId("DAFAS103")
    @ServiceName("후속조치부품조회")
    @ReturnBind("output")
    public List<Map> inqureyFlwgPrplsplan(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureFlwg, Input Param={}", argument); 
        }
        
        List<Map> result = flwgDao.inqureyFlwgPrplsplan(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFlwg Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("DAFAX103")
    @ServiceName("후속조치부품저장")
    @ReturnBind("output")
    public int saveFlwgPrplsPrsts(@DatasetBind("input") List<Map> flwgPrplsPlanList) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : saveFlwgPrplsPlan, Input Param={}", flwgPrplsPlanList); 
          }
        

        int result = 0;
          
          for (Map flwgPrplsPlan : flwgPrplsPlanList) {
              
             String rowType = XPlatformUtil.getDataRowType(flwgPrplsPlan);
             if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                 
                  result +=flwgDao.insertFlwgPrplsPrsts(flwgPrplsPlan);
                  
             } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                 
                  result +=flwgDao.updateFlwgPrplsPrsts(flwgPrplsPlan);
                  
              } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                 
                  result +=flwgDao.deleteFlwgPrplsPrsts(flwgPrplsPlan);
                  
              }
          }

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : saveFlwgPrplsPlan Output ={}", result);
          }

          return result; 
    }
    
    @Override
    @ServiceId("DAFAS104")
    @ServiceName("후속조치부품조회")
    @ReturnBind("output")
    public List<Map> inqureyFlwgPrplsPrsts(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureFlwg, Input Param={}", argument); 
        }
        
        List<Map> result = flwgDao.inqureyFlwgPrplsPrsts(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFlwg Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("DAFAS105")
    @ServiceName("후속조치조회")
    @ReturnBind("output")
    public List<Map> inqureSysTestResult(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureFlwg, Input Param={}", argument); 
        }
        
        List<Map> result = flwgDao.inqureSysTestResultList(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFlwg Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("DAFAS106")
    @ServiceName("후속조치조회")
    @MultiReturnBind
    public Map inqureFlwgActitm(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){
            logger.debug("Service Method : inqureFlwgActitm, Input Param={}", argument);
        } 
        List<Map> flwgActitm = flwgDao.inqureFlwgActitm(argument);
        List<Map> spvsnDept = flwgDao.inqureSpvsnDept(argument);
        List<Map> coprDept = flwgDao.inqureCoprDept(argument);
        
        Map result = new HashMap();

        result.put("output1", flwgActitm);
        result.put("output2", spvsnDept);
        result.put("output3", coprDept);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFlwgActitm Output ={}", result);
        }
        return result;
    }
    
    
    @Override
    @ServiceId("DAFAS701")
    @ServiceName("후속조치조회")
    @ReturnBind("output")
    public List<Map> inqureFollowAct(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureFlwg, Input Param={}", argument); 
        }
        
        List<Map> result = flwgDao.inqureFollowAct(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFlwg Output ={}", result);
        }
        
        return result;
    }
    
}