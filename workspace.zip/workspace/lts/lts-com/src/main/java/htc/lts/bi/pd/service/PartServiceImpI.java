/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.bi.pd.dao.PartDao;
import htc.lts.da.dm.dao.DataDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date          : 2016. 10. 4. 오후 8:07:24
 * @Author        : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date             Programmer              Description
 * 2016. 10. 4.     강진오                 CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 10. 오후 1:35:44
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 10.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class PartServiceImpI implements PartService{

    private static final Logger LOGGER = LoggerFactory.getLogger(PartServiceImpI.class);
    
    @Autowired
    PartDao partDao;
  
    @Autowired
    private DataDao dataDao;
    
    
    /**
     * @see htc.lts.bi.pd.service.PartService#inqurePart(java.util.Map)
     * @Method Name        : inqurePart
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("BIPDS301")
    @ServiceName("부품조회")
    @ReturnBind("output")
    public List<Map> inqurePart(@DatasetBind("input") Map searchParam) {

        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : inqurePart, Input Param={}", searchParam); 
        } 
        
        List<Map> partList = partDao.inqurePartList(searchParam);
                
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqurePart Output ={}", partList);
        }
        
        return partList;
    }
    
    /**
     * @Method Name        : inqurePartMake
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("BIPDS302")
    @ServiceName("함정관리내역(부품제조회사)조회")
    @ReturnBind("output")
    public List<Map> inqurePartMake(@DatasetBind("input") Map searchParam) {

        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : inqurePartMake, Input Param={}", searchParam); 
        } 
        
        List<Map> partList = partDao.inqurePartMake(searchParam);
                
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqurePartMake Output ={}", partList);
        }
        
        return partList;
    }
    
    /**
     * @Method Name        : insertPart
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("BIPDS303")
    @ServiceName("부품 함정관리 내역 저장")
    @ReturnBind("output")
    public int insertPartMake(@DatasetBind("input") List<Map> searchParam) {
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : insertPartMake, Input Param={}", searchParam); 
        }
        
        int result = 0;
        for (Map PartMake : searchParam) {
            String rowType = XPlatformUtil.getDataRowType(PartMake);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    result += partDao.insertPartMake(PartMake);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += partDao.updatePartMake(PartMake);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += partDao.deletePartMake(PartMake);
            }
        }
               

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : insertPartMake Output ={}", result);
        }

        return result; 
    }
    
    /**
     * @Method Name        : insertPartList
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("BIPDS304")
    @ServiceName("부품 내역 수정")
    @ReturnBind("output")
    public int upDatePartList(@DatasetBind("input") List<Map> searchParam) {
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : upDatePartList, Input Param={}", searchParam); 
        }
        
        int result = 0;
        for (Map PartList : searchParam) {
                result += partDao.updatePartList(PartList);
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : upDatePartList Output ={}", result);
        }

        return result; 
    }
    
    /**
     * @see htc.lts.bi.pd.service.PartService#insertPartList(java.util.List)
     * @Method Name        : insertPartList
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("BIPDS305")
    @ServiceName("부품 내역 저장")
    @ReturnBind("output")
    public int insertPartList(@DatasetBind("input") List<Map> searchParam) {
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : insertPartList, Input Param={}", searchParam); 
        }
        
        int result = 0;
        for (Map PartList : searchParam) {
                    result += partDao.insertPartList(PartList);
            
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : insertPartList Output ={}", result);
        }

        return result; 
    }
    
    /**
     * @see htc.lts.bi.pd.service.PartService#deletePartList(java.util.List)
     * @Method Name        : deletePartList
     * @Method description : 
     * @Date               : 2016. 10. 10.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 10.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("BIPDS306")
    @ServiceName("부품 내역 저장")
    @ReturnBind("output")
    public int deletePartList(@DatasetBind("input") List<Map> searchParam) {
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : deletePartList, Input Param={}", searchParam); 
        }
        
        int result = 0;
        for (Map PartList : searchParam) {
            result += partDao.deletePartList(PartList);
            
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : deletePartList Output ={}", result);
        }

        return result; 
    }
    
    /**
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 10.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 10.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("BIPDS307")
    @ReturnBind("output")
    public List<Map> inqureFile(@DatasetBind("input") Map argument) {

        argument.put("FILENO", argument.get("CMPNTS_ATCHFL_FILENO"));
        List<Map> result = dataDao.inqureFile(argument);
        //List<Map> result = partDao.inqureFile(argument);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureFile Output ={}", result);
        }

        return result;
    }
    
    @Override
    @ServiceId("BIPDS308")
    @ServiceName("첨부파일 삭제")
    @ReturnBind("output")
    public int deleteFile(@DatasetBind("input") List<Map> deleteFileList) {
        if(LOGGER.isDebugEnabled()){ 
              LOGGER.debug("Service Method : deleteFile, Input Param={}", deleteFileList); 
          }
        

        int result = 0;
          
          for (Map deleteFile : deleteFileList) {
              
                  String rowType = XPlatformUtil.getDataRowType(deleteFile);
                 if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                     
                      result +=partDao.deleteFile(deleteFile);
                      
                  }
          }

          if (LOGGER.isDebugEnabled()) {
              LOGGER.debug("Service Method : deleteFile Output ={}", result);
          }

          return result; 
    }
    
    
    @Override
    @ServiceId("BIPDD006")
    @ServiceName("부품 내역 수정")
    @ReturnBind("output")
    public int deletePart(@DatasetBind("input") List<Map> searchParam) {
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : deletePart, Input Param={}", searchParam); 
        }
        
        int result = 0;
        for (Map PartList1 : searchParam) {
             result += partDao.deletePartList(PartList1);
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : deletePart Output ={}", result);
        }

        return result; 
    }
    
    
    
    /**
     * @see htc.lts.bi.pd.service.PartService#inqureEqNm(java.util.Map)
     * @Method Name        : inqureEqNm
     * @Method description : 
     * @Date               : 2016. 11. 2.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 2.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("BIPDS500")
    @ServiceName("부품조회")
    @ReturnBind("output")
    public List<Map> inqureEqNm(@DatasetBind("input") Map searchParam) {

        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : inqureEqNm, Input Param={}", searchParam); 
        } 
        
        List<Map> eqNmList = partDao.inqureEqNmList(searchParam);
                
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureEqNm result Output ={}", eqNmList);
        }
        
        return eqNmList;
    }
    
    
    
    
    
    
    
    

}