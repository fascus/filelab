/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.qa.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.commons.paging.PagingSupport;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 7. 오전 10:29:44
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 7.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class SwErrorDaoImpl extends AbstractHtcDao implements SwErrorDao {

	/**
	 * @see htc.lts.da.qa.dao.SwErrorDao#inqureSwErrorList(java.util.Map)
	 * @Method Name        : inqureSwErrorList
	 * @Method description : 
	 * @Date               : 2016. 10. 7.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 7.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param swError
	 * @return
	*/
	
	@Override
	public List inqureSwErrorList(Map swError) {
		return queryForList("htc.lts.da.qa.hqml.SwErrorQuery.selectSwErrorList", swError);
	}

	   @Override
	    public List inqureSwErrorList(Map swError, PagingSupport paging) {    
	        return queryForPagingList("htc.lts.da.qa.hqml.SwErrorQuery.selectSwErrorList", swError, paging);
	    }
	   
	/**
	 * @see htc.lts.da.qa.dao.SwErrorDao#insertSwErr(java.util.Map)
	 * @Method Name        : insertSwErr
	 * @Method description : 
	 * @Date               : 2016. 10. 10.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 10.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param swErr
	 * @return
	*/
	
	@Override
	public int insertSwErr(Map swErr) {
		return update("htc.lts.da.qa.hqml.SwErrorQuery.insertSwError", swErr);
	}

	/**
	 * @see htc.lts.da.qa.dao.SwErrorDao#updateSwErr(java.util.Map)
	 * @Method Name        : updateSwErr
	 * @Method description : 
	 * @Date               : 2016. 10. 10.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 10.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param swErr
	 * @return
	*/
	
	@Override
	public int updateSwErr(Map swErr) {
		return update("htc.lts.da.qa.hqml.SwErrorQuery.updateSwError", swErr);
	}

	/**
	 * @see htc.lts.da.qa.dao.SwErrorDao#inqureShpNmList(java.util.Map)
	 * @Method Name        : inqureShpNmList
	 * @Method description : 
	 * @Date               : 2016. 10. 10.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 10.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param ShpTpCd
	 * @return
	*/
	
	@Override
	public List inqureShpNmList(Map ShpTpCd) {
		return queryForList("htc.lts.da.qa.hqml.SwErrorQuery.selectShpNmList", ShpTpCd);
	}

	/**
	 * @see htc.lts.da.qa.dao.SwErrorDao#inqureFileList(java.util.Map)
	 * @Method Name        : inqureFileList
	 * @Method description : 
	 * @Date               : 2016. 10. 12.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 12.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param swError
	 * @return
	*/
	
	@Override
	public List inqureFileList(Map swError) {

		return queryForList("htc.lts.da.qa.hqml.SwErrorQuery.inqureFile", swError);
	}

	/**
	 * @see htc.lts.da.qa.dao.SwErrorDao#deleteSwErr(java.util.Map)
	 * @Method Name        : deleteSwErr
	 * @Method description : 
	 * @Date               : 2016. 11. 16.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 16.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param swError
	 * @return
	*/
	
	@Override
	public int deleteSwErr(Map swError) {
		return update("htc.lts.da.qa.hqml.SwErrorQuery.deleteSwError", swError);
	}

	/**
	 * @see htc.lts.da.qa.dao.SwErrorDao#inqureMainSwErrorList(java.util.Map)
	 * @Method Name        : inqureMainSwErrorList
	 * @Method description : 
	 * @Date               : 2016. 11. 17.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 17.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
	public List inqureMainSwErrorList(Map searchParam) {
		return queryForList("htc.lts.da.qa.hqml.SwErrorQuery.selectMainSwErrorList", searchParam);
	}

	/**
	 * @see htc.lts.da.qa.dao.SwErrorDao#insertCmnt(java.util.Map)
	 * @Method Name        : insertCmnt
	 * @Method description : 
	 * @Date               : 2016. 12. 8.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 12. 8.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmnt
	 * @return
	*/
	
	@Override
	public int insertCmnt(Map cmnt) {
		return update("htc.lts.da.qa.hqml.SwErrorQuery.insertCmnt", cmnt);
	}

	/**
	 * @see htc.lts.da.qa.dao.SwErrorDao#updateCmnt(java.util.Map)
	 * @Method Name        : updateCmnt
	 * @Method description : 
	 * @Date               : 2016. 12. 8.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 12. 8.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmnt
	 * @return
	*/
	
	@Override
	public int updateCmnt(Map cmnt) {
		return update("htc.lts.da.qa.hqml.SwErrorQuery.UpdateCmnt", cmnt);
	}

	/**
	 * @see htc.lts.da.qa.dao.SwErrorDao#deleteCmnt(java.util.Map)
	 * @Method Name        : deleteCmnt
	 * @Method description : 
	 * @Date               : 2016. 12. 8.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 12. 8.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmnt
	 * @return
	*/
	
	@Override
	public int deleteCmnt(Map cmnt) {
		return update("htc.lts.da.qa.hqml.SwErrorQuery.deleteCmnt", cmnt);
	}

}
