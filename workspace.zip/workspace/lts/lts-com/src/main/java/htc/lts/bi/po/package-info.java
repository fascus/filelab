/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 26. 오후 2:46:11
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 26.		변용수				CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
package htc.lts.bi.po;