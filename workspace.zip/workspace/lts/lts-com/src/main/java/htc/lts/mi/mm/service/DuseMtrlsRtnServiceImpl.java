/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.mm.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.mi.mm.dao.DuseMtrlsRtnDao;
import htc.lts.mi.mm.dao.UsePnDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:59:12
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class DuseMtrlsRtnServiceImpl implements DuseMtrlsRtnService {

    private static final Logger logger = LoggerFactory.getLogger(DuseMtrlsRtnServiceImpl.class);

    @Autowired
    DuseMtrlsRtnDao duseMtrlsRtnDao;

    @Autowired
    UsePnDao usePnDao;
    
    @Override
    @ServiceId("MIMMS012")
    @ServiceName("부품조회")
    @ReturnBind("output")
    public List<Map> inqureDuseMtrlsRtn(@DatasetBind("input") Map searchParam) {
    	
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureDuseMtrlsRtn, Input Param={}", searchParam); 
        }
        
        List<Map> duseMtrlsRtnList = duseMtrlsRtnDao.inqureDuseMtrlsRtnList(searchParam);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureDuseMtrlsRtn Output ={}", duseMtrlsRtnList);
        }
        
        return duseMtrlsRtnList;
    }
    
    @Override
    @ServiceId("MIMMX014")
    @ServiceName("폐자재저장")
    @ReturnBind("output")
    public int saveDuseMtrlsRtn(@DatasetBind("input") List<Map> duseMtrlsRtnList) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : deleteFile, Input Param={}", duseMtrlsRtnList); 
          }
        

        int result = 0;
          
          for (Map duseMtrlsRtn : duseMtrlsRtnList) {
              
                  String rowType = XPlatformUtil.getDataRowType(duseMtrlsRtn);
                  if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                     
                	 //usePnDao.updateUsePn2(duseMtrlsRtn);
                     result +=duseMtrlsRtnDao.updateDuseMtrlsRtn3(duseMtrlsRtn);
                      
                  }
          }

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : deleteFile Output ={}", result);
          }

          return result; 
    }

    @Override
    @ServiceId("MIMMX015")
    @ServiceName("폐자재수정")
    @ReturnBind("output")
    public int updateDuseMtrlsRtn(@DatasetBind("input") List<Map> duseMtrlsRtnList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : updateDuseMtrlsRtn, Input Param={}", duseMtrlsRtnList); 
        }
        
        
        int result = 0;
        
        for (Map duseMtrlsRtn : duseMtrlsRtnList) {

            logger.debug("Service Method : updateDuseMtrlsRtn, Input Param={}", duseMtrlsRtnList); 
            
            String rowType = XPlatformUtil.getDataRowType(duseMtrlsRtn);
            result +=duseMtrlsRtnDao.updateDuseMtrlsRtn4(duseMtrlsRtn);
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateDuseMtrlsRtn Output ={}", result);
        }
        
        return result; 
    }
}