/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.hone.utils.SMSUtil;
import htc.lts.bi.pd.dao.RateDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;


/**
 * @Class KorName : RateServiceImpI
 * @Date		  : 2016. 11. 5. 오전 11:11:51
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 11. 5.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class RateServiceImpI implements RateService{

    private static final Logger logger = LoggerFactory.getLogger(RateServiceImpI.class);
    
    @Autowired
    RateDao rateDao;
    
    @Override
    @ServiceId("BIPDS602")
    @ServiceName("환율조회")
    @MultiReturnBind
    public Map<String, List> inqureExchangRate(@DatasetBind("input") Map searchParam) {

        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureRate, Input Param={}", searchParam); 
        } 

        List<Map> standardList = rateDao.inqureStandard(searchParam);
        List<Map> costList = rateDao.inqureCost(searchParam);
        List<Map> mandayList = rateDao.inqureManday(searchParam);
        List<Map> rateList = rateDao.inqureRate(searchParam);
        List<Map> lbcstList = rateDao.inqureLbcst(searchParam);
        List<Map> outscList = rateDao.inqureOutsc(searchParam);
        List<Map> costMainList = rateDao.inqureCostMain(searchParam);
        List<Map> applyList = rateDao.inqureApply(searchParam);
        List<Map> mfgTimeList = rateDao.inqueryMfgTimeList(searchParam);
        
        Map<String, List> data = new HashMap<>();

        data.put("standard", standardList);
        data.put("cost", costList);
        data.put("manday", mandayList);
        data.put("rate", rateList);
        data.put("lbcst", lbcstList);
        data.put("outsc", outscList);
        data.put("costMain", costMainList);
        data.put("apply", applyList);
        data.put("mfgTime", mfgTimeList);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : result Output ={}", standardList);
        }
        
        return data;
    }
    
    @Override
    @ServiceId("BIPDS601")
    @ServiceName("계략원가 갑지 저장")
    @ReturnBind("output")
    public int saveCostMain(@DatasetBind("input") List<Map> costmainList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveCostMain, Input Param={}", costmainList); 
        }
        
        int result = 0;
        for (Map CostMain : costmainList) {
            String rowType = XPlatformUtil.getDataRowType(CostMain);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
               result += rateDao.insertCostMain(CostMain);
               result += rateDao.updateAmount(CostMain);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += rateDao.updateCostMain(CostMain);
                result += rateDao.updateAmount(CostMain);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                //result += rateDao.deleteCostMain(Apply);
            }
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveCostMain Output ={}", result);
        }

        return result; 
    }
    
}
