/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.ra.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.bi.ra.dao.SwVerDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 11. 17. 오전 8:25:13
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 11. 17.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class SwVerServiceImpl implements SwVerService {
	
	private static final Logger logger = LoggerFactory.getLogger(SwVerServiceImpl.class);

	@Autowired
	private SwVerDao swVerDao;
	
	  @Override
	  @ServiceId({"BIRAX002"})
	  @ServiceName("SwVer저장")
	  @ReturnBind("output")
	  public int mergeSwVer(@DatasetBind("input") List<Map> arguments) {
	      if(logger.isDebugEnabled()){ 
	            logger.debug("Service Method : SwVerList, Input Param={}", arguments); 
	        }
	      
	        int result = 0;
	        for (Map argument : arguments) {
	          String rowType = XPlatformUtil.getDataRowType(argument);
	          if(logger.isDebugEnabled()){
	                logger.debug(rowType);
	            }
	          
	          if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                  result += swVerDao.insertSwVer(argument);
	          } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
	              result += swVerDao.updateSwVer(argument);
	          } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
	              result += swVerDao.deleteSwVer(argument);
	          }
	        }

	        if (logger.isDebugEnabled()) {
	            logger.debug("Service Method : mergeSwVer Output ={}", result);
	        }

	        return result; 
	  }

	@Override
	@ServiceId("BIRAS002")
	@ServiceName("SwVer조회")
	@ReturnBind("output")
	public List<Map> inqureSwVer(@DatasetBind("input") Map argument) {
		if(logger.isDebugEnabled()){
			
	        logger.debug("Service Method : inqureSwVer, Input Param={}", argument);
	    } 
		List<Map> result;
		if("1".equals(argument.get("TYPE")))
		{
		    result = swVerDao.inqureLastSwVer(argument);
		}else{
		    result = swVerDao.inqureSwVer(argument);
		}
	            
	    if (logger.isDebugEnabled()) {
	        logger.debug("Service Method : inqureSwVer Output ={}", argument);
	    }
	        
	    return result;
	}

    @Override
    @ServiceId({"BIRAD001"})
    @ServiceName("SwVer삭제")
    @ReturnBind("output")
    public int deleteSwVer(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : deleteSwVer, Input Param={}", argument); 
          }
        
          int result = 0;
          result += swVerDao.deleteSwVer2(argument);

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : deleteSwVer Output ={}", result);
          }

          return result; 
    }
}
