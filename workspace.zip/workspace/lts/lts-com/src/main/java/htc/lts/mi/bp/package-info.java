/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 7. 오후 4:19:52
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 7.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
package htc.lts.mi.bp;