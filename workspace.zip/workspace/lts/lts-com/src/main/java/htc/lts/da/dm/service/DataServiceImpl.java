package htc.lts.da.dm.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.da.dm.dao.DataDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : 일반자료관리
 * @Date		  : 2016. 10. 12. 오후 7:14:14
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 12.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class DataServiceImpl implements DataService{

    private static final Logger logger = LoggerFactory.getLogger(DataServiceImpl.class);
    
    @Autowired
    private DataDao dataDao;
    
    /**
     * @Method Name        : inqureData
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 12.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("DADMS001")
    @ServiceName("오류보고내역 조회")
    @ReturnBind("output")
    public List<Map> inqureData(@DatasetBind("input")Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureData, Input Param={}", searchParam);
        } 
        
        List<Map> dataList = dataDao.inqureDataList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureData Output ={}", dataList);
        }
        
        return dataList;
    }
    
    
    /**
     * @Method Name        : insertDataList
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 12.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("DADMS002")
    @ServiceName("일반자료관리저장")
    @ReturnBind("output")
    public int insertDataList(@DatasetBind("input") List<Map> searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : insertDataList, Input Param={}", searchParam); 
        }
        
        int result = 0;
        for (Map DataList : searchParam) {
            String rowType = XPlatformUtil.getDataRowType(DataList);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    result += dataDao.insertDataList(DataList);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += dataDao.updateDataList(DataList);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += dataDao.deleteDataList(DataList);
            }
        }
       
        return result; 
    }
    
    /**
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 13.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 13.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("DADMS003")
    @ReturnBind("output")
    public List<Map> inqureFile(@DatasetBind("input") Map argument) {
        
        argument.put("FILENO", argument.get("TCHDATA_ATCHFL_NO"));
        List<Map> result = dataDao.inqureFile(argument);

        return result;
    }
    
    @Override
    @ServiceId("DADMS004")
    @ServiceName("첨부파일 삭제")
    @ReturnBind("output")
    public int deleteFile(@DatasetBind("input") List<Map> deleteFileList) {
        
        int result = 0;
          for (Map deleteFile : deleteFileList) {
                  String rowType = XPlatformUtil.getDataRowType(deleteFile);
                 if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                      result +=dataDao.deleteFile(deleteFile);
                  }
          }
          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : deleteFile Output ={}", result);
          }
          return result; 
    }

}
