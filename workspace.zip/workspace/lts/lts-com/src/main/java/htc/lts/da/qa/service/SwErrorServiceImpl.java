/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.qa.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.commons.paging.PagingSupport;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.bi.pd.dao.WrshpDao;
import htc.lts.bi.pd.service.WrshpServiceImpl;
import htc.lts.da.dm.dao.DataDao;
import htc.lts.da.qa.dao.SwErrorDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.annotation.VariableBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 6. 오후 8:55:08
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 6.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class SwErrorServiceImpl implements SwErrorService {
	
	private static final Logger logger = LoggerFactory.getLogger(SwErrorServiceImpl.class);
    
    @Autowired
    private SwErrorDao swErrorDao;
    
    @Autowired
    private DataDao dataDao;
    

	/**
	 * @see htc.lts.da.qa.service.SwErrorService#inqureSwError(java.util.Map)
	 * @Method Name        : inqureSwError
	 * @Method description : 
	 * @Date               : 2016. 10. 7.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 7.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
    @ServiceId("DAQAS001_NEW")
    @ServiceName("오류보고내역 조회")
    @ReturnBind("output")
	public List<Map> inqureSwError(@DatasetBind("input")Map searchParam) {
		
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureSwError, Input Param={}", searchParam);
        } 
        
        List<Map> swErrorList = swErrorDao.inqureSwErrorList(searchParam);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureSwError Output ={}", swErrorList);
        }
       // swErrorList.put("dsOutput", swErrorList);
       // swErrorList.put("dsPage", paging);
        return swErrorList;
	}

	
	   @Override
	    @ServiceId("DAQAS001")
	    @ServiceName("오류보고내역 조회")
	    @ReturnBind("output")
	    //public List<Map> inqureSwError(@DatasetBind("input")Map searchParam) {
	    public List<Map> inqureSwError(SystemHeader header, @DatasetBind("input") Map searchParam, PagingSupport paging) {    
	        
	        if(logger.isDebugEnabled()){ 
	            logger.debug("Service Method : inqureSwError, Input Param={}", searchParam);
	        } 
	        
	        //List<Map> swErrorList = swErrorDao.inqureSwErrorList(searchParam);
	        
	        List<Map> swErrorList = swErrorDao.inqureSwErrorList(searchParam, paging);
	        if (logger.isDebugEnabled()) {
	            logger.debug("Service Method : inqureSwError Output ={}", swErrorList);
	        }
	       // swErrorList.put("dsOutput", swErrorList);
	       // swErrorList.put("dsPage", paging);
	        return swErrorList;
	    }

	   
	   
	/**
	 * @see htc.lts.da.qa.service.SwErrorService#saveSwErr(java.util.List)
	 * @Method Name        : saveSwErr
	 * @Method description : 
	 * @Date               : 2016. 10. 10.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 10.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param swErrParam
	 * @return
	*/
	
	@Override
	@ServiceId("DAQAX001")
    @ServiceName("오류보고내역 저장")
    @ReturnBind("output")
	public int saveSwErr(@DatasetBind("input")List<Map> swErrParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveSwErr, Input Param={}", swErrParam); 
        }
        
        int result = 0;
        for (Map swErr : swErrParam) {
            String rowType = XPlatformUtil.getDataRowType(swErr);
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += swErrorDao.insertSwErr(swErr);
                
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += swErrorDao.updateSwErr(swErr);
            
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                //result += swErrorDao.deleteSwErr(swErr);
            
            }
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveSwErr Output ={}", result);
        }
        return result; 
	}

	/**
	 * @see htc.lts.da.qa.service.SwErrorService#inqureShpTpCdList(java.util.Map)
	 * @Method Name        : inqureShpTpCdList
	 * @Method description : 
	 * @Date               : 2016. 10. 10.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 10.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
    @ServiceId("DAQAS002")
    @ServiceName("함정명 조회")
    @ReturnBind("output")
	public List<Map> inqureShpNm(@DatasetBind("input")Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureShpNm, Input Param={}", searchParam);
        } 
        
        List<Map> shpNmList = swErrorDao.inqureShpNmList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureShpNm Output ={}", shpNmList);
        }
        
        return shpNmList;
	}

	/**
	 * @see htc.lts.da.qa.service.SwErrorService#inqureFile(java.util.Map)
	 * @Method Name        : inqureFile
	 * @Method description : 
	 * @Date               : 2016. 10. 12.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 12.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	
	
	@Override
    @ServiceId("DAQAS003")
    @ServiceName("첨부파일 조회")
    @ReturnBind("output")
	public List<Map> inqureFile(@DatasetBind("input")Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureFile, Input Param={}", searchParam); 
        } 

//        if(searchParam.get("NTCNT_FILENO") != null){
//            System.out.println("======================================NTCNT_FILENO=================================================      "+searchParam.get("NTCNT_FILENO"));
//            searchParam.put("FILENO", searchParam.get("NTCNT_FILENO"));
//        }else if(searchParam.get("ERR_RPT_ATCHFL_NO") != null){
//            System.out.println("======================================ERR_RPT_ATCHFL_NO=================================================      "+searchParam.get("ERR_RPT_ATCHFL_NO"));
//            searchParam.put("FILENO", searchParam.get("ERR_RPT_ATCHFL_NO"));
//        }else if(searchParam.get("ATCHFL_FILENO") != null){
//            System.out.println("======================================ATCHFL_FILENO=================================================      "+searchParam.get("ATCHFL_FILENO"));
//            searchParam.put("FILENO", searchParam.get("ATCHFL_FILENO"));
//        }else{
//            System.out.println("======================================NULL=================================================");
//            searchParam.put("FILENO", null);
//        }
        List<Map> fileList = swErrorDao.inqureFileList(searchParam);
        //List<Map> fileList = swErrorDao.inqureFileList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFile Output ={}", fileList);
        }
        
        return fileList;
	}


	/**
	 * @see htc.lts.da.qa.service.SwErrorService#deleteSwErr(java.util.List)
	 * @Method Name        : deleteSwErr
	 * @Method description : 
	 * @Date               : 2016. 11. 16.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 16.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param swErrParam
	 * @return
	*/
	
	@Override
	@ServiceId("DAQAD001")
    @ServiceName("sw오류보고삭제")
    @ReturnBind("output")
	public int deleteSwErr(@DatasetBind("input")List<Map> swErrParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : deleteSwErr, Input Param={}", swErrParam); 
        }
        
        int result = 0;
        for (Map swErr : swErrParam) {
        	result += swErrorDao.deleteSwErr(swErr);
        	result += swErrorDao.deleteCmnt(swErr);
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : deleteSwErr Output ={}", result);
        }
        return result; 
	}


	/**
	 * @see htc.lts.da.qa.service.SwErrorService#inqureMainSwError(java.util.Map)
	 * @Method Name        : inqureMainSwError
	 * @Method description : 
	 * @Date               : 2016. 11. 17.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 17.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
    @ServiceId("DAQAS004")
    @ServiceName("SW오류보고 조회")
    @ReturnBind("output")
	public List<Map> inqureMainSwError(Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureMainSwError, Input Param={}", searchParam);
        } 
        
        List<Map> ntcntList = swErrorDao.inqureMainSwErrorList(searchParam);          
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureMainSwError Output ={}", searchParam);
        }
        
        return ntcntList;
	}
	
	@Override
	@ServiceId("DAQAX002")
    @ServiceName("게시물답글 저장")
    @ReturnBind("output")
	public int saveCmnt(@DatasetBind("input")List<Map> cmntParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveCmnt, Input Param={}", cmntParam); 
        }
        
        int result = 0;
        for (Map cmnt : cmntParam) {
            String rowType = XPlatformUtil.getDataRowType(cmnt);
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += swErrorDao.insertCmnt(cmnt);
                
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += swErrorDao.updateCmnt(cmnt);
            
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                //result += boardDao.deleteNtcnt(ntcnt);
            
            }
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveCmnt Output ={}", result);
        }
        return result; 
	}


	/**
	 * @see htc.lts.da.qa.service.SwErrorService#deleteCmnt(java.util.List)
	 * @Method Name        : deleteCmnt
	 * @Method description : 
	 * @Date               : 2016. 12. 8.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 12. 8.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmntParam
	 * @return
	*/
	
	@Override
	@ServiceId("DAQAD002")
    @ServiceName("게시물삭제")
    @ReturnBind("output")
	public int deleteCmnt(@DatasetBind("input")List<Map> cmntParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : deleteCmnt, Input Param={}", cmntParam); 
        }
        
        int result = 0;
        for (Map cmnt : cmntParam) {
        	result += swErrorDao.deleteCmnt(cmnt);
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : deleteCmnt Output ={}", result);
        }
        return result; 
	}
	
	
	
	
	
	

}
