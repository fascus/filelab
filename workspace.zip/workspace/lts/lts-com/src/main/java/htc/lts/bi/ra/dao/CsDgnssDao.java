/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.ra.dao;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 28. 오후 4:21:17
 * @Author     	  : 송대성
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 28.		송대성						CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface CsDgnssDao {
	
	/**
     * @Method Name        : inqureCsDgnss
     * @Method description : 
     * @Date               : 2016. 9. 28.
     * @Author             : 송대성 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 9. 28.		송대성						CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param resident
     * @return
    */
    public List inqureCsDgnss(Map CsDgnss);
    
    /**
     * @Method Name        : inqureCsDgnss
     * @Method description : 
     * @Date               : 2016. 9. 28.
     * @Author             : 송대성 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 9. 28.     송대성                     CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param resident
     * @return
    */
    public List inqureEqCdNm(Map CsDgnss);
    
    public int insertCsDgnss(Map CsDgnss);
    
    public int updateCsDgnss(Map CsDgnss);
  
    public int deleteCsDgnss(Map CsDgnss);
    
}
