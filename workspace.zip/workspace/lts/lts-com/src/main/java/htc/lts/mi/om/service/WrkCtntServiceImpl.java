package htc.lts.mi.om.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.mi.mm.dao.MngNoDao;
import htc.lts.mi.mm.service.UsePnServiceImpl;
import htc.lts.mi.om.dao.WrkCtntDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date : 2016. 10. 19. 오전 10:21:01
 * @Author : 이창환
 *
 *         <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 *         </pre>
 */
@Service
public class WrkCtntServiceImpl implements WrkCtntService {

    private static final Logger logger = LoggerFactory.getLogger(UsePnServiceImpl.class);

    @Autowired
    WrkCtntDao wrkCtntDao;

    @Autowired
    MngNoDao mngNoDao;

    @Override
    @ServiceId("MIOMS004")
    @ServiceName("단종관리잗업일지조회")
    @ReturnBind("output")
    public List<Map> inqureyDsctnIdtfWrkCtnt(@DatasetBind("input") Map searchParam) {

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureyDsctnIdtfWrkCtnt, Input Param={}", searchParam);
        }

        List<Map> dsctnIdtfWrkCtntList = wrkCtntDao.inqueryDsctnIdtfWrkCtntList(searchParam);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureyDsctnIdtfWrkCtnt Output ={}", dsctnIdtfWrkCtntList);
        }

        return dsctnIdtfWrkCtntList;
    }

    @Override
    @ServiceId("MIOMX002")
    @ServiceName("단종관리작업일지저장")
    @ReturnBind("output")
    public int saveDsctnIdtfWrkCtnt(@DatasetBind("input") List<Map> DsctnIdtfItemList) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveDsctnIdtfWrkCtnt, Input Param={}", DsctnIdtfItemList);
        }
        List<Map> dsctnIdtfWrkCtntList = null;
        int result = 0;
        for (Map DsctnIdtfItem : DsctnIdtfItemList) {

            dsctnIdtfWrkCtntList = wrkCtntDao.inqueryDsctnIdtfWrkCtntList(DsctnIdtfItem);
            if (dsctnIdtfWrkCtntList.size() == 0) {

                result = wrkCtntDao.insertDsctnIdtfWrkCtnt(DsctnIdtfItem);
            } else {
                result = wrkCtntDao.updateDsctnIdtfWrkCtnt(DsctnIdtfItem);
            }

        }

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveDsctnIdtfWrkCtnt Output ={}", result);
        }

        return result;
    }

}
