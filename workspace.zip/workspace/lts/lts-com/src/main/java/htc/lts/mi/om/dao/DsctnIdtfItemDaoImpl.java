package htc.lts.mi.om.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:30:20
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class DsctnIdtfItemDaoImpl extends AbstractHtcDao implements DsctnIdtfItemDao {

    /**
     * @see htc.lts.mi.om.dao.DsctnIdtfItemDao#inqueryDsctnIdtfItemPopList(java.util.Map)
     * @Method Name        : inqueryDsctnIdtfItemPopList
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DsctnIdtfItem
     * @return
    */
    @Override
    public List inqueryDsctnIdtfItemPopList(Map DsctnIdtfItem) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.selectDsctnIdtfItemPopList", DsctnIdtfItem);
    }
    
    /**
     * @see htc.lts.mi.om.dao.DsctnIdtfItemDao#inqueryDsctnIdtfItemList(java.util.Map)
     * @Method Name        : inqueryDsctnIdtfItemList
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DsctnIdtfItem
     * @return
    */
    @Override
    public List inqueryDsctnIdtfItemList(Map DsctnIdtfItem) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.selectDsctnIdtfItemList", DsctnIdtfItem);
    }
    
    @Override
    public List selectCount1(Map DsctnIdtfItem) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.selectCount1", DsctnIdtfItem);
    }
    
    @Override
    public List selectCount2(Map DsctnIdtfItem) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.selectCount2", DsctnIdtfItem);
    }
    
    @Override
    public List selectCount3(Map DsctnIdtfItem) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.selectCount3", DsctnIdtfItem);
    }
    /**
     * @see htc.lts.mi.om.dao.DsctnIdtfItemDao#searchDsctnIdRsltList(java.util.Map)
     * @Method Name        : searchDsctnIdRsltList
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DsctnIdtfItem
     * @return
    */
    @Override
    public List searchDsctnIdRsltList(Map DsctnIdtfItem) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.searchDsctnIdRsltList", DsctnIdtfItem);
    }
    
    /**
     * @see htc.lts.mi.om.dao.DsctnIdtfItemDao#inqureyMgtNoRfNo(java.util.Map)
     * @Method Name        : inqureyMgtNoRfNo
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param param
     * @return
    */
    @Override
    public List inqureyMgtNoRfNo(Map param) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.selectMgtNoRfNoList", param);
    }
    
    /**
     * @see htc.lts.mi.om.dao.DsctnIdtfItemDao#insertDsctnIdtfItem(java.util.Map)
     * @Method Name        : insertDsctnIdtfItem
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DsctnIdtfItem
     * @return
    */
    @Override
    public int insertDsctnIdtfItem(Map DsctnIdtfItem) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.insertDsctnIdtfItem", DsctnIdtfItem);
    }
    
    @Override
    public int updateDsctnIdtfItem(Map DsctnIdtfItem) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.updateDsctnIdtfItem", DsctnIdtfItem);
    }
    
    @Override
    public int updateDsctnIdtfItem2(Map DsctnIdtfItem) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.updateDsctnIdtfItem2", DsctnIdtfItem);
    }
    
    @Override
    public int deleteDsctnIdtfItem(Map DsctnIdtfItem) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.deleteDsctnIdtfItem", DsctnIdtfItem);
    }

    @Override
    public int deleteDsctnPrsts(Map DsctnIdtfItem) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.deleteDsctnPrsts", DsctnIdtfItem);
    }
    
    @Override
    public int deleteDsctnPrstsHistry(Map DsctnIdtfItem) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.deleteDsctnPrstsHistry", DsctnIdtfItem);
    }
    
    /**
     * @see htc.lts.mi.om.dao.DsctnIdtfItemDao#insertDsctnHistry(java.util.Map)
     * @Method Name        : insertDsctnHistry
     * @Method description : 
     * @Date               : 2016. 11. 23.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 23.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param dsctnHistry
     * @return
    */
    @Override
    public int insertDsctnHistry(Map dsctnHistry) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.insertDsctnHistry", dsctnHistry);
    }
    
    @Override
    public int updateDsctnHistry(Map dsctnHistry) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.updateDsctnHistry", dsctnHistry);
    }
    
    @Override
    public int deleteDsctnHistry(Map dsctnHistry) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.deleteDsctnHistry", dsctnHistry);
    }
    
    @Override
    public List inqueryDsctnHistryList(Map param) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.selectDsctnHistryList", param);
    }
    
    @Override
    public int insertDsctnPrsts(Map dsctnHistry) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.insertDsctnPrsts", dsctnHistry);
    }
    
    @Override
    public int updateDsctnPrsts(Map dsctnHistry) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.updateDsctnPrsts", dsctnHistry);
    }
    
    @Override
    public int updateDsctnPrsts2(Map dsctnHistry) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.updateDsctnPrsts2", dsctnHistry);
    }
    
    @Override
    public List inqueryDsctnPrstsList(Map param) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.selectDsctnPrstsList", param);
    }
    
    @Override
    public List inqueryDsctnPrstsHistryList(Map param) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.selectDsctnPrstsHistryList", param);
    }
    
    @Override
    public int insertDsctnPrstsHistry(Map dsctnHistry) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.insertDsctnPrstsHistry", dsctnHistry);
    }
    
    /**
     * @see htc.lts.mi.om.dao.DsctnIdtfItemDao#inqueryItemIdtfList(java.util.Map)
     * @Method Name        : inqueryItemIdtfList
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param param
     * @return
    */
    @Override
    public List inqueryItemIdtfList(Map param) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.selectItemIdtfList", param);
    }
    

    
    public int insertDsctnIdRslt(Map DsctnIdtfItem) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.insertDsctnIdRslt", DsctnIdtfItem);
    }
    
    /**
     * @see htc.lts.mi.om.dao.DsctnIdtfItemDao#selectMiotIng(java.util.Map)
     * @Method Name        : selectMiotIng
     * @Method description : 
     * @Date               : 2016. 10. 31.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 31.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mtn
     * @return
    */
    @Override
    public List selectMiotIng(Map mtn) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.selectMiotIng", mtn);
    }

    @Override
    public int insertCheck(Map dsctnHistry) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.insertCheck", dsctnHistry);
    }
    
    @Override
    public int updateCheck(Map dsctnHistry) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.updateCheck", dsctnHistry);
    }
    
    @Override
    public int deleteCheck(Map dsctnHistry) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.deleteCheck", dsctnHistry);
    }

    @Override
    public List inqureRfnoCrtnAndDel(Map mtn) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.inqureRfnoCrtnAndDel", mtn);
    }
    
    @Override
    public int deleteDsctnIdRslt(Map dsctnHistry) {
        return  update("htc.lts.mi.om.hqml.DsctnIdtfItemQuery.deleteDsctnIdRslt", dsctnHistry);
    }
    
}
