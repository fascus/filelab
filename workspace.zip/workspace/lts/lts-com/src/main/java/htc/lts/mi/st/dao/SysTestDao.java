/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.st.dao;

import java.util.List;
import java.util.Map;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:59:07
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface SysTestDao {

    public List inqureSysTestList(Map sysTest);
    
   
    //public List inqureScreenObjList(Map screenObj);
    
   
    public int insertSysTestMaster(Map sysTest);
    
    public int insertSysTestDetail(Map sysTest);
    
    public int insertCmplRpt(Map sysTest);
    
    public int updateCmplRpt(Map sysTest);
    
    public List searchSysTestList(Map sysTest);
    
    public List selectMistIng(Map sysTest);


    /**
     * @Method Name        : inqureDmndMatr
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureDmndMatr(Map argument);
    
    /**
     * @Method Name        : insertDmndMatr updateDmndMatr
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public int insertDmndMatr(Map argument);

    public int updateDmndMatr(Map argument);

    public int deleteDmndMatr(Map argument);
    /**
     * @Method Name        : updateDmndMatrCtnt
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public int updateDmndMatrCtnt(Map argument);


    /**
     * @Method Name        : inqureMtnList
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureMtnList(Map argument);


    /**
     * @Method Name        : inqureDmndMatrCtnt
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureDmndMatrCtnt(Map argument);

    /**
     * @Method Name        : insertCsDgnssResultDtl
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public int insertCsDgnssResultDtl(Map argument);


    /**
     * @Method Name        : inqureCsDgnssResultDtl
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List inqureCsDgnssResultDtl(Map argument);


    /**
     * @Method Name        : updateCsDgnssResultDtl deleteCsDgnssResultDtl
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public int updateCsDgnssResultDtl(Map argument);

    public int deleteCsDgnssResultDtl(Map argument);
    /**
     * @Method Name        : inqureCsDgnssResultDtl2
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List inqureCsDgnssResultDtl2(Map argument);
    
    public List inqureItemList(Map argument);


    public int deleteSysTestDetail(Map argument);


    public int deleteCmplRpt(Map argument);


    public int mergeDgnssRslt(Map argument);
    
}
