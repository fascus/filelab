/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.rp.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 28. 오후 4:47:36
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 28.		변용수						CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class ResidentDaoImpl extends AbstractHtcDao implements ResidentDao {

	/**
	 * @see htc.lts.bi.rp.dao.ResidentDao#inqureResidentList(java.util.Map)
	 * @Method Name        : inqureResidentList
	 * @Method description : 
	 * @Date               : 2016. 9. 28.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 9. 28.		변용수						CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param user
	 * @return
	*/
	@Override
	public List inqureResidentList(Map resident) {
		return queryForList("htc.lts.bi.rp.hqml.ResidentQuery.selectResidentList", resident);
	}

	/**
	 * @see htc.lts.bi.rp.dao.ResidentDao#insertResident(java.util.Map)
	 * @Method Name        : insertResident
	 * @Method description : 
	 * @Date               : 2016. 9. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 9. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param resident
	 * @return
	*/
	
	@Override
	public int insertResident(Map resident) {
		return  update("htc.lts.bi.rp.hqml.ResidentQuery.insertResident", resident);
	}

	/**
	 * @see htc.lts.bi.rp.dao.ResidentDao#updateResident(java.util.Map)
	 * @Method Name        : updateResident
	 * @Method description : 
	 * @Date               : 2016. 9. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 9. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param resident
	 * @return
	*/
	
	@Override
	public int updateResident(Map resident) {
		return  update("htc.lts.bi.rp.hqml.ResidentQuery.updateResident", resident);
	}

	/**
	 * @see htc.lts.bi.rp.dao.ResidentDao#deleteResident(java.util.Map)
	 * @Method Name        : deleteResident
	 * @Method description : 
	 * @Date               : 2016. 9. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 9. 30.		변용수						CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param resident
	 * @return
	*/
	
	@Override
	public int deleteResident(Map resident) {
		return  update("htc.lts.bi.rp.hqml.ResidentQuery.deleteResident", resident);
	}

	/**
	 * @see htc.lts.bi.rp.dao.ResidentDao#inqureUserList(java.util.Map)
	 * @Method Name        : inqureUserList
	 * @Method description : 
	 * @Date               : 2016. 9. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 9. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param resident
	 * @return
	*/
	
	@Override
	public List inqureUserList(Map resident) {
		return queryForList("htc.lts.bi.rp.hqml.ResidentQuery.selectUserList", resident);
	}
	
    @Override
    public List inqureResidentTempList(Map resident) {
        return queryForList("htc.lts.bi.rp.hqml.ResidentQuery.inqureResidentTempList", resident);
    }

}
