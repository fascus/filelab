/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.cp.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.mi.cp.dao.MiCpDao;
import htc.xplatform.annotation.DatasetBind;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 10:04:40
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class MiCpServiceImpl implements MiCpService {

    private static final Logger logger = LoggerFactory.getLogger(MiCpServiceImpl.class);

    @Autowired
    MiCpDao miCpDao;
   
    @Override
    @ServiceId("MICPS001")
    @ServiceName("손환부품정비조회")
    @MultiReturnBind
    public Map<String, List> inqureMtn(SystemHeader header, @DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureMtn, Input Param={}", argument); 
        }
        
        
        List<Map> mtnList = miCpDao.inqureMtnList(argument);
        
        List<Map> mimmList = miCpDao.selectMimmIng(argument);
        
        Map<String, List> data = new HashMap<>();
        
        data.put("output", mtnList);
        data.put("mimmIng", mimmList);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureMtn Output ={}", mtnList);
        }
        
        return data;
    }

    @Override
    @ServiceId("MICPS002")
    @ServiceName("완료보고조회")
    @ReturnBind("output")
    public List<Map> inqureCmplRpt(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureCmplRpt, Input Param={}", argument); 
        }
        
        List<Map> result = miCpDao.inqureCmplRptList(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureCmplRpt Output ={}", result);
        }
        
        return result;
    }
}