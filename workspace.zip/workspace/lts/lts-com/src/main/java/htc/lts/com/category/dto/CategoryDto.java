package htc.lts.com.category.dto;

import htc.hone.core.dto.AbstractDto;

public class CategoryDto extends AbstractDto {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5457226249147789392L;
	private String id;
	private String name;
	private String description;
	private String useYn;
	private String regUser;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getRegUser() {
		return regUser;
	}
	public void setRegUser(String regUser) {
		this.regUser = regUser;
	}
	@Override
	public String toString() {
		return "CategoryDto [id=" + id + ", name=" + name + ", description=" + description + ", useYn=" + useYn
				+ ", regUser=" + regUser + "]";
	}
	
	
}
