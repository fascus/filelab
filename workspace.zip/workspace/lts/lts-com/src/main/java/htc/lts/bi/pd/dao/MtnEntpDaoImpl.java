/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import htc.hone.dao.AbstractHtcDao;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 8. 오후 4:28:19
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 8.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */

@Repository
public class MtnEntpDaoImpl extends AbstractHtcDao implements MtnEntpDao {

    @Override
    public List inqureMtnEntp(Map argument) {
        return queryForList("htc.lts.bi.pd.hqml.MtnEntpQuery.inqureMtnEntp", argument);
    }
    
    @Override
    public List inqureMtnEntpPsnchrg(Map argument) {
        return  queryForList("htc.lts.bi.pd.hqml.MtnEntpQuery.inqureMtnEntpPsnchrg", argument);
    }
    
    @Override
    public List inqureMtnEntpEqcd(Map argument) {
        return  queryForList("htc.lts.bi.pd.hqml.MtnEntpQuery.inqureMtnEntpEqcd", argument);
    }
    
    @Override
    public List inqureMtnEntpCdList(Map argument) {
        return  queryForList("htc.lts.bi.pd.hqml.MtnEntpQuery.inqureMtnEntpCdList", argument);
    }
    
    @Override
    public int insertMtnEntp(Map argument) {
        return  update("htc.lts.bi.pd.hqml.MtnEntpQuery.insertMtnEntp", argument);
    }
    
    @Override
    public int insertMtnEntpPsnchrg(Map argument) {
        return  update("htc.lts.bi.pd.hqml.MtnEntpQuery.insertMtnEntpPsnchrg", argument);
    }
    
    @Override
    public int insertMtnEntpEqcd(Map argument) {
        return  update("htc.lts.bi.pd.hqml.MtnEntpQuery.insertMtnEntpEqcd", argument);
    }

    @Override
    public int updateEqcd(Map argument) {
        return  update("htc.lts.bi.pd.hqml.MtnEntpQuery.updateEqcd", argument);
    }
    
    @Override
    public int deleteEqcd(Map argument) {
        return  update("htc.lts.bi.pd.hqml.MtnEntpQuery.deleteEqcd", argument);
    }

    @Override
    public int updatePsnchrg(Map argument) {
        return  update("htc.lts.bi.pd.hqml.MtnEntpQuery.updatePsnchrg", argument);
    }
    
    @Override
    public int deletePsnchrg(Map argument) {
        return  update("htc.lts.bi.pd.hqml.MtnEntpQuery.deletePsnchrg", argument);
    }
    
    @Override
    public int updateMtnEntpMain(Map argument) {
        return  update("htc.lts.bi.pd.hqml.MtnEntpQuery.updateMtnEntpMain", argument);
    }
    
    @Override
    public int deleteMtnEntpMain(Map argument) {
        return  update("htc.lts.bi.pd.hqml.MtnEntpQuery.deleteMtnEntpMain", argument);
    }
    
    /*
    @Override
    public int updatePo(Map argument) {
        return  update("htc.lts.bi.po.hqml.PoQuery.updatePo", argument);
    }
    
    @Override
    public int deletePo(Map argument) {
        return  update("htc.lts.bi.po.hqml.PoQuery.deletePo", argument);
    }
    */
}
