/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.fa.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.da.fa.dao.DaFaDao;
import htc.lts.mi.mm.dao.MngNoDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 10:04:40
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class DaFaServiceImpl implements DaFaService {

    private static final Logger logger = LoggerFactory.getLogger(DaFaServiceImpl.class);

    @Autowired
    DaFaDao daFaDao;
    
    @Autowired
    MngNoDao mngNoDao;

   
    @Override
    @ServiceId("DAFAS001")
    @ServiceName("고장부품정비조회")
    @MultiReturnBind
    public  Map<String, List> inqureMtn(SystemHeader header, @DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureMtn, Input Param={}", searchParam); 
        }
        
        List<Map> result = daFaDao.inqureMtnList(searchParam);
        
        List<Map> mimmIng = daFaDao.selectMimmIng(searchParam);
        
        Map<String, List> data = new HashMap<>();
        
        data.put("output", result);
        data.put("mimmIng", mimmIng);
                
        //if (logger.isDebugEnabled()) {
        //    logger.debug("Service Method : inqureMtn Output ={}", result);
        //}
        
        return data;
    }
    
    @Override
    @ServiceId("DAFAS002")
    @ServiceName("완료보고조회")
    @ReturnBind("output")
    public List<Map> inqureCmplRpt(@DatasetBind("input") Map argument) {
       // if(logger.isDebugEnabled()){ 
       //     logger.debug("Service Method : inqureCmplRpt, Input Param={}", argument); 
       // }
        
        List<Map> result = daFaDao.inqureCmplRptList(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureCmplRpt Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("DAFAS003")
    @ReturnBind("output")
    public List<Map> inqureSysTestList(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureSysTestList, Input Param={}", argument); 
        }
        
        List<Map> result = daFaDao.inqureSysTestList(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureSysTestList Output ={}", result);
        }
        
        return result;
    }
    
    
    @Override
    @ServiceId("DAFAI001")
    @ReturnBind("output")
    public int saveFollowActTask (@DatasetBind("input1") List<Map> argument1,@DatasetBind("input2") List<Map> argument2,@DatasetBind("input3") List<Map> argument3) {
        int result = 0;
        //String preSHP = "";
        String ActSeq = "";
        //List<Map> FollowActSeq = null;
        Map param = new HashMap<>();
        
        for (Map arg1 : argument1) {
            String rowType = XPlatformUtil.getDataRowType(arg1);
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                
                //System.out.println(preSHP+ "----------------------------------"+mngNo.get("SHP_TP_CD").toString());
                
            	//String MtnItmCd;
            	String SHP_TP_CD;
                String ITM_CD =    "AI"  ;           //정비유형
                String EQCD;
                String ENTP_CD;
                
                
                
            	if("1".equals(arg1.get("FLWG_ACTITM_OCCR_TYPE_CD")) || "2".equals(arg1.get("FLWG_ACTITM_OCCR_TYPE_CD"))  || "3".equals(arg1.get("FLWG_ACTITM_OCCR_TYPE_CD")) ){
            		//MtnItmCd = arg1.get("REL_BASIS_MGTNO").toString().substring(0,2);
            		SHP_TP_CD = arg1.get("REL_BASIS_MGTNO").toString().substring(0,2);
            		ENTP_CD =   arg1.get("REL_BASIS_RFNO").toString().substring(0,1);  
            		EQCD =      arg1.get("REL_BASIS_RFNO").toString().substring(1,2);               //함 장비부호 
            	}else{
            		//MtnItmCd = arg1.get("SHP_TP_CD").toString(); 
            		SHP_TP_CD = arg1.get("SHP_TP_CD").toString(); 
                    EQCD =      arg1.get("EQCD").toString();               //함 장비부호 
                    ENTP_CD =   arg1.get("ENTP_CD").toString();            //정비업체부호
            	}

        		param.put("ITM_CD", "AI");
        		param.put("SHP_TP_CD", SHP_TP_CD);
        		
            	
            	//if(preSHP!=MtnItmCd){    
                    List<Map> searchMgtNo = mngNoDao.searchMngNoList(param);
                
                    String mgt = searchMgtNo.get(0).get("MGT").toString();
                    
                //}

                
                String MGT_NO = SHP_TP_CD + ITM_CD + mgt;                      //관리번호 
                String RFNO   = ENTP_CD.trim() + EQCD.trim();                  //참조번호
            	
            	
            	
                arg1.put("MGT_NO", MGT_NO);
                arg1.put("RFNO", RFNO);
                
                List<Map> FollowActSeq = daFaDao.inqureFollowActTask(arg1);
                ActSeq = FollowActSeq.get(0).get("FLWG_ACTITM_SEQ").toString();
                
                arg1.put("FLWG_ACTITM_SEQ", ActSeq);
                result += daFaDao.insertFollowActTask(arg1);
                
                
                

               // preMgt = mgt;
               // preSHP = MtnItmCd;
                
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += daFaDao.updateFollowActTask(arg1);
            //} else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
            
            }
            
        }
        
        for (Map arg2 : argument2) {
            String rowType = XPlatformUtil.getDataRowType(arg2);
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                arg2.put("FLWG_ACTITM_SEQ", ActSeq);
                result += daFaDao.insertSpvsnDept(arg2);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                String chk = arg2.get("CHK").toString();
                
                result += daFaDao.deleteSpvsnDept(arg2);
                
                if( "1".equals(chk))
                {
                    result += daFaDao.insertSpvsnDept(arg2);
                }
            //} else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
            
            }
        }
       
        for (Map arg3 : argument3) {
            String rowType = XPlatformUtil.getDataRowType(arg3);
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                arg3.put("FLWG_ACTITM_SEQ", ActSeq);
                result += daFaDao.insertCoprDept(arg3);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                String chk = arg3.get("CHK").toString();
                result += daFaDao.deleteCoprDept(arg3);
                if( "1".equals(chk))
                {
                    result += daFaDao.insertCoprDept(arg3);
                }
            //} else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
            
            }
        }
        return result;
    }
    
    @Override
    @ServiceId("DAFAS007")
    @ReturnBind("output")
    public List<Map> inqureUserList(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureUserList, Input Param={}", argument); 
        }
        
        List<Map> result = daFaDao.inqureUserList(argument);
        
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureUserList Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("DAFAD001")
    @ServiceName("후속조치삭제")
    @MultiReturnBind
    public int deleteFlwgActitm(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){
            logger.debug("Service Method : inqureFlwgActitm, Input Param={}", argument);
        } 
        
        int result = 0;
        result += daFaDao.deleteFollowActTask(argument);
        result += daFaDao.deleteSpvsnDept(argument);
        result += daFaDao.deleteCoprDept(argument);
        
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFlwgActitm Output ={}", result);
        }
        return result;
    }
    
}