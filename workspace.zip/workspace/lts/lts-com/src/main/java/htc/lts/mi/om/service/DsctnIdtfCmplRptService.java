package htc.lts.mi.om.service;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:21:27
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface DsctnIdtfCmplRptService {

    public List<Map> inqureyDsctnIdtfCmplRpt(Map argument);
    
    public int saveDsctnIdtfCmplRpt(Map DsctnIdtfCmplRptList);
    
    public List<Map> inqureFile(Map argument); 
    
    public List<Map> inqureFile2(Map argument); 

}
