/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.ot.service;

import java.util.List;
import java.util.Map;

import htc.hone.core.message.SystemHeader;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 18. 오전 9:55:25
 * @Author     	  : 변용수
 * 
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 18.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface OprdnsPrstsService {
	
	/**
     * @Method Name        : inqureShipInfo
     * @Method description : 함정보 콤보박스조회
     * @Date               : 2016. 10. 18.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 18.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public List<Map> inqureShipInfo(Map searchParam);
    
    /**
     * @Method Name        : inqureShipInfo
     * @Method description : 장비명 조회
     * @Date               : 2016. 10. 18.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 18.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public List<Map> seachEqNm(Map searchParam);
    
    /**
     * @Method Name        : inqureOprdnsPrsts
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param header
     * @param searchParam
     * @return
    */
    
    public Map<String, List> inqureOprdnsPrsts(SystemHeader header, Map searchParam);
    
    
    public int saveCrtMngNo(List<Map> mngNoList);

    public List<Map> inqureRfnoCrtnAndDel(Map searchParam);

    public int saveRfNo(List<Map> arguments);

}
