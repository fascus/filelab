package htc.lts.mi.om.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:30:20
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class RqmMnhrDaoImpl extends AbstractHtcDao implements RqmMnhrDao {

    @Override
    public List inqureyRqmMnhrList(Map param) {
        return queryForList("htc.lts.mi.om.hqml.RqmMnhrQuery.selectRqmMnhrList", param);
    }
    
    @Override
    public int insertRqmMnhr(Map rqmMnhr) {
        return update("htc.lts.mi.om.hqml.RqmMnhrQuery.insertRqmMnhr", rqmMnhr);
    }
    
    @Override
    public int updateRqmMnhr(Map rqmMnhr) {
        return update("htc.lts.mi.om.hqml.RqmMnhrQuery.updateRqmMnhr", rqmMnhr);
    }
    
    @Override
    public int deleteRqmMnhr(Map rqmMnhr) {
        return update("htc.lts.mi.om.hqml.RqmMnhrQuery.deleteRqmMnhr", rqmMnhr);
    }
    
    @Override
    public int insertDsctnIdtfWrkCtnt(Map rqmMnhr) {
        return update("htc.lts.mi.om.hqml.RqmMnhrQuery.insertDsctnIdtfWrkCtnt", rqmMnhr);
    }
    
    @Override
    public int updateDsctnIdtfWrkCtnt(Map rqmMnhr) {
        return update("htc.lts.mi.om.hqml.RqmMnhrQuery.updateDsctnIdtfWrkCtnt", rqmMnhr);
    }
}
