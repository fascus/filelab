/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.bp.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import htc.hone.dao.AbstractHtcDao;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 11. 3. 오후 3:13:40
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 11. 3.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class StateInspPrstsDaoImpl extends AbstractHtcDao implements StateInspPrstsDao {

	@Override
    public List inqureStateInspPrstsList(Map mngNo) {
        return queryForList("htc.lts.mi.bp.hqml.StateInspPrstsQuery.selectStateInspPrstsList", mngNo);
    }
    
    @Override
    public int insertStateInspPrsts(Map argument) {
        return update("htc.lts.mi.bp.hqml.StateInspPrstsQuery.insertStateInspPrsts", argument);
    }
    
    @Override
    public int updateStateInspPrsts(Map argument) {
        return update("htc.lts.mi.bp.hqml.StateInspPrstsQuery.updateStateInspPrsts", argument);
    }
    
    @Override
    public int updateStateInspPrsts2(Map argument) {
        return update("htc.lts.mi.bp.hqml.StateInspPrstsQuery.updateStateInspPrsts2", argument);
    }
    
    @Override
    public int updateStateInspPrsts3(Map argument) {
        return update("htc.lts.mi.bp.hqml.StateInspPrstsQuery.updateStateInspPrsts3", argument);
    }
    
    @Override
    public int deleteStateInspPrsts(Map argument) {
        return update("htc.lts.mi.bp.hqml.StateInspPrstsQuery.deleteStateInspPrsts", argument);
    }
    
    @Override
    public List inqureyStateInspPrstsImgList(Map mngNo) {
        return queryForList("htc.lts.mi.bp.hqml.StateInspPrstsQuery.selectStateInspPrstsImgList", mngNo);
    }

}
