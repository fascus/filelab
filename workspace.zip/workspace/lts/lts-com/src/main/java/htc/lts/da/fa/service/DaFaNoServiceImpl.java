/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.fa.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.da.fa.dao.DaFaDao;
import htc.lts.da.fa.dao.DaFaNoDao;
import htc.lts.mi.mm.dao.MngNoDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 10:04:40
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class DaFaNoServiceImpl implements DaFaNoService {

    private static final Logger logger = LoggerFactory.getLogger(DaFaNoServiceImpl.class);

    @Autowired
    DaFaNoDao daFaNoDao;
    
    @Autowired
    MngNoDao mngNoDao;
    
    @Autowired
    DaFaDao daFaDao;
   
    @Override
    @ServiceId("DAFAS200")
    @ServiceName("후속조치부품조회")
    @ReturnBind("output")
    public List<Map> inqureItemSeq(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureFlwg, Input Param={}", argument); 
        }
        
        List<Map> result = daFaNoDao.inqureItemSeqList(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFlwg Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("DAFAS201")
    @ServiceName("후속조치순번조회")
    @ReturnBind("output")
    public List<Map> inqureDgnssItemSeq(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureFlwg, Input Param={}", argument); 
        }
        
        List<Map> result = daFaNoDao.inqureDgnssItemSeqList(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFlwg Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("DAFAX501")
    @ServiceName("이동정비생성")
    @ReturnBind("output")
    public int saveMngNo(@DatasetBind("input") List<Map> mngNoList) {
       
        int result = 0;
       // String preSHP = "";
      //  String preMgt = "";
        for (Map mngNo : mngNoList) {
          //  String mgt = preMgt;
            //System.out.println(preSHP+ "----------------------------------"+mngNo.get("SHP_TP_CD").toString());
         //   if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){    
         //       List<Map> searchMgtNo = mngNoDao.searchMngNoList(mngNo);
            
           //     mgt = searchMgtNo.get(0).get("MGT").toString();
                
         //   }
            //System.out.println(preMgt+ "----------------------------------"+mgt);
            
          //  String SHP_TP_CD = mngNo.get("SHP_TP_CD").toString();          //함형
          //  String ITM_CD =    mngNo.get("ITM_CD").toString();             //정비유형
          //  String EQCD =      mngNo.get("EQCD").toString();               //함 장비부호 
         //   String ENTP_CD =   mngNo.get("ENTP_CD").toString();            //정비업체부호
            
          //  String MGT_NO = SHP_TP_CD + ITM_CD + mgt;                      //관리번호 
          //  String RFNO   = ENTP_CD.trim() + EQCD.trim();                  //참조번호
            
            //System.out.println(MGT_NO+ "----------------------------------"+RFNO);

    		String SHP_TP_CD = mngNo.get("MGT_NO").toString().substring(0,2);
    		String ENTP_CD =   mngNo.get("RFNO").toString().substring(0,1); 
    		String EQCD =   mngNo.get("RFNO").toString().substring(1,2);
    		mngNo.put("ITM_CD", "AI");
    		mngNo.put("SHP_TP_CD", SHP_TP_CD);
    		mngNo.put("ENTP_CD", ENTP_CD);
    		mngNo.put("EQCD", EQCD);
            
            List<Map> searchCtrno = mngNoDao.searchCtrNoList2(mngNo);       //공문번호로 계약번호 검색후 
            
            mngNo.put("CTRNO", searchCtrno.get(0).get("CTRNO").toString()); 
            mngNo.put("CTR_CHNG_SRLNO", searchCtrno.get(0).get("CTR_CHNG_SRLNO").toString());
            
          //  mngNo.put("MGT_NO", MGT_NO);
          //  mngNo.put("RFNO", RFNO);
            
            //if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){
            result += mngNoDao.insertMngNoMaster(mngNo);
           // }
            result += mngNoDao.insertMngNoDetail(mngNo);
            result += mngNoDao.insertWrk(mngNo);
            result += mngNoDao.insertCmplRpt(mngNo);
            daFaDao.updateYn(mngNo);
           // preMgt = mgt;
           // preSHP = mngNo.get("SHP_TP_CD").toString();
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveScreen Output ={}", result);
        }

        return result; 
    }
    
    @Override
    @ServiceId("DAFAS119")
    @ReturnBind("output")
    public List<Map> inqureDafa(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureDafa, Input Param={}", argument); 
        }
        
        List<Map> result = daFaNoDao.inqureDafa(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureDafa Output ={}", result);
        }
        
        return result;
    }
}