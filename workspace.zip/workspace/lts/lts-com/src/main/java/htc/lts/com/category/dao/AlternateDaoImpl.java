package htc.lts.com.category.dao;

import java.util.Map;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import htc.hone.dao.AbstractHtcDao;

@Repository
public class AlternateDaoImpl extends AbstractHtcDao implements AlternateDao {

	@Override
	protected String getDataSourceName() {
		return "honeDataSource";
	}

	@Override
	public void insertCategory(Map category) {
		update("htc.lts.com.category.hqml.AlternateQuery.insertCategory", category);
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	public void insertSeperateCategory(Map category) {
		update("htc.lts.com.category.hqml.AlternateQuery.insertCategory", category);
		
	}
}
