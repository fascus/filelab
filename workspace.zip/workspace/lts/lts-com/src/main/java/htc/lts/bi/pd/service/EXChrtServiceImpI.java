/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.bi.pd.dao.EXChrtDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;


@Service
public class EXChrtServiceImpI implements EXChrtService{

    private static final Logger logger = LoggerFactory.getLogger(EXChrtServiceImpI.class);
    
    @Autowired
    EXChrtDao exchrtDao;
    
    /**
     * @Method Name        : inqureChrt
     * @Method description : 
     * @Date               : 2016. 12. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 12. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("BIPDS901")
    @ServiceName("기준환율")
    @ReturnBind("output")
    public List<Map> inqureChrt(@DatasetBind("input") Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureChrt, Input Param={}", searchParam);
        } 
        
        List<Map> exchrtList = exchrtDao.inqureChrt(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureChrt Output ={}", exchrtList);
        }
        
        return exchrtList;
    }
    

    /**
     * @Method Name        : saveChrt
     * @Method description : 
     * @Date               : 2016. 12. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 12. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param exchrtList
     * @return
    */
    @Override
    @ServiceId("BIPDX901")
    @ServiceName("기준환율 저장")
    @ReturnBind("output")
    public int saveChrt(@DatasetBind("input") List<Map> exchrtList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveChrt, Input Param={}", exchrtList); 
        }
        
        int result = 0;
        for (Map Chrt : exchrtList) {
            String rowType = XPlatformUtil.getDataRowType(Chrt);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
               result += exchrtDao.insertChrt(Chrt);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += exchrtDao.updateChrt(Chrt);
            } 
            else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += exchrtDao.deleteChrt(Chrt);
            }
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveChrt Output ={}", result);
        }

        return result; 
    }
  
      
}