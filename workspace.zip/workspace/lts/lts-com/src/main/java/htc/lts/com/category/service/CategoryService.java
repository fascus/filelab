package htc.lts.com.category.service;

import java.util.List;
import java.util.Map;

import htc.commons.paging.PagingSupport;
import htc.hone.core.message.SystemHeader;
import htc.lts.com.category.dto.CategoryDto;
import htc.xplatform.annotation.DatasetBind;

public interface CategoryService {
	List<Map> listCategory(SystemHeader header,Map category, PagingSupport paging);
	int saveCategory(List<Map> categories);
	Map getCategory(String id);
	CategoryDto getCategory(CategoryDto category);
	Map getMultiCategory(String key1, String key2);
	List<Map> insertCategory(List<Map> categories);
	List<Map> updateCategory(List<Map> categories);
	List<Map> deleteCategory(List<Map> categories);
	void transactionSample(Map<String, Object> category);
	int saveMultiCategory(List<Map> categories1, List<Map> categories2);
	void smsTest(List<Map> categories);
}
