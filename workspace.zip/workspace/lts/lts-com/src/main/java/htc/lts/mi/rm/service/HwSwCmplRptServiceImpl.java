/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.rm.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.mi.rm.dao.HwSwCmplRptDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date          : 2016. 9. 21. 오후 2:59:12
 * @Author        : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date             Programmer              Description
 * 2016. 9. 21.     이창환                 CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class HwSwCmplRptServiceImpl implements HwSwCmplRptService {

    private static final Logger logger = LoggerFactory.getLogger(HwSwCmplRptServiceImpl.class);

    @Autowired
    HwSwCmplRptDao hwSwCmplRptDao;
    
    /**
     * @see htc.lts.mi.rm.service.HwSwMntncPldocService#saveHwSwMntncPldoc(java.util.List)
     * @Method Name        : saveHwSwMntncPldoc
     * @Method description : 
     * @Date               : 2016. 10. 25.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 25.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param hwSwList
     * @return
    */
    @Override
    @ServiceId("MIRMX003")
    @ServiceName("hw/sw완료보고저장")
    @ReturnBind("output")
    public int saveHwSwCmplRpt(@DatasetBind("input") List<Map> hwSwList) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : deleteFile, Input Param={}", hwSwList); 
          }
        

        int result = 0;
          
          for (Map hwSw : hwSwList) {
              result +=hwSwCmplRptDao.updateHwSwCmplRpt(hwSw);
          }

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : deleteFile Output ={}", result);
          }

          return result; 
    }
    
    /**
     * @see htc.lts.mi.rm.service.HwSwCmplRptService#inqureyHwSwCmplRpt(java.util.Map)
     * @Method Name        : inqureyHwSwCmplRpt
     * @Method description : 
     * @Date               : 2016. 10. 25.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 25.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("MIRMS003")
    @ServiceName("HW/SW수정개선사항조회")
    @ReturnBind("output")
    public List<Map> inqureyHwSwCmplRpt(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureyHwSwMntncPldoc, Input Param={}", searchParam); 
        }
        
        List<Map> hwSwMntncPldocList = hwSwCmplRptDao.inqureyHwSwCmplRpt(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureyHwSwMntncPldoc Output ={}", hwSwMntncPldocList);
        }
        
        return hwSwMntncPldocList;
    }
    
}