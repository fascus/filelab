/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.qa.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.commons.paging.PagingSupport;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.da.qa.dao.BoardDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.annotation.VariableBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 6:53:54
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class BoardServiceImpl implements BoardService{
	
	private static final Logger logger = LoggerFactory.getLogger(BoardServiceImpl.class);
	
	@Autowired
    private BoardDao boardDao;

	/**
	 * @see htc.lts.da.qa.service.BoardService#inqureNtcnt(java.util.Map)
	 * @Method Name        : inqureNtcnt
	 * @Method description : 
	 * @Date               : 2016. 10. 11.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 11.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
    @ServiceId("DAQAS101")
    @ServiceName("게시물 조회")
    @ReturnBind("output")
	public List<Map> inqureNtcnt(SystemHeader header, @DatasetBind("input") Map searchParam, PagingSupport paging) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureNtcnt, Input Param={}", searchParam); 
        } 
        
        //List<Map> ntcntList = boardDao.inqureNtcntList(searchParam);
        List<Map> ntcntList = boardDao.inqureNtcntList(searchParam, paging);          
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureNtcnt Output ={}", ntcntList);
        }
        
        return ntcntList;
	}
	
	

	/**
	 * @see htc.lts.da.qa.service.BoardService#inqureMainNtcnt()
	 * @Method Name        : inqureMainNtcnt
	 * @Method description : 
	 * @Date               : 2016. 11. 16.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 16.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @return
	*/
	
	@Override
    @ServiceId("DAQAS102")
    @ServiceName("게시물 조회")
    @ReturnBind("output")
	public List<Map> inqureMainNtcnt(@DatasetBind("input") Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureMainNtcnt, Input Param={}", searchParam);
        } 
        
        List<Map> ntcntList = boardDao.inqureMainNtcntList(searchParam);          
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureMainNtcnt Output ={}", searchParam);
        }
        
        return ntcntList;
	}



	/**
	 * @see htc.lts.da.qa.service.BoardService#saveNtcnt(java.util.List)
	 * @Method Name        : saveNtcnt
	 * @Method description : 
	 * @Date               : 2016. 10. 11.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 11.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param ntcntParam
	 * @return
	*/
	
	@Override
	@ServiceId("DAQAX101")
    @ServiceName("게시물 저장")
    @ReturnBind("output")
	public int saveNtcnt(@DatasetBind("input")List<Map> ntcntParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveNtcnt, Input Param={}", ntcntParam); 
        }
        
        int result = 0;
        for (Map ntcnt : ntcntParam) {
            String rowType = XPlatformUtil.getDataRowType(ntcnt);
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += boardDao.insertNtcnt(ntcnt);
                
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += boardDao.updateNtcnt(ntcnt);
            
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                //result += boardDao.deleteNtcnt(ntcnt);
            
            }
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveNtcnt Output ={}", result);
        }
        return result; 
	}

	/**
	 * @see htc.lts.da.qa.service.BoardService#saveCmnt(java.util.List)
	 * @Method Name        : saveCmnt
	 * @Method description : 
	 * @Date               : 2016. 10. 13.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 13.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmntParam
	 * @return
	*/
	
	@Override
	@ServiceId("DAQAX102")
    @ServiceName("게시물답글 저장")
    @ReturnBind("output")
	public int saveCmnt(@DatasetBind("input")List<Map> cmntParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveNtcnt, Input Param={}", cmntParam); 
        }
        
        int result = 0;
        for (Map cmnt : cmntParam) {
            String rowType = XPlatformUtil.getDataRowType(cmnt);
            if(logger.isDebugEnabled()){
                logger.debug(rowType);
            }
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += boardDao.insertCmnt(cmnt);
                
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += boardDao.updateCmnt(cmnt);
            
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                //result += boardDao.deleteNtcnt(ntcnt);
            
            }
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveNtcnt Output ={}", result);
        }
        return result; 
	}



	/**
	 * @see htc.lts.da.qa.service.BoardService#deleteNtcnt(java.util.List)
	 * @Method Name        : deleteNtcnt
	 * @Method description : 
	 * @Date               : 2016. 11. 16.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 16.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param ntcntParam
	 * @return
	*/
	
	@Override
	@ServiceId("DAQAD101")
    @ServiceName("게시물삭제")
    @ReturnBind("output")
	public int deleteNtcnt(@DatasetBind("input")List<Map> ntcntParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : deleteNtcnt, Input Param={}", ntcntParam); 
        }
        
        int result = 0;
        for (Map ntcnt : ntcntParam) {
        	result += boardDao.deleteNtcnt(ntcnt);
        	result += boardDao.deleteCmnt(ntcnt);
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : deleteNtcnt Output ={}", result);
        }
        return result; 
	}



	/**
	 * @see htc.lts.da.qa.service.BoardService#deleteCmnt(java.util.List)
	 * @Method Name        : deleteCmnt
	 * @Method description : 
	 * @Date               : 2016. 11. 16.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 16.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmntParam
	 * @return
	*/
	
	@Override
	@ServiceId("DAQAD102")
    @ServiceName("게시물삭제")
    @ReturnBind("output")
	public int deleteCmnt(@DatasetBind("input")List<Map> cmntParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : deleteNtcnt, Input Param={}", cmntParam); 
        }
        
        int result = 0;
        for (Map cmnt : cmntParam) {
        	result += boardDao.deleteCmnt(cmnt);
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : deleteNtcnt Output ={}", result);
        }
        return result; 
	}



	/**
	 * @see htc.lts.da.qa.service.BoardService#addInqrySndngNumcs(java.util.List)
	 * @Method Name        : addInqrySndngNumcs
	 * @Method description : 
	 * @Date               : 2016. 11. 16.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 16.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmntParam
	 * @return
	*/
	
	@Override
	@ServiceId("DAQAU101")
    @ServiceName("조회수증가")
    @ReturnBind("output")
	public int addInqrySndngNumcs(@DatasetBind("input")List<Map> cmntParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : addInqrySndngNumcs, Input Param={}", cmntParam); 
        }
        
        int result = 0;
        for (Map cmnt : cmntParam) {
        	result += boardDao.addInqrySndngNumcs(cmnt);
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : addInqrySndngNumcs Output ={}", result);
        }
        return result; 
	}
	
	
	
	
	
	
	
}
