/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.bp.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.mi.bp.dao.BreakDnDao;
import htc.lts.mi.mm.dao.MngNoDao;
import htc.lts.mi.st.dao.SysTestDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;
import htc.xplatform.web.XPlatformRowType;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:59:12
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class BreakDnServiceImpl implements BreakDnService {

    private static final Logger logger = LoggerFactory.getLogger(BreakDnServiceImpl.class);

    @Autowired
    BreakDnDao breakDnDao;
    @Autowired
    MngNoDao mngNoDao;
    @Autowired
    SysTestDao sysTestDao;
   
    @Override
    @ServiceId("MIBPM001")
    @ServiceName("납지조회")
    @ReturnBind("output")
    public List<Map> searchOrgnz(@DatasetBind("intput") Map searchParam) {
    	
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : searchOrgnz, Input Param={}", searchParam); 
        }
        
        List<Map> orgnzList = breakDnDao.searchOrgnz(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : searchOrgnz Output ={}", orgnzList);
        }
        
        return orgnzList;
    }
    
    @Override
    @ServiceId("MIBPS001")
    @ServiceName("고장부품정비생성")
    @ReturnBind("output")
    public int saveBreakDown(@DatasetBind("input") List<Map> BreakDownList) {
       
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveBreakDown, Input Param={}", BreakDownList); 
        }
        int result = 0;
        String preSHP = "";
        String preMgt = "";
        for (Map bdList : BreakDownList) {
            //String rowType = XPlatformUtil.getDataRowType(bdList);
            String mgt = preMgt;
            
            if(!preSHP.equals(bdList.get("SHP_TP_CD").toString())){    
                List<Map> searchMgtNo = mngNoDao.searchMngNoList(bdList);
            
                mgt = searchMgtNo.get(0).get("MGT").toString();
            }
            
            String SHP_TP_CD = bdList.get("SHP_TP_CD").toString();          //함형
            String ITM_CD =    bdList.get("ITM_CD").toString();             //정비유형
            String EQCD =      bdList.get("EQCD").toString();               //함 장비부호 
            String ENTP_CD =   bdList.get("ENTP_CD").toString();            //정비업체부호
            
            String MGT_NO = SHP_TP_CD + ITM_CD + mgt;                      //관리번호 
            String RFNO   = ENTP_CD + EQCD;                                //참조번호
            
            bdList.put("MGT_NO", MGT_NO);
            bdList.put("RFNO", RFNO);
            
            if(!preSHP.equals(bdList.get("SHP_TP_CD").toString())){
                result += sysTestDao.insertSysTestMaster(bdList);
            }
            result += breakDnDao.insertBreakDnDetail(bdList);
            result += mngNoDao.insertMngNoDetail(bdList);
            result += mngNoDao.insertMtnPlan(bdList);
            result += mngNoDao.insertTestList(bdList);
            
            result += mngNoDao.insertWrk(bdList);
            
            preMgt = mgt;
            preSHP = bdList.get("SHP_TP_CD").toString();
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveScreen Output ={}", result);
        }

        return result; 
    }

	/**
	 * @see htc.lts.mi.bp.service.BreakDnService#saveTrfctr(java.util.List)
	 * @Method Name        : saveTrfctr
	 * @Method description : 
	 * @Date               : 2016. 12. 15.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 12. 15.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param mngNoList
	 * @return
	*/
	
    @Override
    @ServiceId("MIBPU201")
    @ServiceName("계약이관")
    @ReturnBind("output")
	public int saveTrfctr(@DatasetBind("input")List<Map> BreakDownList) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveTrfctr, Input Param={}", BreakDownList); 
        }
        int result = 0;
        String preSHP = "";
        String preMgt = "";
        for (Map bdList : BreakDownList) {
            //String rowType = XPlatformUtil.getDataRowType(bdList);
            String mgt = preMgt;

            if(!preSHP.equals(bdList.get("SHP_TP_CD").toString())){    
                List<Map> searchMgtNo = mngNoDao.searchMngNoList(bdList);
            
                mgt = searchMgtNo.get(0).get("MGT").toString();
            }

            List<Map> searchCtrno = mngNoDao.searchCtrNoList2(bdList);

            bdList.put("CTRNO", searchCtrno.get(0).get("CTRNO").toString()); 
            bdList.put("CTR_CHNG_SRLNO", searchCtrno.get(0).get("CTR_CHNG_SRLNO").toString());
            
            String SHP_TP_CD = bdList.get("SHP_TP_CD").toString();          //함형
            String ITM_CD =    bdList.get("MTN_ITM_CD").toString();             //정비유형
            String EQCD =      bdList.get("EQCD").toString();               //함 장비부호 
            String ENTP_CD =   bdList.get("ENTP_CD").toString();            //정비업체부호
            
            String MGT_NO = SHP_TP_CD + ITM_CD + mgt;                      //관리번호 
            String RFNO   = ENTP_CD + EQCD;                                //참조번호

            bdList.put("MGT_NO", MGT_NO);
            bdList.put("RFNO", RFNO);
            
            if(!preSHP.equals(bdList.get("SHP_TP_CD").toString())){
                result += sysTestDao.insertSysTestMaster(bdList);
            }
            result += breakDnDao.insertBreakDnDetail(bdList);
            result += mngNoDao.insertMngNoDetail(bdList);
            result += mngNoDao.insertMtnPlan(bdList);
            result += mngNoDao.insertTestList(bdList);
            
            result += mngNoDao.insertWrk(bdList);
            
            preMgt = mgt;
            preSHP = bdList.get("SHP_TP_CD").toString();
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveTrfctr Output ={}", result);
        }

        return result; 
	}
    
    
    @Override
    @ServiceId("MIBPS016")
    @ReturnBind("output")
    public List<Map> inqureRfnoCrtnAndDel(@DatasetBind("input") Map argument) {

        List<Map> result = breakDnDao.inqureRfnoCrtnAndDel(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureRfnoCrtnAndDel Output ={}", result);
        }

        return result;
    }
    

    @Override
    @ServiceId("MIBPX003")
    @ReturnBind("output")
    public int saveRfNo(@DatasetBind("input") List<Map> arguments) {
       
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveRfNo, Input Param={}", arguments); 
        }
        int result = 0;
            for (Map argument : arguments) {
                //argument.put("RFNO",argument.get("RFNO").toString().substring(10,2));
                String rowType = XPlatformUtil.getDataRowType(argument);
                
                if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    argument.put("RFNO",argument.get("ENTP_CD").toString().trim() + argument.get("EQCD").toString().trim());
                    result += breakDnDao.insertBreakDnDetail(argument);
                    result += mngNoDao.insertMngNoDetail(argument);
                    result += mngNoDao.insertMtnPlan(argument);
                    result += mngNoDao.insertTestList(argument);
                    result += mngNoDao.insertWrk(argument);
                    
                } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                    result += breakDnDao.deleteBreakDnDetail(argument);
                    result += mngNoDao.deleteMngNoDetail(argument);
                    result += mngNoDao.deleteMtnPlan(argument);
                    result += mngNoDao.deleteTestList(argument);
                    result += mngNoDao.deleteWrk(argument);
                }
            }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveRfNo Output ={}", result);
        }
    
        return result; 
    }
  
}
