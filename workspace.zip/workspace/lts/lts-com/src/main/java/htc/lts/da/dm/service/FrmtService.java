package htc.lts.da.dm.service;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : 양식함관리
 * @Date		  : 2016. 10. 14. 오후 1:27:55
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 14.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface FrmtService {
    
    /**
     * @Method Name        : inqureFrmt
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    public List<Map> inqureFrmt(Map searchParam);
    
    /**
     * @Method Name        : insertFrmtList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param FrmtList
     * @return
    */
    public int insertFrmtList(List<Map> FrmtList);
    
    /**
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureFile(Map argument);
}
