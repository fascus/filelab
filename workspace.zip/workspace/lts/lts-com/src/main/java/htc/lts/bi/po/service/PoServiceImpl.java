/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.po.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.bi.po.dao.PoDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 29. 오후 9:25:17
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 29.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class PoServiceImpl implements PoService {

    private static final Logger logger = LoggerFactory.getLogger(PoServiceImpl.class);

    @Autowired
    private PoDao poDao;


    @Override
    @ServiceId("BIPOS001")
    @ServiceName("PO관리조회")
    @ReturnBind("output")
    public int createPo(SystemHeader header, @DatasetBind("input") Map argument) {

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : createPo, Input Param={}", argument);
        }
        //poDao.deletePo(argument);
        int result = poDao.createPo(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : createPo Output ={}", result);
        }

        return result;
    }

    /**
	 * @see htc.lts.bi.po.service.PoService#inqurePo(java.util.Map)
	 * @Method Name        : inqurePo
	 * @Method description : 
	 * @Date               : 2016. 12. 6.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 12. 6.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param argument
	 * @return
	*/
	
    @Override
    @ServiceId("BIPOS002")
    @ServiceName("PO관리조회")
    @ReturnBind("output")
	public List<Map> inqurePo(@DatasetBind("input") Map argument) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqurePo, Input Param={}", argument); 
        }
        
        List<Map> result = poDao.inqurePo(argument);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqurePo Output ={}", result);
        }
        
        return result;
	}

	@Override
    @ServiceId({"BIPOX001"})
    @ServiceName("PO관리저장")
    @ReturnBind("output")
    public int isertPo(@DatasetBind("input") List<Map> arguments) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : csDgnssList, Input Param={}", arguments); 
          }
        
          int result = 0;
          for (Map argument : arguments) {
            String rowType = XPlatformUtil.getDataRowType(argument);
            if(logger.isDebugEnabled()){
                logger.debug(rowType);
            }
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    result += poDao.insertPo(argument);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += poDao.updatePo(argument);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += poDao.deletePo(argument);
            }
          }
                 

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : saveUsePn Output ={}", result);
          }

          return result; 
    }
}
