/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.ra.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 11. 17. 오전 8:33:46
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 11. 17.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class SwConfigMngtDaoImpl extends AbstractHtcDao implements SwConfigMngtDao {

   @Override
   public int insertSwConfigMngt(Map argument) {
       return  update("htc.lts.bi.ra.hqml.SwConfigMngtQuery.insertSwConfigMngt", argument);
   }
   
   @Override
   public int updateSwConfigMngt(Map argument) {
       return  update("htc.lts.bi.ra.hqml.SwConfigMngtQuery.updateSwConfigMngt", argument);
   }
   
   @Override
   public int deleteSwConfigMngt(Map argument) {
       return  update("htc.lts.bi.ra.hqml.SwConfigMngtQuery.deleteSwConfigMngt", argument);
   }
   
   @Override
   public List inqureSwConfigMngt(Map argument) {
	   return queryForList("htc.lts.bi.ra.hqml.SwConfigMngtQuery.inqureSwConfigMngt", argument);
   }
   
   @Override
   public List inqureVerCnt(Map argument) {
       return queryForList("htc.lts.bi.ra.hqml.SwConfigMngtQuery.inqureVerCnt", argument);
   }
}
