package htc.lts.mt.mj.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 20. 오후 9:08:20
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 20.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class ToolDaoImpl extends AbstractHtcDao implements ToolDao{

    /**
     * @see htc.lts.mt.mj.dao.ToolDao#inqureToolList(java.util.Map)
     * @Method Name        : inqureToolList
     * @Method description : 
     * @Date               : 2016. 10. 20.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 20.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param tool
     * @return
    */
    @Override
    public List inqureToolList(Map tool) {
        return queryForList("htc.lts.mt.mj.hqml.ToolQuery.selectToolList", tool);
    }
    
    @Override
    public int insertToolList(Map tool) {
        return  update("htc.lts.mt.mj.hqml.ToolQuery.insertToolList", tool);
    }
    
    @Override
    public int updateToolList(Map tool) {
        return  update("htc.lts.mt.mj.hqml.ToolQuery.updateToolList", tool);
    }
    
    @Override
    public int deleteToolList(Map tool) {
        return  update("htc.lts.mt.mj.hqml.ToolQuery.deleteToolList", tool);
    }
    
    
    
    @Override
    public List inqureFile(Map argument) {
        return queryForList("htc.lts.mt.mj.hqml.ToolQuery.inqureFile", argument);
    }
    
    @Override
    public int deleteFile(Map deleteFile) {
        return  update("htc.lts.mt.mj.hqml.ToolQuery.deleteFile", deleteFile);
    }
    
    
    
    @Override
    public List inqureTkoutList(Map tool) {
        return queryForList("htc.lts.mt.mj.hqml.ToolQuery.selectTkoutlList", tool);
    }
    
    
    
    
    @Override
    public int insertTkoutList(Map Tkout) {
        return  update("htc.lts.mt.mj.hqml.ToolQuery.insertTkoutList", Tkout);
    }
    
    @Override
    public int updateTkoutList(Map Tkout) {
        return  update("htc.lts.mt.mj.hqml.ToolQuery.updateTkoutList", Tkout);
    }
    @Override
    public int updateStateCd(Map Tkout) {
        return  update("htc.lts.mt.mj.hqml.ToolQuery.updateStateCd", Tkout);
    }
    
    @Override
    public int deleteTkoutList(Map Tkout) {
        return  update("htc.lts.mt.mj.hqml.ToolQuery.deleteTkoutList", Tkout);
    }

}
