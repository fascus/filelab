/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.qa.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.commons.paging.PagingSupport;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.da.qa.dao.FaqDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.annotation.VariableBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 12. 오후 2:46:10
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 12.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class FaqServiceImpl implements FaqService{
	
	private static final Logger logger = LoggerFactory.getLogger(FaqServiceImpl.class);
	
	@Autowired
	private FaqDao faqDao;

	/**
	 * @see htc.lts.da.qa.service.FaqService#inqureFaq(java.util.Map)
	 * @Method Name        : inqureFaq
	 * @Method description : 
	 * @Date               : 2016. 10. 12.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 12.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
    @ServiceId("DAQAS201")
    @ServiceName("FAQ 조회")
    @ReturnBind("output")
	public List<Map> inqureFaq(SystemHeader header, @DatasetBind("input")Map searchParam, PagingSupport paging) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureFaq, Input Param={}", searchParam);
        } 
        
        //List<Map> faqList = faqDao.inqureFaqList(searchParam); 
        List<Map> faqList = faqDao.inqureFaqList(searchParam, paging);
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFaq Output ={}", faqList);
        }
        
        return faqList;
	}

	/**
	 * @see htc.lts.da.qa.service.FaqService#saveFaq(java.util.List)
	 * @Method Name        : saveFaq
	 * @Method description : 
	 * @Date               : 2016. 10. 12.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 12.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param faqParam
	 * @return
	*/
	
	@Override
	@ServiceId("DAQAX201")
    @ServiceName("FAQ 저장")
    @ReturnBind("output")
	public int saveFaq(@DatasetBind("input")List<Map> faqParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveFaq, Input Param={}", faqParam); 
        }
        
        int result = 0;
        for (Map faq : faqParam) {
            String rowType = XPlatformUtil.getDataRowType(faq);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += faqDao.insertFaq(faq);
                
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += faqDao.updateFaq(faq);
            
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                //result += faqDao.deleteFaq(faq);
            
            }
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveFaq Output ={}", result);
        }
        return result; 
	}

	/**
	 * @see htc.lts.da.qa.service.FaqService#saveCmnt(java.util.List)
	 * @Method Name        : saveCmnt
	 * @Method description : 
	 * @Date               : 2016. 10. 17.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 17.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmntParam
	 * @return
	*/
	
	@Override
	@ServiceId("DAQAX202")
    @ServiceName("게시물답글 저장")
    @ReturnBind("output")
	public int saveCmnt(@DatasetBind("input")List<Map> cmntParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveNtcnt, Input Param={}", cmntParam); 
        }
        
        int result = 0;
        for (Map cmnt : cmntParam) {
            String rowType = XPlatformUtil.getDataRowType(cmnt);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += faqDao.insertCmnt(cmnt);
                
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += faqDao.updateCmnt(cmnt);
            
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                //result += boardDao.deleteNtcnt(ntcnt);
            
            }
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveNtcnt Output ={}", result);
        }
        return result; 
	}

	

}
