/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.ra.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.bi.ra.dao.CsDgnssDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 28. 오후 4:50:51
 * @Author     	  : 송대성
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 28.		송대성						CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class CsDgnssServiceImpl implements CsDgnssService {
	
	private static final Logger logger = LoggerFactory.getLogger(CsDgnssServiceImpl.class);

	@Autowired
	private CsDgnssDao csDgnssDao;

	/**
	 * @see htc.lts.bi.rp.service.CsDgnssService#inqureCsDgnss(java.util.Map)
	 * @Method Name        : inqureResident
	 * @Method description : 
	 * @Date               : 2016. 9. 28.
	 * @Author             : 송대성 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 9. 28.		송대성					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/

	@Override
	@ServiceId("BIRAS001")
    @ServiceName("체계진단항목조회")
    @ReturnBind("output")
	public List<Map> inqureCsDgnss(@DatasetBind("input") Map searchParam) {
		if(logger.isDebugEnabled()){
			
            logger.debug("Service Method : inqureCsDgnss, Input Param={}", searchParam);
        } 
        List<Map> csDgnssList = csDgnssDao.inqureCsDgnss(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureCsDgnss Output ={}", csDgnssList);
        }
        
        return csDgnssList;
	}
	
	@Override
    @ServiceId("BIRAS990")
    @ServiceName("장비항목조회")
    @ReturnBind("output")
    public List<Map> inqureEqCdNm(@DatasetBind("input") Map searchParam) {
        if(logger.isDebugEnabled()){
            
            logger.debug("Service Method : inqureEqCdNm, Input Param={}", searchParam);
        } 
        List<Map> csDgnssList = csDgnssDao.inqureEqCdNm(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureEqCdNm Output ={}", csDgnssList);
        }
        
        return csDgnssList;
    }
	
	  @Override
	  @ServiceId({"BIRAX001"})
	  @ServiceName("체계진단항목저장")
	  @ReturnBind("output")
	  public int saveCsDgnss(@DatasetBind("input") List<Map> csDgnssList) {
	      if(logger.isDebugEnabled()){ 
	            logger.debug("Service Method : csDgnssList, Input Param={}", csDgnssList); 
	        }
	      
	        int result = 0;
	        for (Map csDgnss : csDgnssList) {
	          String rowType = XPlatformUtil.getDataRowType(csDgnss);
	          if(logger.isDebugEnabled()){
	                logger.debug(rowType);
	          }
	          
	          if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
	                  result += csDgnssDao.insertCsDgnss(csDgnss);
	          } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
	              result += csDgnssDao.updateCsDgnss(csDgnss);
	          } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
	              result += csDgnssDao.deleteCsDgnss(csDgnss);
	          }
	        }
	               

	        if (logger.isDebugEnabled()) {
	            logger.debug("Service Method : saveUsePn Output ={}", result);
	        }

	        return result; 
	  }
	
}
