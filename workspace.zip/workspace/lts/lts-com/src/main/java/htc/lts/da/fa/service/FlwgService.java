/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.fa.service;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 28. 오후 5:19:30
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 28.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface FlwgService {
	
    /**
     * @Method Name        : inqureFlwg
     * @Method description : 
     * @Date               : 2016. 10. 28.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 28.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureFlwg(Map argument);
    
    public int saveFlwg(List<Map> flwgList);
    
    public List<Map> inqureResult(Map argument);
    
    public int saveFlwgPn(List<Map> flwgPnList);
    
    public List<Map> inqureFlwgPn(Map argument);
    
    public int saveFlwgPrplsPlan(List<Map> flwgList);
    
    public List<Map> inqureyFlwgPrplsplan(Map argument);
    
    public int saveFlwgPrplsPrsts(List<Map> flwgList);
    
    public List<Map> inqureyFlwgPrplsPrsts(Map argument);
    
    public List<Map> inqureSysTestResult(Map argument);

    public Map inqureFlwgActitm(Map argument);

    public List<Map> inqureFollowAct(Map argument);
}
