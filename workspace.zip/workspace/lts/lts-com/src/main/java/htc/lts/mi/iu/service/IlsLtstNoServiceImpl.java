/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.iu.service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.lts.da.dm.dao.DataDao;
import htc.lts.mi.iu.dao.IlsLtstNoDao;
import htc.lts.mi.mm.dao.MngNoDao;
import htc.lts.mi.om.dao.DsctnIdtfCmplRptDao;
import htc.lts.mi.om.dao.DsctnIdtfItemDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date          : 2016. 9. 21. 오후 2:59:12
 * @Author        : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date             Programmer              Description
 * 2016. 9. 21.     이창환                 CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class IlsLtstNoServiceImpl implements IlsLtstNoService {

    private static final Logger LOGGER = LoggerFactory.getLogger(IlsLtstNoServiceImpl.class);

    @Autowired
    MngNoDao mngNoDao;
    
    @Autowired
    DsctnIdtfItemDao dsctnIdtfItemDao;
    
    @Autowired
    IlsLtstNoDao ilsLtstNoDao;
    
    @Autowired
    private DataDao dataDao;
    
    @Autowired
    DsctnIdtfCmplRptDao dsctnIdtfCmplRptDao;
    
    /**
     * @see htc.lts.mi.rm.service.HwSwNoService#saveMngNo(java.util.List)
     * @Method Name        : saveMngNo
     * @Method description : 
     * @Date               : 2016. 10. 25.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 25.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mngNoList
     * @return
    */
    @Override
    @ServiceId("MIIUX001")
    @ServiceName("ILS최신화관리번호생성")
    @ReturnBind("output")
    public int saveMngNo(@DatasetBind("input") List<Map> mngNoList) {
        if(LOGGER.isDebugEnabled()){ 
              LOGGER.debug("Service Method : saveMngNo, Input Param={}", mngNoList); 
          }
        

        int result = 0;
        
        String preSHP = "";
        String preMgt = "";
//        String perIlsUpdateDvcd1 = "";
//        String perIlsUpdateDvcd2 = "";
//        List<Map> searchMgtNo = null;
        
        for (Map mngNo : mngNoList) {
//            String rowType = XPlatformUtil.getDataRowType(mngNo);
            String mgt = preMgt;
//            perIlsUpdateDvcd1 = mngNo.get("ILS_UPDATE_DVCD").toString();
            //System.out.println(preSHP+ "----------------------------------"+mngNo.get("SHP_TP_CD").toString());
            if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){    
                List<Map> searchMgtNo = mngNoDao.searchMngNoList(mngNo);
            
                mgt = searchMgtNo.get(0).get("MGT").toString();
                
            }
              
              String SHP_TP_CD = mngNo.get("SHP_TP_CD").toString();          //함형
              String ITM_CD =    mngNo.get("ITM_CD").toString();             //정비유형
              String EQCD =      mngNo.get("EQCD").toString();               //함 장비부호 
              String ENTP_CD =   mngNo.get("MTN_ENTP_CD").toString();            //정비업체부호
//              String ILS_UPDATE_DVCD = mngNo.get("ILS_UPDATE_DVCD").toString();
              
              String MGT_NO = SHP_TP_CD + ITM_CD + mgt;                      //관리번호 
              String RFNO   = ENTP_CD.trim() + EQCD.trim();                  //참조번호
              
              //System.out.println(MGT_NO+ "----------------------------------"+RFNO);
              
             
              
              List<Map> searchCtrno = mngNoDao.searchCtrNoList2(mngNo);

              mngNo.put("CTRNO", searchCtrno.get(0).get("CTRNO").toString()); 
              mngNo.put("CTR_CHNG_SRLNO", searchCtrno.get(0).get("CTR_CHNG_SRLNO").toString());
              
              
              HashMap<String, String> param = new HashMap<>();
              
              param.put("MGT_NO", MGT_NO);
              param.put("RFNO", RFNO);
              
              List<Map> mgtNoRfNoList = dsctnIdtfItemDao.inqureyMgtNoRfNo(param);       //공문번호로 계약번호 검색후 
              
              mngNo.put("MGT_NO", MGT_NO);
              mngNo.put("RFNO", RFNO);
                  
             if(!mgtNoRfNoList.isEmpty()){
                 
                 for(Map mgtNoRfNo: mgtNoRfNoList){
                     
                     if(!mgtNoRfNo.get("RFNO").equals(RFNO)){
                     
                         if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){
                             result += mngNoDao.insertMngNoMaster(mngNo);
                         }
                     
                         result += mngNoDao.insertMngNoDetail(mngNo);
                         ilsLtstNoDao.insertIlsLtstPlan(mngNo);
                     }
                 
                 }
                     
             }else{
                 
                 if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){
                     result += mngNoDao.insertMngNoMaster(mngNo);
                 }
                 
                 result += mngNoDao.insertMngNoDetail(mngNo);
                 ilsLtstNoDao.insertIlsLtstPlan(mngNo);
             }
             
             
//             List<Map> list1 = ilsLtstNoDao.inqueryIlsLtstCmplRpt(mngNo);
//             
//             List<Map> list2 = ilsLtstNoDao.inqueryIlsLtstMgt(mngNo);
             
//             if(list1.size()==0){
//            	 ilsLtstNoDao.insertIlsLtstCmplRpt(mngNo);
//             }
//             
//             if(list2.size()==0){
//            	 ilsLtstNoDao.insertIlsLtstMgt(mngNo);
//             }
             
             
              
              preMgt = mgt;
              preSHP = mngNo.get("SHP_TP_CD").toString();
//              perIlsUpdateDvcd1 = mngNo.get("ILS_UPDATE_DVCD").toString(); 
          }
          

          if (LOGGER.isDebugEnabled()) {
              LOGGER.debug("Service Method : saveMngNo Output ={}", result);
          }

          return result; 
    }
    
    /**
     * @see htc.lts.mi.iu.service.IlsLtstNoService#inqureIlsLtst(java.util.Map)
     * @Method Name        : inqureIlsLtst
     * @Method description : 
     * @Date               : 2016. 10. 27.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 27.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("MIIUS001")
    @ServiceName("ILS최신화조회")
    @MultiReturnBind
    public Map<String, List> inqureIlsLtst(@DatasetBind("input") Map searchParam) {
        
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : inqureIlsLtst, Input Param={}", searchParam); 
        }
        
        List<Map> ilsLtstList = ilsLtstNoDao.inqureIlsLtst(searchParam);
        
        List<Map> miotList = ilsLtstNoDao.selectMiotIng(searchParam);
        
        Map<String, List> data = new HashMap<>();
        
        data.put("output", ilsLtstList);
        data.put("miotIng", miotList);
                
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureIlsLtst Output ={}", ilsLtstList);
        }
        
        return data;
    }
    
    @Override
    @ServiceId("MIIUS002")
    @ServiceName("ILS최신화조회")
    @ReturnBind("output")
    public List<Map> inqueryIlsLtstPlan(@DatasetBind("input") Map searchParam) {
        
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : inqueryIlsLtstPlan, Input Param={}", searchParam); 
        }
        
        List<Map> ilsLtstPlanList = ilsLtstNoDao.inqureIlsPlanLtst(searchParam);
                
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqueryIlsLtstPlan Output ={}", ilsLtstPlanList);
        }
        
        return ilsLtstPlanList;
    }
    
    @Override
    @ServiceId("MIIUX002")
    @ServiceName("ILS최신화계획저장")
    @ReturnBind("output")
    public int saveIlsLtstPlan(@DatasetBind("input") List<Map> ilsLtstPlanList) {
        if(LOGGER.isDebugEnabled()){ 
              LOGGER.debug("Service Method : saveIlsLtstPlan, Input Param={}", ilsLtstPlanList); 
          }
        

        int result = 0;
          
          for (Map ilsLtstPlan : ilsLtstPlanList) {
              result +=ilsLtstNoDao.updateIlsLtstPlan(ilsLtstPlan);
          }

          if (LOGGER.isDebugEnabled()) {
              LOGGER.debug("Service Method : saveIlsLtstPlan Output ={}", result);
          }

          return result; 
    }
    
    @Override
    @ServiceId("MIIUS003")
    @ReturnBind("output")
    public List<Map> inqureFile2(@DatasetBind("input") Map argument) {


        List<Map> result = dataDao.inqureFile2(argument);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureFile2 Output ={}", result);
        }

        return result;
    }

    @Override
    public List selectMiotIng(Map mtn) {
        return Collections.emptyList();
    }
    
    @Override
    @ServiceId("MIIUS700")
    @ServiceName("ILS최신화조회")
    @ReturnBind("output")
    public List<Map> inqureyIlsCmrpt(@DatasetBind("input") Map searchParam) {
        
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : inqureyIlsCmrpt, Input Param={}", searchParam); 
        }
        
        List<Map> ilsCmrptList = ilsLtstNoDao.inqueryIlsLtstCmplRpt(searchParam);
                
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureyIlsCmrpt Output ={}", ilsCmrptList);
        }
        
        return ilsCmrptList;
    }
    
    @Override
    @ServiceId("MIIUX700")
    @ServiceName("ILS최신화계획저장")
    @ReturnBind("output")
    public int saveIlsCmrpt(@DatasetBind("input") List<Map> ilsLtstPlanList) {
        if(LOGGER.isDebugEnabled()){ 
              LOGGER.debug("Service Method : saveIlsCmrpt, Input Param={}", ilsLtstPlanList); 
          }
        

        int result = 0;
          
          for (Map ilsLtstPlan : ilsLtstPlanList) {
        	  
        	  List<Map> ilsCmrptList = ilsLtstNoDao.inqueryIlsLtstCmplRpt(ilsLtstPlan);
              
        	  if(ilsCmrptList.isEmpty()){
        		  result +=ilsLtstNoDao.insertIlsLtstCmplRpt(ilsLtstPlan);
        		  result += dsctnIdtfCmplRptDao.updateLbcst(ilsLtstPlan);
        	  }else{
        		  result +=ilsLtstNoDao.updateIlsLtstCmplRpt(ilsLtstPlan);
        		  result += dsctnIdtfCmplRptDao.updateLbcst(ilsLtstPlan);
        	  }
              
                  
          }

          if (LOGGER.isDebugEnabled()) {
              LOGGER.debug("Service Method : saveIlsCmrpt Output ={}", result);
          }

          return result; 
    }
    
    @Override
    @ServiceId("MIIUS004")
    @ServiceName("ILS최신화계획참조번호조회")
    @ReturnBind("output")
    public List<Map> inqureRfnoCrtnAndDel(@DatasetBind("input") Map searchParam) {
        
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : inqureRfnoCrtnAndDel, Input Param={}", searchParam); 
        }
        
        List<Map> result = ilsLtstNoDao.inqureRfnoCrtnAndDel(searchParam);
                
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureRfnoCrtnAndDel Output ={}", result);
        }
        
        return result;
    }
    

    @Override
    @ServiceId("MIIUX701")
    @ReturnBind("output")
    public int saveRfNo(@DatasetBind("input") List<Map> arguments) {
       
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : saveRfNo, Input Param={}", arguments); 
        }
        int result = 0;
        for (Map argument : arguments) {
            //argument.put("RFNO",argument.get("RFNO").toString().substring(10,2));
            String rowType = XPlatformUtil.getDataRowType(argument);
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                argument.put("RFNO",argument.get("MTN_ENTP_CD").toString().trim() + argument.get("EQCD").toString().trim());
                result += mngNoDao.insertMngNoDetail(argument);
                result += ilsLtstNoDao.insertIlsLtstPlan(argument);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += mngNoDao.deleteMngNoDetail(argument);
                result += ilsLtstNoDao.deleteIlsLtstPlan(argument);
            }
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : saveRfNo Output ={}", result);
        }

        return result; 
    }
}