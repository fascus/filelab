package htc.lts.da.dm.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : 일반자료관리
 * @Date		  : 2016. 10. 12. 오후 7:13:59
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 12.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class DataDaoImpl extends AbstractHtcDao implements DataDao{
    
    /**
     * @see htc.lts.da.dm.dao.DataDao#inqureData(java.util.Map)
     * @Method Name        : inqureData
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 12.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param swError
     * @return
    */
    @Override
    public List inqureDataList(Map data) {
        return queryForList("htc.lts.da.dm.hqml.DataQuery.selectDataList", data);
    }

    /**
     * @see htc.lts.da.dm.dao.DataDao#insertDataList(java.util.Map)
     * @Method Name        : insertDataList
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 12.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DataList
     * @return
    */
    @Override
    public int insertDataList(Map DataList) {
        return  update("htc.lts.da.dm.hqml.DataQuery.insertDataList", DataList);
    }
    

    /**
     * @see htc.lts.da.dm.dao.DataDao#updateDataList(java.util.Map)
     * @Method Name        : updateDataList
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 12.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DataList
     * @return
    */
    @Override
    public int updateDataList(Map DataList) {
        return  update("htc.lts.da.dm.hqml.DataQuery.updateDataList", DataList);
    }
    
    /**
     * @see htc.lts.da.dm.dao.DataDao#deleteDataList(java.util.Map)
     * @Method Name        : deleteDataList
     * @Method description : 
     * @Date               : 2016. 10. 12.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 12.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DataList
     * @return
    */
    @Override
    public int deleteDataList(Map DataList) {
        return  update("htc.lts.da.dm.hqml.DataQuery.deleteDataList", DataList);
    }
    
    /**
     * @see htc.lts.da.dm.dao.DataDao#inqureFile(java.util.Map)
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 13.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 13.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    public List inqureFile(Map argument) {
        return queryForList("htc.lts.da.dm.hqml.DataQuery.inqureFile", argument);
    }
    
    @Override
    public List inqureFile2(Map argument) {
        return queryForList("htc.lts.da.dm.hqml.DataQuery.inqureFile2", argument);
    }
    
    @Override
    public int deleteFile(Map deleteFile) {
        return  update("htc.lts.da.dm.hqml.DataQuery.deleteFile", deleteFile);
    }
}
