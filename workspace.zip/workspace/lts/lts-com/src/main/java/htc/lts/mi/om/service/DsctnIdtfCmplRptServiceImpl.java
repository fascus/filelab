package htc.lts.mi.om.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.da.dm.dao.DataDao;
import htc.lts.mi.mm.service.UsePnServiceImpl;
import htc.lts.mi.om.dao.DsctnIdtfCmplRptDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:21:01
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class DsctnIdtfCmplRptServiceImpl implements DsctnIdtfCmplRptService {

    private static final Logger logger = LoggerFactory.getLogger(UsePnServiceImpl.class);
    
    @Autowired
    DsctnIdtfCmplRptDao dsctnIdtfCmplRptDao;

    @Autowired
    private DataDao dataDao;

    @Override
    @ServiceId("MIOMS005")
    @ServiceName("단종관리잗업일지조회")
    @ReturnBind("output")
    public List<Map> inqureyDsctnIdtfCmplRpt(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureyDsctnIdtfWrkCtnt, Input Param={}", searchParam); 
        }
        
//        List<Map> list1 = dsctnIdtfCmplRptDao.inqueryDsctnIdtfCmplRptList(searchParam);
//        
//        
//        if(list1.size()==0){
//            List<Map> eqnmList =  dsctnIdtfCmplRptDao.inqueryEqnm(searchParam);
//            
//            for (Map eqNm : eqnmList) {
//                dsctnIdtfCmplRptDao.insertDsctnIdtfCmplRpt(eqNm);
//            }
//        }
        
        List<Map> dsctnIdtfCmplRptList = dsctnIdtfCmplRptDao.inqueryDsctnIdtfCmplRptList(searchParam);
        
        
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureyDsctnIdtfWrkCtnt Output ={}", dsctnIdtfCmplRptList);
        }
        
        return dsctnIdtfCmplRptList;
    }
    
    
    
    @Override
    @ServiceId("MIOMX003")
    @ServiceName("단종관리완료보고저장")
    @ReturnBind("output")
    public int saveDsctnIdtfCmplRpt(@DatasetBind("input") Map DsctnIdtfCmplRptList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveDsctnIdtfCmplRpt, Input Param={}", DsctnIdtfCmplRptList); 
        }
        
        int result = 0;
//        for (Map dsctnIdtfCmplRpt : DsctnIdtfCmplRptList) {
//            String rowType = XPlatformUtil.getDataRowType(DsctnIdtfCmplRptList);
            
        
        	List<Map> eqnmList = dsctnIdtfCmplRptDao.inqueryDsctnIdtfCmplRptList(DsctnIdtfCmplRptList);
        	
        	if(eqnmList.size()==0){
        		result += dsctnIdtfCmplRptDao.insertDsctnIdtfCmplRpt(DsctnIdtfCmplRptList);
        		result += dsctnIdtfCmplRptDao.updateLbcst(DsctnIdtfCmplRptList);
        		
        	}else{
        		result += dsctnIdtfCmplRptDao.updatedsctnIdtfCmplRpt(DsctnIdtfCmplRptList);
        		result += dsctnIdtfCmplRptDao.updateLbcst(DsctnIdtfCmplRptList);
        	}
            
//            if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_UPDATED)) {
//                result += dsctnIdtfCmplRptDao.updatedsctnIdtfCmplRpt(DsctnIdtfCmplRptList);
//            }
//        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveDsctnIdtfCmplRpt Output ={}", result);
        }

        return result; 
    }
    
    
    @Override
    @ServiceId("MIOMS200")
    @ReturnBind("output")
    public List<Map> inqureFile(@DatasetBind("input") Map argument) {


        List<Map> result = dataDao.inqureFile2(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFile Output ={}", result);
        }

        return result;
    }
    
    @Override
    @ServiceId("MIOMS201")
    @ReturnBind("output")
    public List<Map> inqureFile2(@DatasetBind("input") Map argument) {


        List<Map> result = dsctnIdtfCmplRptDao.inqureFile2(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFile Output ={}", result);
        }

        return result;
    }
    
}
