/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.ot.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ch.qos.logback.core.util.Loader;
import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.mi.mm.dao.MngNoDao;
import htc.lts.mi.ot.dao.OprdnsPrstsDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 18. 오전 9:56:32
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 18.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class OprdnsPrstsServiceImpl implements OprdnsPrstsService {
	
	private static final Logger logger = LoggerFactory.getLogger(OprdnsPrstsServiceImpl.class);
	
	@Autowired
	OprdnsPrstsDao oprdnsPrstsDao;
	@Autowired
    MngNoDao mngNoDao;
	

	/**
	 * @see htc.lts.mi.ot.service.OprdnsPrstsService#inqureShipInfo(java.util.Map)
	 * @Method Name        : inqureShipInfo
	 * @Method description : 함정보 콤보박스 조회
	 * @Date               : 2016. 10. 18.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 18.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
    @ServiceId("MIOTS001")
	@ServiceName("함명장비명조회")
    @ReturnBind("output")
	public List<Map> inqureShipInfo(@DatasetBind("input")Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureCmplRpt, Input Param={}", searchParam); 
        }
        List<Map> mtnList;
        
        if("SHP_TP_CD".equals(searchParam.get("GBN"))){
            mtnList = oprdnsPrstsDao.inqureShipNmList(searchParam);
        }else if("MTNCD".equals(searchParam.get("GBN"))){
            mtnList = oprdnsPrstsDao.inqureMtnCdList(searchParam);
        }else{
            mtnList = oprdnsPrstsDao.inqureEqNmList(searchParam);
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureCmplRpt Output ={}", mtnList);
        }
        
        return mtnList;
	}
	
	/**
	 * @see htc.lts.mi.ot.service.OprdnsPrstsService#seachEqNm(java.util.Map)
	 * @Method Name        : seachEqNm
	 * @Method description : 
	 * @Date               : 2016. 10. 18.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 18.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
    @ServiceId("MIOTS002")
	@ServiceName("장비명조회")
    @ReturnBind("output")
	public List<Map> seachEqNm(@DatasetBind("input")Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : seachEqNm, Input Param={}", searchParam); 
        }
        
        List<Map> mtnList = oprdnsPrstsDao.seachEqNm(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : mtnList Output ={}", mtnList);
        }
        
        return mtnList;
	}

	/**
	 * @see htc.lts.mi.ot.service.OprdnsPrstsService#inqureOprdnsPrsts(htc.hone.core.message.SystemHeader, java.util.Map)
	 * @Method Name        : inqureOprdnsPrsts
	 * @Method description : 
	 * @Date               : 2016. 10. 19.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 19.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param header
	 * @param searchParam
	 * @return
	*/
	
	@Override
    @ServiceId("MIOTS003")
    @ServiceName("전비태세현황조회")
	@MultiReturnBind
	public Map<String, List> inqureOprdnsPrsts(SystemHeader header, @DatasetBind("input")Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureOprdnsPrsts, Input Param={}", searchParam); 
        }
        
        List<Map> oprdnsPrstsList = oprdnsPrstsDao.inqureOprdnsList(searchParam);
        
        List<Map> miotList = oprdnsPrstsDao.selectMiotIng(searchParam);
        
        Map<String, List> data = new HashMap<>();
        
        data.put("output", oprdnsPrstsList);
        data.put("miotIng", miotList);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureOprdnsPrsts Output ={}", oprdnsPrstsList);
        }
        
        return data;
	}

	@Override
    @ServiceId("MIOTX031")
    @ServiceName("전비태세생성")
    @ReturnBind("output")
    public int saveCrtMngNo(@DatasetBind("input") List<Map> mngNoList) {
       
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveCrtMngNo, Input Param={}", mngNoList); 
        }
        int result = 0; 
        String preSHP = "";
        String preMgt = "";
        for (Map mngNo : mngNoList) {
            String mgt = preMgt;
            if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){    
                List<Map> searchMgtNo = mngNoDao.searchMngNoList(mngNo);
            
                mgt = searchMgtNo.get(0).get("MGT").toString();
                
            }
            
            String SHP_TP_CD = mngNo.get("SHP_TP_CD").toString();          //함형
            String ITM_CD =    mngNo.get("ITM_CD").toString();             //정비유형
            String EQCD =      mngNo.get("EQCD").toString();               //함 장비부호 
            String ENTP_CD =   mngNo.get("ENTP_CD").toString();            //정비업체부호
            String DVCD   =    mngNo.get("OPRDNS_TCHASST_BASIS_CD").toString();      //관련근거
            
            String MGT_NO = SHP_TP_CD + ITM_CD + mgt;                      //관리번호 
            String RFNO   = ENTP_CD.trim() + EQCD.trim();                  //참조번호
                  
            //System.out.println(MGT_NO+ "----------------------------------"+RFNO);
            List<Map> searchCtrno = null;
            if("1".equals(DVCD)){
                //searchCtrno = mngNoDao.searchCtrNoList(mngNo);       //공문번호로 계약번호 검색후 
            }else if("2".equals(DVCD) || "3".equals(DVCD)){
                searchCtrno = mngNoDao.searchCtrNoList2(mngNo);
                mngNo.put("CTRNO", searchCtrno.get(0).get("CTRNO").toString()); 
                mngNo.put("CTR_CHsNG_SRLNO", searchCtrno.get(0).get("CTR_CHNG_SRLNO").toString());
            }

            
            
            mngNo.put("MGT_NO", MGT_NO);
            mngNo.put("RFNO", RFNO);
            
            if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){
                result += mngNoDao.insertMngNoMaster(mngNo);
            }
            result += mngNoDao.insertMngNoDetail(mngNo);
            //result += mngNoDao.insertWrk(mngNo);
            result += oprdnsPrstsDao.insertWrk(mngNo);
            
            preMgt = mgt;
            preSHP = mngNo.get("SHP_TP_CD").toString();
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveCrtMngNo Output ={}", result);
        }

        return result; 
    }

    
    @Override
    @ServiceId("MIOTS004")
    @ServiceName("전비태세참조번호조회")
    @ReturnBind("output")
    public List<Map> inqureRfnoCrtnAndDel(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureRfnoCrtnAndDel, Input Param={}", searchParam); 
        }
        
        List<Map> result = oprdnsPrstsDao.inqureRfnoCrtnAndDel(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureRfnoCrtnAndDel Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId("MIOTX032")
    @ReturnBind("output")
    public int saveRfNo(@DatasetBind("input") List<Map> arguments) {
       
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveRfNo, Input Param={}", arguments); 
        }
        int result = 0;
            for (Map argument : arguments) {
                //argument.put("RFNO",argument.get("RFNO").toString().substring(10,2));
                String rowType = XPlatformUtil.getDataRowType(argument);
                
                if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    argument.put("RFNO",argument.get("ENTP_CD").toString().trim() + argument.get("EQCD").toString().trim());
                    result += mngNoDao.insertMngNoDetail(argument);
                    result += oprdnsPrstsDao.insertWrk(argument);
                    
                } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                    result += mngNoDao.deleteMngNoDetail(argument);
                    result += oprdnsPrstsDao.deleteWrk(argument);
                }
            }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveRfNo Output ={}", result);
        }

        return result; 
    }
}
