/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.dao;

import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

@Repository
public class EXChrtDaoImpI extends AbstractHtcDao implements EXChrtDao {

   
    @Override
    public int insertChrt(Map chrtList) {
        return  update("htc.lts.bi.pd.hqml.EXChrtQuery.insertChrt", chrtList);
    }
    @Override
    public int updateChrt(Map chrtList) {
        return  update("htc.lts.bi.pd.hqml.EXChrtQuery.updateChrt", chrtList);
    }
    @Override
    public int deleteChrt(Map chrtList) {
        return  update("htc.lts.bi.pd.hqml.EXChrtQuery.deleteChrt", chrtList);
    }
    
    @Override
    public List inqureChrt(Map chrtList) {
        return  queryForList("htc.lts.bi.pd.hqml.EXChrtQuery.selectChrtList", chrtList);
    }
        
}
