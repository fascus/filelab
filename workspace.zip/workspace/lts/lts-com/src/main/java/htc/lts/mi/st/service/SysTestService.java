/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.st.service;

import java.util.List;
import java.util.Map;

import htc.hone.core.message.SystemHeader;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:55:18
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface SysTestService {

   
    public List<Map> inqureSysTest(Map argument);
    
   
    public int saveSysTest(List<Map> mngNoList);


    /**
     * @Method Name        : inqureDmndMatr
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureDmndMatr(Map argument);


    /**
     * @Method Name        : saveDmndMatr
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public int saveDmndMatr(List<Map> argument);
    
    public int deleteDmndMatr(Map argument);

    public int saveCtnt(List<Map> argument);
    /**
     * @Method Name        : updateDmndMatrCtnt
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public int updateDmndMatrCtnt(Map argument);
    
    //public int saveScreenObj(List<Map> screenObjList);
    
    /**
     * @Method Name        : inqureMtn
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    //public List<Map> inqureMtn(Map argument);
    public Map<String, List> inqureMtn(SystemHeader header, Map searchParam);


    /**
     * @Method Name        : inqureDmndMatrCtnt
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureDmndMatrCtnt(Map argument);
    
    /**
     * @Method Name        : inqureCsDgnssResult
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureCsDgnssResult(Map argument);


    /**
     * @Method Name        : insertCsDgnssResult
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    int saveTotMng(List<Map> argument1, List<Map> argument2);


    /**
     * @Method Name        : updateCsDgnssResult
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public int updateCsDgnssResult(Map argument);


    /**
     * @Method Name        : inqureCsDgnssResult2
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureCsDgnssResult2(Map argument);

    /**
     * @Method Name        : insertCsDgnssResultDtl
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param arguments
     * @return
    */
    public int insertCsDgnssResultDtl(List<Map> arguments);


    /**
     * @Method Name        : inqureCsDgnssResultDtl
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    Map<String, List> inqureCsDgnssResultDtl(SystemHeader header, Map searchParam);


    /**
     * @Method Name        : updateCsDgnssResultDtl
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public int updateCsDgnssResultDtl(Map argument);


    /**
     * @Method Name        : inqureCsDgnssResultDtl2
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureCsDgnssResultDtl2(Map argument);


    public int saveRfNo(List<Map> arguments);

    public int mergeDgnssRslt(Map argument);
    
    
}
