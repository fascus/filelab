package htc.lts.mt.mj.service;

import java.util.List;
import java.util.Map;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 20. 오후 9:08:10
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 20.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface ToolService {
    
    /**
     * @Method Name        : inqureTool
     * @Method description : 
     * @Date               : 2016. 10. 20.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 20.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    public List<Map> inqureTool(Map searchParam);
    
    /**
     * @Method Name        : insertToolList
     * @Method description : 
     * @Date               : 2016. 10. 24.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 24.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param ToolList
     * @return
    */
    public int insertToolList(List<Map> ToolList);
    
    /**
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 24.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 24.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureFile(Map argument);
    
    public int deleteFile(List<Map> deleteFileList);
    
    public List<Map> inqureTkout(Map searchParam);
    
    public int saveTkout(List<Map> ToolList);
}
