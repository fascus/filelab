/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.ot.dao;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 18. 오전 9:57:41
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 18.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */ 
public interface OprdnsPrstsDao {
	
    public List inqureShipNmList(Map mngNo);
    
    public List inqureMtnCdList(Map mngNo);
    
    public List inqureEqNmList(Map mngNo);
    
    public List seachEqNm(Map mngNo);
    
    public List inqureOprdnsList(Map searchParam);
    
    public int insertWrk(Map mngNo);
    
    public List selectMiotIng(Map mtn);

    public List inqureRfnoCrtnAndDel(Map searchParam);

    public int deleteWrk(Map argument);
}
