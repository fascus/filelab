/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.st.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.mi.mm.dao.MngNoDao;
import htc.lts.mi.st.dao.SysTestDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:59:12
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class SysTestServiceImpl implements SysTestService {

    private static final Logger logger = LoggerFactory.getLogger(SysTestServiceImpl.class);

    @Autowired
    SysTestDao sysTestDao;
    @Autowired
    MngNoDao mngNoDao;
   
    @Override
    @ServiceId("MIMMM001")
    @ServiceName("이동정비현황조회")
    @ReturnBind("output")
    public List<Map> inqureSysTest(@DatasetBind("intput") Map searchParam) {
    	
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureSysTest, Input Param={}", searchParam); 
        }
        
        List<Map> sysTestList = sysTestDao.inqureSysTestList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inquireSysTest Output ={}", sysTestList);
        }
        
        return sysTestList;
    }
    
   
	
    
	@Override
	@ServiceId("MISTX001")
	@ServiceName("체계진단생성")
	@ReturnBind("output")
	public int saveSysTest(@DatasetBind("input") List<Map> sysTestList) {
	    
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveSysTest, Input Param={}", sysTestList); 
        }
		int result = 0;
		String preSHP = "";
		String preMgt = "";
		for (Map sysTest : sysTestList) {
            //String rowType = XPlatformUtil.getDataRowType(sysTest);
            String mgt = preMgt;
            //System.out.println(preSHP+ "----------------------------------"+sysTest.get("SHP_TP_CD").toString());
            if(!preSHP.equals(sysTest.get("SHP_TP_CD").toString())){    
                List<Map> searchSysTest = mngNoDao.searchMngNoList(sysTest);
        	
                mgt = searchSysTest.get(0).get("MGT").toString();
            }
            //System.out.println(preMgt+ "----------------------------------"+mgt);
            
            
        	String SHP_TP_CD = sysTest.get("SHP_TP_CD").toString();          //함형
        	String ITM_CD =    sysTest.get("ITM_CD").toString();             //정비유형
        	String EQCD =      sysTest.get("EQCD").toString();               //함 장비부호 
        	String ENTP_CD =   sysTest.get("ENTP_CD").toString();            //정비업체부호
        	
        	String MGT_NO = SHP_TP_CD + ITM_CD + mgt;                      //관리번호 
        	String RFNO   = ENTP_CD.trim() + EQCD.trim();                  //참조번호
        	//System.out.println(MGT_NO+ "----------------------------------"+RFNO);
        	/*
        	List<Map> searchCtrno = mngNoDao.searchCtrNoList(sysTest);       //공문번호로 계약번호 검색후 
            
        	for (Map ctrno : searchCtrno) {                                //해당 함형에 따른 계약번호 추출  
                if(SHP_TP_CD.equals(ctrno.get("SHP_TP_CD"))){
                    sysTest.put("CTRNO", ctrno.get("CTRNO")); 
                    sysTest.put("CTR_CHNG_SRLNO", ctrno.get("CTR_CHNG_SRLNO"));
                    break;
                }
            }
            */
        	
            sysTest.put("MGT_NO", MGT_NO);
            sysTest.put("RFNO", RFNO);
            
            if(!preSHP.equals(sysTest.get("SHP_TP_CD").toString())){
                result += sysTestDao.insertSysTestMaster(sysTest);
            }
            result += sysTestDao.insertSysTestDetail(sysTest);
            result += sysTestDao.insertCmplRpt(sysTest);
            preMgt = mgt;
        	preSHP = sysTest.get("SHP_TP_CD").toString();
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveScreen Output ={}", result);
        }

        return result; 
	}
	
	
    /**
     * @Method Name        : inqureDmndMatr
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("MISTS001")
    @ReturnBind("output")
    public List<Map> inqureDmndMatr(@DatasetBind("input") Map argument) {

        List<Map> result = sysTestDao.inqureDmndMatr(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureOfcdocNo Output ={}", result);
        }

        return result;
    }
    
    /**
     * @see htc.lts.mi.st.service.SysTestService#insertDmndMatr(java.util.Map)
     * @Method Name        : saveDmndMatr
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("MISTI001")
    @ServiceName("승조원진단요구사항저장")
    @ReturnBind("output")
    public int saveDmndMatr(@DatasetBind("input") List<Map> argument) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertDmndMatr, Input Param={}", argument);
        }
        
        int result = 0;
        for (Map arg : argument) {
            String rowType = XPlatformUtil.getDataRowType(arg);
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += sysTestDao.insertDmndMatr(arg);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += sysTestDao.updateDmndMatr(arg);
            //}else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
            
            }
        }
       
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertDmndMatr Output ={}", result);
        }

        return result;
    }
    
    
    @Override
    @ServiceId("MISTD001")
    @ServiceName("승조원진단요구사항저장")
    @ReturnBind("output")
    public int deleteDmndMatr(@DatasetBind("input") Map argument) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertDmndMatr, Input Param={}", argument);
        }
        
        int result = 0;
        
        result += sysTestDao.deleteDmndMatr(argument);
  
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertDmndMatr Output ={}", result);
        }

        return result;
    }

    /**
     * @see htc.lts.mi.st.service.SysTestService#insertDmndMatr(java.util.Map)
     * @Method Name        : saveDmndMatr
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 6.     강형순                 CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("MISTI010")
    @ReturnBind("output")
    public int saveCtnt(@DatasetBind("input") List<Map> argument) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertDmndMatr, Input Param={}", argument);
        }
        int result = 0;
        for (Map arg : argument) {
            result += sysTestDao.updateCmplRpt(arg);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertDmndMatr Output ={}", result);
        }

        return result;
    }
    
    /**
     * @Method Name        : updateDmndMatrCtnt
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("MISTU001")
    @ReturnBind("output")
    public int updateDmndMatrCtnt(@DatasetBind("input") Map argument) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateDmndMatrCtnt, Input Param={}", argument);
        }

        int result = sysTestDao.updateDmndMatrCtnt(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateDmndMatrCtnt Output ={}", result);
        }

        return result;
    }
    
    /**
     * @see htc.lts.mi.st.service.SysTestService#inqureMtn(java.util.Map)
     * @Method Name        : inqureMtn
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("MISTS002")
    @ServiceName("체계진단조회")
    @MultiReturnBind
    public Map<String, List> inqureMtn(SystemHeader header, @DatasetBind("input")Map searchParam) {     
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureMtn, Input Param={}", searchParam); 
        }
        
        List<Map> result = sysTestDao.inqureMtnList(searchParam);
        
        List<Map> mistList = sysTestDao.selectMistIng(searchParam);
        
        Map<String, List> data = new HashMap<>();
        
        data.put("output", result);
        data.put("mistIng", mistList);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureMtn Output ={}", result);
        }
        
        return data;
    }
    
    /**
     * @see htc.lts.mi.st.service.SysTestService#inqureDmndMatrCtnt(java.util.Map)
     * @Method Name        : inqureDmndMatrCtnt
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("MISTS003")
    @ServiceName("체계진단권고사항조회")
    @ReturnBind("output")
    public List<Map> inqureDmndMatrCtnt(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureDmndMatrCtnt, Input Param={}", argument); 
        }
        
        List<Map> result = sysTestDao.inqureDmndMatrCtnt(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureDmndMatrCtnt Output ={}", result);
        }
        
        return result;
    }
    
    
    
    /**
     * @see htc.lts.mi.st.service.SysTestService#insertCsDgnssResult(java.util.Map)
     * @Method Name        : insertCsDgnssResult
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("MISTI002")
    @ServiceName("체계진단종합진단결과등록")
    @ReturnBind("output")
    public int saveTotMng(@DatasetBind("input1") List<Map> argument1,@DatasetBind("input2") List<Map> argument2) {
        int result = 0;
        for (Map arg : argument1) {
            result += sysTestDao.updateCmplRpt(arg);
        }
        
        for (Map arg : argument2) {
            String rowType = XPlatformUtil.getDataRowType(arg);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += sysTestDao.insertCsDgnssResultDtl(arg);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += sysTestDao.updateCsDgnssResultDtl(arg);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += sysTestDao.deleteCsDgnssResultDtl(arg);
            }
        }
        return result;
    }
    
    
    
    /**
     * @see htc.lts.mi.st.service.SysTestService#insertCsDgnssResultDtl(java.util.List)
     * @Method Name        : insertCsDgnssResultDtl
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param arguments
     * @return
    */
    @Override
    @ServiceId("MISTI003")
    @ServiceName("체계진단종합진단결과상세등록")
    @ReturnBind("output")
    public int insertCsDgnssResultDtl(@DatasetBind("input") List<Map> arguments) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertCsDgnssResultDtl, Input Param={}", arguments);
        }
        
        int result = 0;
        for (Map argument : arguments) {
            result += sysTestDao.insertCsDgnssResultDtl(argument);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertCsDgnssResultDtl Output ={}", result);
        }

        return result;
    }
    
    /**
     * @see htc.lts.mi.st.service.SysTestService#inqureCsDgnssResultDtl(java.util.Map)
     * @Method Name        : inqureCsDgnssResultDtl
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("MISTS006")
    @ServiceName("체계진단종합진단결과상세조회")
    @MultiReturnBind
    //public List<Map> inqureCsDgnssResultDtl(@DatasetBind("input") Map argument) {
    public Map<String, List> inqureCsDgnssResultDtl(SystemHeader header, @DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureCsDgnssResultDtl, Input Param={}", searchParam); 
        }
        
        List<Map> dtl1 = sysTestDao.inqureCsDgnssResultDtl(searchParam);
        
        List<Map> dtl2 = sysTestDao.inqureCsDgnssResultDtl2(searchParam);
        
        List<Map> dtl3 = sysTestDao.inqureItemList(searchParam);
        
        Map<String, List> result = new HashMap<>();
        
        result.put("output1", dtl1);
        result.put("output2", dtl2);
        result.put("output3", dtl3);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureCsDgnssResultDtl Output ={}", result);
        }
        
        return result;
    }
    

    /**
     * @see htc.lts.mi.st.service.SysTestService#updateCsDgnssResultDtl(java.util.Map)
     * @Method Name        : updateCsDgnssResultDtl
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("MISTU003")
    @ServiceName("체계진단종합진단결과상세수정")
    @ReturnBind("output")
    public int updateCsDgnssResultDtl(@DatasetBind("input") Map argument) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : updateCsDgnssResultDtl, Input Param={}", argument); 
        }
        
        int result = sysTestDao.updateCsDgnssResultDtl(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateCsDgnssResultDtl Output ={}", result);
        }
        
        return result;
    }




    /**
     * @see htc.lts.mi.st.service.SysTestService#inqureCsDgnssResultDtl2(java.util.Map)
     * @Method Name        : inqureCsDgnssResultDtl2
     * @Method description : 
     * @Date               : 2016. 10. 17.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 17.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    
    @Override
    public List<Map> inqureCsDgnssResultDtl2(Map argument) {
        
        List<Map> result = null;
        
        return result;
    }




    /**
     * @see htc.lts.mi.st.service.SysTestService#inqureCsDgnssResult(java.util.Map)
     * @Method Name        : inqureCsDgnssResult
     * @Method description : 
     * @Date               : 2016. 10. 18.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 18.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    
    @Override
    public List<Map> inqureCsDgnssResult(Map argument) {
        List<Map> result = null;
        
        return result;
    }




    /**
     * @see htc.lts.mi.st.service.SysTestService#updateCsDgnssResult(java.util.Map)
     * @Method Name        : updateCsDgnssResult
     * @Method description : 
     * @Date               : 2016. 10. 18.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 18.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    
    @Override
    public int updateCsDgnssResult(Map argument) {
        return 0;
    }




    /**
     * @see htc.lts.mi.st.service.SysTestService#inqureCsDgnssResult2(java.util.Map)
     * @Method Name        : inqureCsDgnssResult2
     * @Method description : 
     * @Date               : 2016. 10. 18.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 18.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    
    @Override
    public List<Map> inqureCsDgnssResult2(Map argument) {
        List<Map> result = null;
        
        return result;
    }
    
    @Override
    @ServiceId("MISTX002")
    @ReturnBind("output")
    public int saveRfNo(@DatasetBind("input") List<Map> arguments) {
       
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveRfNo, Input Param={}", arguments); 
        }
        int result = 0;
            for (Map argument : arguments) {
                //argument.put("RFNO",argument.get("RFNO").toString().substring(10,2));
                String rowType = XPlatformUtil.getDataRowType(argument);
                
                if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    argument.put("RFNO",argument.get("ENTP_CD").toString().trim() + argument.get("EQCD").toString().trim());
                    result += sysTestDao.insertSysTestDetail(argument);
                    result += sysTestDao.insertCmplRpt(argument);
                    
                } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                    result += sysTestDao.deleteSysTestDetail(argument);
                    result += sysTestDao.deleteCmplRpt(argument);
                }
            }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveRfNo Output ={}", result);
        }

        return result; 
    }
    
    
    /**
     * @see htc.lts.mi.st.service.SysTestService#mergeDgnssRslt(java.util.Map)
     * @Method Name        : mergeDgnssRslt
     * @Method description : 
     * @Date               : 2016. 12. 29.
     * @Author             : 강형순 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 12. 29.		강형순					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("MISTI004")
    @ServiceName("체계진단결과등록")
    @ReturnBind("output")
    public int mergeDgnssRslt(@DatasetBind("input") Map argument) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : mergeDgnssRslt, Input Param={}", argument);
        }
        
        if(argument.get("WRSHP_NM").toString().matches(".*LBTS.*")){
        }else{
            argument.put("WRSHP_NM", "공통");
        }
        int result = sysTestDao.mergeDgnssRslt(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : mergeDgnssRslt Output ={}", result);
        }

        return result;
    }
}