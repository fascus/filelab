/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.mm.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 3:22:14
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class MngNoDaoImpl extends AbstractHtcDao implements MngNoDao {

    
    
    @Override
    public List inqureMngNoList(Map mngNo) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.selectMngNoList", mngNo);
    }
    
	
	@Override
	public int insertMngNoMaster(Map mngNo) {
		return  update("htc.lts.mi.mm.hqml.MngNoQuery.insertMngNoMaster", mngNo);
	}
	
	@Override
    public int insertMngNoDetail(Map mngNo) {
        return  update("htc.lts.mi.mm.hqml.MngNoQuery.insertMngNoDetail", mngNo);
    }
	
	@Override
    public List searchMngNoList(Map mngNo) {
	    return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.searchMngNoList", mngNo);
    }
	
	@Override
    public List searchCtrNoList(Map mngNo) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.searchCtrNoList", mngNo);
    }
	
	@Override
    public List searchCtrNoList2(Map mngNo) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.searchCtrNoList2", mngNo);
    }
	
	@Override
    public List searchMasterList(Map mngNo) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.searchMasterList", mngNo);
    }
	
	@Override
    public List searchDetailList(Map mngNo) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.searchDetailList", mngNo);
    }
	
	@Override
    public int insertWrk(Map mngNo) {
        return  update("htc.lts.mi.mm.hqml.MngNoQuery.insertWrk", mngNo);
    }
	
    @Override
    public int insertMtnPlan(Map mngNo) {
        return  update("htc.lts.mi.mm.hqml.MngNoQuery.insertMtnPlan", mngNo);
    }
    
    @Override
    public int insertTestList(Map mngNo) {
        return  update("htc.lts.mi.mm.hqml.MngNoQuery.insertTestList", mngNo);
    }    

	//@Override
	//public int insertScreenObj(Map screenObj) {
	//	return  update("htc.lts.um.hqml.ScreenQuery.insertScreenObj", screenObj);
	//}
	
    /**
     * @see htc.lts.mi.mm.dao.MngNoDao#inqureMtnList(java.util.Map)
     * @Method Name        : inqureMtnList
     * @Method description : 
     * @Date               : 2016. 9. 28.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 9. 28.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mtn
     * @return
    */
    @Override
    public List inqureMtnList(Map mtn) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.selectMtnList", mtn);
    }
    
    /**
     * @see htc.lts.mi.mm.dao.MngNoDao#inqureCmplRptList(java.util.Map)
     * @Method Name        : inqureCmplRptList
     * @Method description : 
     * @Date               : 2016. 9. 28.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				DescriptionC
     * 2016. 9. 28.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param cmplRpt
     * @return
    */
    @Override
    public List inqureCmplRptList(Map cmplRpt) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.selectCmplRptList", cmplRpt);
    }
    
	@Override
	public int insertCmplRpt(Map cmplRpt) {
		return  update("htc.lts.mi.mm.hqml.MngNoQuery.insertCmplRpt", cmplRpt);
	}
	
	
	@Override
	public int updateCmplRpt(Map cmplRpt) {
		return  update("htc.lts.mi.mm.hqml.MngNoQuery.updateCmplRpt", cmplRpt);
	}
	
	@Override
    public List inqureShipNmList(Map mtn) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.selectShipNmList", mtn);
    }
	
	@Override
    public List inqureEqNmList(Map mtn) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.selectEqNmList", mtn);
    }
	
	@Override
    public List inqureHwEqcdList(Map mtn) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.selectHwEqcdList", mtn);
    }
	
	@Override
    public List inqureEqcdList(Map mtn) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.selectEqcdList", mtn);
    }
	
	@Override
    public List inqureBpEqcdList(Map mtn) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.selectBpEqcdList", mtn);
    }
	
	@Override
    public List inqureBpEqcdList2(Map mtn) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.selectBpEqcdList2", mtn);
    }
	
	@Override
    public List inqureHwMtnCdList(Map mtn) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.inqureHwMtnCdList", mtn);
    }

	@Override
    public List inqureAiMtnCdList(Map mtn) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.inqureAiMtnCdList", mtn);
    }

	@Override
    public List inqureAiEqCdList(Map mtn) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.inqureAiEqCdList", mtn);
    }
	
	@Override
    public List seachEqNm(Map mngNo) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.seachEqNm", mngNo);
    }
	
	@Override
    public List selectMimmIng(Map mngNo) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.selectMimmIng", mngNo);
    }
	
	@Override
    public List inqureFile(Map argument) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.inqureFile", argument);
    }
	
    @Override
    public List inqureRfnoCrtnAndDel(Map argument) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.inqureRfnoCrtnAndDel", argument);
    }	
	
    @Override
    public int deleteMngNoDetail(Map argument) {
        return  update("htc.lts.mi.mm.hqml.MngNoQuery.deleteMngNoDetail", argument);
    }
    
    @Override
    public int deleteTestList(Map argument) {
        return  update("htc.lts.mi.mm.hqml.MngNoQuery.deleteTestList", argument);
    }
    
    @Override
    public int deleteWrk(Map argument) {
        return  update("htc.lts.mi.mm.hqml.MngNoQuery.deleteWrk", argument);
    }
    
    @Override
    public List inqureRsptAmt(Map argument) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.inqureRsptAmt", argument);
    }
    
    @Override
    public List inqureLbAmt(Map argument) {
        return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.inqureLbAmt", argument);
    }


	/**
	 * @see htc.lts.mi.mm.dao.MngNoDao#selectUgcyMtnRqstno(java.util.Map)
	 * @Method Name        : selectUgcyMtnRqstno
	 * @Method description : 
	 * @Date               : 2016. 12. 2.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 12. 2.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param mngNo
	 * @return
	*/
	
	@Override
	public List selectUgcyMtnRqstno(Map mngNo) {
		return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.selectUgcyMtnRqstno", mngNo);
	}


	/**
	 * @see htc.lts.mi.mm.dao.MngNoDao#insertUgcyMtn(java.util.Map)
	 * @Method Name        : insertUgcyMtn
	 * @Method description : 
	 * @Date               : 2016. 12. 2.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 12. 2.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param mngNo
	 * @return
	*/
	
	@Override
	public int insertUgcyMtn(Map mngNo) {
		return  update("htc.lts.mi.mm.hqml.MngNoQuery.insertUgcyMtn", mngNo);
	}

   @Override
    public int updateMngNoDetail(Map mngNo) {
        return  update("htc.lts.mi.mm.hqml.MngNoQuery.updateMngNoDetail", mngNo);
    }

   @Override
   public List inqureRsptAmt2(Map mngNo) {
       return queryForList("htc.lts.mi.mm.hqml.MngNoQuery.inqureRsptAmt2", mngNo);
   }

   @Override
    public int updateOfcdocNoMngNoDetail(Map mngNo) {
        return  update("htc.lts.mi.mm.hqml.MngNoQuery.updateOfcdocNoMngNoDetail", mngNo);
    }

   @Override
    public int updateOfcdocNoUgcyMtn(Map mngNo) {
        return  update("htc.lts.mi.mm.hqml.MngNoQuery.updateOfcdocNoUgcyMtn", mngNo);
    }
   
   @Override
   public int deleteMtnPlan(Map mngNo) {
       return  update("htc.lts.mi.mm.hqml.MngNoQuery.deleteMtnPlan", mngNo);
   }
   
   
}