/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.ot.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.mi.ot.dao.OprdnsTchasstDao;
import htc.lts.mi.ot.dao.OprdnsTchasstPlanDao;
import htc.xplatform.annotation.DatasetBind;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 24. 오후 1:45:29
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 24.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class OprdnsTchasstServiceImpl implements OprdnsTchasstService {

	private static final Logger logger = LoggerFactory.getLogger(OprdnsTchasstServiceImpl.class);
	
	@Autowired
	OprdnsTchasstDao oprdnsTchasstDao;

	/**
	 * @see htc.lts.mi.ot.service.OprdnsTchasstService#inqureTchasst(java.util.Map)
	 * @Method Name        : inqureTchasst
	 * @Method description : 
	 * @Date               : 2016. 10. 24.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 24.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
    @ServiceId("MIOTS201")
    @ServiceName("전비태세 결과보고 조회")
    @ReturnBind("output")
	public List<Map> inqureTchasst(@DatasetBind("input")Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureTchasst, Input Param={}", searchParam); 
        }
        
        List<Map> tchasstList = oprdnsTchasstDao.inqureTchasstList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureTchasst Output ={}", tchasstList);
        }
        
        return tchasstList;
	}

	/**
	 * @see htc.lts.mi.ot.service.OprdnsTchasstService#saveTchasst(java.util.List)
	 * @Method Name        : saveTchasst
	 * @Method description : 
	 * @Date               : 2016. 10. 24.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 24.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param tchasstList
	 * @return
	*/
	
	@Override
    @ServiceId("MIOTX201")
    @ServiceName("전비태세 결과보고 저장")
    @ReturnBind("output")
	public int saveTchasst(@DatasetBind("input")List<Map> tchasstList) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveTchasst, Input Param={}", tchasstList); 
        }
        
        int result = 0;
//        int result2 = 0;
        Map param = new HashMap();
        
       // List<Map> cmplRptList2 = mngNoDao.inqureCmplRptList(param);
        
        
        for (Map tchasst : tchasstList) {
            
            param.put("MGT_NO", tchasst.get("MGT_NO"));
            param.put("RFNO", tchasst.get("RFNO"));
            
            List<Map> tchasstList2 = oprdnsTchasstDao.inqureTchasstList(param);
            
            for(int i = 0; i < tchasstList2.size(); i++){
                if(tchasstList2.get(i).get("MGT_NO2") == null && tchasstList2.get(i).get("RFNO2") == null){
                    result += oprdnsTchasstDao.insertTchasst(tchasst);
                    if(logger.isDebugEnabled()){
                        logger.debug("입력");
                    }
                    
                }else{
                    result += oprdnsTchasstDao.updateTchasst(tchasst);
                    if(logger.isDebugEnabled()){
                        logger.debug("수정");
                    }
                }
            }       
        }
     

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveTchasst Output ={}", result);
        }

        return result;
	}
}
