/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 26. 오후 5:20:33
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 26.		변용수            				CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class WrshpDaoImpl extends AbstractHtcDao implements WrshpDao {

    /**
     * @see htc.lts.bi.pd.dao.WrshpDao#inqureUserList(java.util.Map)
     * @Method Name        : inqureWrshpList
     * @Method description : 
     * @Date               : 2016. 9. 26.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 9. 26.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param user
     * @return
    */

    @Override
    public List inqureWrshpList(Map wrshp) {
        return queryForList("htc.lts.bi.pd.hqml.WrshpQuery.selectWrshpList", wrshp);
    }
    
    /**
     * @see htc.lts.bi.pd.dao.WrshpDao#insertWrshp(java.util.Map)
     * @Method Name        : insertWrshp
     * @Method description : 
     * @Date               : 2016. 9. 27.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 9. 27.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     *
    */

	@Override
	public int insertWrshp(Map wrshp) {
	    return update("htc.lts.bi.pd.hqml.WrshpQuery.insertWrshp", wrshp);
	}
	
    @Override
    public int deleteWrshp(Map wrshp) {
        return update("htc.lts.bi.pd.hqml.WrshpQuery.deleteWrshp", wrshp);
    }
	
	/**
	 * @see htc.lts.bi.pd.dao.WrshpDao#inqureEqNmModelList(java.util.Map)
	 * @Method Name        : inqureEqNmModelList
	 * @Method description : 
	 * @Date               : 2016. 10. 4.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 4.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
	public List inqureEqNmModelList(Map searchParam) {
		return queryForList("htc.lts.bi.pd.hqml.WrshpQuery.selectEqNmModelList", searchParam);
	}

	@Override
    public int insertWrshpEq(Map wrshp) {
	    return update("htc.lts.bi.pd.hqml.WrshpQuery.insertWrshpEq", wrshp);
    }
	
    @Override
    public int deleteWrshpEq(Map wrshp) {
        return update("htc.lts.bi.pd.hqml.WrshpQuery.deleteWrshpEq", wrshp);
    }
    
    @Override
    public List inqureEqList(Map eq) {
        return queryForList("htc.lts.bi.pd.hqml.WrshpQuery.selectEqList", eq);
    }
    
    @Override
    public List inqureEqModelList(Map eq) {
        return queryForList("htc.lts.bi.pd.hqml.WrshpQuery.selectEqModelList", eq);
    }

}
