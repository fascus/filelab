/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.hone.utils.MapUtil;
import htc.lts.bi.pd.dao.MtnEntpDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 29. 오후 9:25:17
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 29.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class MtnEntpServiceImpl implements MtnEntpService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MtnEntpService.class);

    @Autowired
    private MtnEntpDao mtnEntpDao;


    @Override
    @ServiceId("BIPDS004")
    @ServiceName("협력업체조회")
    @ReturnBind("output")
    public List<Map> inqureMtnEntp(SystemHeader header, @DatasetBind("input") Map argument) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureMtnEntp, Input Param={}", argument);
        }

        List<Map> result = mtnEntpDao.inqureMtnEntp(argument);
        
        MapUtil mapUtil = new MapUtil();
        mapUtil.decryptMapList(result,false,true,"TELNO","FAXNO", "BORNO");

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureMtnEntp Output ={}", result);
        }

        return result;
    }
    
    @Override
    @ServiceId("BIPDS005")
    @ServiceName("협력업체담장자조회")
    @ReturnBind("output")
    public List<Map> inqureMtnEntpPsnchrg(SystemHeader header, @DatasetBind("input") Map argument) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureMtnEntpPsnchrg, Input Param={}", argument);
        }
        
        List<Map> result = mtnEntpDao.inqureMtnEntpPsnchrg(argument);
        
        MapUtil mapUtil = new MapUtil();
        mapUtil.decryptMapList(result,false,false,"TELNO","FAXNO","HP_NO","EMAIL");

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureMtnEntpPsnchrg Output ={}", result);
        }

        return result;
    }
    
    @Override
    @ServiceId("BIPDS006")
    @ServiceName("관리함형장비조회")
    @ReturnBind("output")
    public List<Map> inqureMtnEntpEqcd(SystemHeader header, @DatasetBind("input") Map argument) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureMtnEntpEqcd, Input Param={}", argument);
        }

        List<Map> result = mtnEntpDao.inqureMtnEntpEqcd(argument);
        
       if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureMtnEntpEqcd Output ={}", result);
        }

        return result;
    }
    
    @Override
    @ServiceId("BIPDS007")
    @ServiceName("업체부호리스트")
    @ReturnBind("output")
    public List<Map> inqureMtnEntpCdList(SystemHeader header, @DatasetBind("input") Map argument) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureMtnEntpCdList, Input Param={}", argument);
        }

        List<Map> result = mtnEntpDao.inqureMtnEntpCdList(argument);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqureMtnEntpCdList Output ={}", result);
        }

        return result;
    }
    
    
    @Override
    @ServiceId("BIPDI003")
    @ServiceName("협력업체 등록")
    @ReturnBind("output")
    public int insertMtnEntp(@DatasetBind("input") Map argument) {
        
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : insertMtnEntp, Input Param={}", argument); 
        }
        
        MapUtil mapUtil = new MapUtil();
        mapUtil.encryptMap(argument,false,false,"TELNO","FAXNO", "BORNO");

        int result = mtnEntpDao.insertMtnEntp(argument);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : insertMtnEntp Output ={}", result);
        }
        return result; 
    }
    
    @Override
    @ServiceId("BIPDI004")
    @ServiceName("협력업체 담당자 및 관리함형장비 등록")
    @MultiReturnBind
    public int insertMtnEntpPsnchrgnEqcd(@DatasetBind("input1")  List<Map> arguments1, @DatasetBind("input2") List<Map> arguments2) {
        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("Service Method : insertMtnEntpPsnchrgnEqcd1, Input Param={}", arguments1);
            LOGGER.debug("Service Method : insertMtnEntpPsnchrgnEqcd2, Input Param={}", arguments2); 
        }
        int result = 0;
        int result2 = 0;
        
        MapUtil mapUtil = new MapUtil();
        mapUtil.encryptMapList(arguments1,false,true,"TELNO","FAXNO", "HP_NO", "EMAIL");

        for (Map argument1 : arguments1) {
                result = mtnEntpDao.insertMtnEntpPsnchrg(argument1);
        }
        for (Map argument2 : arguments2) {
                result2 = mtnEntpDao.insertMtnEntpEqcd(argument2);
        }
        
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : insertOfcdoc Output ={}", result);
            LOGGER.debug("Service Method : insertOfcdoc2 Output ={}", result2);
        }
        
        return result;
    }

    @Override
    @ServiceId({"BIPDX001"})
    @ServiceName("협력업체 담당자 및 관리함형장비 수정삭제")
    @ReturnBind("output")
    public int mergeMtnEntpMainEqcd (@DatasetBind("input1") List<Map> arguments1,@DatasetBind("input2") List<Map> arguments2) {

        if(LOGGER.isDebugEnabled()){ 
              LOGGER.debug("Service Method : mergeMtnEntpMainEqcd_arg1, Input Param={}", arguments1); 
        }
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : mergeMtnEntpMainEqcd_arg2, Input Param={}", arguments2); 
        }
        
        int result = 0;
        MapUtil mapUtil = new MapUtil();
        mapUtil.encryptMapList(arguments1,false,true,"TELNO","FAXNO", "HP_NO", "EMAIL");
        
        for (Map argument1 : arguments1) {
            String rowType = XPlatformUtil.getDataRowType(argument1);
            if(LOGGER.isDebugEnabled()){ 
                LOGGER.debug(rowType);
            }
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += mtnEntpDao.insertMtnEntpPsnchrg(argument1);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += mtnEntpDao.updatePsnchrg(argument1);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += mtnEntpDao.deletePsnchrg(argument1);
                result += mtnEntpDao.deleteEqcd(argument1);
            }
        }
        
        for (Map argument2 : arguments2) {
            String rowType = XPlatformUtil.getDataRowType(argument2);
            if(LOGGER.isDebugEnabled()){ 
                LOGGER.debug(rowType);
            }
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += mtnEntpDao.insertMtnEntpEqcd(argument2);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += mtnEntpDao.updateEqcd(argument2);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += mtnEntpDao.deleteEqcd(argument2);
            }
        }
        
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : mergeMtnEntpMainEqcd Output ={}", result);
        }
          return result; 
    }
    
    @Override
    @ServiceId({"BIPDX002"})
    @ServiceName("협력업체 담당자 수정삭제")
    @ReturnBind("output")
    public int mergeMtnEntpMainPsnchrg(@DatasetBind("input") List<Map> arguments) {
        if(LOGGER.isDebugEnabled()){ 
              LOGGER.debug("Service Method : mergeMtnEntpMainPsnchrg, Input Param={}", arguments); 
          }
        
          int result = 0;
          
          MapUtil mapUtil = new MapUtil();
          mapUtil.encryptMapList(arguments,false,true,"TELNO","FAXNO", "HP_NO", "EMAIL");
          
          for (Map argument : arguments) {
            String rowType = XPlatformUtil.getDataRowType(argument);
            if(LOGGER.isDebugEnabled()){ 
                LOGGER.debug(rowType);
            }
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    result += mtnEntpDao.insertMtnEntpPsnchrg(argument);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += mtnEntpDao.updatePsnchrg(argument);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += mtnEntpDao.deletePsnchrg(argument);
                result += mtnEntpDao.deleteEqcd(argument);
            }
          }
                 

          if (LOGGER.isDebugEnabled()) {
              LOGGER.debug("Service Method : mergeMtnEntpMainPsnchrg Output ={}", result);
          }

          return result; 
    }
    
    @Override
    @ServiceId("BIPDU001")
    @ServiceName("협력업체수정")
    @ReturnBind("output")
    public int updateMtnEntpMain(@DatasetBind("input") Map argument) {
        
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : updateMtnEntpMain, Input Param={}", argument); 
        }
        
        MapUtil mapUtil = new MapUtil();
        mapUtil.encryptMap(argument,false,true,"TELNO","FAXNO", "BORNO");

        int result = mtnEntpDao.updateMtnEntpMain(argument);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : updateMtnEntpMain Output ={}", result);
        }
        return result; 
    }    
    
    @Override
    @ServiceId("BIPDD001")
    @ServiceName("협력업체삭제")
    @ReturnBind("output")
    public int deleteMtnEntpMain(@DatasetBind("input") Map argument) {
        
        if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : deleteMtnEntpMain, Input Param={}", argument); 
        }
        int result = mtnEntpDao.deleteMtnEntpMain(argument);
            //result += mtnEntpDao.deletePsnchrg(argument);
            //result += mtnEntpDao.deleteEqcd(argument);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : deleteMtnEntpMain Output ={}", result);
        }
        return result; 
    }    
    
}
