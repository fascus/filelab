/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.mm.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.mi.mm.dao.PrtsplMtrlsDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:59:12
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class PrtsplMtrlsServiceImpl implements PrtsplMtrlsService {

    private static final Logger logger = LoggerFactory.getLogger(PrtsplMtrlsServiceImpl.class);

    @Autowired
    PrtsplMtrlsDao prtsplMtrlsDao;

   
    @Override
    @ServiceId("MIMMS100")
    @ServiceName("부품조회")
    @ReturnBind("output")
    public List<Map> inqurePrtsplMtrls(@DatasetBind("input") Map searchParam) {
    	
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqurePrtsplMtrls, Input Param={}", searchParam); 
        }
        
        List<Map> prtsplMtrlsList = prtsplMtrlsDao.inqurePrtsplMtrlsList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqurePrtsplMtrls Output ={}", prtsplMtrlsList);
        }
        
        return prtsplMtrlsList;
    }
    
    @Override
    @ServiceId("MIMMS009")
    @ServiceName("부품조회")
    @ReturnBind("output")
    public List<Map> inqurePrtsplMtrlsPop(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqurePrtsplMtrlsPop, Input Param={}", searchParam); 
        }
        
        List<Map> prtsplMtrlsPopList = prtsplMtrlsDao.inqurePrtsplMtrlsPopList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqurePrtsplMtrlsPop Output ={}", prtsplMtrlsPopList);
        }
        
        return prtsplMtrlsPopList;
    }
    
    @Override
    @ServiceId("MIMMX008")
    @ServiceName("주요수리내역저장")
    @ReturnBind("output")
    public int savePrtsplMtrls(@DatasetBind("input") List<Map> prtsplMtrlsList) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : saveUsePn, Input Param={}", prtsplMtrlsList); 
          }
        

        int result = 0;
        
//        String MGT_NO = null;
//        String RFNO = null;
//        String PN = null;
//        String con = null;
        
//          Map param = new HashMap();
          
          for (Map prtsplMtrls : prtsplMtrlsList) {
              
                  String rowType = XPlatformUtil.getDataRowType(prtsplMtrls);
                  
                  if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                      result +=prtsplMtrlsDao.insertPrtsplMtrls(prtsplMtrls);
                  } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                      result +=prtsplMtrlsDao.updatePrtsplMtrls(prtsplMtrls);
                  } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                      result +=prtsplMtrlsDao.updatePrtsplMtrls(prtsplMtrls);
                  }
              
//              param.put("MGT_NO", prtsplMtrls.get("MGT_NO"));
//              param.put("RFNO", prtsplMtrls.get("RFNO"));
//              param.put("PN", prtsplMtrls.get("PN"));
//             
//              List<Map> prtsplMtrlsList2 = prtsplMtrlsDao.inqurePrtsplMtrlsList(param);
//              if(prtsplMtrlsList2.size()==0){
//                  result +=prtsplMtrlsDao.insertPrtsplMtrls(prtsplMtrls);
//              }else{
//                  for(int i=0; i<prtsplMtrlsList2.size(); i++){
//                      MGT_NO = (String) prtsplMtrlsList2.get(i).get("MGT_NO");
//                      RFNO = (String) prtsplMtrlsList2.get(i).get("RFNO");
//                      PN = (String) prtsplMtrlsList2.get(i).get("PN");
//                      if(MGT_NO.equals(prtsplMtrls.get("MGT_NO")) && RFNO.equals(prtsplMtrls.get("RFNO")) && PN.equals(prtsplMtrls.get("PN"))){
//                          con = "modify";
//                          break;
//                      }else if(MGT_NO.equals(prtsplMtrls.get("MGT_NO")) && RFNO.equals(prtsplMtrls.get("RFNO")) && !PN.equals(prtsplMtrls.get("PN"))){
//                          con = "new";
//                      }
//                      
//                  }   
//              }
//              if(con=="modify"){
//                  result +=prtsplMtrlsDao.updatePrtsplMtrls(prtsplMtrls);
//              }else if(con=="new"){
//                  result +=prtsplMtrlsDao.insertPrtsplMtrls(prtsplMtrls);
//              }
          }

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : saveUsePn Output ={}", result);
          }

          return result; 
    }
    
    /**
     * 결재시 사급자재 부품별 결재상태 저장.
     * 2016.12.02 이원순 
     */
    @Override
    @ServiceId("MIMMX009")
    @ServiceName("부품별결재상태저장")
    @ReturnBind("output")
    public int updatePrtsplMtrls(@DatasetBind("input") List<Map> prtsplMtrlsList) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : updatePrtsplMtrls, Input Param={}", prtsplMtrlsList); 
        }
        
        int result = 0;
        
        for (Map prtsplMtrls : prtsplMtrlsList) {
            result = prtsplMtrlsDao.updatePrtsplMtrls(prtsplMtrls);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updatePrtsplMtrls Output ={}", result);
        }

        return result; 
    }

    @Override
    @ServiceId("MIMMX011")
    @ServiceName("부품별결재상태 초기화")
    @ReturnBind("output")
    public int initPrtsplMtrls(@DatasetBind("input") List<Map> prtsplMtrlsList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : initPrtsplMtrls, Input Param={}", prtsplMtrlsList); 
        }
        
        int result = 0;
        
        for (Map prtsplMtrls : prtsplMtrlsList) {
            result = prtsplMtrlsDao.initPrtsplMtrls(prtsplMtrls);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : initPrtsplMtrls Output ={}", result);
        }
        
        return result; 
    }
}