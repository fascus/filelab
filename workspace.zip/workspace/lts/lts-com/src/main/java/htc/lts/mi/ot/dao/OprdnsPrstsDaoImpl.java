/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.ot.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 18. 오전 9:59:26
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 18.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository 
public class OprdnsPrstsDaoImpl extends AbstractHtcDao implements OprdnsPrstsDao {

	/**
	 * @see htc.lts.mi.ot.dao.OprdnsPrstsDao#inqureShipNmList(java.util.Map)
	 * @Method Name        : inqureShipNmList
	 * @Method description : 
	 * @Date               : 2016. 10. 18.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 18.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param mngNo
	 * @return
	*/
	
	@Override
	public List inqureShipNmList(Map mngNo) {
		return queryForList("htc.lts.mi.ot.hqml.OprdnsPrstsQuery.selectShipNmList", mngNo);
	}
	
	@Override
	public List inqureMtnCdList(Map mngNo) {
		return queryForList("htc.lts.mi.ot.hqml.OprdnsPrstsQuery.selectMtnCdList", mngNo);
	}

	/**
	 * @see htc.lts.mi.ot.dao.OprdnsPrstsDao#inqureEqNmList(java.util.Map)
	 * @Method Name        : inqureEqNmList
	 * @Method description : 
	 * @Date               : 2016. 10. 18.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 18.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param mngNo
	 * @return
	*/
	
	@Override
	public List inqureEqNmList(Map mngNo) {
		return queryForList("htc.lts.mi.ot.hqml.OprdnsPrstsQuery.selectEqNmList2", mngNo);
	}

	/**
	 * @see htc.lts.mi.ot.dao.OprdnsPrstsDao#seachEqNm(java.util.Map)
	 * @Method Name        : seachEqNm
	 * @Method description : 
	 * @Date               : 2016. 10. 18.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 18.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param mtn
	 * @return
	*/
	
	@Override
	public List seachEqNm(Map mngNo) {
		return queryForList("htc.lts.mi.ot.hqml.OprdnsPrstsQuery.searchEqNm", mngNo);
	}

	/**
	 * @see htc.lts.mi.ot.dao.OprdnsPrstsDao#inqureOprdnsList(java.util.Map)
	 * @Method Name        : inqureOprdnsList
	 * @Method description : 
	 * @Date               : 2016. 10. 19.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 19.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
	public List inqureOprdnsList(Map searchParam) {
		return queryForList("htc.lts.mi.ot.hqml.OprdnsPrstsQuery.selectOprdnsList", searchParam);
	}

	
	@Override
    public int insertWrk(Map mngNo) {
        return  update("htc.lts.mi.ot.hqml.OprdnsPrstsQuery.insertWrkList", mngNo);
    }

	/**
	 * @see htc.lts.mi.ot.dao.OprdnsPrstsDao#selectMiotIng(java.util.Map)
	 * @Method Name        : selectMiotIng
	 * @Method description : 
	 * @Date               : 2016. 10. 25.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 25.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param mtn
	 * @return
	*/
	
	@Override
	public List selectMiotIng(Map mtn) {
		return queryForList("htc.lts.mi.ot.hqml.OprdnsPrstsQuery.selectMiotIng", mtn);
	}
	
	
    @Override
    public List inqureRfnoCrtnAndDel(Map mtn) {
        return queryForList("htc.lts.mi.ot.hqml.OprdnsPrstsQuery.inqureRfnoCrtnAndDel", mtn);
    }

    @Override
    public int deleteWrk(Map mngNo) {
        return  update("htc.lts.mi.ot.hqml.OprdnsPrstsQuery.deleteWrkList", mngNo);
    }

}
