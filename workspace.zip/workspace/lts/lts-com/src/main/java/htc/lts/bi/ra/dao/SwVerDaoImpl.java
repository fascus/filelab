/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.ra.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 11. 17. 오전 8:33:46
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 11. 17.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class SwVerDaoImpl extends AbstractHtcDao implements SwVerDao {

    @Override
    public int insertSwVer(Map argument) {
        return  update("htc.lts.bi.ra.hqml.SwVerQuery.insertSwVer", argument);
    }
    
    @Override
    public int updateSwVer(Map argument) {
        return  update("htc.lts.bi.ra.hqml.SwVerQuery.updateSwVer", argument);
    }
   
    @Override
    public int deleteSwVer(Map argument) {
        return  update("htc.lts.bi.ra.hqml.SwVerQuery.deleteSwVer", argument);
    }
    
    @Override
    public List inqureSwVer(Map argument) {
	    return queryForList("htc.lts.bi.ra.hqml.SwVerQuery.inqureSwVer", argument);
    }
    
    @Override
    public List inqureMaxEqVer(Map argument) {
    	return queryForList("htc.lts.bi.ra.hqml.SwVerQuery.inqureMaxEqVer", argument);
    }

   @Override
    public List inqureLastSwVer(Map argument) {
        return queryForList("htc.lts.bi.ra.hqml.SwVerQuery.inqureLastSwVer", argument);
    }
   
   @Override
   public int deleteSwVer2(Map argument) {
       return  update("htc.lts.bi.ra.hqml.SwVerQuery.deleteSwVer2", argument);
   }
   
}
