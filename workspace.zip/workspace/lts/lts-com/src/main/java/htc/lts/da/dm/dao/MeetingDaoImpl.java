package htc.lts.da.dm.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 14. 오후 1:20:38
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 14.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class MeetingDaoImpl extends AbstractHtcDao implements MeetingDao{

    /**
     * @see htc.lts.da.dm.dao.MeetingDao#inqureMeetingList(java.util.Map)
     * @Method Name        : inqureMeetingList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param data
     * @return
    */
    @Override
    public List inqureMeetingList(Map data) {
        return queryForList("htc.lts.da.dm.hqml.MeetingQuery.selectMeetingList", data);
    }

    /**
     * @see htc.lts.da.dm.dao.MeetingDao#insertMeetingList(java.util.Map)
     * @Method Name        : insertMeetingList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param MeetingList
     * @return
    */
    @Override
    public int insertMeetingList(Map MeetingList) {
        return  update("htc.lts.da.dm.hqml.MeetingQuery.insertMeetingList", MeetingList);
    }
    
    /**
     * @see htc.lts.da.dm.dao.MeetingDao#updateMeetingList(java.util.Map)
     * @Method Name        : updateMeetingList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param MeetingList
     * @return
    */
    @Override
    public int updateMeetingList(Map MeetingList) {
        return  update("htc.lts.da.dm.hqml.MeetingQuery.updateMeetingList", MeetingList);
    }
    
    /**
     * @see htc.lts.da.dm.dao.MeetingDao#deleteMeetingList(java.util.Map)
     * @Method Name        : deleteMeetingList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param MeetingList
     * @return
    */
    @Override
    public int deleteMeetingList(Map MeetingList) {
        return  update("htc.lts.da.dm.hqml.MeetingQuery.deleteMeetingList", MeetingList);
    }
    
    /**
     * @see htc.lts.da.dm.dao.MeetingDao#inqureFile(java.util.Map)
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    public List inqureFile(Map argument) {
        return queryForList("htc.lts.da.dm.hqml.MeetingQuery.inqureFile", argument);
    }
}
