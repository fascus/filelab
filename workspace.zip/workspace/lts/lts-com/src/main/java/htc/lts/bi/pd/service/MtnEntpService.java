/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.service;

import java.util.List;
import java.util.Map;

import htc.hone.core.message.SystemHeader;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 22. 오전 8:25:28
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 22.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface MtnEntpService {
    

    public List<Map> inqureMtnEntp(SystemHeader header, Map argument);

    public List<Map> inqureMtnEntpPsnchrg(SystemHeader header, Map argument);

    public List<Map> inqureMtnEntpEqcd(SystemHeader header, Map argument);

    public List<Map> inqureMtnEntpCdList(SystemHeader header, Map argument);

    public int insertMtnEntp(Map argument);

    public int insertMtnEntpPsnchrgnEqcd(List<Map> argument, List<Map> arguments);

    //public int mergeMtnEntpMainEqcd(List<Map> arguments);

    public int mergeMtnEntpMainPsnchrg(List<Map> arguments);

    public int updateMtnEntpMain(Map argument);

    public int deleteMtnEntpMain(Map argument);

    public int mergeMtnEntpMainEqcd(List<Map> arguments1, List<Map> arguments2);

    //public int isertPo(List<Map> arguments);
}
