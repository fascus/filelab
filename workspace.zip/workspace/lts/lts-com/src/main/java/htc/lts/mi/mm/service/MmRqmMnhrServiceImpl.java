/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.mm.service;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.lts.bi.po.dao.PoDao;
import htc.lts.mi.mm.dao.MmRqmMnhrDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:59:12
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class MmRqmMnhrServiceImpl implements MmRqmMnhrService {

    private static final Logger logger = LoggerFactory.getLogger(MmRqmMnhrServiceImpl.class);

    @Autowired
    MmRqmMnhrDao mmRqmMnhrDao;
    @Autowired
    private PoDao poDao;
 
	@Override
	@ServiceId("MIMMX200")
	@ServiceName("사용부품저장")
	@ReturnBind("output")
	public int createRqmMnhr(@DatasetBind("input") Map rqmMnhr) {
	if(logger.isDebugEnabled()){ 
	      logger.debug("Service Method : createRqmMnhr, Input Param={}", rqmMnhr); 
	  }
	
	  //int result = 0;
	  
	  Map param = new HashMap();
	  
	  
	  String MGT_NO = rqmMnhr.get("MGT_NO").toString();
	  String RFNO = rqmMnhr.get("RFNO").toString();
	  
	  String WBS_EVMS =  MGT_NO+RFNO;
	  
	  param.put("WBS_EVMS", WBS_EVMS);
	  
	  mmRqmMnhrDao.deleteRqmMnhr(rqmMnhr);
	  
	  int result =  mmRqmMnhrDao.createRqmMnhr(param);
	  
	  List<Map> poList = poDao.inqurePo(rqmMnhr);
	  
	  if(poList.size()>0){
		  param.clear();
		  param.put("MGT_NO", MGT_NO);
		  param.put("RFNO", RFNO);
		  
		  for(int i=0; i<poList.size(); i++){
			  param.put("SALES_ORDER", poList.get(i).get("PRJCD").toString());
			  param.put("SALES_SERNO", poList.get(i).get("WBSCD").toString());
			  param.put("PROD_ORDER", poList.get(i).get("PRJ_ORJ").toString());

			  mmRqmMnhrDao.createRqmMnhr2(param);
		  }
	  }
	  		
		if (logger.isDebugEnabled()) {
	      logger.debug("Service Method : createRqmMnhr Output ={}", rqmMnhr);
	      }
	      
	      return result; 
    }
	
	@Override
	@ServiceId("MIMMX300")
	@ServiceName("사용부품저장")
	@ReturnBind("output")
	public int saveRqmMnhr(@DatasetBind("input") List<Map> rqmMnhrList) {
	if(logger.isDebugEnabled()){ 
	      logger.debug("Service Method : createRqmMnhr, Input Param={}", rqmMnhrList); 
	  }
	
	  int result = 0;
	  
	  //List<Map> rqmMnhrList2 = null;
	  
	  for (Map rqmMnhr : rqmMnhrList) {
		  
		  String rowType = XPlatformUtil.getDataRowType(rqmMnhr);
		  
		  if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
			  
			  mmRqmMnhrDao.deleteRqmMnhr2(rqmMnhr);
			  
		  }else{
		  
		  //Map param = new HashMap();
		  //Map param2 = new HashMap();
		  
		  
		  if(rqmMnhr.get("A020")!=null){

			  rqmMnhr.put("RQM_MNHR_DVCD", "A020");
			  rqmMnhr.put("WRKTM",rqmMnhr.get("A020").toString());
		  
			  List<Map> rqmMnhrList21 = mmRqmMnhrDao.inqueryRqmMnhr(rqmMnhr);
		  
			  if(rqmMnhrList21.size()==0){
				  result += mmRqmMnhrDao.insertRqmMnhr(rqmMnhr);
			  }else{
				  result += mmRqmMnhrDao.updateRqmMnhr(rqmMnhr);
			  }
		  }
		  
		  if(rqmMnhr.get("W020")!=null){

			  rqmMnhr.put("RQM_MNHR_DVCD", "W020");
			  rqmMnhr.put("WRKTM",rqmMnhr.get("W020").toString());
		  
			  List<Map> rqmMnhrList22 = mmRqmMnhrDao.inqueryRqmMnhr(rqmMnhr);
		  
			  if(rqmMnhrList22.size()==0){
				  result += mmRqmMnhrDao.insertRqmMnhr(rqmMnhr);
			  }else{
				  result += mmRqmMnhrDao.updateRqmMnhr(rqmMnhr);
			  }
		  }
		  
		  if(rqmMnhr.get("W060")!=null){

			  rqmMnhr.put("RQM_MNHR_DVCD", "W060");
			  rqmMnhr.put("WRKTM",rqmMnhr.get("W060").toString());
		  
			  List<Map> rqmMnhrList23 = mmRqmMnhrDao.inqueryRqmMnhr(rqmMnhr);
		  
			  if(rqmMnhrList23.size()==0){
				  result += mmRqmMnhrDao.insertRqmMnhr(rqmMnhr);
			  }else{
				  result += mmRqmMnhrDao.updateRqmMnhr(rqmMnhr);
			  }
		  }
		  
		  if(rqmMnhr.get("W070")!=null){

			  rqmMnhr.put("RQM_MNHR_DVCD", "W070");
			  rqmMnhr.put("WRKTM",rqmMnhr.get("W070").toString());
		  
			  List<Map> rqmMnhrList24 = mmRqmMnhrDao.inqueryRqmMnhr(rqmMnhr);
		  
			  if(rqmMnhrList24.size()==0){
				  result += mmRqmMnhrDao.insertRqmMnhr(rqmMnhr);
			  }else{
				  result += mmRqmMnhrDao.updateRqmMnhr(rqmMnhr);
			  }
		  }
		  
		  if(rqmMnhr.get("W080")!=null){

			  rqmMnhr.put("RQM_MNHR_DVCD", "W080");
			  rqmMnhr.put("WRKTM",rqmMnhr.get("W080").toString());
		  
			  List<Map> rqmMnhrList25 = mmRqmMnhrDao.inqueryRqmMnhr(rqmMnhr);
		  
			  if(rqmMnhrList25.size()==0){
				  result += mmRqmMnhrDao.insertRqmMnhr(rqmMnhr);
			  }else{
				  result += mmRqmMnhrDao.updateRqmMnhr(rqmMnhr);
			  }
		  }
		  
		  if(rqmMnhr.get("W050")!=null){

			  rqmMnhr.put("RQM_MNHR_DVCD", "W050");
			  rqmMnhr.put("WRKTM",rqmMnhr.get("W050").toString());
		  
			  List<Map> rqmMnhrList26 = mmRqmMnhrDao.inqueryRqmMnhr(rqmMnhr);
		  
			  if(rqmMnhrList26.size()==0){
				  result += mmRqmMnhrDao.insertRqmMnhr(rqmMnhr);
			  }else{
				  result += mmRqmMnhrDao.updateRqmMnhr(rqmMnhr);
			  }
		  }
		  
		  if(rqmMnhr.get("A120B")!=null){

			  rqmMnhr.put("RQM_MNHR_DVCD", "A120B");
			  rqmMnhr.put("WRKTM",rqmMnhr.get("A120B").toString());
		  
			  List<Map> rqmMnhrList27 = mmRqmMnhrDao.inqueryRqmMnhr(rqmMnhr);
		  
			  if(rqmMnhrList27.size()==0){
				  result += mmRqmMnhrDao.insertRqmMnhr(rqmMnhr);
			  }else{
				  result += mmRqmMnhrDao.updateRqmMnhr(rqmMnhr);
			  }
		  }
		  
		  if(rqmMnhr.get("A510")!=null){

			  rqmMnhr.put("RQM_MNHR_DVCD", "A510");
			  rqmMnhr.put("WRKTM",rqmMnhr.get("A510").toString());
		  
			  List<Map> rqmMnhrList28 = mmRqmMnhrDao.inqueryRqmMnhr(rqmMnhr);
		  
			  if(rqmMnhrList28.size()==0){
				  result += mmRqmMnhrDao.insertRqmMnhr(rqmMnhr);
			  }else{
				  result += mmRqmMnhrDao.updateRqmMnhr(rqmMnhr);
			  }
		  }
		  
		  if(rqmMnhr.get("A610")!=null){

			  rqmMnhr.put("RQM_MNHR_DVCD", "A610");
			  rqmMnhr.put("WRKTM",rqmMnhr.get("A610").toString());
		  
			  List<Map> rqmMnhrList29 = mmRqmMnhrDao.inqueryRqmMnhr(rqmMnhr);
		  
			  if(rqmMnhrList29.size()==0){
				  result += mmRqmMnhrDao.insertRqmMnhr(rqmMnhr);
			  }else{
				  result += mmRqmMnhrDao.updateRqmMnhr(rqmMnhr);
			  }
		  }
		  
		  if(rqmMnhr.get("A620B")!=null){

			  rqmMnhr.put("RQM_MNHR_DVCD", "A620B");
			  rqmMnhr.put("WRKTM",rqmMnhr.get("A620B").toString());
		  
			  List<Map> rqmMnhrList30 = mmRqmMnhrDao.inqueryRqmMnhr(rqmMnhr);
		  
			  if(rqmMnhrList30.size()==0){
				  result += mmRqmMnhrDao.insertRqmMnhr(rqmMnhr);
			  }else{
				  result += mmRqmMnhrDao.updateRqmMnhr(rqmMnhr);
			  }
		  }
		  
		  if(rqmMnhr.get("A810")!=null){

			  rqmMnhr.put("RQM_MNHR_DVCD", "A810");
			  rqmMnhr.put("WRKTM",rqmMnhr.get("A810").toString());
		  
			  List<Map> rqmMnhrList31 = mmRqmMnhrDao.inqueryRqmMnhr(rqmMnhr);
		  
			  if(rqmMnhrList31.size()==0){
				  result += mmRqmMnhrDao.insertRqmMnhr(rqmMnhr);
			  }else{
				  result += mmRqmMnhrDao.updateRqmMnhr(rqmMnhr);
			  }
		  }
		  
		  }
	  
	  }
	  		
		if (logger.isDebugEnabled()) {
	      logger.debug("Service Method : createRqmMnhr Output ={}", rqmMnhrList);
	      }
	      
	      return result; 
    }
	
    @Override
    @ServiceId("MIMMS200")
    @ServiceName("부품조회")
    @MultiReturnBind
    public Map<String, List> inqueryRqmMnhr(@DatasetBind("input") Map searchParam) {
    	
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqueryRqmMnhr, Input Param={}", searchParam); 
        }
        
        String dvs = searchParam.get("DVS").toString();
        
        
        List<Map> rqmMnhrList = null;
        
        if("MM".equals(dvs)){
        	rqmMnhrList = mmRqmMnhrDao.inqueryMmRqmMnhrList(searchParam);
        }else if("ST".equals(dvs)){
        	rqmMnhrList = mmRqmMnhrDao.inqueryStRqmMnhrList(searchParam);
        }else if("FA".equals(dvs)){
        	rqmMnhrList = mmRqmMnhrDao.inqueryFaRqmMnhrList(searchParam);
        }else if("BP".equals(dvs)){
        	rqmMnhrList = mmRqmMnhrDao.inqueryBpRqmMnhrList(searchParam);
        }else if("BP2".equals(dvs)){
        	rqmMnhrList = mmRqmMnhrDao.inqueryBpRqmMnhrOutList(searchParam);
        }else if("MT".equals(dvs)){
        	rqmMnhrList = mmRqmMnhrDao.inqueryMtRqmMnhrList(searchParam);
        }else if("CP".equals(dvs)){
        	rqmMnhrList = mmRqmMnhrDao.inqueryCpRqmMnhrList(searchParam);
        }else if("EC".equals(dvs)){
        	rqmMnhrList = mmRqmMnhrDao.inqueryEcRqmMnhrList(searchParam);
        }else if("OT".equals(dvs)){
        	rqmMnhrList = mmRqmMnhrDao.inqueryOtRqmMnhrList(searchParam);
        }else if("HW".equals(dvs)){
        	rqmMnhrList = mmRqmMnhrDao.inqueryHwRqmMnhrList(searchParam);
        }else if("IL".equals(dvs)){
        	rqmMnhrList = mmRqmMnhrDao.inqueryIlRqmMnhrList(searchParam);
        }
        
        List<Map> mfgTimeList = mmRqmMnhrDao.inqueryMfgTimeList(searchParam);
        
        Map<String, List> data = new HashMap<>();
        
        data.put("Output1", rqmMnhrList);
        data.put("Output2", mfgTimeList);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqueryRqmMnhr Output ={}", rqmMnhrList);
        }
        
        return data;
    }
	
}