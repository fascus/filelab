/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.bi.pd.dao.PrdcstDao;
import htc.lts.bi.rp.dao.ResidentDao;
import htc.lts.bi.rp.service.ResidentServiceImpl;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 11. 11. 오후 7:22:06
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 11. 11.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class PrdcstServiceImpl implements PrdcstService {

	private static final Logger logger = LoggerFactory.getLogger(PrdcstServiceImpl.class);

	@Autowired
	private PrdcstDao prdcstDao;

	/**
	 * @see htc.lts.bi.pd.service.PrdcstService#savePrdcst(java.util.List)
	 * @Method Name        : savePrdcst
	 * @Method description : 
	 * @Date               : 2016. 11. 11.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 11.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param prdcstList
	 * @return
	*/
	
	@Override
	@ServiceId("BIPDX801")
	@ServiceName("원가갑지산정기준저장")
	@ReturnBind("output")
	public int savePrdcst(@DatasetBind("input")List<Map> prdcstList) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : savePrdcst, Input Param={}", prdcstList); 
        }
		
        int result = 0;
        for (Map resident : prdcstList) {
        	String rowType = XPlatformUtil.getDataRowType(resident);
        	if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
	        	result += prdcstDao.insertPrdcst(resident);
	        	
        	} else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
        		result += prdcstDao.updatePrdcst(resident);
        		
        	} else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
        		result += prdcstDao.deletePrdcst(resident);
        		
        	}
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : savePrdcst Output ={}", result);
        }

        return result;
	}

	/**
	 * @see htc.lts.bi.pd.service.PrdcstService#inqurePrdcst(java.util.Map)
	 * @Method Name        : inqurePrdcst
	 * @Method description : 
	 * @Date               : 2016. 11. 11.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 11.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
	@ServiceId("BIPDS801")
	@ServiceName("원가갑지산정기준저장조회")
	@ReturnBind("output")
	public List<Map> inqurePrdcst(@DatasetBind("input")Map searchParam) {
		if(logger.isDebugEnabled()){
            logger.debug("Service Method : inqurePrdcst, Input Param={}", searchParam);
        } 
        
        List<Map> residentList = prdcstDao.inqurePrdcst(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqurePrdcst Output ={}", residentList);
        }
        
        return residentList;
	}

		



}
