/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.service;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : 부품관리
 * @Date          : 2016. 10. 4. 오후 8:06:11
 * @Author        : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date             Programmer              Description
 * 2016. 10. 4.     강진오                 CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface PartService {

    /**
     * @Method Name        : inqurePart
     * @Method description : 
     * @Date               : 2016. 10. 4.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 4.     강진오                 CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param header
     * @param argument
     * @return
    */
    public List<Map> inqurePart(Map argument);
    
    /**
     * @Method Name        : inqurePartMake
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqurePartMake(Map argument);
    
    /**
     * @Method Name        : insertPart
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public int insertPartMake(List<Map> argument);
    
    /**
     * @Method Name        : insertPartList
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public int insertPartList(List<Map> argument);
    
    /**
     * @Method Name        : upDatePartList
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public int upDatePartList(List<Map> argument);
    
    /**
     * @Method Name        : deletePartList
     * @Method description : 
     * @Date               : 2016. 10. 10.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 10.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public int deletePartList(List<Map> argument);
    
    /**
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 10.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 10.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureFile(Map argument);
    
    public int deleteFile(List<Map> deleteFileList);
    
    public int deletePart(List<Map> deleteFileList);
    
    /**
     * @Method Name        : inqureEqNm
     * @Method description : 
     * @Date               : 2016. 11. 2.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 2.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureEqNm(Map argument);

}
