/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.bi.pd.dao.ItemDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 4. 오후 9:34:32
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 4.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class ItemServiceImpl implements ItemService {

	 private static final Logger logger = LoggerFactory.getLogger(ItemServiceImpl.class);
	 
	 @Autowired
	 private ItemDao itemDao;

	/**
	 * @see htc.lts.bi.pd.service.ItemService#inqureItem(java.util.Map)
	 * @Method Name        : inqureItem
	 * @Method description : 
	 * @Date               : 2016. 10. 4.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 4.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param argument
	 * @return
	*/
	
	 @Override
	 @ServiceId("BIPDS201")
	 @ServiceName("품목제원내역 조회")
	 @ReturnBind("output")
	public List<Map> inqureItem(@DatasetBind("input")Map searchParam) {
		 if(logger.isDebugEnabled()){ 
	            logger.debug("Service Method : inqureItem, Input Param={}", searchParam);
	        } 
	        
	        List<Map> itemList = itemDao.inqureItemList(searchParam);
	                
	        if (logger.isDebugEnabled()) {
	            logger.debug("Service Method : inqureItem Output ={}", itemList);
	        }
	        
	        return itemList;
	}

	/**
	 * @see htc.lts.bi.pd.service.ItemService#inqureShpTpCdList(java.util.Map)
	 * @Method Name        : inqureShpTpCdList
	 * @Method description : 
	 * @Date               : 2016. 10. 5.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 5.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
	@ServiceId("BIPDS202")
	@ServiceName("함형조회")
	@ReturnBind("output")
	public List<Map> inqureShpTpCdList(@DatasetBind("input")Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureShpTpCdList, Input Param={}", searchParam);
        } 
        
        List<Map> shpTpCdList = itemDao.inqureShpTpCdList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureShpTpCdList Output ={}", shpTpCdList);
        }
        
        return shpTpCdList;
	}

	/**
	 * @see htc.lts.bi.pd.service.ItemService#inqureEqList(java.util.Map)
	 * @Method Name        : inqureEqList
	 * @Method description : 
	 * @Date               : 2016. 10. 5.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 5.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
	@ServiceId("BIPDS203")
	@ServiceName("장비조회")
	@ReturnBind("output")
	public List<Map> inqureEqList(@DatasetBind("input")Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureEqList, Input Param={}", searchParam);
        } 
        
        List<Map> eqList = itemDao.inqureEqList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureEqList Output ={}", eqList);
        }
        
        return eqList;
	}

	/**
	 * @see htc.lts.bi.pd.service.ItemService#saveItem(java.util.List)
	 * @Method Name        : saveItem
	 * @Method description : 
	 * @Date               : 2016. 10. 5.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 5.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param insertParam
	 * @return
	*/
	
	@Override
	@ServiceId("BIPDU201")
    @ServiceName("품목 수정")
    @ReturnBind("output")
	public int saveItem(@DatasetBind("input")List<Map> insertParam) {
		
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveItem, Input Param={}", insertParam); 
        }
        int result = 0;
        for (Map item : insertParam) {
            result += itemDao.updateItem(item);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveItem Output ={}", result);
        }
        return result; 
	}

	/**
	 * @see htc.lts.bi.pd.service.ItemService#insertItem(java.util.List)
	 * @Method Name        : insertItem
	 * @Method description : 
	 * @Date               : 2016. 10. 6.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 6.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param insertParam
	 * @return
	*/
	
	@Override
	@ServiceId("BIPDI201")
    @ServiceName("품목 등록")
    @ReturnBind("output")
	public int insertItem(@DatasetBind("input")List<Map> insertParam) {

		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : insertItem, Input Param={}", insertParam); 
        }
        int result = 0;
        for (Map item : insertParam) {
            result += itemDao.insertItem(item);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertItem Output ={}", result);
        }
        return result; 
	}

	/**
	 * @see htc.lts.bi.pd.service.ItemService#saveItemShpTpCd(java.util.List)
	 * @Method Name        : saveItemShpTpCd
	 * @Method description : 
	 * @Date               : 2016. 10. 6.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 6.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param insertParam
	 * @return
	*/
	
	@Override
	@ServiceId("BIPDU202")
    @ServiceName("품목적용함형 등록")
    @ReturnBind("output")
	public int saveItemShpTpCd(@DatasetBind("input")List<Map> insertParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveItemShpTpCd, Input Param={}", insertParam); 
        }
	    
        int result = 0;
        Map data = new HashMap<>();
        data.put("NSN", insertParam.get(0).get("NSN"));
        
        itemDao.deleteItemShpTpCd(data);
        for (Map itemShpTpCd : insertParam) {
            //String rowType = XPlatformUtil.getDataRowType(itemShpTpCd);
            //if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_INSERTED)) {
                result += itemDao.insertItemShpTpCd(itemShpTpCd);
                
            //} else if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_UPDATED)) {
            //    result += itemDao.updateItemShpTpCd(itemShpTpCd);
            
            //} 
            //else if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_DELETED)) {
              //  result += itemDao.deleteItemShpTpCd(itemShpTpCd);
            
            //}
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveItemShpTpCd, Output ={}", result);
        }
        return result; 
	}

	/**
	 * @see htc.lts.bi.pd.service.ItemService#saveItemEqList(java.util.List)
	 * @Method Name        : saveItemEqList
	 * @Method description : 
	 * @Date               : 2016. 10. 6.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 6.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param insertParam
	 * @return
	*/
	
	@Override
	@ServiceId("BIPDU203")
    @ServiceName("품목적용장비 등록")
    @ReturnBind("output")
	public int saveItemEqList(@DatasetBind("input")List<Map> insertParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveItemEqList, Input Param={}", insertParam); 
        }
	    
        int result = 0;
        Map data = new HashMap<>();
        data.put("NSN", insertParam.get(0).get("NSN"));
        
        itemDao.deleteItemEq(data);
        for (Map itemEq : insertParam) {
            //String rowType = XPlatformUtil.getDataRowType(itemEq);
            //if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_INSERTED)) {
                result += itemDao.insertItemEq(itemEq);
                
            //} else if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_UPDATED)) {
                //result += itemDao.updateItemEq(itemEq);
            
            //} 
            //else if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_DELETED)) {
              //  result += itemDao.deleteItemEq(itemShpTpCd);
            
            //}
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveItemEqList, Output ={}", result);
        }
        return result; 
	}
	
	
    @Override
    @ServiceId("BIPDD002")
    @ServiceName("품목적용장비 삭제")
    @ReturnBind("output")
	public int deleteEq(@DatasetBind("input")Map insertParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : deleteEq, Input Param={}", insertParam); 
        }
        int result = 0;
        
        result += itemDao.deleteItemShpTpCd(insertParam);
        result += itemDao.deleteItemEq(insertParam);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : deleteEq, Output ={}", result);
        }
        return result; 
    }
    
	@Override
	@ServiceId("BIPDD005")
    @ServiceName("정비공구제원 삭제")
    @ReturnBind("output")
	public int deleteItem(@DatasetBind("input") List<Map> shipNmList) {
	    
	    if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveWrshp, Input Param={}", shipNmList); 
        }
        int result = 0;
        for (Map shipNm : shipNmList) {
        	
        	result = itemDao.deleteItem(shipNm);
        	
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveWrshp Output ={}", result);
        }
        return result; 
	}
	 
	 
}
