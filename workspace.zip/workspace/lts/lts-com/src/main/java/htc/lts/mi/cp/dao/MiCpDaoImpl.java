/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.cp.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 10:05:06
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class MiCpDaoImpl extends AbstractHtcDao implements MiCpDao {

    @Override
    public List inqureMtnList(Map argument) {
        return queryForList("htc.lts.mi.cp.hqml.MiCpQuery.inqureMtnList", argument);
    }
    
    @Override
    public List inqureCmplRptList(Map argument) {
        return queryForList("htc.lts.mi.cp.hqml.MiCpQuery.selectCmplRptList", argument);
    }
    
    @Override
    public List selectMimmIng(Map mngNo) {
        return queryForList("htc.lts.mi.cp.hqml.MiCpQuery.selectMimmIng", mngNo);
    }
    
}
