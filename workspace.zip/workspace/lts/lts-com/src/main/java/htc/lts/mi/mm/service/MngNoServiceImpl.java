/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.mm.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.da.dm.dao.DataDao;
import htc.lts.mi.mm.dao.MngNoDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date          : 2016. 9. 21. 오후 2:59:12
 * @Author        : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date             Programmer              Description
 * 2016. 9. 21.     이창환                 CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class MngNoServiceImpl implements MngNoService {

    private static final Logger logger = LoggerFactory.getLogger(MngNoServiceImpl.class);

    @Autowired
    MngNoDao mngNoDao;

    @Autowired
    private DataDao dataDao;
    
    @Override
    @ServiceId("MIMMM001")
    @ServiceName("이동정비현황조회")
    @ReturnBind("output")
    public List<Map> inqureMngNo(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureMngNo, Input Param={}", searchParam); 
        }
        
        List<Map> mngNoList = mngNoDao.inqureMngNoList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inquireMngNo Output ={}", mngNoList);
        }
        
        return mngNoList;
    }
    
    @Override
    @ServiceId("MIMMM019")
    @ReturnBind("output")
    public List<Map> searchCtrNoList(@DatasetBind("input") Map searchParam) {
    
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : searchCtrNoList, Input Param={}", searchParam); 
        }
        List<Map> ctrList = mngNoDao.searchCtrNoList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : searchCtrNoList Output ={}", searchParam);
        }
        
        return ctrList;
    }
    
   
    
    
    @Override
    @ServiceId("MIMMX001")
    @ServiceName("이동정비생성")
    @ReturnBind("output")
    public int saveMngNo(@DatasetBind("input") List<Map> mngNoList) {
       
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveMngNo, Input Param={}", mngNoList); 
        }
        int result = 0;
        String preSHP = "";
        String preMgt = "";
        for (Map mngNo1 : mngNoList) {
            //String rowType = XPlatformUtil.getDataRowType(mngNo);
            String mgt = preMgt;
            //System.out.println(preSHP+ "----------------------------------"+mngNo.get("SHP_TP_CD").toString());
            if(!preSHP.equals(mngNo1.get("SHP_TP_CD").toString())){    
                List<Map> searchMgtNo = mngNoDao.searchMngNoList(mngNo1);
            
                mgt = searchMgtNo.get(0).get("MGT").toString();
                
            }
            //System.out.println(preMgt+ "----------------------------------"+mgt);
            String UGCY_MTN_RQSTNO = null;
            if("2".equals(mngNo1.get("DVCD").toString()))
            {
            	List<Map> UgcyMtnRqstnoList = mngNoDao.selectUgcyMtnRqstno(mngNo1);
            	UGCY_MTN_RQSTNO = UgcyMtnRqstnoList.get(0).get("UGCY_MTN_RQSTNO").toString();
            	
            	List<Map> searchCtrno = mngNoDao.searchCtrNoList2(mngNo1);

                mngNo1.put("CTRNO", searchCtrno.get(0).get("CTRNO").toString()); 
                mngNo1.put("CTR_CHNG_SRLNO", searchCtrno.get(0).get("CTR_CHNG_SRLNO").toString());
            }
            
            String SHP_TP_CD = mngNo1.get("SHP_TP_CD").toString();          //함형
            String ITM_CD =    mngNo1.get("ITM_CD").toString();             //정비유형
            String EQCD =      mngNo1.get("EQCD").toString();               //함 장비부호 
            String ENTP_CD =   mngNo1.get("ENTP_CD").toString();            //정비업체부호
            
            String MGT_NO = SHP_TP_CD + ITM_CD + mgt;                      //관리번호 
            String RFNO   = ENTP_CD.trim() + EQCD.trim();                  //참조번호
            
                        
            //System.out.println(MGT_NO+ "----------------------------------"+RFNO);
            /*
            List<Map> searchCtrno = mngNoDao.searchCtrNoList(mngNo);       //공문번호로 계약번호 검색후 
            
            // 화면에서 생성시 계약 번호를 저장 할수 있도록 수정 2016-11-15
            for (Map ctrno : searchCtrno) {                                 
                if(SHP_TP_CD.equals(ctrno.get("SHP_TP_CD"))){
                    mngNo.put("CTRNO", ctrno.get("CTRNO")); 
                    mngNo.put("CTR_CHNG_SRLNO", ctrno.get("CTR_CHNG_SRLNO"));
                    break;
                }
            }
            */
            mngNo1.put("MGT_NO", MGT_NO);
            mngNo1.put("RFNO", RFNO);
            if("2".equals(mngNo1.get("DVCD").toString()))
            {
            	mngNo1.put("UGCY_MTN_RQSTNO", UGCY_MTN_RQSTNO);
            	result += mngNoDao.insertUgcyMtn(mngNo1);
            }
            
            if(!preSHP.equals(mngNo1.get("SHP_TP_CD").toString())){
                result += mngNoDao.insertMngNoMaster(mngNo1);
            }
            result += mngNoDao.insertMngNoDetail(mngNo1);
            result += mngNoDao.insertWrk(mngNo1);
            
            preMgt = mgt;
            preSHP = mngNo1.get("SHP_TP_CD").toString();
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveScreen Output ={}", result);
        }

        return result; 
    }
    
    
    /**
	 * @see htc.lts.mi.mm.service.MngNoService#saveTrfctr(java.util.List)
	 * @Method Name        : saveTrfctr
	 * @Method description : 
	 * @Date               : 2016. 12. 13.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 12. 13.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param mngNoList
	 * @return
	*/
	
    @Override
    @ServiceId("MIMMX989")
    @ServiceName("이동정비생성")
    @ReturnBind("output")
	public int saveTrfctr(@DatasetBind("input")List<Map> mngNoList) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveTrfctr, Input Param={}", mngNoList); 
        }
        int result = 0;
        String preSHP = "";
        String preMgt = "";
        for (Map mngNo : mngNoList) {
            //String rowType = XPlatformUtil.getDataRowType(mngNo);
            String mgt = preMgt;
            //System.out.println(preSHP+ "----------------------------------"+mngNo.get("SHP_TP_CD").toString());
            if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){    
                List<Map> searchMgtNo = mngNoDao.searchMngNoList(mngNo);
            
                mgt = searchMgtNo.get(0).get("MGT").toString();
                
            }
            //System.out.println(preMgt+ "----------------------------------"+mgt);
            String UGCY_MTN_RQSTNO = null;
            if("2".equals(mngNo.get("DVCD").toString()))
            {
            	List<Map> UgcyMtnRqstnoList = mngNoDao.selectUgcyMtnRqstno(mngNo);
            	UGCY_MTN_RQSTNO = UgcyMtnRqstnoList.get(0).get("UGCY_MTN_RQSTNO").toString();
            }	
            
            List<Map> searchCtrno = mngNoDao.searchCtrNoList2(mngNo);

            mngNo.put("CTRNO", searchCtrno.get(0).get("CTRNO").toString()); 
            mngNo.put("CTR_CHNG_SRLNO", searchCtrno.get(0).get("CTR_CHNG_SRLNO").toString());
            
            
            String SHP_TP_CD = mngNo.get("SHP_TP_CD").toString();          //함형
            String ITM_CD =    mngNo.get("ITM_CD").toString();             //정비유형
            String EQCD =      mngNo.get("EQCD").toString();               //함 장비부호 
            String ENTP_CD =   mngNo.get("ENTP_CD").toString();            //정비업체부호
            
            String MGT_NO = SHP_TP_CD + ITM_CD + mgt;                      //관리번호 
            String RFNO   = ENTP_CD.trim() + EQCD.trim();                  //참조번호
            
                        
            mngNo.put("MGT_NO", MGT_NO);
            mngNo.put("RFNO", RFNO);
            if("2".equals(mngNo.get("DVCD").toString()))
            {
            	mngNo.put("UGCY_MTN_RQSTNO", UGCY_MTN_RQSTNO);
            	result += mngNoDao.insertUgcyMtn(mngNo);
            }
            
            if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){
                result += mngNoDao.insertMngNoMaster(mngNo);
            }
            result += mngNoDao.insertMngNoDetail(mngNo);
            result += mngNoDao.insertWrk(mngNo);
            
            preMgt = mgt;
            preSHP = mngNo.get("SHP_TP_CD").toString();
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveTrfctr Output ={}", result);
        }

        return result; 
	}

	/**
     * @see htc.lts.mi.mm.service.MngNoService#inqureMtn(java.util.Map)
     * @Method Name        : inqureMtn
     * @Method description : 
     * @Date               : 2016. 9. 28.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 9. 28.     이창환                 CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("MIMMS002")
    @ServiceName("이동정비조회")
    @MultiReturnBind
    //public Map<String, List> inqureMtn(@DatasetBind("input") Map searchParam) {
    public Map<String, List> inqureMtn(SystemHeader header, @DatasetBind("input") Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureMtn, Input Param={}", searchParam); 
        }
        
        List<Map> mtnList = mngNoDao.inqureMtnList(searchParam);
        
        List<Map> mimmList = mngNoDao.selectMimmIng(searchParam);
        
        Map<String, List> data = new HashMap<>();
        
        data.put("output", mtnList);
        data.put("mimmIng", mimmList);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureMtn Output ={}", mtnList);
        }
        
        return data;
    }
    
    
    /**
     * @see htc.lts.mi.mm.service.MngNoService#inqureCmplRpt(java.util.Map)
     * @Method Name        : inqureCmplRpt
     * @Method description : 
     * @Date               : 2016. 9. 28.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 9. 28.     이창환                 CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("MIMMS003")
    @ServiceName("완료보고조회")
    @ReturnBind("output")
    public List<Map> inqureCmplRpt(@DatasetBind("input") Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureCmplRpt, Input Param={}", searchParam); 
        }
        
        List<Map> mtnList = mngNoDao.inqureCmplRptList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureCmplRpt Output ={}", mtnList);
        }
        
        return mtnList;
    }
    
    @Override
    @ServiceId("MIMMX002")
    @ServiceName("완료보고저장")
    @ReturnBind("output")
    public int saveCmplRpt(@DatasetBind("input") List<Map> cmplRptList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveCmplRpt, Input Param={}", cmplRptList); 
        }
        
        int result = 0;
//        int result2 = 0;
        Map param = new HashMap();
        
       // List<Map> cmplRptList2 = mngNoDao.inqureCmplRptList(param);

        for (Map cmplRpt : cmplRptList) {
            
            param.put("MGT_NO", cmplRpt.get("MGT_NO"));
            param.put("RFNO", cmplRpt.get("RFNO"));
            
            List<Map> cmplRptList2 = mngNoDao.inqureCmplRptList(param);
 
            for(int i = 0; i < cmplRptList2.size(); i++){
                if(cmplRptList2.get(i).get("MGT_NO2") == null && cmplRptList2.get(i).get("RFNO2") == null){
                    result += mngNoDao.insertCmplRpt(cmplRpt);
                    if(logger.isDebugEnabled()){
                        logger.debug("입력");
                    }
                }else{
                    result += mngNoDao.updateCmplRpt(cmplRpt);
                    if(logger.isDebugEnabled()){
                        logger.debug("수정");
                    }
                    
                }
            }
            
        }
        
        

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveCmplRpt Output ={}", result);
        }

        return result; 
    }
    
    /**
     * @see htc.lts.mi.mm.service.MngNoService#inqureShipInfo(java.util.Map)
     * @Method Name        : inqureCmplRpt
     * @Method description : 
     * @Date               : 2016. 9. 28.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 9. 28.     이창환                 CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("MIMMP010")
    @ReturnBind("output")
    public List<Map> inqureShipInfo(@DatasetBind("input") Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureShipInfo, Input Param={}", searchParam); 
        }
        List<Map> mtnList;
        
        if("SHP_TP_CD".equals(searchParam.get("GBN"))){
            mtnList = mngNoDao.inqureShipNmList(searchParam);
        }
        else if("HWEQCD".equals(searchParam.get("GBN"))){
            mtnList = mngNoDao.inqureHwEqcdList(searchParam);
        }else if("EQCD".equals(searchParam.get("GBN"))){
            mtnList = mngNoDao.inqureEqcdList(searchParam);
        }else if("BPEQCD".equals(searchParam.get("GBN"))){
            mtnList = mngNoDao.inqureBpEqcdList(searchParam);
        }else if("BPEQCD2".equals(searchParam.get("GBN"))){
            mtnList = mngNoDao.inqureBpEqcdList2(searchParam);
        }else if("HWMTNCD".equals(searchParam.get("GBN"))){
            mtnList = mngNoDao.inqureHwMtnCdList(searchParam);
        }else if("AIMTNCD".equals(searchParam.get("GBN"))){
            mtnList = mngNoDao.inqureAiMtnCdList(searchParam);
        }else if("AIEQCD".equals(searchParam.get("GBN"))){
            mtnList = mngNoDao.inqureAiEqCdList(searchParam);
        }else{
            mtnList = mngNoDao.inqureEqNmList(searchParam);
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureShipInfo Output ={}", mtnList);
        }
        
        return mtnList;
    }
    
    
    @Override
    @ServiceId("MIMMS030")
    @ReturnBind("output")
    public List<Map> seachEqNm(@DatasetBind("input") Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : seachEqNm, Input Param={}", searchParam); 
        }
        
        List<Map> mtnList = mngNoDao.seachEqNm(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : mtnList Output ={}", mtnList);
        }
        
        return mtnList;
    }
    
    @Override
    @ServiceId("MIMMF001")
    @ReturnBind("output")
    public List<Map> inqureFile(@DatasetBind("input") Map argument) {

        
        List<Map> result = dataDao.inqureFile2(argument);
        //List<Map> result = mngNoDao.inqureFile(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFile Output ={}", result);
        }

        return result;
    }
    
    
    @Override
    @ServiceId("MIMMS016")
    @ReturnBind("output")
    public List<Map> inqureRfnoCrtnAndDel(@DatasetBind("input") Map argument) {

        List<Map> result = mngNoDao.inqureRfnoCrtnAndDel(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureRfnoCrtnAndDel Output ={}", result);
        }

        return result;
    }
    

    @Override
    @ServiceId("MIMMX005")
    @ReturnBind("output")
    public int saveRfNo(@DatasetBind("input") List<Map> arguments) {
       
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveRfNo, Input Param={}", arguments); 
        }
        int result = 0;
            for (Map argument : arguments) {
                //argument.put("RFNO",argument.get("RFNO").toString().substring(10,2));
                String rowType = XPlatformUtil.getDataRowType(argument);
                
                if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    argument.put("RFNO",argument.get("ENTP_CD").toString().trim() + argument.get("EQCD").toString().trim());
                    result += mngNoDao.insertMngNoDetail(argument);
                    result += mngNoDao.insertWrk(argument);
                    
                } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                    result += mngNoDao.deleteMngNoDetail(argument);
                    result += mngNoDao.deleteWrk(argument);
                }
            }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveRfNo Output ={}", result);
        }

        return result; 
    }
    
    @Override
    @ServiceId("MIMMS021")
    @ReturnBind("output")
    public List<Map> inqureRsptAmt(@DatasetBind("input") Map argument) {

        List<Map> result = mngNoDao.inqureRsptAmt(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureRsptAmt Output ={}", result);
        }

        return result;
    }
    
    
    @Override
    @ServiceId("MIMMS022")
    @ReturnBind("output")
    public List<Map> inqureLbAmt(@DatasetBind("input") Map argument) {

        List<Map> result = mngNoDao.inqureLbAmt(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureRsptAmt Output ={}", result);
        }

        return result;
    }
    
    @Override
    @ServiceId("MIMMS023")
    @ReturnBind("output")
    public List<Map> inqureRsptAmt2(@DatasetBind("input") Map argument) {

        List<Map> result = mngNoDao.inqureRsptAmt2(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureRsptAmt2 Output ={}", result);
        }

        return result;
    }
    
    @Override
    @ServiceId("MIMMI001")
    @ReturnBind("output")
    public int saveCmplRpt2(@DatasetBind("input") Map cmplRptList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveCmplRpt2, Input Param={}", cmplRptList); 
        }
        
        int result = 0;

        result += mngNoDao.updateMngNoDetail(cmplRptList);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveCmplRpt2 Output ={}", result);
        }

        return result; 
    }
    
    @Override
    @ServiceId("MIMMX201")
    @ReturnBind("output")
    public int saveOfcdocNo(@DatasetBind("input") Map cmplRptList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveCmplRpt2, Input Param={}", cmplRptList); 
        }
        
        int result = 0;

        result += mngNoDao.updateOfcdocNoMngNoDetail(cmplRptList);

        result += mngNoDao.updateOfcdocNoUgcyMtn(cmplRptList);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveCmplRpt2 Output ={}", result);
        }

        return result; 
    }
}