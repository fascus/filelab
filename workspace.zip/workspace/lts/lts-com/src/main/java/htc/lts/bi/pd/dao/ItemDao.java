/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.dao;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 4. 오후 9:31:34
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 4.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface ItemDao {
	
	/**
     * @Method Name        : inqureItemList
     * @Method description : 
     * @Date               : 2016. 10. 4.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 4.     변용수                                               CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param item
     * @return
    */
	
    public List inqureItemList(Map item);
    
    /**
     * @Method Name        : inqureShpTpCdList
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 5.     변용수                                               CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    public List inqureShpTpCdList(Map searchParam);
    
    /**
     * @Method Name        : inqureEqList
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 5.     변용수                                               CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    public List inqureEqList(Map searchParam);
    
    /**
     * @Method Name        : updateItem
     * @Method description : 
     * @Date               : 2016. 10.  5.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int updateItem(Map item);
    
    /**
     * @Method Name        : insertItem
     * @Method description : 
     * @Date               : 2016. 10.  6.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int insertItem(Map item);
    
    /**
     * @Method Name        : updateItemShpTpCd
     * @Method description : 
     * @Date               : 2016. 10.  6.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int updateItemShpTpCd(Map item);
    
    /**
     * @Method Name        : insertItemShpTpCd
     * @Method description : 
     * @Date               : 2016. 10.  6.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int insertItemShpTpCd(Map item);
    
    /**
     * @Method Name        : deleteItemShpTpCd
     * @Method description : 
     * @Date               : 2016. 10.  6.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int deleteItemShpTpCd(Map item);
    
    /**
     * @Method Name        : deleteItemEq
     * @Method description : 
     * @Date               : 2016. 10.  6.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int deleteItemEq(Map item);
    
    /**
     * @Method Name        : insertItemEq
     * @Method description : 
     * @Date               : 2016. 10.  6.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int insertItemEq(Map item);
    
    /**
     * @Method Name        : updateItemEq
     * @Method description : 
     * @Date               : 2016. 10.  6.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		변용수					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * 
    */
    public int updateItemEq(Map item);
    
    public int deleteItem(Map item);

}
