/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.ra.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.bi.ra.dao.SwConfigMngtDao;
import htc.lts.bi.ra.dao.SwVerDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 11. 17. 오전 8:25:13
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 11. 17.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class SwConfigMngtServiceImpl implements SwConfigMngtService {
	
	private static final Logger logger = LoggerFactory.getLogger(SwConfigMngtServiceImpl.class);

	@Autowired
	private SwConfigMngtDao swConfigMngtDao;
	
	@Autowired
	private SwVerDao swVerDao;
	
	
	  @Override
	  @ServiceId({"BIRAX003"})
	  @ServiceName("SwConfigMngt저장")
	  @ReturnBind("output")
	  public int mergeSwConfigMngt(@DatasetBind("input") List<Map> arguments) {
	      if(logger.isDebugEnabled()){ 
	            logger.debug("Service Method : SwConfigMngtList, Input Param={}", arguments); 
	        }
	      
	        int result = 0;
	        for (Map argument : arguments) {
	          String rowType = XPlatformUtil.getDataRowType(argument);
	          if(logger.isDebugEnabled()){
	                logger.debug(rowType);
	            }
	          
	          if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
	                  result += swConfigMngtDao.insertSwConfigMngt(argument);
	          } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
	              result += swConfigMngtDao.updateSwConfigMngt(argument);
	          } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
	              result += swConfigMngtDao.deleteSwConfigMngt(argument);
	          }
	        }

	        if (logger.isDebugEnabled()) {
	            logger.debug("Service Method : mergeSwConfigMngt Output ={}", result);
	        }

	        return result; 
	  }
	
	@Override
	@ServiceId("BIRAS003")
	@ServiceName("SwConfigMngt조회")
	@ReturnBind("output")
	public List<Map> inqureSwConfigMngt(@DatasetBind("input") Map argument) {
		if(logger.isDebugEnabled()){
			
	        logger.debug("Service Method : inqureSwConfigMngt, Input Param={}", argument);
	    } 

	    List<Map> result = swConfigMngtDao.inqureSwConfigMngt(argument);
	            
	    if (logger.isDebugEnabled()) {
	        logger.debug("Service Method : inqureSwConfigMngt Output ={}", result);
	    }
	        
	    return result;
	}
	
	@Override
	@ServiceId("BIRAS004")
	@ServiceName("MaxEqVer조회")
	@ReturnBind("output")
	public List<Map> inqureMaxEqVer(@DatasetBind("input") Map argument) {
		if(logger.isDebugEnabled()){
			
	        logger.debug("Service Method : inqureSwVer, Input Param={}", argument);
	    } 
		
		List<Map> maxEqVer = swVerDao.inqureMaxEqVer(argument);
	            
	    if (logger.isDebugEnabled()) {
	        logger.debug("Service Method : inqureMaxEqVer Output ={}", maxEqVer);
	    }
	        
	    return maxEqVer;
	}
	
    @Override
    @ServiceId("BIRAS005")
    @ServiceName("VerCnt조회")
    @ReturnBind("output")
    public List<Map> inqureVerCnt(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){
            
            logger.debug("Service Method : inqureSwVer, Input Param={}", argument);
        } 
        
        List<Map> result = swConfigMngtDao.inqureVerCnt(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureMaxEqVer Output ={}", result);
        }
            
        return result;
    }
}
