/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.ot.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 24. 오후 1:49:01
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 24.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class OprdnsTchassDaoImpl extends AbstractHtcDao implements OprdnsTchasstDao {

	/**
	 * @see htc.lts.mi.ot.dao.OprdnsTchasstDao#inqureTchasstList(java.util.Map)
	 * @Method Name        : inqureTchasstList
	 * @Method description : 
	 * @Date               : 2016. 10. 24.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 24.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmplRpt
	 * @return
	*/
	
	@Override
	public List inqureTchasstList(Map cmplRpt) {
		return queryForList("htc.lts.mi.ot.hqml.OprdnsTchassQuery.selectTchasstList", cmplRpt);
	}

	/**
	 * @see htc.lts.mi.ot.dao.OprdnsTchasstDao#insertTchasst(java.util.Map)
	 * @Method Name        : insertTchasst
	 * @Method description : 
	 * @Date               : 2016. 10. 24.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 24.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmplRpt
	 * @return
	*/
	
	@Override
	public int insertTchasst(Map cmplRpt) {
		return  update("htc.lts.mi.ot.hqml.OprdnsTchassQuery.insertTchasst", cmplRpt);
	}

	/**
	 * @see htc.lts.mi.ot.dao.OprdnsTchasstDao#updateTchasst(java.util.Map)
	 * @Method Name        : updateTchasst
	 * @Method description : 
	 * @Date               : 2016. 10. 24.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 24.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmplRpt
	 * @return
	*/
	
	@Override
	public int updateTchasst(Map cmplRpt) {
		return  update("htc.lts.mi.ot.hqml.OprdnsTchassQuery.updateTchasst", cmplRpt);
	}
	
	

	

}
