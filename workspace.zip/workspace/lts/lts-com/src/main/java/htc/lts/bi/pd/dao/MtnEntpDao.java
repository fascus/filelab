/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.dao;

import java.util.List;
import java.util.Map;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 8. 오후 4:27:13
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 8.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface MtnEntpDao {

    public List inqureMtnEntp(Map argument);

    public List inqureMtnEntpPsnchrg(Map argument);

    public List inqureMtnEntpEqcd(Map argument);

    public List inqureMtnEntpCdList(Map argument);

    public int insertMtnEntp(Map argument);

    public int insertMtnEntpPsnchrg(Map argument1);

    public int insertMtnEntpEqcd(Map argument2);

    public int updateEqcd(Map argument);

    public int deleteEqcd(Map argument);

    public int updatePsnchrg(Map argument);

    public int deletePsnchrg(Map argument);

    public int updateMtnEntpMain(Map argument);

    public int deleteMtnEntpMain(Map argument);

    //public int insertPo(Map argument);

    //public int updatePo(Map argument);

    //public int deletePo(Map argument);
}
