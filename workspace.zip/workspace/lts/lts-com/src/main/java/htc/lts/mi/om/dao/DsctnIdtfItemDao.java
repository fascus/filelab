package htc.lts.mi.om.dao;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:28:41
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface DsctnIdtfItemDao {

    /**
     * @Method Name        : inqueryDsctnIdtfItemPopList
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DsctnIdtfItem
     * @return
    */
    public List inqueryDsctnIdtfItemPopList(Map DsctnIdtfItem);
    
    /**
     * @Method Name        : inqueryDsctnIdtfItemList
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DsctnIdtfItem
     * @return
    */
    public List inqueryDsctnIdtfItemList(Map DsctnIdtfItem);
    

    public List selectCount1(Map DsctnIdtfItem);
    

    public List selectCount2(Map DsctnIdtfItem);
    

    public List selectCount3(Map DsctnIdtfItem);
    
    /**
     * @Method Name        : selectMiotIng
     * @Method description : 
     * @Date               : 2016. 10. 31.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 31.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mtn
     * @return
    */
    public List selectMiotIng(Map mtn);
    
    /**
     * @Method Name        : searchDsctnIdRsltList
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DsctnIdtfItem
     * @return
    */
    public List searchDsctnIdRsltList(Map DsctnIdtfItem);
    
    /**
     * @Method Name        : inqureyMgtNoRfNo
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param param
     * @return
    */
    public List inqureyMgtNoRfNo(Map param);
    
    /**
     * @Method Name        : insertDsctnIdtfItem
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DsctnIdtfItem
     * @return
    */
    public int insertDsctnIdtfItem(Map DsctnIdtfItem);
    
    public int updateDsctnIdtfItem(Map DsctnIdtfItem);
    
    public int updateDsctnIdtfItem2(Map DsctnIdtfItem);
    
    public int deleteDsctnIdtfItem(Map DsctnIdtfItem);
    
    public int deleteDsctnPrsts(Map DsctnIdtfItem);
    
    public int deleteDsctnPrstsHistry(Map DsctnIdtfItem);
    
    public int insertDsctnHistry(Map dsctnHistry);
    
    public int updateDsctnHistry(Map dsctnHistry);
    
    public int deleteDsctnHistry(Map dsctnHistry);
    
    public List inqueryDsctnHistryList(Map param);
    
    public int insertDsctnPrsts(Map dsctnHistry);
    
    public int updateDsctnPrsts(Map dsctnHistry);
    
    public int updateDsctnPrsts2(Map dsctnHistry);
    
    public List inqueryDsctnPrstsList(Map param);
    
    public List inqueryDsctnPrstsHistryList(Map param);
    
    public int insertDsctnPrstsHistry(Map dsctnHistry);
    
    /**
     * @Method Name        : inqueryItemIdtfList
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param param
     * @return
    */
    public List inqueryItemIdtfList(Map param);
    
    /**
     * @Method Name        : insertDsctnIdRslt
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DsctnIdtfItem
     * @return
    */
    public int insertDsctnIdRslt(Map DsctnIdtfItem);
    
    public int insertCheck(Map dsctnHistry);
    
    public int updateCheck(Map dsctnHistry);
    
    public int deleteCheck(Map dsctnHistry);

    public List inqureRfnoCrtnAndDel(Map argument);

    public int deleteDsctnIdRslt(Map argument);
}
