/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.bp.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.mi.bp.dao.MiBpDao;
import htc.lts.mi.bp.dao.StateInspPrstsDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 10:04:40
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class MiBpServiceImpl implements MiBpService {

    private static final Logger logger = LoggerFactory.getLogger(MiBpServiceImpl.class);

    @Autowired
    MiBpDao miBpDao;
    
    @Autowired
    StateInspPrstsDao stateInspPrstsDao;
   
    @Override
    @ServiceId("MIBPS002")
    @ServiceName("고장부품정비조회")
    @MultiReturnBind
    //public Map<String, List> inqureMtn(@DatasetBind("input") Map searchParam) {
    public Map<String, List> inqureMtn(SystemHeader header, @DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureMtn, Input Param={}", argument); 
        }
        
        List<Map> mtnList = miBpDao.inqureMtnList(argument);
        
        List<Map> mimmList = miBpDao.selectMimmIng(argument);
        
        Map<String, List> data = new HashMap<>();
        
        data.put("output", mtnList);
        data.put("mimmIng", mimmList);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureMtn Output ={}", mtnList);
        }
        
        return data;
    }
    
    
    @Override
    @ServiceId("MIBPS003")
    @ServiceName("완료보고조회")
    @ReturnBind("output")
    public List<Map> inqureCmplRpt(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureCmplRpt, Input Param={}", argument); 
        }
        
        List<Map> result = miBpDao.inqureCmplRptList(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureCmplRpt Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId({"MIBPI001","MICPI001"})
    @ServiceName("검사결과 등록")
    @ReturnBind("output")
    public int insertInspRslt(@DatasetBind("input") Map argument) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertInspRslt, Input Param={}", argument);
        }
        
        int result = 0;
        List<Map> inspRsltList = miBpDao.inqureInspRslt(argument);
    	if(inspRsltList.size()==0){
    		result += miBpDao.insertInspRslt(argument);
    	}else{
    		result += miBpDao.updateInspRslt(argument);
    	}
    	
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertInspRslt Output ={}", result);
        }

        return result;
    }

    @Override
    @ServiceId({"MIBPI002","MICPI002"})
    @ServiceName("심의결과 및 고장유형 등록")
    @MultiReturnBind
    public int insertRsltnTycd(@DatasetBind("input1") List<Map> arguments, @DatasetBind("input2") List<Map> arguments2, @DatasetBind("input3") Map param) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertRsltnTtcd, Input Param={}", arguments);
            logger.debug("Service Method : insertRsltnTtcd2, Input Param={}", arguments2);
        }
        int result = 0;
        int result2 = 0;
        result += miBpDao.deleteRslt(param);
        if(arguments.size()!=0){
            for (Map argument : arguments) {
                result += miBpDao.insertRslt(argument);
            }
        }
        result2 += miBpDao.deleteTycd(param);
        if(arguments2.size()!=0){
            for (Map argument2 : arguments2) {
                result2 += miBpDao.insertTycd(argument2);
            }
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertRslt Output ={}", result);
            logger.debug("Service Method : insertTtcd Output ={}", result2);
        }

        return result;
    }
    
    @Override
    @ServiceId({"MIBPS004","MICPS004"})
    @ServiceName("검사결과조회")
    @ReturnBind("output")
    public List<Map> inqureInspRslt(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureInspRslt, Input Param={}", argument); 
        }
        
        List<Map> result = miBpDao.inqureInspRslt(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureInspRslt Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId({"MIBPS005","MICPS005"})
    @ServiceName("심의결과조회")
    @ReturnBind("output")
    public List<Map> inqureRslt(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureRslt, Input Param={}", argument); 
        }
        
        List<Map> result = miBpDao.inqureRslt(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureRslt Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId({"MIBPS006","MICPS006"})
    @ServiceName("고장유형조회")
    @ReturnBind("output")
    public List<Map> inqureTycd(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : imqureTycd, Input Param={}", argument); 
        }
        
        List<Map> result = miBpDao.inqureTycd(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : imqureTycd Output ={}", result);
        }
        
        return result;
    }
    

    @Override
    @ServiceId({"MIBPI003","MICPI003"})
    @ServiceName("심의결과 및 고장유형 등록")
    @MultiReturnBind
    public int insertMtnPlan(@DatasetBind("input1") List<Map> arguments, @DatasetBind("input2") List<Map> arguments2, @DatasetBind("input3") Map param) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertRsltnTtcd, Input Param={}", arguments);
            logger.debug("Service Method : insertRsltnTtcd2, Input Param={}", arguments2);
        }
        String mgtNo = param.get("MGT_NO").toString();
        String rfno = param.get("RFNO").toString();
        String cnt;
        
        List list = new ArrayList();
        List<Map> inspRsltCnt = miBpDao.inqureInspRsltCnt(param); //검사결과서가 등록되었는지 확인한다.(감사별로 하나라도 있으면 실행하지 않음)
        
        cnt = inspRsltCnt.get(0).get("CNT").toString();
        if("0".equals(cnt))
        {
            int firstInspRslt = 0;
            String[] score;
            score = new String[]{ "02","04","05"}; // 02:해체 , 04:중간 , 05:최종
            for(int i=0;i<3;i++) {
                Map<String, Object> param1 = new HashMap<>();
                param1.put("MGT_NO", mgtNo);      //관리번호
                param1.put("RFNO", rfno);         //참조번호
                param1.put("INSP_DVCD",score[i]); //검사구분
                list.add(i, param1);
            }
            //각 검사별로 loop돌며 생성한다.
            for(int i=0;i<list.size();i++) {
                
                //검사결과서 등록
                miBpDao.insertFirstInspRslt((Map) list.get(i));
                // 검사결과서 심의결과 등록
                if(arguments.size()!=0){
                    for (Map argument : arguments) {
                        argument.put("INSP_DVCD", ((Map) list.get(i)).get("INSP_DVCD"));
                        firstInspRslt += miBpDao.insertRslt(argument);
                    }
                }
                //검사결과서 고장유형 등록
                if(arguments2.size()!=0){
                    for (Map argument2 : arguments2) {
                        argument2.put("INSP_DVCD", ((Map) list.get(i)).get("INSP_DVCD"));
                        firstInspRslt += miBpDao.insertTycd(argument2);
                    }
                }
            }
            
        }
        int result = 0;
        int result2 = 0;
        
        result += miBpDao.deleteMtnPlanRslt(param);
        if(arguments.size()!=0){
            for (Map argument : arguments) {
                result += miBpDao.insertMtnPlanRslt(argument);
            }
        }
        result2 += miBpDao.deleteMtnPlanTycd(param);
        if(arguments2.size()!=0){
            for (Map argument2 : arguments2) {
                result2 += miBpDao.insertMtnPlanTycd(argument2);
            }
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertRslt Output ={}", result);
            logger.debug("Service Method : insertTtcd Output ={}", result2);
        }

        return result;
    }
    
    
    
    
    /**
	 * @see htc.lts.mi.bp.service.MiBpService#insertChartData(java.util.List)
	 * @Method Name        : insertChartData
	 * @Method description : 
	 * @Date               : 2016. 11. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param arguments
	 * @return
	*/
	
    @Override
    @ServiceId("MIBPI004")
    @ServiceName("차트데이터등록")
    @ReturnBind("output")
	public int insertChartData(@DatasetBind("input") List<Map> arguments) {
		if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertChartData, Input Param={}", arguments);
        }
		int result = 0;
		for (Map argument : arguments) {
            //String rowType = XPlatformUtil.getDataRowType(argument);
            
            result += miBpDao.deleteChartData(argument);
            result += miBpDao.insertChartData(argument);
           // result += miBpDao.updateChartData(argument);
            /*
            if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_INSERTED)) {
            	System.out.println("insert");
                result += miBpDao.insertChartData(argument);
                
            } else if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_UPDATED)) {
            	System.out.println("update");
                result += miBpDao.updateChartData(argument);
                
            } else if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_DELETED)) {
            	System.out.println("delete");
                result += miBpDao.deleteChartData(argument);
                
            }
            */
          }

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertChartData Output ={}", result);
        }
        return result;
	}


	@Override
    @ServiceId({"MIBPS007","MICPS007"})
    @ServiceName("검사결과조회")
    @ReturnBind("output")
    public List<Map> inqureMtnPlan(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureMtnPlan, Input Param={}", argument); 
        }
        
        List<Map> result = miBpDao.inqureMtnPlan(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureMtnPlan Output ={}", result);
        }
        
        return result;
    }
    
    
    @Override
    @ServiceId({"MIBPS008","MICPS008"})
    @ServiceName("심의결과조회")
    @ReturnBind("output")
    public List<Map> inqureMtnPlanRslt(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureMtnPlanRslt, Input Param={}", argument); 
        }
        
        List<Map> result = miBpDao.inqureMtnPlanRslt(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureMtnPlanRslt Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId({"MIBPS009","MICPS009"})
    @ServiceName("고장유형조회")
    @ReturnBind("output")
    public List<Map> inqureMtnPlanTycd(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureMtnPlanTycd, Input Param={}", argument); 
        }
        
        List<Map> result = miBpDao.inqureMtnPlanTycd(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureMtnPlanTycd Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId({"MIBPS010","MICPS010"})
    @ServiceName("시험성적서조회")
    @ReturnBind("output")
    public List<Map> inqureTestList(@DatasetBind("input") Map argument) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureTestList, Input Param={}", argument); 
        }
        
        List<Map> result = miBpDao.inqureTestList(argument);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureTestList Output ={}", result);
        }
        
        return result;
    }
    
    @Override
    @ServiceId({"MIBPU001","MICPU001"})
    @ServiceName("검사결과 등록")
    @ReturnBind("output")
    public int updateTestList(@DatasetBind("input") Map argument) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateTestList, Input Param={}", argument);
        }
        int result = 0;
        String cnt;
        List<Map> testList = miBpDao.inqureTestListRowCnt(argument);
        
        cnt = testList.get(0).get("CNT").toString();
        
        if("0".equals(cnt))
        {
            result += miBpDao.insertTestList(argument);
        }else{
            result += miBpDao.updateTestList(argument);
        }
        
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateTestList Output ={}", result);
        }

        return result;
    }
    
    @Override
    @ServiceId({"MIBPU002","MICPU002"})
    @ServiceName("정비계횓 수정")
    @ReturnBind("output")
    public int updateMtnPlan(@DatasetBind("input") Map argument) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateMtnPlan, Input Param={}", argument);
        }
        
        int result = 0;
        String rowType = XPlatformUtil.getDataRowType(argument);
        
        if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
            result += miBpDao.insertMtnPlan(argument);
        } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
            result += miBpDao.updateMtnPlan(argument);
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateMtnPlan Output ={}", result);
        }

        return result;
    }
    
    /**
	 * @see htc.lts.mi.bp.service.MiBpService#updateMtnDetail(java.util.Map)
	 * @Method Name        : updateMtnDetail
	 * @Method description : 
	 * @Date               : 2016. 11. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param argument
	 * @return
	*/
	
    @Override
    @ServiceId("MIBPU003")
    @ServiceName("정비상세업데이트")
    @ReturnBind("output")
	public int updateMtnDetail(@DatasetBind("input")Map argument) {
		if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateMtnDetail, Input Param={}", argument);
        }
        
        int result = 0;

        result += miBpDao.updateMtnDetail1(argument);
        result += miBpDao.updateMtnDetail2(argument);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : updateMtnDetail Output ={}", result);
        }

        return result;
	}


	@Override
    @ServiceId("MIBPS011")
    @ServiceName("사용부품조회")
    @ReturnBind("output")
    public List<Map> inqurePn(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqurePn, Input Param={}", searchParam); 
        }
        
        List<Map> pnList = miBpDao.inqurePn(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqurePn Output ={}", pnList);
        }
        
        return pnList;
    }
    
    @Override
    @ServiceId({"MIBPS012","MICPS012"})
    @ServiceName("사용부품증빙 조회")
    @ReturnBind("output")
    public List<Map> inqureUsePnEvidence(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureUsePnEvidence, Input Param={}", searchParam); 
        }
        
        List<Map> pnList = miBpDao.inqureUsePnEvidence(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureUsePnEvidence Output ={}", pnList);
        }
        
        return pnList;
    }
    
    

    @Override
    @ServiceId({"MIBPX001","MICPX001"})
    @ServiceName("사용부품증빙 저장")
    @ReturnBind("output")
    public int saveUsePnEvidence(@DatasetBind("input") List<Map> usePnList) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : saveUsePn, Input Param={}", usePnList); 
          }
        
          int result = 0;
          
          for (Map usePn : usePnList) {
            String rowType = XPlatformUtil.getDataRowType(usePn);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
//            	List<Map> stateInspPrstsList = stateInspPrstsDao.inqureStateInspPrstsList(usePn);
//            	if(stateInspPrstsList.size()>0){
//            		usePn.put("RPLC_F_CMPNTS_PHOTO_FILENO", stateInspPrstsList.get(0).get("OLD_CMPNTS_PHOTO_FILENO"));
//            		usePn.put("RPLC_R_CMPNTS_PHOTO_FILENO", stateInspPrstsList.get(0).get("NITM_CMPNTS_PHOTO_FILENO"));
//            	}
            	
                result += miBpDao.insertUsePnEvidence(usePn);
//                if(usePn.get("RPLC_F_CMPNTS_PHOTO_FILENO")!=null || usePn.get("RPLC_R_CMPNTS_PHOTO_FILENO")!=null){
//                	result += stateInspPrstsDao.updateStateInspPrsts(usePn);
//                }
                
               // result += stateInspPrstsDao.insertStateInspPrsts(usePn);
                
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += miBpDao.updateUsePnEvidence(usePn);
                //result += stateInspPrstsDao.updateStateInspPrsts(usePn);
                
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += miBpDao.deleteUsePnEvidence(usePn);
               // result += stateInspPrstsDao.deleteStateInspPrsts(usePn);
                
            }
          }
                 

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : saveUsePn Output ={}", result);
          }

          return result; 
    }
    

    @Override
    @ServiceId({"MIBPX002","MICPX002"})
    @ServiceName("검사일자 저장")
    @ReturnBind("output")
    public int mergeInspDt(@DatasetBind("input") List<Map> arguments) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : mergeInspDt, Input Param={}", arguments); 
          }
        
          int result = 0;
          
          for (Map argument : arguments) {
            String rowType = XPlatformUtil.getDataRowType(argument);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += miBpDao.insertInspDt(argument);
                
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += miBpDao.updateInspDt(argument);
                
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += miBpDao.deleteInspDt(argument);
                
            }
          }
                 
          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : mergeInspDt Output ={}", result);
          }
          return result; 
    }
    
    @Override
    @ServiceId({"MIBPS013","MICPS013"})
    @ServiceName("검사일자조회")
    @ReturnBind("output")
    public List<Map> inqureInspDt(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureInspDt, Input Param={}", searchParam); 
        }
        
        List<Map> result = miBpDao.inqureInspDt(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureInspDt Output ={}", result);
        }
        
        return result;
    }


	/**
	 * @see htc.lts.mi.bp.service.MiBpService#inqureMntDetail(java.util.Map)
	 * @Method Name        : inqureMntDetail
	 * @Method description : 
	 * @Date               : 2016. 11. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
    @Override
    @ServiceId("MIBPS014")
    @ServiceName("납품예정일자, 소요예상공수, 정비예상금액, 특이사항 조회")
    @ReturnBind("output")
	public List<Map> inqureMntDetail(@DatasetBind("input")Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureMntDetail, Input Param={}", searchParam); 
        }
        
        List<Map> result = miBpDao.inqureMntDetail(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureMntDetail Output ={}", result);
        }
        
        return result;
	}


	/**
	 * @see htc.lts.mi.bp.service.MiBpService#inqureChartData(java.util.Map)
	 * @Method Name        : inqureChartData
	 * @Method description : 
	 * @Date               : 2016. 11. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
    @Override
    @ServiceId("MIBPS015")
    @ServiceName("차트데이터 조회")
    @ReturnBind("output")
	public List<Map> inqureChartData(@DatasetBind("input")Map searchParam) {
    	if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureChartData, Input Param={}", searchParam); 
        }
        
        List<Map> result = miBpDao.inqureChartData(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureChartData Output ={}", result);
        }
        
        return result;
	}
    
    
}