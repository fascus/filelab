package htc.lts.com.category.dao;

import java.util.Map;

public interface AlternateDao {
	void insertCategory(Map category);
	void insertSeperateCategory(Map category);
}
