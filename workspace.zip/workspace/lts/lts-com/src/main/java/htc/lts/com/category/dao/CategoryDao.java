package htc.lts.com.category.dao;

import java.util.List;
import java.util.Map;

import htc.commons.paging.PagingSupport;
import htc.lts.com.category.dto.CategoryDto;

public interface CategoryDao {
	List listCategory(Map category);
	List listCategory(Map category, PagingSupport paging);
	int insertCategory(Map category);
	int updateCategory(Map category);
	int deleteCategory(Map category);
	Map getCategory(Map category);
	CategoryDto getCategory(CategoryDto category);
}
