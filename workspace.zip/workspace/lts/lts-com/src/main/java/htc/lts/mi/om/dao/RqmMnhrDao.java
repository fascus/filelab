package htc.lts.mi.om.dao;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:28:41
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface RqmMnhrDao {

    public List inqureyRqmMnhrList(Map param); 
    
    public int insertRqmMnhr(Map rqmMnhr);
    
    public int updateRqmMnhr(Map rqmMnhr);
    
    public int deleteRqmMnhr(Map rqmMnhr);
    
    public int insertDsctnIdtfWrkCtnt(Map rqmMnhr);
    
    public int updateDsctnIdtfWrkCtnt(Map rqmMnhr);
    
}
