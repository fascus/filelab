package htc.lts.mi.om.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:30:20
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class DsctnIdtfPlanDaoImpl extends AbstractHtcDao implements DsctnIdtfPlanDao {

    @Override
    public List inqureyDsctnIdtfPlanList(Map param) {
        return queryForList("htc.lts.mi.om.hqml.DsctnIdtfPlanQuery.selectDsctnIdtfPlanList", param);
    }
    
    @Override
    public int updateDsctnIdtfPlan(Map dsctnIdtfPlan) {
        return update("htc.lts.mi.om.hqml.DsctnIdtfPlanQuery.updateDsctnIdtfPlan", dsctnIdtfPlan);
    }
    
}
