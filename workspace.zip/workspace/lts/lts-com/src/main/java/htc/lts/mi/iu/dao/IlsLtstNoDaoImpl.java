/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.iu.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 3:22:14
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class IlsLtstNoDaoImpl extends AbstractHtcDao implements IlsLtstNoDao {
    
    /**
     * @see htc.lts.mi.iu.dao.IlsLtstNoDao#inqueryIlsLtstCmplRpt(java.util.Map)
     * @Method Name        : inqueryIlsLtstCmplRpt
     * @Method description : 
     * @Date               : 2016. 10. 27.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 27.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mngNo
     * @return
    */
    public List inqueryIlsLtstCmplRpt(Map mngNo) {
        return queryForList("htc.lts.mi.iu.hqml.IlsLtstNoQuery.selectIlsLtstCmplRptList", mngNo);
    }
    
    /**
     * @see htc.lts.mi.iu.dao.IlsLtstNoDao#inqueryIlsLtstMgt(java.util.Map)
     * @Method Name        : inqueryIlsLtstMgt
     * @Method description : 
     * @Date               : 2016. 10. 27.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 27.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mngNo
     * @return
    */
    public List inqueryIlsLtstMgt(Map mngNo) {
        return queryForList("htc.lts.mi.iu.hqml.IlsLtstNoQuery.selectIlsLtstMgtList", mngNo);
    }
    
    /**
     * @see htc.lts.mi.iu.dao.IlsLtstNoDao#insertIlsLtstCmplRpt(java.util.Map)
     * @Method Name        : insertIlsLtstCmplRpt
     * @Method description : 
     * @Date               : 2016. 10. 27.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 27.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mngNo
     * @return
    */
    @Override
    public int insertIlsLtstCmplRpt(Map mngNo) {
        return  update("htc.lts.mi.iu.hqml.IlsLtstNoQuery.insertIlsLtstCmplRpt", mngNo);
    }
    
    
    @Override
    public int updateIlsLtstCmplRpt(Map mngNo) {
        return  update("htc.lts.mi.iu.hqml.IlsLtstNoQuery.updateIlsLtstCmplRpt", mngNo);
    }
    /**
     * @see htc.lts.mi.iu.dao.IlsLtstNoDao#insertIlsLtstMgt(java.util.Map)
     * @Method Name        : insertIlsLtstMgt
     * @Method description : 
     * @Date               : 2016. 10. 27.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 27.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mngNo
     * @return
    */
    @Override
    public int insertIlsLtstMgt(Map mngNo) {
        return  update("htc.lts.mi.iu.hqml.IlsLtstNoQuery.insertIlsLtstMgt", mngNo);
    }
    
    public List inqureIlsLtst(Map mngNo) {
        return queryForList("htc.lts.mi.iu.hqml.IlsLtstNoQuery.selectIlsLtst", mngNo);
    }

    @Override
    public int insertIlsLtstPlan(Map mngNo) {
        return  update("htc.lts.mi.iu.hqml.IlsLtstNoQuery.insertIlsLtstPlan", mngNo);
    }
    
    public List inqureIlsPlanLtst(Map mngNo) {
        return queryForList("htc.lts.mi.iu.hqml.IlsLtstNoQuery.selectIlsPlanLtst", mngNo);
    }
    
    @Override
    public int updateIlsLtstPlan(Map ilsLtstPlan) {
        return  update("htc.lts.mi.iu.hqml.IlsLtstNoQuery.updateIlsLtstPlan", ilsLtstPlan);
    }
    
    @Override
    public List inqureFile2(Map argument) {
        return queryForList("htc.lts.mi.iu.hqml.IlsLtstNoQuery.inqureFile2", argument);
    }
    
    @Override
    public List selectMiotIng(Map mtn) {
        return queryForList("htc.lts.mi.iu.hqml.IlsLtstNoQuery.selectMiotIng", mtn);
    }
    
    @Override
    public List inqureRfnoCrtnAndDel(Map mtn) {
        return queryForList("htc.lts.mi.iu.hqml.IlsLtstNoQuery.inqureRfnoCrtnAndDel", mtn);
    }
    
    @Override
    public int deleteIlsLtstPlan(Map ilsLtstPlan) {
        return  update("htc.lts.mi.iu.hqml.IlsLtstNoQuery.deleteIlsLtstPlan", ilsLtstPlan);
    }
    
}


