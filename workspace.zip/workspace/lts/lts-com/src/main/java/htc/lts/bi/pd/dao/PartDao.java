/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.dao;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date          : 2016. 10. 4. 오후 8:20:40
 * @Author        : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date             Programmer              Description
 * 2016. 10. 4.     강진오                 CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 11. 2. 오후 7:01:35
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 11. 2.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface PartDao {

    /**
     * @Method Name        : inqurePartList
     * @Method description : 
     * @Date               : 2016. 10. 4.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 4.     강진오                 CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List inqurePartList(Map part);
    
    /**
     * @Method Name        : inqurePartMake
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param part
     * @return
    */
    public List inqurePartMake(Map part);
    
    /**
     * @Method Name        : insertPart
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param Part
     * @return
    */
    public int insertPartMake(Map PartMake);
    
    /**
     * @Method Name        : updatePart
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param Part
     * @return
    */
    public int updatePartMake(Map PartMake);
    
    /**
     * @Method Name        : deletePart
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param Part
     * @return
    */
    public int deletePartMake(Map PartMake);
    
    /**
     * @Method Name        : insertPartList
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param PartList
     * @return
    */
    public int insertPartList(Map PartList);
    
    /**
     * @Method Name        : updatPartList
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param PartList
     * @return
    */
    public int updatePartList(Map PartList);
    
    /**
     * @Method Name        : deletePartList
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param PartList
     * @return
    */
    public int deletePartList(Map PartList);
    
    /**
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 10.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 10.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureFile(Map argument);
    
    public int deleteFile(Map deleteFile);
    
    
    /**
     * @Method Name        : inqureEqNmList
     * @Method description : 
     * @Date               : 2016. 11. 2.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 2.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureEqNmList(Map argument);
    
}
