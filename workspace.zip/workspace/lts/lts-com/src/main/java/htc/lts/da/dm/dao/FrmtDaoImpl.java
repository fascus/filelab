package htc.lts.da.dm.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : 양식함 관리
 * @Date		  : 2016. 10. 14. 오후 1:28:44
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 14.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class FrmtDaoImpl extends AbstractHtcDao implements FrmtDao{

    /**
     * @see htc.lts.da.dm.dao.FrmtDao#inqureFrmtList(java.util.Map)
     * @Method Name        : inqureFrmtList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param frmt
     * @return
    */
    @Override
    public List inqureFrmtList(Map frmt) {
        return queryForList("htc.lts.da.dm.hqml.FrmtQuery.selectFrmtList", frmt);
    }

    /**
     * @see htc.lts.da.dm.dao.FrmtDao#insertFrmtList(java.util.Map)
     * @Method Name        : insertFrmtList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param FrmtList
     * @return
    */
    @Override
    public int insertFrmtList(Map FrmtList) {
        return  update("htc.lts.da.dm.hqml.FrmtQuery.insertFrmtList", FrmtList);
    }
    
    /**
     * @see htc.lts.da.dm.dao.FrmtDao#updateFrmtList(java.util.Map)
     * @Method Name        : updateFrmtList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param FrmtList
     * @return
    */
    @Override
    public int updateFrmtList(Map FrmtList) {
        return  update("htc.lts.da.dm.hqml.FrmtQuery.updateFrmtList", FrmtList);
    }
    
    /**
     * @see htc.lts.da.dm.dao.FrmtDao#deleteFrmtList(java.util.Map)
     * @Method Name        : deleteFrmtList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param FrmtList
     * @return
    */
    @Override
    public int deleteFrmtList(Map FrmtList) {
        return  update("htc.lts.da.dm.hqml.FrmtQuery.deleteFrmtList", FrmtList);
    }
    
    /**
     * @see htc.lts.da.dm.dao.FrmtDao#inqureFile(java.util.Map)
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    public List inqureFile(Map argument) {
        return queryForList("htc.lts.da.dm.hqml.FrmtQuery.inqureFile", argument);
    }
}
