package htc.lts.mi.om.dao;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:28:41
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface DsctnIdtfCmplRptDao {

    public List inqueryDsctnIdtfCmplRptList(Map param);
    
    public List inqueryEqnm(Map param);
    
    public int insertDsctnIdtfCmplRpt(Map eqNm);
    
    public int updatedsctnIdtfCmplRpt(Map dsctnIdtfCmplRpt);
    
    public List<Map> inqureFile(Map argument);
    
    public List<Map> inqureFile2(Map argument);

    public int updateLbcst(Map dsctnIdtfCmplRpt);
    
}
