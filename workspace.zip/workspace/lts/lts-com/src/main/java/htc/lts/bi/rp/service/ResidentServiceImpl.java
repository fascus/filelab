/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.rp.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.utils.MapUtil;
import htc.lts.bi.rp.dao.ResidentDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 28. 오후 4:50:51
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 28.		변용수						CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class ResidentServiceImpl implements ResidentService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ResidentServiceImpl.class);

	@Autowired
	private ResidentDao residentDao;

	/**
	 * @see htc.lts.bi.rp.service.ResidentService#inqureResident(java.util.Map)
	 * @Method Name        : inqureResident
	 * @Method description : 
	 * @Date               : 2016. 9. 28.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 9. 28.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/

	@Override
	@ServiceId("BIRPS001")
    @ServiceName("상주인원 조회")
	@MultiReturnBind
	public Map<String, List> inqureResident(@DatasetBind("input") Map searchParam) {
		if(LOGGER.isDebugEnabled()){
            LOGGER.debug("Service Method : inqureResident, Input Param={}", searchParam);
        } 

		
        List<Map> residentList = residentDao.inqureResidentList(searchParam);
        
        MapUtil mapUtil = new MapUtil();
        mapUtil.decryptMapList(residentList,false,false,"HP_NO","EMAIL");
                
        List<Map> residentTempList = residentDao.inqureResidentTempList(searchParam);
          
        Map<String, List> data = new HashMap<>();
        data.put("output1", residentList);
        data.put("output2", residentTempList);
        
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqurePn Output ={}", data);
            
        }
        return data;
	}

	/**
	 * @see htc.lts.bi.rp.service.ResidentService#inqureUser(java.util.Map)
	 * @Method Name        : inqureUser
	 * @Method description : 
	 * @Date               : 2016. 9. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 9. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
	@ServiceId("BIRPS002")
    @ServiceName("사용자명검색")
    @ReturnBind("output")
	public List<Map> inqureUser(@DatasetBind("input") Map searchParam) {
		if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : inqurePn, Input Param={}", searchParam); 
        }
        
        List<Map> userList = residentDao.inqureUserList(searchParam);
        
        MapUtil mapUtil = new MapUtil();
        mapUtil.decryptMapList(userList,false,true,"HP_NO", "EMAIL");
                
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : inqurePn Output ={}", userList);
        }
        
        return userList;
	}

	/**
	 * @see htc.lts.bi.rp.service.ResidentService#saveResident(java.util.Map)
	 * @Method Name        : saveResident
	 * @Method description : 
	 * @Date               : 2016. 9. 29.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 9. 29.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	@Override
	@ServiceId("BIRPX001")
	@ServiceName("상주인원저장")
	@ReturnBind("output")
	public int saveResident(@DatasetBind("input")List<Map> residentList) {
		if(LOGGER.isDebugEnabled()){ 
            LOGGER.debug("Service Method : saveResident, Input Param={}", residentList); 
        }
		
        int result = 0;
        
        MapUtil mapUtil = new MapUtil();
        mapUtil.encryptMapList(residentList,false,true,"EMAIL","HP_NO");
        
        for (Map resident : residentList) {
        	String rowType = XPlatformUtil.getDataRowType(resident);
        	
        	if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
	        	result += residentDao.insertResident(resident);
        	} else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
        		result += residentDao.updateResident(resident);
        	} else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
        		result += residentDao.deleteResident(resident);
        		
        	}
        }
               

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Service Method : saveGroupCode Output ={}", result);
        }

        return result;
	}

}
