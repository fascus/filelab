package htc.lts.mi.om.service;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:21:27
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface DsctnIdtfItemService {
    /**
     * @Method Name        : inqueryDsctnIdtfItemPop
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqueryDsctnIdtfItemPop(List<Map> argument);
    
    /**
     * @Method Name        : inqureyDsctnIdtfItem
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public Map<String, List> inqureyDsctnIdtfItem(Map argument);
    
    /**
     * @Method Name        : saveDsctnIdtfItem
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DsctnIdtfItemList
     * @return
    */
    public int saveDsctnIdtfItem(List<Map> DsctnIdtfItemList);
    
    /**
     * @Method Name        : inqureyItemIdtf
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureyItemIdtf(Map argument);
    
    public int saveItemIdtf(List<Map> DsctnIdtfItemList);
    
    public int saveDsctnHistry(List<Map> dsctnHistryList);
    
    public List<Map> inqureyDsctnHistry(Map argument);
    
    public int saveDsctnPrsts(List<Map> dsctnHistryList);
    
    public List<Map> inqureyDsctnPrsts(Map argument);
    
    public List<Map> inqureyDsctnPrstsHistry(Map argument);

    public int saveCheck(List<Map> checkList);

    public List<Map> inqureRfnoCrtnAndDel(Map argument);

    public int saveRfNo(List<Map> arguments);
    
}
