/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.bi.pd.dao.EqDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.annotation.VariableBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 27. 오후 4:12:50
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 27.		변용수						CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class EqServiceImpl implements EqService {

	private static final Logger logger = LoggerFactory.getLogger(EqServiceImpl.class);
	
	@Autowired
	private EqDao eqdao;

	/**
	 * @see htc.lts.bi.pd.service.EqService#insertEq(java.util.Map, java.lang.String)
	 * @Method Name        : insertEq
	 * @Method description : 
	 * @Date               : 2016. 9. 27.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 9. 27.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param eqs
	 * @param paramTest
	*/

	@Override
	@ServiceId("BIPDI002")
	@ServiceName("장비등록")
	@ReturnBind("output")
	public int saveWrshpEq(@DatasetBind("input") List<Map> shipNmEqList) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveWrshpEq, Input Param={}", shipNmEqList); 
        }
        
        int result = 0;
        for (Map shipNmEq : shipNmEqList) {
            String rowType = XPlatformUtil.getDataRowType(shipNmEq);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += eqdao.insertEq(shipNmEq);
                
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += eqdao.updateEq(shipNmEq);
            
            } 
            else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += eqdao.deleteEq(shipNmEq);
            
            }
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveWrshpEq Output ={}", result);
        }
        return result; 
    }
	
	
	/**
	 * @see htc.lts.bi.pd.service.EqService#inqureEq(java.util.Map, java.lang.String)
	 * @Method Name        : inqureEq
	 * @Method description : 
	 * @Date               : 2016. 9. 27.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 9. 27.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param argument
	*/
	@Override
	@ServiceId("BIPDS002")
	@ServiceName("장비관리내역 조회")
    @ReturnBind("output")
	public List<Map> inqureWrshpEq(@DatasetBind("input") Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureWrshpEq, Input Param={}", searchParam); 
        } 
		List<Map> eqList = eqdao.inqureEqList(searchParam);
		
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureWrshpEq Output ={}", eqList);
        }
        
        return eqList;
	}
	
	@Override
	@ServiceId("BIPDD004")
    @ServiceName("함정 삭제")
    @ReturnBind("output")
	public int deleteWrshpEq(@DatasetBind("input") List<Map> shipNmList) {
	    
	    if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveWrshp, Input Param={}", shipNmList); 
        }
        int result = 0;
        for (Map shipNm : shipNmList) {
        	
        	result = eqdao.deleteWrshpEq(shipNm);
        	
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveWrshp Output ={}", result);
        }
        return result; 
	}

}
