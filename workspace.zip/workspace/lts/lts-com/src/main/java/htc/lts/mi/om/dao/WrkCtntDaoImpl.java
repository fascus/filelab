package htc.lts.mi.om.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:30:20
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class WrkCtntDaoImpl extends AbstractHtcDao implements WrkCtntDao {

    @Override
    public List inqueryDsctnIdtfWrkCtntList(Map param) {
        return queryForList("htc.lts.mi.om.hqml.WrkCtntQuery.selectDsctnIdtfWrkCtntList", param);
    }

    @Override
    public int insertDsctnIdtfWrkCtnt(Map DsctnIdtfItem) {
        return update("htc.lts.mi.om.hqml.WrkCtntQuery.insertDsctnIdtfWrkCtnt", DsctnIdtfItem);
    }

    @Override
    public int updateDsctnIdtfWrkCtnt(Map DsctnIdtfItem) {
        return update("htc.lts.mi.om.hqml.WrkCtntQuery.updateDsctnIdtfWrkCtnt", DsctnIdtfItem);
    }

    @Override
    public int deleteDsctnIdtfWrkCtnt(Map DsctnIdtfItem) {
        return update("htc.lts.mi.om.hqml.WrkCtntQuery.deleteDsctnIdtfWrkCtnt", DsctnIdtfItem);
    }

}
