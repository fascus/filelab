/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.mm.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.hone.utils.MapUtil;
import htc.lts.mi.mm.dao.RndshpMtrlsRtnDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:59:12
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class RndshpMtrlsRtnServiceImpl implements RndshpMtrlsRtnService {

    private static final Logger logger = LoggerFactory.getLogger(RndshpMtrlsRtnServiceImpl.class);

    @Autowired
    RndshpMtrlsRtnDao rndshpMtrlsRtnDao;

   
    @Override
    @ServiceId("MIMMS010")
    @ServiceName("부품조회")
    @ReturnBind("output")
    public List<Map> inqureRndshpMtrlsRtnPop(@DatasetBind("input") Map searchParam) {
    	
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureRndshpMtrlsRtnPop, Input Param={}", searchParam); 
        }
        
        List<Map> rndshpMtrlsRtnList = rndshpMtrlsRtnDao.inqureRndshpMtrlsRtnPopList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureRndshpMtrlsRtnPop Output ={}", rndshpMtrlsRtnList);
        }
        
        return rndshpMtrlsRtnList;
    }
    
    @Override
    @ServiceId("MIMMS011")
    @ServiceName("부품조회")
    @ReturnBind("output")
    public List<Map> inqureRndshpMtrlsRtn(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureRndshpMtrlsRtn, Input Param={}", searchParam); 
        }
        
        List<Map> rndshpMtrlsRtnList = rndshpMtrlsRtnDao.inqureRndshpMtrlsRtnList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureRndshpMtrlsRtn Output ={}", rndshpMtrlsRtnList);
        }
        
        return rndshpMtrlsRtnList;
    }
    
    @Override
    @ServiceId("MIMMS015")
    @ServiceName("협력업체조회")
    @ReturnBind("output")
    public List<Map> inqureMntEntp(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureRndshpMtrlsRtn, Input Param={}", searchParam); 
        }
        
        List<Map> rndshpMtrlsRtnList = rndshpMtrlsRtnDao.inqureMntEntpList(searchParam);
        
        MapUtil mapUtil = new MapUtil();
        mapUtil.decryptMapList(rndshpMtrlsRtnList,false,true,"BORNO","TELNO", "FAXNO");
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureRndshpMtrlsRtn Output ={}", rndshpMtrlsRtnList);
        }
        
        return rndshpMtrlsRtnList;
    }
    
    @Override
    @ServiceId("MIMMX010")
    @ServiceName("주요수리내역저장")
    @ReturnBind("output")
    public int saveRndshpMtrlsRtnPop(@DatasetBind("input") List<Map> rndshpMtrlsRtnPopList) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : saveRndshpMtrlsRtnPop, Input Param={}", rndshpMtrlsRtnPopList); 
          }
         
        int result = 0;
        

        //String MGT_NO = null;
        //String RFNO = null;
        //String PN = null;
        String con = null;
        
        Map param = new HashMap();
        
        for (Map rndshpMtrlsRtnPop : rndshpMtrlsRtnPopList) {
            
            param.put("MGT_NO", rndshpMtrlsRtnPop.get("MGT_NO"));
            param.put("RFNO", rndshpMtrlsRtnPop.get("RFNO"));
            param.put("PN", rndshpMtrlsRtnPop.get("PN"));
            
            List<Map> rndshpMtrlsRtnPopList2 = rndshpMtrlsRtnDao.inqureRndshpMtrlsRtnList(param);
              
            if(rndshpMtrlsRtnPopList2.size()==0){
                result +=rndshpMtrlsRtnDao.insertRndshpMtrlsRtn(rndshpMtrlsRtnPop);
            }else{
                for(int i=0; i<rndshpMtrlsRtnPopList2.size(); i++){
                    String MGT_NO = (String) rndshpMtrlsRtnPopList2.get(i).get("MGT_NO");
                    String RFNO = (String) rndshpMtrlsRtnPopList2.get(i).get("RFNO");
                    String PN = (String) rndshpMtrlsRtnPopList2.get(i).get("PN");
                    if(MGT_NO.equals(rndshpMtrlsRtnPop.get("MGT_NO")) && RFNO.equals(rndshpMtrlsRtnPop.get("RFNO")) && PN.equals(rndshpMtrlsRtnPop.get("PN"))){
                        con = "modify";
                        break;
                    }else if(MGT_NO.equals(rndshpMtrlsRtnPop.get("MGT_NO")) && RFNO.equals(rndshpMtrlsRtnPop.get("RFNO")) && !PN.equals(rndshpMtrlsRtnPop.get("PN"))){
                        con = "new";
                    }
                    
                }   
            }
            
            if(con=="modify"){
                result += rndshpMtrlsRtnDao.updateRndshpMtrlsRtn(rndshpMtrlsRtnPop);
            }else if(con=="new"){
                result += rndshpMtrlsRtnDao.insertRndshpMtrlsRtn(rndshpMtrlsRtnPop);
            }
            
            //String rowType = XPlatformUtil.getDataRowType(rndshpMtrlsRtnPop);
//           if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_UPDATED)) {
//               result += rndshpMtrlsRtnDao.updateRndshpMtrlsRtn(rndshpMtrlsRtnPop);
//            }
          }

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : saveRndshpMtrlsRtnPop Output ={}", result);
          }

          return result; 
    }
    
	@Override
	@ServiceId("MIMMU200")
	@ServiceName("사용부품저장")
	@ReturnBind("output")
	public int updateMtnStartDt(@DatasetBind("input") Map rqmMnhr) {
	if(logger.isDebugEnabled()){ 
	      logger.debug("Service Method : createRqmMnhr, Input Param={}", rqmMnhr); 
	  }
	
		int result = 0;
		  
		result += rndshpMtrlsRtnDao.updateMtnStartDt(rqmMnhr);
		  		
		if (logger.isDebugEnabled()) {
			logger.debug("Service Method : createRqmMnhr Output ={}", rqmMnhr);
		}
		      
		return result; 
    }
    
}