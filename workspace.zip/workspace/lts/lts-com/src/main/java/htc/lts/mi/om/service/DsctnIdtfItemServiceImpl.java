package htc.lts.mi.om.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.lts.mi.mm.dao.MngNoDao;
import htc.lts.mi.mm.service.UsePnServiceImpl;
import htc.lts.mi.om.dao.DsctnIdtfItemDao;
import htc.lts.mi.om.dao.WrkCtntDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 19. 오전 10:21:01
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 19.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class DsctnIdtfItemServiceImpl implements DsctnIdtfItemService {

    private static final Logger logger = LoggerFactory.getLogger(UsePnServiceImpl.class);
    
    @Autowired
    DsctnIdtfItemDao dsctnIdtfItemDao;
    
    @Autowired
    MngNoDao mngNoDao;
    
    @Autowired
    WrkCtntDao wrkCtntDao;
    
    /**
     * @see htc.lts.mi.om.service.DsctnIdtfItemService#inqueryDsctnIdtfItemPop(java.util.List)
     * @Method Name        : inqueryDsctnIdtfItemPop
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("MIOMS001")
    @ServiceName("단종관리액셀조회")
    @ReturnBind("output")
    public List<Map> inqueryDsctnIdtfItemPop(@DatasetBind("input") List<Map> searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqueryDsctnIdtfItemPop, Input Param={}", searchParam); 
        }
        
        ArrayList<Map> list = new ArrayList();
        //List<Map> list2 = null; 
        
      for(int i=0; i<searchParam.size(); i++){
          
          List<Map> list2= dsctnIdtfItemDao.inqueryDsctnIdtfItemPopList(searchParam.get(i));
          
          list.addAll(i, list2);
      }
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqueryDsctnIdtfItemPop Output ={}", list);
        }
        
        return list;
    }
    
    /**
     * @see htc.lts.mi.om.service.DsctnIdtfItemService#inqureyDsctnIdtfItem(java.util.Map)
     * @Method Name        : inqureyDsctnIdtfItem
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("MIOMS002")
    @ServiceName("단종관리조회")
    @MultiReturnBind
    public Map<String, List> inqureyDsctnIdtfItem(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureyDsctnIdtfItem, Input Param={}", searchParam); 
        }
        
        List<Map> dsctnIdtfItemList = dsctnIdtfItemDao.inqueryDsctnIdtfItemList(searchParam);
        
        List<Map> count1List = dsctnIdtfItemDao.selectCount1(searchParam);
        
        List<Map> count2List = dsctnIdtfItemDao.selectCount2(searchParam);
        
        List<Map> count3List = dsctnIdtfItemDao.selectCount3(searchParam);
        
        Map<String, List> data = new HashMap<>();
        
        data.put("output1", dsctnIdtfItemList);
        data.put("output2", count1List);
        data.put("output3", count2List);
        data.put("output4", count3List);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureyDsctnIdtfItem Output ={}", dsctnIdtfItemList);
        }
        
        return data;
    }
    
    /**
     * @see htc.lts.mi.om.service.DsctnIdtfItemService#saveDsctnIdtfItem(java.util.List)
     * @Method Name        : saveDsctnIdtfItem
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param DsctnIdtfItemList
     * @return
    */
    @Override
    @ServiceId("MIOMX001")
    @ServiceName("단종관리번호생성")
    @ReturnBind("output")
    public int saveDsctnIdtfItem(@DatasetBind("input") List<Map> DsctnIdtfItemList) {
    	
    	if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveMngNo, Input Param={}", DsctnIdtfItemList); 
        }
        int result = 0;
        
        for (Map mngNo : DsctnIdtfItemList) {
            
            String SHP_TP_CD = mngNo.get("SHP_TP_CD").toString();          //함형
            String ITM_CD =    mngNo.get("ITM_CD").toString();             //정비유형
            String EQCD =      mngNo.get("EQCD").toString();               //함 장비부호 
            String ENTP_CD =   mngNo.get("MTN_ENTP_CD").toString();            //정비업체부호
            String YEAR = 	   mngNo.get("YEAR").toString().substring(2,4);
            String MONTH = 	   mngNo.get("MONTH").toString();
            String mgt =       YEAR+"0"+MONTH;
            
            String MGT_NO = SHP_TP_CD + ITM_CD + mgt;                      //관리번호 
            String RFNO   = ENTP_CD.trim() + EQCD.trim();                  //참조번호
            
            List<Map> searchCtrno = mngNoDao.searchCtrNoList2(mngNo);       //공문번호로 계약번호 검색후 
            
            mngNo.put("CTRNO", searchCtrno.get(0).get("CTRNO").toString()); 
            mngNo.put("CTR_CHNG_SRLNO", searchCtrno.get(0).get("CTR_CHNG_SRLNO").toString());
            
            mngNo.put("MGT_NO", MGT_NO);
            mngNo.put("RFNO", RFNO);
            
            List<Map> masterList = mngNoDao.searchMasterList(mngNo); 
            
            if(masterList.size()==0){
            	result += mngNoDao.insertMngNoMaster(mngNo);
            }
            /*else{
                PlatformData platformData = null;
                XPlatformUtil.setVariable(platformData , "ErrorCode", "-999");
                XPlatformUtil.setVariable(platformData, "ErrorMsg", "중복되는 관리번호가 있습니다");
            }
            */
            List<Map> detailList = mngNoDao.searchDetailList(mngNo); 
            
            if(detailList.size()==0){
            	result += mngNoDao.insertMngNoDetail(mngNo);
            	dsctnIdtfItemDao.insertDsctnIdRslt(mngNo);
            }
            
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveScreen Output ={}", result);
        }

        return result; 
    }
    
    
    /**
     * @see htc.lts.mi.om.service.DsctnIdtfItemService#inqureyItemIdtf(java.util.Map)
     * @Method Name        : inqureyItemIdtf
     * @Method description : 
     * @Date               : 2016. 10. 19.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 19.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("MIOMS003")
    @ServiceName("단종관리품목식별조회")
    @ReturnBind("output")
    public List<Map> inqureyItemIdtf(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureyItemIdtf, Input Param={}", searchParam); 
        }
        
        List<Map> itemIdtfList = dsctnIdtfItemDao.inqueryItemIdtfList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureyItemIdtf Output ={}", itemIdtfList);
        }
        
        return itemIdtfList;
    }
    
    @Override
    @ServiceId("MIOMX201")
    @ServiceName("단종관리완료보고저장")
    @ReturnBind("output")
    public int saveItemIdtf(@DatasetBind("input") List<Map> itemIdtfList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveDsctnIdtfCmplRpt, Input Param={}", itemIdtfList); 
        }
        
        int result = 0;
        for (Map itemIdtf : itemIdtfList) {
            
            
            String rowType = XPlatformUtil.getDataRowType(itemIdtf);
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += dsctnIdtfItemDao.insertDsctnIdtfItem(itemIdtf);
//                List<Map> dsctnPrstsList = dsctnIdtfItemDao.inqueryDsctnPrstsList(itemIdtf);
//                if(dsctnPrstsList.size()==0){
                result += dsctnIdtfItemDao.insertDsctnPrsts(itemIdtf);
//                }
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += dsctnIdtfItemDao.updateDsctnIdtfItem(itemIdtf);
            	//result += dsctnIdtfItemDao.updateDsctnPrsts2(itemIdtf);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += dsctnIdtfItemDao.deleteDsctnIdtfItem(itemIdtf);
                result += dsctnIdtfItemDao.deleteDsctnPrsts(itemIdtf);
                result += dsctnIdtfItemDao.deleteDsctnPrstsHistry(itemIdtf);
                
                
            }
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveDsctnIdtfCmplRpt Output ={}", result);
        }

        return result; 
    }
    
    @Override
    @ServiceId("MIOMX301")
    @ServiceName("단종관리완료보고저장")
    @ReturnBind("output")
    public int saveDsctnHistry(@DatasetBind("input") List<Map> dsctnHistryList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveDsctnIdtfCmplRpt, Input Param={}", dsctnHistryList); 
        }
        
        int result = 0;
        for (Map dsctnHistry : dsctnHistryList) {
            
            String rowType = XPlatformUtil.getDataRowType(dsctnHistry);
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += dsctnIdtfItemDao.insertDsctnHistry(dsctnHistry);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += dsctnIdtfItemDao.updateDsctnHistry(dsctnHistry);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += dsctnIdtfItemDao.deleteDsctnHistry(dsctnHistry);
            }
        }
               

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveDsctnIdtfCmplRpt Output ={}", result);
        }

        return result; 
    }

    @Override
    @ServiceId("MIOMS301")
    @ServiceName("단종이력조회")
    @ReturnBind("output")
    public List<Map> inqureyDsctnHistry(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureyItemIdtf, Input Param={}", searchParam); 
        }
        
        List<Map> dsctnHistryList = dsctnIdtfItemDao.inqueryDsctnHistryList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureyItemIdtf Output ={}", dsctnHistryList);
        }
        
        return dsctnHistryList;
    }
    
    @Override
    @ServiceId("MIOMX302")
    @ServiceName("단종관리완료보고저장")
    @ReturnBind("output")
    public int saveDsctnPrsts(@DatasetBind("input") List<Map> dsctnHistryList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveDsctnIdtfCmplRpt, Input Param={}", dsctnHistryList); 
        }
        
        int result = 0;
        for (Map dsctnHistry : dsctnHistryList) {

        	String rowType = XPlatformUtil.getDataRowType(dsctnHistry);
        	if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {

                List<Map> dsctnPrstsList = dsctnIdtfItemDao.inqueryDsctnPrstsList(dsctnHistry);
                result += dsctnIdtfItemDao.updateDsctnPrsts(dsctnHistry);
                
                if(dsctnPrstsList.get(0).get("ITCHGTM_APLY_TEST_CD")==null){
                	if(!dsctnPrstsList.get(0).get("DSCTN_STATE_CD").toString().equals(dsctnHistry.get("DSCTN_STATE_CD").toString()) || dsctnHistry.get("ITCHGTM_APLY_TEST_CD")!=null){
	                	result += dsctnIdtfItemDao.insertDsctnPrstsHistry(dsctnHistry);
	                }
                }else{
	                if(!dsctnPrstsList.get(0).get("DSCTN_STATE_CD").toString().equals(dsctnHistry.get("DSCTN_STATE_CD").toString()) || !dsctnPrstsList.get(0).get("ITCHGTM_APLY_TEST_CD").toString().equals(dsctnHistry.get("ITCHGTM_APLY_TEST_CD").toString())){
	                	result += dsctnIdtfItemDao.insertDsctnPrstsHistry(dsctnHistry);
	                }
                }
                //result += dsctnIdtfItemDao.updateDsctnIdtfItem2(dsctnHistry);
            }
        	
        }
        

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveDsctnIdtfCmplRpt Output ={}", result);
        }

        return result; 
    }
    
    @Override
    @ServiceId("MIOMS302")
    @ServiceName("단종이력조회")
    @ReturnBind("output")
    public List<Map> inqureyDsctnPrsts(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureyItemIdtf, Input Param={}", searchParam); 
        }
        
        List<Map> dsctnPrstsList = dsctnIdtfItemDao.inqueryDsctnPrstsList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureyItemIdtf Output ={}", dsctnPrstsList);
        }
        
        return dsctnPrstsList;
    }
    
    @Override
    @ServiceId("MIOMS303")
    @ServiceName("단종이력조회")
    @ReturnBind("output")
    public List<Map> inqureyDsctnPrstsHistry(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureyItemIdtf, Input Param={}", searchParam); 
        }
        
        List<Map> dsctnPrstsHistryList = dsctnIdtfItemDao.inqueryDsctnPrstsHistryList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureyItemIdtf Output ={}", dsctnPrstsHistryList);
        }
        
        return dsctnPrstsHistryList;
    }
    
    @Override
    @ServiceId("MIOMX801")
    @ServiceName("단종관리완료보고저장")
    @ReturnBind("output")
    public int saveCheck(@DatasetBind("input") List<Map> checkList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveCheck, Input Param={}", checkList); 
        }
        
        int result = 0;
        for (Map check : checkList) {

        	String rowType = XPlatformUtil.getDataRowType(check);
        	if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += dsctnIdtfItemDao.insertCheck(check);
        	} else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += dsctnIdtfItemDao.deleteCheck(check);
                result += dsctnIdtfItemDao.insertCheck(check);
            }
        	
        }
        

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveCheck Output ={}", result);
        }

        return result; 
    }

    @Override
    @ServiceId("MIOMS008")
    @ReturnBind("output")
    public List<Map> inqureRfnoCrtnAndDel(@DatasetBind("input") Map argument) {

        List<Map> result = dsctnIdtfItemDao.inqureRfnoCrtnAndDel(argument);

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureRfnoCrtnAndDel Output ={}", result);
        }

        return result;
    }
    
        
    @Override
    @ServiceId("MIOMX006")
    @ReturnBind("output")
    public int saveRfNo(@DatasetBind("input") List<Map> arguments) {
       
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveRfNo, Input Param={}", arguments); 
        }
        int result = 0;
            for (Map argument : arguments) {
                //argument.put("RFNO",argument.get("RFNO").toString().substring(10,2));
                String rowType = XPlatformUtil.getDataRowType(argument);
                
                if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    argument.put("RFNO",argument.get("MTN_ENTP_CD").toString().trim() + argument.get("EQCD").toString().trim());
                    result += mngNoDao.insertMngNoDetail(argument);
                    result += dsctnIdtfItemDao.insertDsctnIdRslt(argument);
                    
                } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                    result += mngNoDao.deleteMngNoDetail(argument);
                    result += dsctnIdtfItemDao.deleteDsctnIdRslt(argument);
                }
            }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveRfNo Output ={}", result);
        }

        return result; 
    }
}
