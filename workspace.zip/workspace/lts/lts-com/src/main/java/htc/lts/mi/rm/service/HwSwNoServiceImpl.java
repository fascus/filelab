/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.rm.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.MultiReturnBind;
import htc.hone.annotation.ReturnBind;
import htc.hone.core.message.SystemHeader;
import htc.lts.mi.mm.dao.MngNoDao;
import htc.lts.mi.om.dao.DsctnIdtfItemDao;
import htc.lts.mi.rm.dao.HwSwMntncPldocDao;
import htc.lts.mi.rm.dao.HwSwNoDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date          : 2016. 9. 21. 오후 2:59:12
 * @Author        : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date             Programmer              Description
 * 2016. 9. 21.     이창환                 CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class HwSwNoServiceImpl implements HwSwNoService {

    private static final Logger logger = LoggerFactory.getLogger(HwSwNoServiceImpl.class);

    @Autowired
    MngNoDao mngNoDao;
    
    @Autowired
    DsctnIdtfItemDao dsctnIdtfItemDao;
    
    @Autowired
    HwSwNoDao hwSwNoDao;
    
    @Autowired
    HwSwMntncPldocDao hwSwMntncPldocDao;
    
    
    /**
     * @see htc.lts.mi.rm.service.HwSwNoService#saveMngNo(java.util.List)
     * @Method Name        : saveMngNo
     * @Method description : 
     * @Date               : 2016. 10. 25.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 25.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mngNoList
     * @return
    */
    @Override
    @ServiceId("MIRMX001")
    @ServiceName("단종관리관리번호생성")
    @ReturnBind("output")
    public int saveMngNo(@DatasetBind("input") List<Map> mngNoList) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : saveDsctnIdtfItem, Input Param={}", mngNoList); 
          }
        

        int result = 0;
        
        String preSHP = "";
        String preMgt = "";
        
        for (Map mngNo : mngNoList) {
            //String rowType = XPlatformUtil.getDataRowType(mngNo);
            String mgt = preMgt;
            //System.out.println(preSHP+ "----------------------------------"+mngNo.get("SHP_TP_CD").toString());
            if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){    
                List<Map> searchMgtNo = mngNoDao.searchMngNoList(mngNo);
            
                mgt = searchMgtNo.get(0).get("MGT").toString();
                
            }
              
              String SHP_TP_CD1 = mngNo.get("SHP_TP_CD").toString();          //함형
              String ITM_CD1 =    mngNo.get("ITM_CD").toString();             //정비유형
              String EQCD1 =      mngNo.get("EQCD").toString();               //함 장비부호 
              String ENTP_CD1 =   mngNo.get("ENTP_CD").toString();            //정비업체부호
              
              String MGT_NO = SHP_TP_CD1 + ITM_CD1 + mgt;                      //관리번호 
              String RFNO   = ENTP_CD1.trim() + EQCD1.trim();                  //참조번호
              
              //System.out.println(MGT_NO+ "----------------------------------"+RFNO);
              
             
              /*
              List<Map> searchCtrno = mngNoDao.searchCtrNoList(mngNo);
              for (Map ctrno : searchCtrno) {                                //해당 함형에 따른 계약번호 추출  
                  if(SHP_TP_CD.equals(ctrno.get("SHP_TP_CD"))){
                      mngNo.put("CTRNO", ctrno.get("CTRNO")); 
                      mngNo.put("CTR_CHNG_SRLNO", ctrno.get("CTR_CHNG_SRLNO"));
                      break;
                  }
              }
              */
              
              HashMap<String, String> param = new HashMap<>();
              
              param.put("MGT_NO", MGT_NO);
              param.put("RFNO", RFNO);
              
              List<Map> mgtNoRfNoList = dsctnIdtfItemDao.inqureyMgtNoRfNo(param);       //공문번호로 계약번호 검색후 
              
              mngNo.put("MGT_NO", MGT_NO);
              mngNo.put("RFNO", RFNO);
                  
             if(mgtNoRfNoList.size() > 0){
                 
                 for(Map mgtNoRfNo: mgtNoRfNoList){
                     
                     if(RFNO.equals(mgtNoRfNo.get("RFNO"))){
                         /**
                          * 
                          * 
                          */
                     }else{
                     
                         if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){
                             result += mngNoDao.insertMngNoMaster(mngNo);
                         }
                     
                         result += mngNoDao.insertMngNoDetail(mngNo);
                     }
                 
                 }
                     
             }else{
                 
                 if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){
                     result += mngNoDao.insertMngNoMaster(mngNo);
                 }
                 
                 result += mngNoDao.insertMngNoDetail(mngNo);
             }
             
             mngNo.put("PN", "TEST");
             List<Map> list1 = hwSwNoDao.inqureyMtnPn(mngNo);
             
             
             if(list1.size() == 0){
                 hwSwNoDao.insertMtnPn(mngNo);
             }
             
             List<Map> list2 = hwSwNoDao.inqureyHwSwCmplRpt(mngNo);
             
             if(list2.size() == 0){
                 hwSwNoDao.insertHwSwCmplRpt(mngNo);
                 hwSwMntncPldocDao.insertHwSwMntncPldoc(mngNo);
             }
              
              preMgt = mgt;
              preSHP = mngNo.get("SHP_TP_CD").toString();
                  
              
          }
          

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : saveDsctnIdtfItem Output ={}", result);
          }

          return result; 
    }
    
    
    
    /**
     * @see htc.lts.mi.rm.service.HwSwNoService#inqueryHwSw(java.util.Map)
     * @Method Name        : inqueryHwSw
     * @Method description : 
     * @Date               : 2016. 10. 25.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 25.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("MIRMS001")
    @ServiceName("HW/SW수정개선사항조회")
    @MultiReturnBind
    public Map<String, List> inqueryHwSw(SystemHeader header, @DatasetBind("input") Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqueryHwSw, Input Param={}", searchParam); 
        }
        
        List<Map> hwSwList = hwSwNoDao.inqureHwSwList(searchParam);
                
        List<Map> mirmList = hwSwNoDao.selectMirmIng(searchParam);
        
        Map<String, List> data = new HashMap<>();
        
        data.put("output", hwSwList);
        data.put("mirmIng", mirmList);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqueryHwSw Output ={}", hwSwList);
        }
        
        return data;
    }
    
    
    /**
     * @see htc.lts.mi.rm.service.HwSwNoService#inqureHwSwInfo(java.util.Map)
     * @Method Name        : inqureHwSwInfo
     * @Method description : 
     * @Date               : 2016. 10. 25.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 25.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("MIRMS100")
    @ServiceName("HW/SW조회")
    @ReturnBind("output")
    public List<Map> inqureHwSwInfo(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureHwSwInfo, Input Param={}", searchParam); 
        }
        
        List<Map> hwSwList = hwSwNoDao.inqureHwSwInfoList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureHwSwInfo Output ={}", hwSwList);
        }
        
        return hwSwList;
    }



	/**
	 * @see htc.lts.mi.rm.service.HwSwNoService#saveTrfctr(java.util.List)
	 * @Method Name        : saveTrfctr
	 * @Method description : 
	 * @Date               : 2016. 12. 15.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 12. 15.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param mngNoList
	 * @return
	*/
	
    @Override
    @ServiceId("MIRMX201")
    @ServiceName("단종관리관리번호생성")
    @ReturnBind("output")
	public int saveTrfctr(@DatasetBind("input")List<Map> mngNoList) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveTrfctr, Input Param={}", mngNoList); 
        }
      

      int result = 0;
      
      String preSHP = "";
      String preMgt = "";
      
      for (Map mngNo : mngNoList) {
          //String rowType = XPlatformUtil.getDataRowType(mngNo);
          String mgt = preMgt;
          //System.out.println(preSHP+ "----------------------------------"+mngNo.get("SHP_TP_CD").toString());
          if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){    
              List<Map> searchMgtNo = mngNoDao.searchMngNoList(mngNo);
          
              mgt = searchMgtNo.get(0).get("MGT").toString();
              
          }
          
          List<Map> searchCtrno = mngNoDao.searchCtrNoList2(mngNo);
          
          
          mngNo.put("CTRNO", searchCtrno.get(0).get("CTRNO").toString()); 
          mngNo.put("CTR_CHNG_SRLNO", searchCtrno.get(0).get("CTR_CHNG_SRLNO").toString());
            
            String SHP_TP_CD = mngNo.get("SHP_TP_CD").toString();          //함형
            String ITM_CD =    mngNo.get("ITM_CD").toString();             //정비유형
            String EQCD =      mngNo.get("EQCD").toString();               //함 장비부호 
            String ENTP_CD =   mngNo.get("ENTP_CD").toString();            //정비업체부호
            
            String MGT_NO = SHP_TP_CD + ITM_CD + mgt;                      //관리번호 
            String RFNO   = ENTP_CD.trim() + EQCD.trim();                  //참조번호
            
            //System.out.println(MGT_NO+ "----------------------------------"+RFNO);
            
           
            /*
            List<Map> searchCtrno = mngNoDao.searchCtrNoList(mngNo);
            for (Map ctrno : searchCtrno) {                                //해당 함형에 따른 계약번호 추출  
                if(SHP_TP_CD.equals(ctrno.get("SHP_TP_CD"))){
                    mngNo.put("CTRNO", ctrno.get("CTRNO")); 
                    mngNo.put("CTR_CHNG_SRLNO", ctrno.get("CTR_CHNG_SRLNO"));
                    break;
                }
            }
            */
            
            HashMap<String, String> param = new HashMap<>();
            
            param.put("MGT_NO", MGT_NO);
            param.put("RFNO", RFNO);
            
            List<Map> mgtNoRfNoList = dsctnIdtfItemDao.inqureyMgtNoRfNo(param);       //공문번호로 계약번호 검색후 
            
            mngNo.put("MGT_NO", MGT_NO);
            mngNo.put("RFNO", RFNO);
                
           if(mgtNoRfNoList.size() > 0){
               
               for(Map mgtNoRfNo: mgtNoRfNoList){
                   
                   if(RFNO.equals(mgtNoRfNo.get("RFNO"))){
                       /**
                       **/
                   }else{
                   
                       if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){
                           result += mngNoDao.insertMngNoMaster(mngNo);
                       }
                   
                       result += mngNoDao.insertMngNoDetail(mngNo);
                   }
               
               }
                   
           }else{
               
               if(!preSHP.equals(mngNo.get("SHP_TP_CD").toString())){
                   result += mngNoDao.insertMngNoMaster(mngNo);
               }
               
               result += mngNoDao.insertMngNoDetail(mngNo);
           }
           
           mngNo.put("PN", "TEST");
           List<Map> list1 = hwSwNoDao.inqureyMtnPn(mngNo);
           
           
           if(list1.size() == 0){
               hwSwNoDao.insertMtnPn(mngNo);
           }
           
           List<Map> list2 = hwSwNoDao.inqureyHwSwCmplRpt(mngNo);
           
           if(list2.size() == 0){
               hwSwNoDao.insertHwSwCmplRpt(mngNo);
               hwSwMntncPldocDao.insertHwSwMntncPldoc(mngNo);
           }
            
            preMgt = mgt;
            preSHP = mngNo.get("SHP_TP_CD").toString();
                
            
        }
        

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveTrfctr Output ={}", result);
        }

        return result; 
	}
    
    
    @Override
    @ServiceId("MIRMS004")
    @ServiceName("HW/SW참조번호조회")
    @ReturnBind("output")
    public List<Map> inqureRfnoCrtnAndDel(@DatasetBind("input") Map searchParam) {
        
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureRfnoCrtnAndDel, Input Param={}", searchParam); 
        }
        
        List<Map> hwSwList = hwSwNoDao.inqureRfnoCrtnAndDel(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureRfnoCrtnAndDel Output ={}", hwSwList);
        }
        
        return hwSwList;
    }

    @Override
    @ServiceId("MIRMX004")
    @ReturnBind("output")
    public int saveRfNo(@DatasetBind("input") List<Map> arguments) {
       
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveRfNo, Input Param={}", arguments); 
        }
        int result = 0;
            for (Map argument : arguments) {
                //argument.put("RFNO",argument.get("RFNO").toString().substring(10,2));
                String rowType = XPlatformUtil.getDataRowType(argument);
                
                if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                    argument.put("RFNO",argument.get("ENTP_CD").toString().trim() + argument.get("EQCD").toString().trim());
                    argument.put("PN", "TEST");
                    result += mngNoDao.insertMngNoDetail(argument);
                    
                    List<Map> list1 = hwSwNoDao.inqureyMtnPn(argument);
                    
                    
                    if(list1.size() == 0){
                        hwSwNoDao.insertMtnPn(argument);
                    }
                    
                    List<Map> list2 = hwSwNoDao.inqureyHwSwCmplRpt(argument);
                    
                    if(list2.size() == 0){
                        hwSwNoDao.insertHwSwCmplRpt(argument);
                        hwSwMntncPldocDao.insertHwSwMntncPldoc(argument);
                    }
                    
                } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                    argument.put("PN", "TEST");
                    result += mngNoDao.deleteMngNoDetail(argument);
                    List<Map> list1 = hwSwNoDao.inqureyMtnPn(argument);
                    
                    
                    if(list1.size() != 0){
                        hwSwNoDao.deleteMtnPn(argument);
                    }
                    
                    List<Map> list2 = hwSwNoDao.inqureyHwSwCmplRpt(argument);
                    
                    if(list2.size() != 0){
                        hwSwNoDao.deleteHwSwCmplRpt(argument);
                        hwSwMntncPldocDao.deleteHwSwMntncPldoc(argument);
                    }
                }
            }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveRfNo Output ={}", result);
        }

        return result; 
    }
    
}