/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.ra.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 11. 17. 오전 8:33:46
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 11. 17.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class HwConfigMngtDaoImpl extends AbstractHtcDao implements HwConfigMngtDao {

   @Override
   public List inqureMgtNo(Map argument) {
       return queryForList("htc.lts.bi.ra.hqml.HwConfigMngtQuery.inqureMgtNo", argument);
   }
   
   @Override
   public int insertHwConfigMngt(Map argument) {
       return  update("htc.lts.bi.ra.hqml.HwConfigMngtQuery.insertHwConfigMngt", argument);
   }
   
   @Override
   public int updateHwConfigMngt(Map argument) {
       return  update("htc.lts.bi.ra.hqml.HwConfigMngtQuery.updateHwConfigMngt", argument);
   }
   
   @Override
   public int deleteHwConfigMngt(Map argument) {
       return  update("htc.lts.bi.ra.hqml.HwConfigMngtQuery.deleteHwConfigMngt", argument);
   }
   
   @Override
   public List inqureHwConfigMngt(Map argument) {
       return queryForList("htc.lts.bi.ra.hqml.HwConfigMngtQuery.inqureHwConfigMngt", argument);
   }

   @Override
   public List inqureMaxMgtNo(Map argument) {
       return queryForList("htc.lts.bi.ra.hqml.HwConfigMngtQuery.inqureMaxMgtNo", argument);
   }
   
   @Override
   public List inqureHwLastConfigMngt(Map argument) {
       return queryForList("htc.lts.bi.ra.hqml.HwConfigMngtQuery.inqureHwLastConfigMngt", argument);
   }
   
   @Override
   public List inqureHwSwMgtNo(Map argument) {
       return queryForList("htc.lts.bi.ra.hqml.HwConfigMngtQuery.inqureHwSwMgtNo", argument);
   }
   
   @Override
   public List inqureWrshpNo(Map argument) {
       return queryForList("htc.lts.bi.ra.hqml.HwConfigMngtQuery.inqureWrshpNo", argument);
   }
   
   @Override
   public int insertHwWrkDt(Map argument) {
       return  update("htc.lts.bi.ra.hqml.HwConfigMngtQuery.insertHwWrkDt", argument);
   }
   
   @Override
   public int updateHwWrkDt(Map argument) {
       return  update("htc.lts.bi.ra.hqml.HwConfigMngtQuery.updateHwWrkDt", argument);
   }
   
   @Override
   public int deleteHwWrkDt(Map argument) {
       return  update("htc.lts.bi.ra.hqml.HwConfigMngtQuery.deleteHwWrkDt", argument);
   }
   @Override
   public List inqureHwWrkDt(Map argument) {
       return queryForList("htc.lts.bi.ra.hqml.HwConfigMngtQuery.inqureHwWrkDt", argument);
   }
   
   @Override
   public List inqureHwWrkDt2(Map argument) {
       return queryForList("htc.lts.bi.ra.hqml.HwConfigMngtQuery.inqureHwWrkDt2", argument);
   }
   
   @Override
   public List inqureSwVer(Map argument) {
       return queryForList("htc.lts.bi.ra.hqml.HwConfigMngtQuery.inqureSwVer", argument);
   }
   
   @Override
   public List inqureSwVerWrshpNo(Map argument) {
       return queryForList("htc.lts.bi.ra.hqml.HwConfigMngtQuery.inqureSwVerWrshpNo", argument);
   }
   
   @Override
   public int insertSwWrkDt(Map argument) {
       return  update("htc.lts.bi.ra.hqml.HwConfigMngtQuery.insertSwWrkDt", argument);
   }
   
   @Override
   public int deleteSwWrkDt(Map argument) {
       return  update("htc.lts.bi.ra.hqml.HwConfigMngtQuery.deleteSwWrkDt", argument);
   }
   
   @Override
   public List inqureSwWrkDt(Map argument) {
       return queryForList("htc.lts.bi.ra.hqml.HwConfigMngtQuery.inqureSwWrkDt", argument);
   }
   
   @Override
   public List inqureSwWrkDt2(Map argument) {
       return queryForList("htc.lts.bi.ra.hqml.HwConfigMngtQuery.inqureSwWrkDt2", argument);
   }
}
