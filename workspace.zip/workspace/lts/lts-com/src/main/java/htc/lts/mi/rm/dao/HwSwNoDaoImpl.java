/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.rm.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 3:22:14
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class HwSwNoDaoImpl extends AbstractHtcDao implements HwSwNoDao {

    /**
     * @see htc.lts.mi.rm.dao.HwSwNoDao#inqureyMtnPn(java.util.Map)
     * @Method Name        : inqureyMtnPn
     * @Method description : 
     * @Date               : 2016. 10. 25.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 25.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mngNo
     * @return
    */
    @Override
    public List inqureyMtnPn(Map mngNo) {
        return queryForList("htc.lts.mi.mm.hqml.HwSwNoQuery.selectMtnPnList", mngNo);
    }
    
    /**
     * @see htc.lts.mi.rm.dao.HwSwNoDao#insertMtnPn(java.util.Map)
     * @Method Name        : insertMtnPn
     * @Method description : 
     * @Date               : 2016. 10. 25.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 25.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mngNo
     * @return
    */
    @Override
    public int insertMtnPn(Map mngNo) {
        return  update("htc.lts.mi.mm.hqml.HwSwNoQuery.insertMtnPn", mngNo);
    }
    
    /**
     * @see htc.lts.mi.rm.dao.HwSwNoDao#inqureyHwSwCmplRpt(java.util.Map)
     * @Method Name        : inqureyHwSwCmplRpt
     * @Method description : 
     * @Date               : 2016. 10. 25.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 25.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mngNo
     * @return
    */
    @Override
    public List inqureyHwSwCmplRpt(Map mngNo) {
        return queryForList("htc.lts.mi.mm.hqml.HwSwNoQuery.selectHwSwCmplRptList", mngNo);
    }
    
    /**
     * @see htc.lts.mi.rm.dao.HwSwNoDao#insertHwSwCmplRpt(java.util.Map)
     * @Method Name        : insertHwSwCmplRpt
     * @Method description : 
     * @Date               : 2016. 10. 25.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 25.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param mngNo
     * @return
    */
    @Override
    public int insertHwSwCmplRpt(Map mngNo) {
        return  update("htc.lts.mi.mm.hqml.HwSwNoQuery.insertHwSwCmplRpt", mngNo);
    }
    
    /**
     * @see htc.lts.mi.rm.dao.HwSwNoDao#inqureHwSwList(java.util.Map)
     * @Method Name        : inqureHwSwList
     * @Method description : 
     * @Date               : 2016. 10. 25.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 25.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param hwSw
     * @return
    */
    @Override
    public List inqureHwSwList(Map hwSw) {
        return queryForList("htc.lts.mi.mm.hqml.HwSwNoQuery.selectHwSwList", hwSw);
    }
    
    /**
     * @see htc.lts.mi.rm.dao.HwSwNoDao#inqureHwSwInfoList(java.util.Map)
     * @Method Name        : inqureHwSwInfoList
     * @Method description : 
     * @Date               : 2016. 10. 25.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 25.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param hwSw
     * @return
    */
    @Override
    public List inqureHwSwInfoList(Map hwSw) {
        return queryForList("htc.lts.mi.mm.hqml.HwSwNoQuery.selectHwSwInfoList", hwSw);
    }

	/**
	 * @see htc.lts.mi.rm.dao.HwSwNoDao#selectMirmIng(java.util.Map)
	 * @Method Name        : selectMirmIng
	 * @Method description : 
	 * @Date               : 2016. 10. 27.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 27.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param hwSw
	 * @return
	*/
	
	@Override
	public List selectMirmIng(Map hwSw) {
		return queryForList("htc.lts.mi.mm.hqml.HwSwNoQuery.selectMirmIng", hwSw);
	}
    
    @Override
    public List inqureRfnoCrtnAndDel(Map hwSw) {
        return queryForList("htc.lts.mi.mm.hqml.HwSwNoQuery.inqureRfnoCrtnAndDel", hwSw);
    }
	
    
    @Override
    public int deleteHwSwCmplRpt(Map mngNo) {
        return  update("htc.lts.mi.mm.hqml.HwSwNoQuery.deleteHwSwCmplRpt", mngNo);
    }
    
    
    @Override
    public int deleteMtnPn(Map mngNo) {
        return  update("htc.lts.mi.mm.hqml.HwSwNoQuery.deleteMtnPn", mngNo);
    }
}


