/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.da.qa.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.commons.paging.PagingSupport;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 12. 오후 2:45:20
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 12.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class FaqDaoImpl extends AbstractHtcDao implements FaqDao {

	/**
	 * @see htc.lts.da.qa.dao.FaqDao#inqureFaqList(java.util.Map)
	 * @Method Name        : inqureFaqList
	 * @Method description : 
	 * @Date               : 2016. 10. 12.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 12.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
	public List inqureFaqList(Map searchParam, PagingSupport paging) {
//		return queryForList("htc.lts.da.qa.hqml.FaqQuery.selectFaqList", searchParam);
		return queryForPagingList("htc.lts.da.qa.hqml.FaqQuery.selectFaqList", searchParam, paging);
	}

	/**
	 * @see htc.lts.da.qa.dao.FaqDao#insertFaq(java.util.Map)
	 * @Method Name        : insertFaq
	 * @Method description : 
	 * @Date               : 2016. 10. 12.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 12.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param faq
	 * @return
	*/
	
	@Override
	public int insertFaq(Map faq) {
		return update("htc.lts.da.qa.hqml.FaqQuery.insertFaq", faq);
	}

	/**
	 * @see htc.lts.da.qa.dao.FaqDao#updateFaq(java.util.Map)
	 * @Method Name        : updateFaq
	 * @Method description : 
	 * @Date               : 2016. 10. 12.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 12.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param faq
	 * @return
	*/
	
	@Override
	public int updateFaq(Map faq) {
		return update("htc.lts.da.qa.hqml.FaqQuery.updateFaq", faq);
	}

	/**
	 * @see htc.lts.da.qa.dao.FaqDao#insertCmnt(java.util.Map)
	 * @Method Name        : insertCmnt
	 * @Method description : 
	 * @Date               : 2016. 10. 17.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 17.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmnt
	 * @return
	*/
	
	@Override
	public int insertCmnt(Map cmnt) {
		return update("htc.lts.da.qa.hqml.BoardQuery.insertCmnt", cmnt);
	}

	/**
	 * @see htc.lts.da.qa.dao.FaqDao#updateCmnt(java.util.Map)
	 * @Method Name        : updateCmnt
	 * @Method description : 
	 * @Date               : 2016. 10. 17.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 17.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmnt
	 * @return
	*/
	
	@Override
	public int updateCmnt(Map cmnt) {
		return update("htc.lts.da.qa.hqml.BoardQuery.updateCmnt", cmnt);
	}
	
	

	


}
