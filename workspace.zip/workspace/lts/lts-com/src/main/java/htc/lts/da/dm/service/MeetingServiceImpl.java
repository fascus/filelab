package htc.lts.da.dm.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;
import htc.lts.da.dm.dao.DataDao;
import htc.lts.da.dm.dao.MeetingDao;

/**
 * @Class KorName : 회의자료관리
 * @Date		  : 2016. 10. 13. 오후 6:53:36
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 13.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class MeetingServiceImpl implements MeetingService{

    private static final Logger logger = LoggerFactory.getLogger(MeetingServiceImpl.class);
    
    @Autowired
    private MeetingDao meetingDao;
    
    @Autowired
    private DataDao dataDao;

    /**
     * @see htc.lts.da.dm.service.MeetingService#inqureMeeting(java.util.Map)
     * @Method Name        : inqureMeeting
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("DADMS201")
    @ServiceName("회의자료 조회")
    @ReturnBind("output")
    public List<Map> inqureMeeting(@DatasetBind("input")Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureData, Input Param={}", searchParam);
        } 
        
        List<Map> meetingList = meetingDao.inqureMeetingList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureData Output ={}", meetingList);
        }
        
        return meetingList;
    }
    
 
    /**
     * @see htc.lts.da.dm.service.MeetingService#insertDataList(java.util.List)
     * @Method Name        : insertDataList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    @Override
    @ServiceId("DADMS202")
    @ServiceName("회의자료저장")
    @ReturnBind("output")
    public int insertDataList(@DatasetBind("input") List<Map> searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : insertDataList, Input Param={}", searchParam); 
        }
        
        int result = 0;
        for (Map MeetingList : searchParam) {
            String rowType = XPlatformUtil.getDataRowType(MeetingList);
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                result += meetingDao.insertMeetingList(MeetingList);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += meetingDao.updateMeetingList(MeetingList);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += meetingDao.deleteMeetingList(MeetingList);
            }
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : insertDataList Output ={}", result);
        }
        return result; 
    }
    
    /**
     * @see htc.lts.da.dm.service.MeetingService#inqureFile(java.util.Map)
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    @ServiceId("DADMS203")
    @ReturnBind("output")
    public List<Map> inqureFile(@DatasetBind("input") Map argument) {
        
        argument.put("FILENO", argument.get("CNFRC_ATCHFL_NO"));
        List<Map> result = dataDao.inqureFile(argument);

        return result;
    }

}
