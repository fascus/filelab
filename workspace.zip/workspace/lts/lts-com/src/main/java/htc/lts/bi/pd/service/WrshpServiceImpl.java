/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.bi.pd.dao.WrshpDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 26. 오후 5:26:16
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 26.		변용수            				CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class WrshpServiceImpl implements WrshpService {
    
    private static final Logger logger = LoggerFactory.getLogger(WrshpServiceImpl.class);
    
    @Autowired
    private WrshpDao wrshpDao;

    /**
     * @Method Name        : inqureWrshp
     * @Method description : 
     * @Date               : 2016. 9. 26.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 9. 26.		변용수    					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    
    @Override
    @ServiceId("BIPDS001")
    @ServiceName("함정관리내역 조회")
    @ReturnBind("output")
    public List<Map> inqureWrshp(@DatasetBind("input") Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureWrshp, Input Param={}", searchParam);
        } 
        
        List<Map> wrshpList = wrshpDao.inqureWrshpList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureWrshp Output ={}", wrshpList);
        }
        
        return wrshpList;
    }
    
    /**
     * @Method Name        : insertWrshp
     * @Method description : 
     * @Date               : 2016. 9. 27.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 9. 27.     변용수		                CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param wrshps
     * @param paramTest
    */

	@Override
	@ServiceId("BIPDI001")
    @ServiceName("함정 등록")
    @ReturnBind("output")
	public int saveWrshp(@DatasetBind("input") List<Map> shipNmList) {
	    
	    if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveWrshp, Input Param={}", shipNmList); 
        }
        int result = 0;
        for (Map shipNm : shipNmList) {
            wrshpDao.deleteWrshp(shipNm);
            result += wrshpDao.insertWrshp(shipNm);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveWrshp Output ={}", result);
        }
        return result; 
	}
	
	@Override
    @ServiceId("BIPDI101")
    @ServiceName("함정별 장비 등록")
    @ReturnBind("output")
	public int saveWrshpEq(@DatasetBind("input") List<Map> shipNmEqList) {
	    
	    if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveWrshpEq, Input Param={}", shipNmEqList); 
        }
	    
        int result = 0;
        
        Map data = new HashMap<>();
        data.put("WRSHP_NM", shipNmEqList.get(0).get("WRSHP_NM"));
        
        wrshpDao.deleteWrshpEq(data);
        for (Map shipNmEq : shipNmEqList) {
            //String rowType = XPlatformUtil.getDataRowType(shipNmEq);
            //if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_INSERTED)) {
                result += wrshpDao.insertWrshpEq(shipNmEq);
                
            //} else if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_UPDATED)) {
                //result += wrshpDao.updateWrshpEq(shipNmEq);
            
            //} 
            //else if (rowType.equals(XPlatformUtil.DATASET_ROW_TYPE_DELETED)) {
                //result += wrshpDao.deleteWrshpEq(shipNmEq);
            
            //}
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveWrshpEq, Output ={}", result);
        }
        return result; 
    }
	
	@Override
    @ServiceId("BIPDP100")
    @ServiceName("장비조회")
    @ReturnBind("output")
    public List<Map> inqureEq(@DatasetBind("input") Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureEq, Input Param={}", searchParam); 
        } 
        List<Map> eqList = wrshpDao.inqureEqList(searchParam);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureWrshp, Output ={}", eqList);
        }
        
        return eqList;
    }
	
	@Override
    @ServiceId("BIPDP101")
    @ServiceName("장비모델조회")
    @ReturnBind("output")
    public List<Map> inqureEqModel(@DatasetBind("input") Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureEq, Input Param={}", searchParam); 
        } 
        List<Map> eqList = wrshpDao.inqureEqModelList(searchParam);
        
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureWrshp, Output ={}", eqList);
        }
        
        return eqList;
    }
	
	/**
     * @Method Name        : inqureWrshp
     * @Method description : 
     * @Date               : 2016. 10. 04.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 04.		변용수    					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    
    @Override
    @ServiceId("BIPDS003")
    @ServiceName("구성장비 조회")
    @ReturnBind("output")
    public List<Map> inqureEqNmModel(@DatasetBind("input") Map searchParam) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureEqNmModel, Input Param={}", searchParam);
        } 
        
        List<Map> eqList = wrshpDao.inqureEqNmModelList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureEqNmModel, Output ={}", eqList);
        }
        
        return eqList;
    }
    
	@Override
	@ServiceId("BIPDD003")
    @ServiceName("함정 삭제")
    @ReturnBind("output")
	public int deleteWrshp(@DatasetBind("input") List<Map> shipNmList) {
	    
	    if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveWrshp, Input Param={}", shipNmList); 
        }
        int result = 0;
        for (Map shipNm : shipNmList) {
            wrshpDao.deleteWrshp(shipNm);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveWrshp Output ={}", result);
        }
        return result; 
	}


}
