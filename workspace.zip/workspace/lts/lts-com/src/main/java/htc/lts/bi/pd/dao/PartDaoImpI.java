/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.pd.dao;

import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;
/**
 * @Class KorName : [클래스 한글명]
 * @Date          : 2016. 10. 4. 오후 8:20:47
 * @Author        : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date             Programmer              Description
 * 2016. 10. 4.     강진오                 CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class PartDaoImpI extends AbstractHtcDao implements PartDao {

    /**
     * @Method Name        : inqurePartList
     * @Method description : 
     * @Date               : 2016. 10. 4.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date             Programmer              Description
     * 2016. 10. 4.     강진오                 CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override 
    public List inqurePartList(Map part) {
        return queryForList("htc.lts.bi.pd.hqml.PartQuery.selectPartList", part);
    }
    
    /**
     * @see htc.lts.bi.pd.dao.PartDao#inqurePartMake(java.util.Map)
     * @Method Name        : inqurePartMake
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param part
     * @return
    */
    @Override 
    public List inqurePartMake(Map part) {
        return queryForList("htc.lts.bi.pd.hqml.PartQuery.selectPartMake", part);
    }
    
    /**
     * @see htc.lts.bi.pd.dao.PartDao#insertPart(java.util.Map)
     * @Method Name        : insertPart
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param part
     * @return
    */
    @Override
    public int insertPartMake(Map partmake) {
        return  update("htc.lts.bi.pd.hqml.PartQuery.insertPartMake", partmake);
    }
    
    /**
     * @see htc.lts.bi.pd.dao.PartDao#updatePart(java.util.Map)
     * @Method Name        : updatePart
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param part
     * @return
    */
    @Override
    public int updatePartMake(Map partmake) {
        return  update("htc.lts.bi.pd.hqml.PartQuery.updatePartMake", partmake);
    }
    
    /**
     * @see htc.lts.bi.pd.dao.PartDao#deletePart(java.util.Map)
     * @Method Name        : deletePart
     * @Method description : 
     * @Date               : 2016. 10. 5.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 5.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param part
     * @return
    */
    @Override
    public int deletePartMake(Map partmake) {
        return  update("htc.lts.bi.pd.hqml.PartQuery.deletePartMake", partmake);
    }
    
    /**
     * @see htc.lts.bi.pd.dao.PartDao#insertPartList(java.util.Map)
     * @Method Name        : insertPartList
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param PartList
     * @return
    */
    @Override
    public int insertPartList(Map PartList) {
        return  update("htc.lts.bi.pd.hqml.PartQuery.insertPartList", PartList);
    }
    
    /**
     * @see htc.lts.bi.pd.dao.PartDao#updatPartList(java.util.Map)
     * @Method Name        : updatPartList
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param PartList
     * @return
    */
    @Override
    public int updatePartList(Map PartList) {
        return  update("htc.lts.bi.pd.hqml.PartQuery.updatePartList", PartList);
    }

    /**
     * @see htc.lts.bi.pd.dao.PartDao#deletePartList(java.util.Map)
     * @Method Name        : deletePartList
     * @Method description : 
     * @Date               : 2016. 10. 6.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 6.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param PartList
     * @return
    */
    @Override
    public int deletePartList(Map PartList) {
        return  update("htc.lts.bi.pd.hqml.PartQuery.deletePartList", PartList);
    }
    
    /**
     * @see htc.lts.bi.pd.dao.PartDao#inqureFile(java.util.Map)
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 10.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 10.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    public List inqureFile(Map argument) {
        return queryForList("htc.lts.bi.pd.hqml.PartQuery.inqureFile", argument);
    }
    
    @Override
    public int deleteFile(Map deleteFile) {
        return  update("htc.lts.bi.pd.hqml.PartQuery.deleteFile", deleteFile);
    }
    
    /**
     * @see htc.lts.bi.pd.dao.PartDao#inqureEqNmList(java.util.Map)
     * @Method Name        : inqureEqNmList
     * @Method description : 
     * @Date               : 2016. 11. 2.
     * @Author             : 이창환 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 11. 2.		이창환					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    @Override
    public List inqureEqNmList(Map argument) {
        return queryForList("htc.lts.bi.pd.hqml.PartQuery.selectEqNmList", argument);
    }
}
