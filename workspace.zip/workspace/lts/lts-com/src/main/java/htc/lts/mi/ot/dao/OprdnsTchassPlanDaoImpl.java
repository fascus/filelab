/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.ot.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import hone.bom.dao.core.HoneBaseDaoOperations;
import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 21. 오후 1:51:24
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 21.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class OprdnsTchassPlanDaoImpl extends AbstractHtcDao implements OprdnsTchasstPlanDao {

	/**
	 * @see htc.lts.mi.ot.dao.OprdnsTchasstPlanDao#inqureTchasstPlanList(java.util.Map)
	 * @Method Name        : inqureTchasstPlanList
	 * @Method description : 
	 * @Date               : 2016. 10. 21.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 21.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmplRpt
	 * @return
	*/
	
	@Override
	public List inqureTchasstPlanList(Map cmplRpt) {
		return queryForList("htc.lts.mi.ot.hqml.OprdnsTchassPlanQuery.selectTchasstPlanList", cmplRpt);
	}

	/**
	 * @see htc.lts.mi.ot.dao.OprdnsTchasstPlanDao#insertTchasstPlan(java.util.Map)
	 * @Method Name        : insertTchasstPlan
	 * @Method description : 
	 * @Date               : 2016. 10. 22.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 22.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmplRpt
	 * @return
	*/
	
	@Override
	public int insertTchasstPlan(Map cmplRpt) {
		return  update("htc.lts.mi.ot.hqml.OprdnsTchassPlanQuery.insertTchasstPlan", cmplRpt);
	}

	/**
	 * @see htc.lts.mi.ot.dao.OprdnsTchasstPlanDao#updateTchasstPlan(java.util.Map)
	 * @Method Name        : updateTchasstPlan
	 * @Method description : 
	 * @Date               : 2016. 10. 22.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 22.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param cmplRpt
	 * @return
	*/
	
	@Override
	public int updateTchasstPlan(Map cmplRpt) {
		return  update("htc.lts.mi.ot.hqml.OprdnsTchassPlanQuery.updateTchasstPlan", cmplRpt);
	}

	/**
	 * @see htc.lts.mi.ot.dao.OprdnsTchasstPlanDao#inqureFileList(java.util.Map)
	 * @Method Name        : inqureFileList
	 * @Method description : 
	 * @Date               : 2016. 10. 22.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 22.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param swError
	 * @return
	*/
	
	@Override
	public List inqureFileList(Map swError) {
		return queryForList("htc.lts.mi.ot.hqml.OprdnsTchassPlanQuery.inqureFile", swError);
	}

	/**
	 * @see htc.lts.mi.ot.dao.OprdnsTchasstPlanDao#deleteFile(java.util.Map)
	 * @Method Name        : deleteFile
	 * @Method description : 
	 * @Date               : 2016. 10. 24.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 24.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param deleteFile
	 * @return
	*/
	
	@Override
	public int deleteFile(Map deleteFile) {
		return  update("htc.lts.mi.ot.hqml.OprdnsTchassPlanQuery.deleteFile", deleteFile);
	}

}
