/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.po.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import htc.hone.dao.AbstractHtcDao;


/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 8. 오후 4:28:19
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 8.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */

@Repository
public class PoDaoImpl extends AbstractHtcDao implements PoDao {

    /**
	 * @see htc.lts.bi.po.dao.PoDao#inqurePo(java.util.Map)
	 * @Method Name        : inqurePo
	 * @Method description : 
	 * @Date               : 2016. 12. 6.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 12. 6.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param duseMtrlsRtn
	 * @return
	*/
	
	@Override
	public List inqurePo(Map argument) {
		return queryForList("htc.lts.bi.po.hqml.PoQuery.inqurePo", argument);
	}

	@Override
    public int createPo(Map argument) {
        return update("htc.lts.bi.po.hqml.PoQuery.createPo", argument);
    }
    
    @Override
    public int insertPo(Map argument) {
        return  update("htc.lts.bi.po.hqml.PoQuery.insertPo", argument);
    }
    
    @Override
    public int updatePo(Map argument) {
        return  update("htc.lts.bi.po.hqml.PoQuery.updatePo", argument);
    }
    
    @Override
    public int deletePo(Map argument) {
        return  update("htc.lts.bi.po.hqml.PoQuery.deletePo", argument);
    }
}
