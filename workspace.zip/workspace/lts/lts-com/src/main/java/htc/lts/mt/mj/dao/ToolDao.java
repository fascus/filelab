package htc.lts.mt.mj.dao;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 20. 오후 9:08:33
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 20.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface ToolDao {
   
    /**
     * @Method Name        : inqureToolList
     * @Method description : 
     * @Date               : 2016. 10. 20.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 20.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param tool
     * @return
    */
    public List inqureToolList(Map tool);
    
    public int insertToolList(Map ToolList);
    
    public int updateToolList(Map ToolList);
    
    public int deleteToolList(Map ToolList);
    
    /**
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 24.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 24.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureFile(Map argument);
    
    public int deleteFile(Map deleteFile);
    
    public List inqureTkoutList(Map tool);
    
    public int insertTkoutList(Map TkoutList);
    
    public int updateTkoutList(Map TkoutList);
    public int updateStateCd(Map TkoutList);
    
    public int deleteTkoutList(Map TkoutList);
}
