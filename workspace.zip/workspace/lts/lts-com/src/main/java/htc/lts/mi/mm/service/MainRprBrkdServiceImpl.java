/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.mm.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.mi.mm.dao.MainRprBrkdDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 21. 오후 2:59:12
 * @Author     	  : 이창환
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 21.		이창환					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class MainRprBrkdServiceImpl implements MainRprBrkdService {

    private static final Logger logger = LoggerFactory.getLogger(MainRprBrkdServiceImpl.class);

    @Autowired
    MainRprBrkdDao mainRprBrkdDao;

   
    @Override
    @ServiceId("MIMMS007")
    @ServiceName("주요수리내역조회")
    @ReturnBind("output")
    public List<Map> inqureMainRprBrkd(@DatasetBind("input") Map searchParam) {
    	
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureMainRprBrkd, Input Param={}", searchParam); 
        }
        
        List<Map> mainRprBrkdList = mainRprBrkdDao.inqureMainRprBrkdList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureMainRprBrkd Output ={}", mainRprBrkdList);
        }
        
        return mainRprBrkdList;
    }
    
    @Override
    @ServiceId("MIMMX007")
    @ServiceName("주요수리내역저장")
    @ReturnBind("output")
    public int saveMainRprBrkd(@DatasetBind("input") List<Map> mainRprBrkdList) {
        if(logger.isDebugEnabled()){ 
              logger.debug("Service Method : saveUsePn, Input Param={}", mainRprBrkdList); 
          }
        
          int result = 0;
          
          //Map param = new HashMap();
          
          
          for (Map mainRprBrkd : mainRprBrkdList) {
            String rowType = XPlatformUtil.getDataRowType(mainRprBrkd);
            
            if (XPlatformUtil.DATASET_ROW_TYPE_INSERTED.equals(rowType)) {
                
//                param.put("MGT_NO", mainRprBrkd.get("MGT_NO"));
//                param.put("RFNO", mainRprBrkd.get("RFNO"));0
//                
//                List<Map> mainRprBrkdList2 = mainRprBrkdDao.inqureMainRprBrkdList(param);
                
//                for(int i=0; i<mainRprBrkdList2.size(); i++){
//                    if(mainRprBrkdList2.get(i).get("MGT_NO") == null && mainRprBrkdList2.get(i).get("RFNO") == null){
                        result +=mainRprBrkdDao.insertMainRprBrkd(mainRprBrkd);
//                    }else{
//                        result +=mainRprBrkdDao.updateMainRprBrkd(mainRprBrkd);
//                    }
//                }
            } else if (XPlatformUtil.DATASET_ROW_TYPE_UPDATED.equals(rowType)) {
                result += mainRprBrkdDao.updateMainRprBrkd(mainRprBrkd);
            } else if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                result += mainRprBrkdDao.deleteMainRprBrkd(mainRprBrkd);
            }
          }
                 

          if (logger.isDebugEnabled()) {
              logger.debug("Service Method : saveUsePn Output ={}", result);
          }

          return result; 
    }
}