/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.ot.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hone.bom.annotation.ServiceId;
import hone.bom.annotation.ServiceName;
import htc.hone.annotation.ReturnBind;
import htc.lts.da.dm.dao.DataDao;
import htc.lts.mi.mm.service.MngNoServiceImpl;
import htc.lts.mi.ot.dao.OprdnsTchasstPlanDao;
import htc.xplatform.annotation.DatasetBind;
import htc.xplatform.utils.XPlatformUtil;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 21. 오후 1:49:38
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 21.		변용수					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Service
public class OprdnsTchasstPlanServiceImpl implements OprdnsTchasstPlanService {

	private static final Logger logger = LoggerFactory.getLogger(OprdnsTchasstPlanServiceImpl.class);

	@Autowired
	OprdnsTchasstPlanDao oprdnsTchasstPlanDao;
	
    @Autowired
    private DataDao dataDao;
    
	@Override
    @ServiceId("MIOTX101")
    @ServiceName("전비태세 기술지원 계획서 저장")
    @ReturnBind("output")
    public int saveTchasstPlan(@DatasetBind("input") List<Map> tchasstPlanList) {
        if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : saveTchasstPlan, Input Param={}", tchasstPlanList); 
        }
        
        int result = 0;
//        int result2 = 0;
        Map param = new HashMap();
        
       // List<Map> cmplRptList2 = mngNoDao.inqureCmplRptList(param);
        
        
        for (Map tchasstPlan : tchasstPlanList) {
            
            param.put("MGT_NO", tchasstPlan.get("MGT_NO"));
            param.put("RFNO", tchasstPlan.get("RFNO"));
            
            List<Map> tchasstPlanList2 = oprdnsTchasstPlanDao.inqureTchasstPlanList(param);
            
            for(int i = 0; i < tchasstPlanList2.size(); i++){
                if(tchasstPlanList2.get(i).get("MGT_NO2") == null && tchasstPlanList2.get(i).get("RFNO2") == null){
                    result += oprdnsTchasstPlanDao.insertTchasstPlan(tchasstPlan);
                    if(logger.isDebugEnabled()){
                        logger.debug("입력");
                    }
                    
                }else{
                    result += oprdnsTchasstPlanDao.updateTchasstPlan(tchasstPlan);
                    if(logger.isDebugEnabled()){
                        logger.debug("수정");
                    }
                }
            }
            
        }
     

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : saveTchasstPlan Output ={}", result);
        }

        return result; 
    }
	
	

	/**
	 * @see htc.lts.mi.ot.service.OprdnsTchasstPlanService#inqureTchasstPlan(java.util.Map)
	 * @Method Name        : inqureTchasstPlan
	 * @Method description : 
	 * @Date               : 2016. 10. 21.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 21.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
    @ServiceId("MIOTS101")
    @ServiceName("기술지원계획내용조회")
    @ReturnBind("output")
	public List<Map> inqureTchasstPlan(@DatasetBind("input")Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureTchasstPlan, Input Param={}", searchParam); 
        }
        
        List<Map> chasstPlanList = oprdnsTchasstPlanDao.inqureTchasstPlanList(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureTchasstPlan Output ={}", chasstPlanList);
        }
        
        return chasstPlanList;
	}



	/**
	 * @see htc.lts.mi.ot.service.OprdnsTchasstPlanService#inqureFile(java.util.Map)
	 * @Method Name        : inqureFile
	 * @Method description : 
	 * @Date               : 2016. 10. 22.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 22.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param searchParam
	 * @return
	*/
	
	@Override
    @ServiceId("MIOTS102")
    @ServiceName("첨부파일 조회")
    @ReturnBind("output")
	public List<Map> inqureFile(@DatasetBind("input")Map searchParam) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : inqureFile, Input Param={}", searchParam);
        } 
        
        searchParam.put("FILENO", searchParam.get("OPRDNS_TCHASST_PLAN_ATCHFL_NO"));
        List<Map> fileList = dataDao.inqureFile(searchParam);
                
        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : inqureFile Output ={}", fileList);
        }
        
        return fileList;
	}



	/**
	 * @see htc.lts.mi.ot.service.OprdnsTchasstPlanService#deleteFile(java.util.List)
	 * @Method Name        : deleteFile
	 * @Method description : 
	 * @Date               : 2016. 10. 24.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 10. 24.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param deleteFileList
	 * @return
	*/
	
	@Override
	@ServiceId("MIOTX102")
	@ServiceName("주요수리내역저장")
	@ReturnBind("output")
	public int deleteFile(@DatasetBind("input")List<Map> deleteFileList) {
		if(logger.isDebugEnabled()){ 
            logger.debug("Service Method : deleteFile, Input Param={}", deleteFileList); 
        }
      

		int result = 0;
        
        for (Map deleteFile : deleteFileList) {
            
                String rowType = XPlatformUtil.getDataRowType(deleteFile);
               if (XPlatformUtil.DATASET_ROW_TYPE_DELETED.equals(rowType)) {
                   
                    result +=oprdnsTchasstPlanDao.deleteFile(deleteFile);
                    
                }
        }

        if (logger.isDebugEnabled()) {
            logger.debug("Service Method : deleteFile Output ={}", result);
        }

        return result;
	}
	
	
	
}
