/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.mi.bp.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import htc.hone.dao.AbstractHtcDao;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 10. 11. 오후 10:05:06
 * @Author     	  : 강형순
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 11.		강형순					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
@Repository
public class MiBpDaoImpl extends AbstractHtcDao implements MiBpDao {

    @Override
    public List inqureMtnList(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureMtnList", argument);
    }
    
    @Override
    public List inqureCmplRptList(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.selectCmplRptList", argument);
    }
    
    @Override
    public List selectMimmIng(Map mngNo) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.selectMimmIng", mngNo);
    }
    
    @Override
    public int insertInspRslt(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.insertInspRslt", argument);
    }
    
    @Override
    public int updateInspRslt(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.updateInspRslt", argument);
    }

    @Override
    public int insertFirstInspRslt(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.insertFirstInspRslt", argument);
    }
    
    @Override
    public int insertRslt(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.insertRslt", argument);
    }

    @Override
    public int insertTycd(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.insertTycd", argument);
    }
    
    @Override
    public List inqureInspRslt(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureInspRslt", argument);
    }

    @Override
    public List inqureRslt(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureRslt", argument);
    }
    @Override
    public List inqureTycd(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureTycd", argument);
    }
    
    @Override
    public int deleteRslt(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.deleteRslt", argument);
    }
    
    @Override
    public int deleteTycd(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.deleteTycd", argument);
    }
    
    @Override
    public int insertMtnPlanRslt(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.insertMtnPlanRslt", argument);
    }

    @Override
    public int insertMtnPlanTycd(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.insertMtnPlanTycd", argument);
    }
    
    @Override
    public int deleteMtnPlanRslt(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.deleteMtnPlanRslt", argument);
    }
    
    @Override
    public int deleteMtnPlanTycd(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.deleteMtnPlanTycd", argument);
    }
    
    @Override
    public List inqureMtnPlan(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureMtnPlan", argument);
    }
    
    @Override
    public List inqureMtnPlanRslt(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureMtnPlanRslt", argument);
    }
    
    @Override
    public List inqureMtnPlanTycd(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureMtnPlanTycd", argument);
    }
    
    @Override
    public List inqureTestList(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureTestList", argument);
    }
    
    @Override
    public int updateTestList(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.updateTestList", argument);
    }
    
    @Override
    public int updateMtnPlan(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.updateMtnPlan", argument);
    }
    
    /**
	 * @see htc.lts.mi.bp.dao.MiBpDao#updateMtnDetail(java.util.Map)
	 * @Method Name        : updateMtnDetail
	 * @Method description : 
	 * @Date               : 2016. 11. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param argument
	 * @return
	*/
	
	@Override
	public int updateMtnDetail1(Map argument) {
		return update("htc.lts.mi.bp.hqml.MiBpQuery.updateMtnDetail1", argument);
	}
	
	

	/**
	 * @see htc.lts.mi.bp.dao.MiBpDao#updateMtnDetail2(java.util.Map)
	 * @Method Name        : updateMtnDetail2
	 * @Method description : 
	 * @Date               : 2016. 11. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param argument
	 * @return
	*/
	
	@Override
	public int updateMtnDetail2(Map argument) {
		return update("htc.lts.mi.bp.hqml.MiBpQuery.updateMtnDetail2", argument);
	}

	@Override
    public int insertMtnPlan(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.insertMtnPlan", argument);
    }
    
    @Override
    public List inqurePn(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqurePn", argument);
    }
    
    @Override
    public List inqureUsePnEvidence(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureUsePnEvidence", argument);
    }

    @Override
    public int insertUsePnEvidence(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.insertUsePnEvidence", argument);
    }
    
    @Override
    public int updateUsePnEvidence(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.updateUsePnEvidence", argument);
    }
    
    @Override
    public int deleteUsePnEvidence(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.deleteUsePnEvidence", argument);
    }
    
    @Override
    public List inqureTestListRowCnt(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureTestListRowCnt", argument);
    }
    
    @Override
    public int insertTestList(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.insertTestList", argument);
    }
    
    @Override
    public List inqureInspRsltCnt(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureInspRsltCnt", argument);
    }
    
    @Override
    public List inqureInspDt(Map argument) {
        return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureInspDt", argument);
    }
    
    
    /**
	 * @see htc.lts.mi.bp.dao.MiBpDao#inqureMntDetail(java.util.Map)
	 * @Method Name        : inqureMntDetail
	 * @Method description : 
	 * @Date               : 2016. 11. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param argument
	 * @return
	*/
	
	@Override
	public List inqureMntDetail(Map argument) {
		return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureMntDetail", argument);
	}

	@Override
    public int insertInspDt(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.insertInspDt", argument);
    }
    
    @Override
    public int updateInspDt(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.updateInspDt", argument);
    }
    
    @Override
    public int deleteInspDt(Map argument) {
        return update("htc.lts.mi.bp.hqml.MiBpQuery.deleteInspDt", argument);
    }

	/**
	 * @see htc.lts.mi.bp.dao.MiBpDao#insertChartData(java.util.Map)
	 * @Method Name        : insertChartData
	 * @Method description : 
	 * @Date               : 2016. 11. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param argument
	 * @return
	*/
	
	@Override
	public int insertChartData(Map argument) {
		return update("htc.lts.mi.bp.hqml.MiBpQuery.insertChartData", argument);
	}

	/**
	 * @see htc.lts.mi.bp.dao.MiBpDao#deleteChartData(java.util.Map)
	 * @Method Name        : deleteChartData
	 * @Method description : 
	 * @Date               : 2016. 11. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param argument
	 * @return
	*/
	
	@Override
	public int deleteChartData(Map argument) {
		return update("htc.lts.mi.bp.hqml.MiBpQuery.deleteChartData", argument);
	}

	/**
	 * @see htc.lts.mi.bp.dao.MiBpDao#updateChartData(java.util.Map)
	 * @Method Name        : updateChartData
	 * @Method description : 
	 * @Date               : 2016. 11. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param argument
	 * @return
	*/
	
	@Override
	public int updateChartData(Map argument) {
		return update("htc.lts.mi.bp.hqml.MiBpQuery.updateChartData", argument);
	}

	/**
	 * @see htc.lts.mi.bp.dao.MiBpDao#inqureChartData(java.util.Map)
	 * @Method Name        : inqureChartData
	 * @Method description : 
	 * @Date               : 2016. 11. 30.
	 * @Author             : 변용수 
	 *
	 * <pre>
	 * ------------------------------ Change History -------------------------------
	 * Date				Programmer				Description
	 * 2016. 11. 30.		변용수					CREATE
	 * -----------------------------------------------------------------------------
	 * </pre>
	 * @param argument
	 * @return
	*/
	
	@Override
	public List inqureChartData(Map argument) {
		return queryForList("htc.lts.mi.bp.hqml.MiBpQuery.inqureChartData", argument);
	}


	
    
    

}
