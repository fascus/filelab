package htc.lts.da.dm.dao;

import java.util.List;
import java.util.Map;

/**
 * @Class KorName : 양식함 관리
 * @Date		  : 2016. 10. 14. 오후 1:28:34
 * @Author     	  : 강진오
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 10. 14.		강진오					CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface FrmtDao {
    /**
     * @Method Name        : inqureFrmtList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param frmt
     * @return
    */
    public List inqureFrmtList(Map frmt);
    
    /**
     * @Method Name        : insertFrmtList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param FrmtList
     * @return
    */
    public int insertFrmtList(Map FrmtList);

    /**
     * @Method Name        : updateFrmtList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param FrmtList
     * @return
    */
    public int updateFrmtList(Map FrmtList);

    /**
     * @Method Name        : deleteFrmtList
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param FrmtList
     * @return
    */
    public int deleteFrmtList(Map FrmtList);
    
    /**
     * @Method Name        : inqureFile
     * @Method description : 
     * @Date               : 2016. 10. 14.
     * @Author             : 강진오 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 10. 14.		강진오					CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param argument
     * @return
    */
    public List<Map> inqureFile(Map argument);
}
