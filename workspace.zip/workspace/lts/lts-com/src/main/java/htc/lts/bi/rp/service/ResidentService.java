/**
 * You are strictly prohibited to copy, disclose, distribute, modify, or use this program in part 
 * or as a whole without the prior written consent of Hanwha Thales Co., Ltd.
 * Hanwha Thales Co., Ltd., owns the intellectual property rights in and to this program.
 *
 * (Copyright ⓒ 2016 Hanwha Thales Co., Ltd. All Rights Reserved| Confidential)
 *
 */
package htc.lts.bi.rp.service;

import java.util.List;
import java.util.Map;

import htc.hone.core.message.SystemHeader;

/**
 * @Class KorName : [클래스 한글명]
 * @Date		  : 2016. 9. 28. 오후 4:21:45
 * @Author     	  : 변용수
 *
 * <pre>
 * ------------------------------ Change History -------------------------------
 * Date				Programmer				Description
 * 2016. 9. 28.		변용수						CREATE
 * -----------------------------------------------------------------------------
 * </pre>
 */
public interface ResidentService {
	
	/**
     * @Method Name        : inqureResident
     * @Method description : 
     * @Date               : 2016. 9. 28.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 9. 28.		변용수						CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    public Map<String, List> inqureResident(Map searchParam);
    
    /**
     * @Method Name        : inqureUser
     * @Method description : 
     * @Date               : 2016. 9. 30.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 9. 30.		변용수						CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param searchParam
     * @return
    */
    public List<Map> inqureUser(Map searchParam);
    
    
    /**
     * @Method Name        : saveResident
     * @Method description : 
     * @Date               : 2016. 9. 29.
     * @Author             : 변용수 
     *
     * <pre>
     * ------------------------------ Change History -------------------------------
     * Date				Programmer				Description
     * 2016. 9. 29.		변용수						CREATE
     * -----------------------------------------------------------------------------
     * </pre>
     * @param residentList
     * @return
    */
    public int saveResident(List<Map> residentList);

}
