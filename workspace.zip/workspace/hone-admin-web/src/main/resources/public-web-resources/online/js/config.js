/*
 * Hone Online Module Configuration
 * 새로운 모듈을 만들게 되면 아래 코드를 통해서 꼭 honeModule을 설정해줘야함!
 */
angular.module('app')
	.controller('OnlineModuleCtrl', function($scope, $log, honeConst) {
		$log.debug('OnlineModule config loading.....................');
		var resourcesPath = honeConst.url.contextPath + '/resources/online';
		if (!$scope.$state.get('app.online.service')) {
			app.stateProvider
				.state('app.online.service', {
					url: '/service',
					template: '<div ui-view class="fade-in-up"></div>'
				})
				.state('app.online.service.info', {
					templateUrl: resourcesPath + '/service/serviceinfo.html',
					url: '/info',
					resolve: {
						deps: ['$ocLazyLoad',
							function($ocLazyLoad) {
								return $ocLazyLoad.load([resourcesPath + '/service/serviceinfo.js']);
							}
						]
					}
				})
				.state('app.online.service.infoform/:formType', {
					url: '/infoform/:formType',
					templateUrl: resourcesPath + '/service/service_form.html',
					resolve: {
						deps: ['$ocLazyLoad',
							function($ocLazyLoad) {
								return $ocLazyLoad.load([resourcesPath + '/service/service_form.js']);
							}
						]
					}
				})
				.state('app.online.service.control', {
					templateUrl: resourcesPath + '/service/servicecontrol.html',
					url: '/control',
					resolve: {
						deps: ['$ocLazyLoad',
							function($ocLazyLoad) {
								return $ocLazyLoad.load([resourcesPath + '/service/servicecontrol.js']);
							}
						]
					}
				})
				.state('app.online.service.controlform/:formType', {
					url: '/controlform/:formType',
					templateUrl: resourcesPath + '/service/servicecontrol_form.html',
					resolve: {
						deps: ['$ocLazyLoad',
							function($ocLazyLoad) {
								return $ocLazyLoad.load('bootstrap-tagsinput').then(function() {
									return $ocLazyLoad.load([resourcesPath + '/service/servicecontrol_form.js']);
								});
								
							}
						]
					}
				})
				.state('app.online.instance', {
					templateUrl: resourcesPath + '/instance/instance.html',
					url: '/instance',
					resolve: {
						deps: ['$ocLazyLoad',
							function($ocLazyLoad) {
								return $ocLazyLoad.load([resourcesPath + '/instance/instance.js']);
							}
						]
					}
				})
				.state('app.online.instanceform/:formType', {
					url: '/instanceform/:formType',
					templateUrl: resourcesPath + '/instance/instance_form.html',
					resolve: {
						deps: ['$ocLazyLoad',
							function($ocLazyLoad) {
								return $ocLazyLoad.load([resourcesPath + '/instance/instance_form.js']);
							}
						]
					}
				})
				.state('app.online.monitor', {
					templateUrl: resourcesPath + '/monitor/monitor.html',
					url: '/monitor',
					resolve: {
						deps: ['$ocLazyLoad',
							function($ocLazyLoad) {
								return $ocLazyLoad.load([resourcesPath + '/monitor/monitor.js']);
							}
						]
					}
				})
				.state('app.online.monitordetail/:requestId/:tabId', {
					templateUrl: resourcesPath + '/monitor/monitor_detail.html',
					url: '/detail/:requestId/:tabId',
					resolve: {
						deps: ['$ocLazyLoad',
							function($ocLazyLoad) {
								return $ocLazyLoad.load(resourcesPath + '/monitor/monitor_detail.js');
							}
						]
					}
				})
				.state('app.online.trace/:requestId', {
					templateUrl: resourcesPath + '/monitor/trace.html',
					url: '/trace/:requestId',
					resolve: {
						deps: ['$ocLazyLoad',
							function($ocLazyLoad) {
								return $ocLazyLoad.load([resourcesPath + '/monitor/trace.js']);
							}
						]
					}
				})
				.state('app.online.servicelog/:requestId', {
					templateUrl: resourcesPath + '/monitor/servicelog.html',
					url: '/servicelog/:requestId',
					resolve: {
						deps: ['$ocLazyLoad',
							function($ocLazyLoad) {
								return $ocLazyLoad.load([resourcesPath + '/monitor/servicelog.js']);
							}
						]
					}
				})
				.state('app.online.log', {
					url: '/log',
					template: '<div ui-view class="fade-in-up"></div>'
				})
				.state('app.online.log.control', {
					templateUrl: resourcesPath + '/log/logcontrol.html',
					url: '/control',
					resolve: {
						deps: ['$ocLazyLoad',
							function($ocLazyLoad) {
								return $ocLazyLoad.load([resourcesPath + '/log/logcontrol.js']);
							}
						]
					}
				})
				//state
		}
		$scope.app.currentModule = 'Online';
		$scope.app.currentMenus = [{
			name: 'Instance',
			link: 'instance',
			title: 'Online Application Instance Management',
			description: 'Manage HONE Online Application Instances',
			icon: 'glyphicon glyphicon-certificate text-success-lter',
			subMenus: []
		}, {
			name: 'Service',
			link: 'service',
			title: 'Online Application Service Management',
			description: 'Manage HONE Online Application Services',
			icon: 'glyphicon glyphicon-leaf text-success-lter',
			subMenus: [{
				name: 'Service Info',
				link: 'info',
				title: 'Online Application Service Information',
				description: 'Online Application Service Information'
			}, {
				name: 'Service Control',
				link: 'control',
				title: 'Online Application Service Control',
				description: 'Online Application Service Control'
			}]
		}, {
			name: 'Monitor',
			link: 'monitor',
			title: 'Online Application Service Request Monitoring',
			description: 'Monitoring Service Request',
			icon: 'glyphicon glyphicon-facetime-video text-success-lter',
			subMenus: []
		}, {
			name: 'Log',
			link: 'log',
			title: 'Online Application Log',
			description: 'Application Log',
			icon: 'glyphicon glyphicon-eye-open text-success-lter',
			subMenus: [{
				name: 'Log Control',
				link: 'control',
				title: 'Online Application Log Control',
				description: 'Online Application Log Control'
			}]
		}]; // currentMenus    
	});