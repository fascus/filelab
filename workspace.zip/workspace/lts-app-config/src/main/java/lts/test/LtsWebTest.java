package lts.test;

import java.util.Map;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.AnnotationConfigWebContextLoader;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import htc.hone.core.message.SystemHeader;
import htc.xplatform.web.XPlatformRequestHandler;
import htc.xplatform.web.support.XPlatformRiaArgumentResolver;
import lts.config.test.LtsWebTestConfig;
import lts.config.web.LtsWebConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(loader=AnnotationConfigWebContextLoader.class
, classes={LtsWebTestConfig.class, LtsWebConfig.class})
@TransactionConfiguration(transactionManager="transactionManager", defaultRollback=true)
@Transactional
@ComponentScan(basePackages={"htc"}
)
@WebAppConfiguration
public abstract class LtsWebTest {
    protected MockMvc mockMvc;
    protected SystemHeader header;

    @InjectMocks
    private XPlatformRequestHandler requestHandler;

    @Autowired
    protected WebApplicationContext webApplicationContext;
    
    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(requestHandler)
        		.setCustomArgumentResolvers(new XPlatformRiaArgumentResolver())
        		.build();
        header = new SystemHeader();
    }

    protected Object doTest(String serviceId, Map variables, Map datasets)  {
        try {
			return mockMvc.perform(MockMvcRequestBuilders.get("/ria/" + serviceId))
			.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
    
    

}
