package lts.test;

public class WebRequestBuilder {
	private static WebRequestBuilder instance;
	private String uri;
	private String httpMethod;
	
	public static synchronized WebRequestBuilder build() {
		if(instance == null) {
			instance = new WebRequestBuilder();
		}
		
		return instance;
	}
	
	public WebRequestBuilder uri(String uri) {
		this.uri = uri;
		return this;
	}
	
	public WebRequestBuilder method(String httpMethod) {
		this.httpMethod = httpMethod;
		return this;
	}
	
}
