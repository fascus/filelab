package lts.test;

import org.junit.runner.RunWith;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;
//
import lts.config.test.LtsServiceTestConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={LtsServiceTestConfig.class})
@TransactionConfiguration(transactionManager="transactionManager", defaultRollback=true)
@Transactional
@ComponentScan(basePackages={"htc"}
, excludeFilters=@ComponentScan.Filter(value=Controller.class)
)
@WebAppConfiguration
public class LtsServiceTest {
	
}
