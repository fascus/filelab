package lts.config.test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.jasypt.digest.config.SimpleDigesterConfig;
import org.jasypt.encryption.pbe.PBEStringEncryptor;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.EnvironmentStringPBEConfig;
import org.jasypt.encryption.pbe.config.PBEConfig;
import org.jasypt.spring31.properties.EncryptablePropertyPlaceholderConfigurer;
import org.jasypt.util.password.ConfigurablePasswordEncryptor;
import org.jasypt.util.password.PasswordEncryptor;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.http.converter.json.Jackson2ObjectMapperFactoryBean;
import org.springframework.stereotype.Controller;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.sap.conn.jco.ext.DestinationDataProvider;

import hone.bom.context.ApplicationContextHolder;
import hone.bom.util.StringUtils;
import hone.bom.web.dispatcher.TxServiceRegistry;
import hone.bom.web.dispatcher.registry.AnnotationBasedTxServiceRegistry;
import hone.bom.web.request.RequestContextFilter;
import hone.bom.web.request.RequestContextHandler;
import htc.hone.core.message.support.MessageRepository;
import htc.hone.core.message.support.MessageRepositoryImpl;
import htc.hone.core.message.support.MessageSupport;
import htc.hone.integration.jco.JcoExecutor;
import htc.hone.integration.jco.JcoExecutorImpl;
import htc.hone.web.request.HtcRequestContextHandler;
import lts.config.app.LtsHqmlConfig;
import lts.config.app.LtsIoConfig;
import lts.config.app.LtsJcoConfig;

@Configuration
@ComponentScan(basePackages={"htc"}
//, includeFilters=@ComponentScan.Filter(value=Service.class)
, excludeFilters=@ComponentScan.Filter(value=Controller.class)
)
@ImportResource({"classpath:/config/app/*.xml"})
@Import(value={LtsIoConfig.class, LtsHqmlConfig.class, LtsJcoConfig.class})
public class LtsServiceTestConfig implements ApplicationContextAware, BeanFactoryAware {
 
	private ApplicationContext applicationContext;
	private BeanFactory beanFactory;
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}
	
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		this.beanFactory = beanFactory;
	}

	@Bean
	public Jackson2ObjectMapperFactoryBean jackson2ObjectMapperFactoryBean() {
		Jackson2ObjectMapperFactoryBean factoryBean = new Jackson2ObjectMapperFactoryBean();
		factoryBean.setFeaturesToDisable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, SerializationFeature.FAIL_ON_EMPTY_BEANS);
		factoryBean.setFeaturesToEnable(SerializationFeature.WRITE_BIGDECIMAL_AS_PLAIN);
		return factoryBean;
	}
	
	@Bean(name="objectMapper")
	public ObjectMapper objectMapper() {
		return jackson2ObjectMapperFactoryBean().getObject();
	}
	
	@Bean(name="printObjectMapper")
	public ObjectMapper printObjectMapper() {
		Jackson2ObjectMapperFactoryBean factoryBean = new Jackson2ObjectMapperFactoryBean();
		factoryBean.setFeaturesToDisable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, SerializationFeature.FAIL_ON_EMPTY_BEANS);
		factoryBean.setFeaturesToEnable(SerializationFeature.WRITE_BIGDECIMAL_AS_PLAIN);
		factoryBean.setIndentOutput(true);
		factoryBean.afterPropertiesSet();
		return factoryBean.getObject();
	}

	@Bean
	public ApplicationContextHolder applicationContextHolder() {
		return new ApplicationContextHolder();
	}
	
	@Bean
	public RequestContextHandler requestContextHandler() {
		return new HtcRequestContextHandler();
	}
	
    @Bean
//    (name="hone.bom.web.request.RequestContextFilter")
    public RequestContextFilter requestContextFilter() {
    	List<RequestContextHandler> handlers = new ArrayList<RequestContextHandler>();
    	handlers.add(this.requestContextHandler());
    	
    	RequestContextFilter filter = new RequestContextFilter();
    	filter.setHandlers(handlers);
    	return filter;
    }
    
    @Bean
    public TxServiceRegistry txServiceRegistry() throws Exception {
    	AnnotationBasedTxServiceRegistry txServiceRegistry = new AnnotationBasedTxServiceRegistry();
    	txServiceRegistry.setBeanFactory((ListableBeanFactory) this.beanFactory);
    	return txServiceRegistry;
    }

    @Bean
    public MessageSupport messageSupport() {
    	MessageSupport messageSupport = new MessageSupport();
    	messageSupport.setRepository(repository());
    	
    	return messageSupport;
    }

    @Bean
	public MessageRepository repository() {
		return new MessageRepositoryImpl();
	}

    @Bean
    public PropertyPlaceholderConfigurer propertyPlaceholderConfigurer() {
    	PropertyPlaceholderConfigurer configurer = new EncryptablePropertyPlaceholderConfigurer(pbeStringEncryptor());
    	configurer.setLocation(new ClassPathResource("/config/app.properties"));
    	return configurer;
    }
    
    @Bean 
    public PBEStringEncryptor pbeStringEncryptor() {
    	StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
    	encryptor.setConfig(pbeStringConfig());
    	return encryptor;
    }

    @Bean
	public PBEConfig pbeStringConfig() {
		EnvironmentStringPBEConfig config = new EnvironmentStringPBEConfig();
		config.setAlgorithm("PBEWithMD5AndDES");
		config.setPassword("PWSD");
		return config;
	}
    
    @Bean
    public PasswordEncryptor passwordEncryptor() {
    	ConfigurablePasswordEncryptor encryptor = new ConfigurablePasswordEncryptor();
    	encryptor.setAlgorithm("SHA-256");
    	encryptor.setPlainDigest(true);
    	return encryptor;
    }
   
    
    @Bean
    public JcoExecutor jcoExecutor() {
        return new JcoExecutorImpl();
    }
 
    
}
