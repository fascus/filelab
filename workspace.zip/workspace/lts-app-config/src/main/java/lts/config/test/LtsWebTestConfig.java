package lts.config.test;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.http.converter.json.Jackson2ObjectMapperFactoryBean;
import org.springframework.stereotype.Controller;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import hone.bom.context.ApplicationContextHolder;
import hone.bom.web.dispatcher.TxServiceRegistry;
import hone.bom.web.dispatcher.registry.AnnotationBasedTxServiceRegistry;
import hone.bom.web.request.RequestContextFilter;
import hone.bom.web.request.RequestContextHandler;
import htc.hone.web.request.HtcRequestContextHandler;
import lts.config.app.LtsHqmlConfig;
import lts.config.app.LtsIoConfig;

@Configuration
@ComponentScan(basePackages={"htc"}
//, includeFilters=@ComponentScan.Filter(value=Service.class)
, excludeFilters=@ComponentScan.Filter(value=Controller.class)
)
@ImportResource({"classpath:/config/htc.hone/*.xml"})
@Import(value={LtsIoConfig.class, LtsHqmlConfig.class})
public class LtsWebTestConfig implements ApplicationContextAware, BeanFactoryAware {

	private ApplicationContext applicationContext;
	private BeanFactory beanFactory;
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}
	
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		this.beanFactory = beanFactory;
	}

	@Bean
	public Jackson2ObjectMapperFactoryBean jackson2ObjectMapperFactoryBean() {
		Jackson2ObjectMapperFactoryBean factoryBean = new Jackson2ObjectMapperFactoryBean();
		factoryBean.setFeaturesToDisable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, SerializationFeature.FAIL_ON_EMPTY_BEANS);
		factoryBean.setFeaturesToEnable(SerializationFeature.WRITE_BIGDECIMAL_AS_PLAIN);
		return factoryBean;
	}
	
	@Bean(name="objectMapper")
	public ObjectMapper objectMapper() {
		return jackson2ObjectMapperFactoryBean().getObject();
	}
	
	@Bean(name="printObjectMapper")
	public ObjectMapper printObjectMapper() {
		Jackson2ObjectMapperFactoryBean factoryBean = new Jackson2ObjectMapperFactoryBean();
		factoryBean.setFeaturesToDisable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, SerializationFeature.FAIL_ON_EMPTY_BEANS);
		factoryBean.setFeaturesToEnable(SerializationFeature.WRITE_BIGDECIMAL_AS_PLAIN);
		factoryBean.setIndentOutput(true);
		factoryBean.afterPropertiesSet();
		return factoryBean.getObject();
	}

	@Bean
	public ApplicationContextHolder applicationContextHolder() {
		return new ApplicationContextHolder();
	}
	
	@Bean
	public RequestContextHandler requestContextHandler() {
		return new HtcRequestContextHandler();
	}
	
    @Bean
//    (name="hone.bom.web.request.RequestContextFilter")
    public RequestContextFilter requestContextFilter() {
    	List<RequestContextHandler> handlers = new ArrayList<RequestContextHandler>();
    	handlers.add(this.requestContextHandler());
    	
    	RequestContextFilter filter = new RequestContextFilter();
    	filter.setHandlers(handlers);
    	return filter;
    }
    
    @Bean
    public TxServiceRegistry txServiceRegistry() throws Exception {
    	AnnotationBasedTxServiceRegistry txServiceRegistry = new AnnotationBasedTxServiceRegistry();
    	txServiceRegistry.setBeanFactory((ListableBeanFactory) this.beanFactory);
    	return txServiceRegistry;
    }

}
