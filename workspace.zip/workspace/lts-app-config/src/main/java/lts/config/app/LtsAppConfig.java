package lts.config.app;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.jasypt.digest.config.SimpleDigesterConfig;
import org.jasypt.encryption.pbe.PBEStringEncryptor;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.EnvironmentStringPBEConfig;
import org.jasypt.encryption.pbe.config.PBEConfig;
import org.jasypt.properties.EncryptableProperties;
import org.jasypt.spring31.properties.EncryptablePropertyPlaceholderConfigurer;
import org.jasypt.util.password.ConfigurablePasswordEncryptor;
import org.jasypt.util.password.PasswordEncryptor;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.converter.json.Jackson2ObjectMapperFactoryBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.PlatformTransactionManager;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import hone.bom.context.ApplicationContextHolder;
import hone.bom.context.BomRuntimeContextHolder;
import hone.bom.modules.ModuleBeanFactoryWrapper;
import hone.bom.web.aop.ProfileForAllAdvice;
import hone.bom.web.dispatcher.TxServiceDescriptorStore;
import hone.bom.web.dispatcher.TxServiceRegistry;
import hone.bom.web.dispatcher.registry.AnnotationBasedTxServiceRegistry;
import hone.bom.web.dispatcher.store.TxServiceDescriptorDatabaseStore;
import hone.bom.web.request.RequestContextFilter;
import hone.bom.web.request.RequestContextHandler;
import htc.hone.core.message.support.MessageRepository;
import htc.hone.core.message.support.MessageRepositoryImpl;
import htc.hone.core.message.support.MessageSupport;
import htc.hone.integration.jco.JcoExecutor;
import htc.hone.integration.jco.JcoExecutorImpl;
import htc.hone.web.request.HtcRequestContextHandler;
import htc.xplatform.web.HtcConstants;

@Configuration
@EnableAspectJAutoProxy(proxyTargetClass = true)
@ComponentScan(basePackages = { "htc" }, excludeFilters = @ComponentScan.Filter(value = Controller.class))
@ImportResource({ "classpath:/config/app/*.xml" })
@Import(value = { LtsIoConfig.class, LtsHqmlConfig.class, LtsMonitorConfig.class , LtsJcoConfig.class
//		, LtsSecureConfig.class 
		})
public class LtsAppConfig implements ApplicationContextAware, BeanFactoryAware {

	private ApplicationContext applicationContext;
	private BeanFactory beanFactory;

	@Resource(name="honeDataSource")
	private DataSource honeDataSource;
	
//	@Resource(name="honeJdbcTemplate")
//	private JdbcTemplate honeJdbcTemplate;
//
//   @Resource(name="honeTxManager")
//    private PlatformTransactionManager honeTxManager;


	@Autowired(required=false)
	private ModuleBeanFactoryWrapper moduleBeanFactoryWrapper;

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		this.beanFactory = beanFactory;
	}

	@Bean
	public ProfileForAllAdvice profileForAllAdvice() {
		return new ProfileForAllAdvice();
	}
	
//	@Bean
//	public AnnotationAwareAspectJAutoProxyCreator annotationAwareAspectJAutoProxyCreator() {
//		AnnotationAwareAspectJAutoProxyCreator aop = new AnnotationAwareAspectJAutoProxyCreator();
//		return aop;
//	}

	@Bean
	public BomRuntimeContextHolder bomRuntimeContextHolder() {
		BomRuntimeContextHolder holder = new BomRuntimeContextHolder();
		holder.setApplicationContext(applicationContext);
		return holder;
	}

	@Bean
	public Jackson2ObjectMapperFactoryBean jackson2ObjectMapperFactoryBean() {
		Jackson2ObjectMapperFactoryBean factoryBean = new Jackson2ObjectMapperFactoryBean();
		factoryBean.setFeaturesToDisable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
				SerializationFeature.FAIL_ON_EMPTY_BEANS);
		factoryBean.setFeaturesToEnable(SerializationFeature.WRITE_BIGDECIMAL_AS_PLAIN);
		return factoryBean;
	}

	@Bean(name = "objectMapper")
	public ObjectMapper objectMapper() {
		return jackson2ObjectMapperFactoryBean().getObject();
	}

	@Bean(name = "printObjectMapper")
	public ObjectMapper printObjectMapper() {
		Jackson2ObjectMapperFactoryBean factoryBean = new Jackson2ObjectMapperFactoryBean();
		factoryBean.setFeaturesToDisable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
				SerializationFeature.FAIL_ON_EMPTY_BEANS);
		factoryBean.setFeaturesToEnable(SerializationFeature.WRITE_BIGDECIMAL_AS_PLAIN);
		factoryBean.setIndentOutput(true);
		factoryBean.afterPropertiesSet();
		return factoryBean.getObject();
	}

	@Bean
	public ApplicationContextHolder applicationContextHolder() {
		return new ApplicationContextHolder();
	}

	@Bean
	public RequestContextHandler requestContextHandler() {
		return new HtcRequestContextHandler();
	}

	@Bean
	public RequestContextFilter requestContextFilter() {
		List<RequestContextHandler> handlers = new ArrayList<RequestContextHandler>();
		handlers.add(this.requestContextHandler());

		RequestContextFilter filter = new RequestContextFilter();
		filter.setHandlers(handlers);
		return filter;
	}

//	@Bean
//	public TxServiceRegistry txServiceRegistry() throws Exception {
//		AnnotationBasedTxServiceRegistry txServiceRegistry = new AnnotationBasedTxServiceRegistry();
//		txServiceRegistry.setBeanFactory((ListableBeanFactory) this.beanFactory);
//		return txServiceRegistry;
//	}

	@Bean
	public MessageSupport messageSupport() {
		MessageSupport messageSupport = new MessageSupport();
		messageSupport.setRepository(repository());

		return messageSupport;
	}

	@Bean
	public MessageRepository repository() {
		return new MessageRepositoryImpl();
	}

	@Bean(name = {"app", "honeProp"})
	public Properties properties() {
		Properties properties = new EncryptableProperties(pbeStringEncryptor());
		try (final InputStream stream = this.getClass().getResourceAsStream(HtcConstants.APP_PROPERTIES_LOCATION)) {
			properties.load(stream);
			/* or properties.loadFromXML(...) */
		} catch (IOException e) {
			throw new RuntimeException("Loading properties failed. [" + HtcConstants.APP_PROPERTIES_LOCATION + "]", e);
		}

		return properties;

	}

	@Bean(name = { "enc" })
	public PropertyPlaceholderConfigurer encryptablePropertyPlaceholderConfigurer() {
		PropertyPlaceholderConfigurer configurer = new EncryptablePropertyPlaceholderConfigurer(pbeStringEncryptor());
		configurer.setLocation(new ClassPathResource(HtcConstants.APP_PROPERTIES_LOCATION));
		return configurer;
	}

	@Bean
	public PBEStringEncryptor pbeStringEncryptor() {
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setConfig(pbeStringConfig());
		return encryptor;
	}

	@Bean
	public PBEConfig pbeStringConfig() {
		EnvironmentStringPBEConfig config = new EnvironmentStringPBEConfig();
		config.setAlgorithm("PBEWithMD5AndDES");
		config.setPassword("Lts!339");
		return config;
	}

	@Bean
	public PasswordEncryptor passwordEncryptor() {
		ConfigurablePasswordEncryptor encryptor = new ConfigurablePasswordEncryptor();
		SimpleDigesterConfig config = new SimpleDigesterConfig();
		config.setAlgorithm("SHA-256");
		config.setIterations(2190);
		config.setSaltSizeBytes(11);
		encryptor.setConfig(config);
		return encryptor;
	}

//	@Bean
//	@DependsOn("honeJdbcTemplate")
//	public TxServiceDescriptorStore descriptorStore() {
//		if(honeJdbcTemplate == null) {
//			honeJdbcTemplate = applicationContext.getBean("honeJdbcTemplate", JdbcTemplate.class);
//		}
//		
//		if(honeTxManager == null) {
//			honeTxManager = applicationContext.getBean(PlatformTransactionManager.class);
//		}
//		
//		TxServiceDescriptorDatabaseStore descriptorStore = new TxServiceDescriptorDatabaseStore();
//		descriptorStore.setJdbcTemplate(honeJdbcTemplate);
//		descriptorStore.setTransactionManager(honeTxManager);
//		return descriptorStore;
//	}
	
//	@Bean
//	public JdbcTemplate honeJdbcTemplate() {
//		JdbcTemplate jdbcTemplate = new JdbcTemplate(honeDataSource);
//		return jdbcTemplate;
//	}
	@Bean(name="honeJdbcTemplate")
	public JdbcTemplate honeJdbcTemplate() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		jdbcTemplate.setDataSource(applicationContext.getBean("honeDataSource", DataSource.class));
		return jdbcTemplate;
	}

	
	public TxServiceDescriptorStore descriptorStore() {
		TxServiceDescriptorDatabaseStore descriptorStore = new TxServiceDescriptorDatabaseStore();
		descriptorStore.setJdbcTemplate(honeJdbcTemplate());
		descriptorStore.setTransactionManager(honeTransactionManager());
		return descriptorStore;
	}
	
	
	@Bean(name="honeTransactionManager")
	public PlatformTransactionManager honeTransactionManager() {
		DataSourceTransactionManager manager = new DataSourceTransactionManager(applicationContext.getBean("honeDataSource", DataSource.class));
		return manager;
	}

	@Bean(name="hone.service.TxServiceRegistry")
	public TxServiceRegistry txServiceRegistry() {
		AnnotationBasedTxServiceRegistry registry = new AnnotationBasedTxServiceRegistry();
		registry.setBeanFactory((ListableBeanFactory) this.beanFactory);
		registry.setTxServiceDescriptorStore(descriptorStore());
		return registry;
	}
    
    @Bean
    public JcoExecutor jcoExecutor() {
        return new JcoExecutorImpl();
    }
 

}
