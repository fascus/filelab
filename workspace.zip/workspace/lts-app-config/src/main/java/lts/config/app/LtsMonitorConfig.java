package lts.config.app;

import javax.sql.DataSource;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import hone.bom.rpc.server.RpcServer;
import hone.bom.rpc.spring.RpcApplicationContextStopEventListener;
import hone.bom.rpc.spring.RpcServerFactoryBean;
import hone.bom.rpc.spring.RpcServiceRegisterBeanFactoryPostProcessor;
import hone.monitor.online.log.LogControl;
import hone.monitor.online.log.impl.LogControlImpl;
import hone.monitor.online.modules.ModuleReloadService;
import hone.monitor.online.modules.ModuleReloadServiceImpl;
import hone.monitor.online.services.ServicesControl;
import hone.monitor.online.services.impl.ServicesControlImpl;
import hone.monitor.online.store.ManagedStoreControl;
import hone.monitor.online.store.ManagedStoreControlImpl;

@Configuration
public class LtsMonitorConfig implements ApplicationContextAware  {
	ApplicationContext applicationContext;
	
	@Bean(name="nettyRpcServer")
	public static RpcServer nettyRpcServer() throws Exception {
		return new RpcServerFactoryBean().getObject();
	}
	
	
	@Bean(name="hone.bom.rpc.spring.RpcServiceRegisterBeanFactoryPostProcessor")
	public static RpcServiceRegisterBeanFactoryPostProcessor rpcServerPostProcessor() throws Exception {
		RpcServiceRegisterBeanFactoryPostProcessor processor = new RpcServiceRegisterBeanFactoryPostProcessor();
		processor.setRpcServer(nettyRpcServer());
		return processor;
	}
	
	@Bean
	public RpcApplicationContextStopEventListener rpcApplicationContextStopEventListener() {
		return new RpcApplicationContextStopEventListener();
	}
	
	
	@Bean
	public ServicesControl serviceControl() {
		ServicesControl control = new ServicesControlImpl();
		return control;
	}
	
	@Bean
	public LogControl logControl() {
		LogControl logControl = new LogControlImpl();
		return logControl;
	}
	
	@Bean
	public ModuleReloadService moduleReloadService() {
		ModuleReloadService moduleReloadService = new ModuleReloadServiceImpl();
		return moduleReloadService;
	}
	
	@Bean 
	public ManagedStoreControl managedStoreControl() {
		ManagedStoreControl storeControl = new ManagedStoreControlImpl();
		return storeControl;
	}


	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}
	
	
}
