package lts.config.app;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.util.StringUtils;

import com.sap.conn.jco.ext.DestinationDataEventListener;
import com.sap.conn.jco.ext.DestinationDataProvider;
import com.sap.conn.jco.ext.Environment;
import com.sap.conn.jco.ext.ServerDataEventListener;
import com.sap.conn.jco.ext.ServerDataProvider;

import htc.hone.integration.jco.JcoExecutor;
import htc.hone.integration.jco.JcoExecutorImpl;

@Configuration
public class LtsJcoConfig implements InitializingBean {
	private static final Logger logger = LoggerFactory.getLogger(LtsJcoConfig.class);
    public final static String JCO_PROPERTIES_LOCATION = "config/jco.properties";
    
    public final static String JCO_CREDENTIAL_PROPERTIES_LOCATION = "config/jco_credential.properties";

    public final static String[] JCO_DESTINATION_PROPS = new String[] {
            DestinationDataProvider.JCO_ASHOST, DestinationDataProvider.JCO_SYSNR, DestinationDataProvider.JCO_CLIENT, 
            DestinationDataProvider.JCO_MSHOST, DestinationDataProvider.JCO_R3NAME, DestinationDataProvider.JCO_GROUP
        };

	@Override
	public void afterPropertiesSet() throws Exception {
		try {
			Environment.registerDestinationDataProvider(destinationProvider());
			Environment.registerServerDataProvider(serverDataProvider());
		} catch (ExceptionInInitializerError e) {
			logger.error(e.getMessage(), e);
			if(e.getMessage().indexOf("already") < 0) {
				throw e;
			}
		}
	}
	
	@Bean
	public JcoExecutor jcoExecutor() {
		return new JcoExecutorImpl();
	}

	private ServerDataProvider serverDataProvider() {
		return new ServerDataProvider() {
			private Properties properties;
			
			@Override
			public boolean supportsEvents() {
				return false;
			}
			
			@Override
			public void setServerDataEventListener(ServerDataEventListener paramServerDataEventListener) {
			}
			
			@Override
			public Properties getServerProperties(String paramString) {
				return jcoProperties();
			}
			
		};
	}

	private DestinationDataProvider destinationProvider() {
		return new DestinationDataProvider() {
			
			@Override
			public boolean supportsEvents() {
				return false;
			}
			
			@Override
			public void setDestinationDataEventListener(DestinationDataEventListener paramDestinationDataEventListener) {
				
			}
			
			@Override
			public Properties getDestinationProperties(String paramString) {
				return jcoProperties();
			}
		};
	}
	
	@Bean(name="jcoProperties")
	public Properties jcoProperties() {
//		InputStream jcoInputStream = getClass().getClassLoader().getResourceAsStream(JCO_PROPERTIES_LOCATION);
//		InputStream jcoCredentialInputStream = getClass().getClassLoader().getResourceAsStream(JCO_CREDENTIAL_PROPERTIES_LOCATION);
		Properties jcoProperties;
		Properties jcoCredentialProperties;
		Resource jcoResource = new ClassPathResource(JCO_PROPERTIES_LOCATION);
		Resource jcoCredentialResource = new ClassPathResource(JCO_CREDENTIAL_PROPERTIES_LOCATION);
//		PropertiesLoaderUtils.loadProperties(resource);
		try {
			jcoProperties = PropertiesLoaderUtils.loadProperties(jcoResource);
			jcoCredentialProperties = PropertiesLoaderUtils.loadProperties(jcoCredentialResource);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		
		// 인증 정보 있을 때 처리
		if(jcoCredentialProperties != null && !jcoCredentialProperties.isEmpty()) {
			if(jcoProperties.containsKey("jco.client.user") && StringUtils.hasText(jcoProperties.getProperty("jco.client.user"))) {
                String password = jcoCredentialProperties.getProperty(jcoProperties.getProperty("jco.client.user"));
                if(StringUtils.hasText(password)) {
                	jcoProperties.setProperty("jco.client.passwd", password);

                    //JCO 접속정보 설정
                    for(String propName : JCO_DESTINATION_PROPS) {
                    	jcoProperties.remove(propName);
                        String propValue = jcoCredentialProperties.getProperty(propName);
                        if(StringUtils.hasText(propValue)) {
                        	jcoProperties.setProperty(propName, propValue);
                        }
                    }
                }
			}
		}
		if(logger.isDebugEnabled()) {
			logger.debug("================== JCO PROPERTIES START ====================");
			Enumeration<Object> jcoKeys = jcoProperties.keys();
			while(jcoKeys.hasMoreElements()) {
				Object key = jcoKeys.nextElement();
				Object value = jcoProperties.get(key);
				logger.debug(key + " ==> " + value);
			}
			logger.debug("================== JCO PROPERTIES END   ====================");
		}
		
		return jcoProperties;

	}
	
}
