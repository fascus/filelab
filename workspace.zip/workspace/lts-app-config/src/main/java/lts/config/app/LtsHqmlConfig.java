package lts.config.app;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import hone.bom.dao.hqml.dynamic.DynamicSqlBuilderFactory;
import hone.bom.dao.hqml.dynamic.fm.FreemarkerSqlBuilderFactory;
import hone.bom.dao.hqml.loader.HqmlDocumentLoader;
import hone.bom.dao.hqml.loader.fs.ClasspathHqmlDocumentLoader;
import hone.bom.dao.hqml.provider.HoneDbioProvider;
import hone.bom.dao.hqml.provider.StatementProvider;

@Configuration
public class LtsHqmlConfig implements ApplicationContextAware {

	private ApplicationContext applicationContext;
	
	@Resource(name="dataSource")
	private DataSource dataSource;

	@Bean(name="hone.bom.dao.hqml.provider.StatementProvider")
	public StatementProvider statementProvider() {
		HoneDbioProvider dbioProvider = new HoneDbioProvider();

		dbioProvider.setHqmlDocumentLoader(hqmlDocumentLoader());
		dbioProvider.setDynamicSqlBuilderFactory(dynamicSqlBuilderFactory());
		dbioProvider.setPreload(true);
		return dbioProvider;
	}

	
	@Bean
	public HqmlDocumentLoader hqmlDocumentLoader() {
		ClasspathHqmlDocumentLoader loader = new ClasspathHqmlDocumentLoader();
		loader.setLocationPattern("classpath*:/htc/**/*.hqml");
		return loader;
	}


	@Bean
	public DynamicSqlBuilderFactory dynamicSqlBuilderFactory() {
		return new FreemarkerSqlBuilderFactory();
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	
}
