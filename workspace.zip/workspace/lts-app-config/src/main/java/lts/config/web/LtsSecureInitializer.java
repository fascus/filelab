package lts.config.web;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class LtsSecureInitializer extends AbstractSecurityWebApplicationInitializer {

}
