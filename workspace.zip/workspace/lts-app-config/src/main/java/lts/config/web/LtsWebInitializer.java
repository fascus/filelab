package lts.config.web;

import javax.servlet.FilterRegistration;
import javax.servlet.MultipartConfigElement;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;
import javax.servlet.ServletRegistration.Dynamic;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.filter.DelegatingFilterProxy;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import hone.bom.web.log.LogbackConfigListener;
import htc.hone.web.filter.CORSFilter;
import htc.hone.web.servlet.FileUploadServlet;
import htc.xplatform.web.HtcConstants;
import lts.config.app.LtsAppConfig;

public class LtsWebInitializer extends AbstractAnnotationConfigDispatcherServletInitializer implements WebApplicationInitializer {

	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		
		// Logback Configuration
		servletContext.setInitParameter("logbackConfigLocation", "classpath:config/log/logback.xml");
		servletContext.addListener(new LogbackConfigListener());

		super.onStartup(servletContext);
		
		FilterRegistration.Dynamic corsFilterChain = servletContext.addFilter("corsFilter", new CORSFilter());
		corsFilterChain.addMappingForUrlPatterns(null, false, "/*");
		
		CharacterEncodingFilter encodingFilter = new CharacterEncodingFilter();
		encodingFilter.setEncoding("UTF-8");
		FilterRegistration.Dynamic encodingFilterChaing = servletContext.addFilter("encodingFilter", encodingFilter);
		encodingFilterChaing.addMappingForUrlPatterns(null, false, "/*");
		
		FilterRegistration.Dynamic requestContextFilter = servletContext.addFilter("requestContextFilter", new DelegatingFilterProxy());
		requestContextFilter.addMappingForUrlPatterns(null, false, "/*");

		// Weblogic 의 경우 SecureInintializer 작동 비정상이므로 해당 설정 필요.
		String server = servletContext.getServerInfo();
		logger.info("Current Running Servier is [" + server + "]");
		if(server.indexOf("Tomcat") < 0) {
			FilterRegistration.Dynamic springSecurityFilterChain = servletContext.addFilter("springSecurityFilterChain", new DelegatingFilterProxy());
			springSecurityFilterChain.addMappingForUrlPatterns(null, false, "/*");
			springSecurityFilterChain.setAsyncSupported(true);
		}

	}
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class<?>[] { LtsAppConfig.class
			, LtsSecureConfig.class
		};
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class<?>[] { LtsWebConfig.class };
	}

	@Override
	protected String getServletName() {
		return super.getServletName();
	}

	@Override
	protected String[] getServletMappings() {
		return new String[] { "/" };
	}

}
