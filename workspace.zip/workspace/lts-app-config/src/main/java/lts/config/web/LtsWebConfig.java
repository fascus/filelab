package lts.config.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.accept.ContentNegotiationManager;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import com.fasterxml.jackson.databind.ObjectMapper;

import hone.bom.web.dispatcher.TxCodeResolver;
import hone.bom.web.dispatcher.TxServiceRegistry;
import hone.bom.web.request.RequestContextFilter;
import hone.bom.web.request.RequestContextHandler;
import htc.commons.file.web.FileController;
import htc.hone.web.JsonRequestHandler;
import htc.hone.web.support.JsonMessageArgumentResolver;
import htc.hone.web.support.JsonMessageReturnValueHandler;
import htc.xplatform.message.HtcXplatformMessage;
import htc.xplatform.web.HtcXPlatformTxCodeResolver;
import htc.xplatform.web.XPlatformRequestHandler;
import htc.xplatform.web.exception.XplatformExceptionResolver;
import htc.xplatform.web.handler.XPlatformDataHandler;
import htc.xplatform.web.handler.XPlatformRiaDataHandler;
import htc.xplatform.web.mav.XPlatformMapView;
import htc.xplatform.web.support.XPlatformRiaArgumentResolver;
import htc.xplatform.web.support.XPlatformRiaReturnValueHandler;
import htc.xplatform.web.support.XplatformDataParser;

@Configuration
@EnableWebMvc
public class LtsWebConfig extends WebMvcConfigurerAdapter implements ApplicationContextAware {

	private ApplicationContext applicationContext;
	
	@Resource(name="transactionManager")
	private PlatformTransactionManager transactionManager;

	@Resource(name="objectMapper")
	private ObjectMapper objectMapper;

	@Autowired
	private TxServiceRegistry txServiceRegistry;

	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		configurer.enable();
	}

//	@Bean
//	public ViewResolver contentNegotiatingViewResolver(ContentNegotiationManager manager) {
//	    ContentNegotiatingViewResolver resolver = new ContentNegotiatingViewResolver();
//	    resolver.setContentNegotiationManager(manager);
//	 
//	    // Define all possible view resolvers
//	    List<ViewResolver> resolvers = new ArrayList<ViewResolver>();
//	 
//	    resolvers.add(jsonViewResolver());
//
//	    resolver.setViewResolvers(resolvers);
//	    return resolver;
//	}	
	
//    @Bean
//    public ViewResolver jsonViewResolver() {
//    	return new ViewResolver() {
//			
//			@Override
//			public View resolveViewName(String viewName, Locale locale) throws Exception {
//	              MappingJackson2JsonView view = new MappingJackson2JsonView();  
//	              view.setPrettyPrint(true);  
//	              return view;  
//			}
//		};
//    }
    
//    @Bean 
//    public JsonRequestHandler jsonRequestHandler() {
//    	JsonRequestHandler handler = new JsonRequestHandler();
//    	handler.setTransactionManager(transactionManager);
//    	handler.setObjectMapper(objectMapper);
//    	return handler;
//    }
    
    @Bean 
    public ViewResolver xplatformViewResolver() {
    	return new ViewResolver() {
			
			@Override
			public View resolveViewName(String viewName, Locale locale) throws Exception {
				XPlatformMapView view = new XPlatformMapView();
				view.setDataHandler(xplatformDataHandler());
				return view;
			}
		};
    }
    
    @Bean
    public XPlatformRequestHandler xPlatformRequestHandler() {
    	if(transactionManager == null) {
    		throw new RuntimeException("Transaction manager is null");
    	}
    	
    	XPlatformRequestHandler handler = new XPlatformRequestHandler();
    	handler.setTransactionManager(transactionManager);
    	handler.setTxCodeResolver(this.txCodeResolver());
    	handler.setTxServiceRegistry(this.txServiceRegistry);
    	return handler;
    }
    
    @Bean
	public TxCodeResolver<HtcXplatformMessage> txCodeResolver() {
		return new HtcXPlatformTxCodeResolver();
	}

	@Override
	public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
//		JsonMessageArgumentResolver jsonMessageArgumentResolver = new JsonMessageArgumentResolver();
//		jsonMessageArgumentResolver.setObjectMapper(objectMapper);
//		argumentResolvers.add(jsonMessageArgumentResolver);
		XPlatformRiaArgumentResolver xPlatformRiaArgumentResolver = new XPlatformRiaArgumentResolver();
		xPlatformRiaArgumentResolver.setParser(xplatformDataParser());
		argumentResolvers.add(xPlatformRiaArgumentResolver);
	}
	
	@Bean
	public XplatformDataParser xplatformDataParser() {
		XplatformDataParser dataParser = new XplatformDataParser();
		dataParser.setDataHandler(xplatformDataHandler());
		dataParser.setCamelizeMode(true);
		return dataParser;
	}

	@Bean
	public XPlatformDataHandler xplatformDataHandler() {
		return new XPlatformRiaDataHandler();
	}

	@Override
	public void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers) {
//		XPlatformRiaReturnValueHandler xPlatformRiaReturnValueHandler = new XPlatformRiaReturnValueHandler();
//		xPlatformRiaReturnValueHandler.setDataHandler(xplatformDataHandler());
//		returnValueHandlers.add(xPlatformRiaReturnValueHandler);
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations("/public-web-resources/")
				.setCachePeriod(31556926);
	}

	@Override
	public void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {
		XplatformExceptionResolver xplatformExceptionResolver = new XplatformExceptionResolver();
		exceptionResolvers.add(xplatformExceptionResolver);
	}
	

	@Bean(name="multipartResolver")
	public CommonsMultipartResolver multipartResolver() {
		CommonsMultipartResolver resolver = new CommonsMultipartResolver();
		resolver.setMaxUploadSize(1024000000);
		return resolver;
	}
	
	@Bean
	public FileController fileController() {
		return new FileController();
	}

}
