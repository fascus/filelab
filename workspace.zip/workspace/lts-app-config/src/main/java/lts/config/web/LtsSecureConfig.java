package lts.config.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.commons.lang.ArrayUtils;
import org.jasypt.encryption.pbe.PBEStringEncryptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;

import htc.commons.auth.entrypoint.Xplatform403ForbiddenEntryPoint;
import htc.commons.auth.filter.XplatformAuthFilter;
import htc.commons.auth.handler.XplatformAccessDecisionManager;
import htc.commons.auth.handler.XplatformAccessDeniedHandler;
import htc.commons.auth.handler.XplatformAuthFailureHandler;
import htc.commons.auth.handler.XplatformAuthSuccessHandler;
import htc.commons.auth.handler.XplatformLogoutSuccessHandler;
import htc.commons.auth.provider.XplatfromAuthenticationProvider;
import htc.hone.utils.EncUtil;

@Configuration
@EnableWebSecurity
@PropertySource({"classpath:config/app.properties"})
public class LtsSecureConfig extends WebSecurityConfigurerAdapter{
	@Value("#{'${auth.ignore.svc.list}'.split(',')}")
	private List<String> authIgnoreSvcList;
	
	
	@Resource(name="dataSource")
	DataSource ltsDataSource;
	
	@Resource(name="userDetailsService")
	UserDetailsService userDetailsService;
	
	@Autowired
	PBEStringEncryptor passwordEncryptor;
	
    @Autowired
    protected void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
    	// do nothging
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
		return new XplatfromAuthenticationProvider();
	}


	@Bean(name="passwordEncoder")
	public PasswordEncoder passwordEncoder() {
		return new PasswordEncoder() {
			
			@Override
			public boolean matches(CharSequence rawPassword, String encodedPassword) {
				return EncUtil.checkPassword(rawPassword.toString(), encodedPassword);
			}
			
			@Override
			public String encode(CharSequence rawPassword) {
				return EncUtil.encryptPassword(rawPassword.toString());
			}
		};
	}


	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring()
			.antMatchers("/ui/**")
			.antMatchers("/rMateChart/**")
			.antMatchers("/LTS_Runtime/**");
	}	


	/* (non-Javadoc)
	 * @see org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter#userDetailsService()
	 */
	@Override
	protected UserDetailsService userDetailsService() {
		return userDetailsService;
	}


	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http.authorizeRequests()
				.anyRequest().authenticated().accessDecisionManager(accessDecisionManager())
//				.anyRequest().permitAll()
				.and()
				.exceptionHandling().authenticationEntryPoint(new Xplatform403ForbiddenEntryPoint())
				.and()
				.addFilterBefore(customAuthFilter(), UsernamePasswordAuthenticationFilter.class)
				.authenticationProvider(authenticationProvider())
			.logout()
				.logoutUrl("/logout")
				.logoutSuccessHandler(logoutSuccessHandler())
				.permitAll()
				.and()
			.headers()
				.frameOptions().disable()
				//.xssProtection().disable();
				.and()
			.csrf().disable()
			.sessionManagement()
				.maximumSessions(1)
				.maxSessionsPreventsLogin(false)
				;
	}


	
	@Bean
	public AccessDeniedHandler accessDeniedHandler() {
		return new XplatformAccessDeniedHandler("403");
	}


	@Bean
	public AccessDecisionManager accessDecisionManager() {
		XplatformAccessDecisionManager accessDecisionManager = new XplatformAccessDecisionManager();
		
		List<String> svcUris = new ArrayList<String>();
		svcUris.add("/");
		svcUris.add("/loginProc");
		svcUris.add("/logout");
		svcUris.add("/ria/SYSCS001");
		for(String s : authIgnoreSvcList) {
			svcUris.add("/ria/" + s);
		}
		accessDecisionManager.setPermitUris((String[]) svcUris.toArray(new String[svcUris.size()]));
		return accessDecisionManager ;
	}


	@Bean
	public LogoutSuccessHandler logoutSuccessHandler() {
		return new XplatformLogoutSuccessHandler();
	}


	@Bean
	public AuthenticationFailureHandler failHandler() {
		return new XplatformAuthFailureHandler();
	}

	@Bean
	public AuthenticationSuccessHandler successHandler() {
		return new XplatformAuthSuccessHandler();
	}


	@Bean
	public XplatformAuthFilter customAuthFilter() throws Exception {
		XplatformAuthFilter authFilter = new XplatformAuthFilter();
		authFilter.setAuthenticationManager(authenticationManagerBean());
		authFilter.setAuthenticationSuccessHandler(successHandler());
		authFilter.setAuthenticationFailureHandler(failHandler());
		authFilter.setFilterProcessesUrl("/loginProc");
		return authFilter;
	}
    
}
