package lts.config.app;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import hone.bom.binding.bind.DtoPropertyBinderFactory;
import hone.bom.binding.bind.DtoPropertyBinderRegistry;
import hone.bom.binding.bind.DtoPropertyBinderRegistryHolder;
import hone.bom.binding.bind.base.DefaultDtoPropertyBinderFactory;
import hone.bom.binding.bind.base.DefaultDtoPropertyBinderRegistry;
import hone.bom.binding.converters.BindingConverter;
import hone.bom.binding.converters.DateConverter;
import hone.bom.binding.metadata.builder.FieldBaseDtoMetadataBuilder;
import hone.bom.io.segment.factory.AnnotatedDtoSegmentFactory;
import hone.bom.io.segment.registry.DefaultDtoSegmentRegistry;
import hone.bom.io.segment.registry.DtoSegmentRegistry;
import hone.bom.io.support.DefaultIoSupport;
import hone.bom.io.support.IoSupport;
import hone.bom.io.support.IoSupportHolder;

@Configuration
public class LtsIoConfig {

	@Bean
	public DtoPropertyBinderFactory dtoPropertyBinderFactory() {
		DefaultDtoPropertyBinderFactory dtoPropertyBinderFactory = new DefaultDtoPropertyBinderFactory();

		Map<Class<?>, BindingConverter<?>> converters = new HashMap<Class<?>, BindingConverter<?>>();
		converters.put(Date.class, new DateConverter("yyyyMMdd"));

		dtoPropertyBinderFactory.setCustomValueConverters(converters);
		return dtoPropertyBinderFactory;
	}

	@Bean
	public DtoPropertyBinderRegistry dtoPropertyBinderRegistry() {
		DefaultDtoPropertyBinderRegistry dtoPropertyBinderRegistry = new DefaultDtoPropertyBinderRegistry();

		dtoPropertyBinderRegistry.setMetadataBuilder(new FieldBaseDtoMetadataBuilder());
		dtoPropertyBinderRegistry.setPropertyBinderFactory(dtoPropertyBinderFactory());

		return dtoPropertyBinderRegistry;
	}

	@Bean
	public AnnotatedDtoSegmentFactory dtoSegmentFactory() {
		AnnotatedDtoSegmentFactory annotatedDtoSegmentFactory = new AnnotatedDtoSegmentFactory();

		annotatedDtoSegmentFactory.setBinderRegistry(dtoPropertyBinderRegistry());

		return annotatedDtoSegmentFactory;
	}

	@Bean
	public DtoSegmentRegistry dtoSegmentRegistry() {
		DefaultDtoSegmentRegistry dtoSegmentRegistry = new DefaultDtoSegmentRegistry();

		dtoSegmentRegistry.setDtoSegmentFactory(dtoSegmentFactory());

		return dtoSegmentRegistry;
	}

	@Bean
	public IoSupport ioSupport() {
		DefaultIoSupport ioSupport = new DefaultIoSupport();

		ioSupport.setSegmentRegistry(dtoSegmentRegistry());

		return ioSupport;
	}

	@Bean
	public IoSupportHolder ioSupportHolder() {
		IoSupportHolder ioSupportHolder = new IoSupportHolder();

		ioSupportHolder.setIoSupport(ioSupport());
		return ioSupportHolder;
	}

	@Bean
	public DtoPropertyBinderRegistryHolder dtoPropertyBinderRegistryHolder() {
		return new DtoPropertyBinderRegistryHolder();
	}


}
