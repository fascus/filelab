// ----- Start of excel import script -----

// [엑셀 시트(excel sheet)를 스캔(scan)하기 전에 전처리 작업]
// 
// - 메시지 필드 시작 행 번 및 끝 번호 설정
//   importMeta.firstRowNum : first row number of message field. if unknown set -1
//   importMeta.lastRowNum : last row number of message field. if unknown set -1
//   importMeta.sheetIndex : index of excel sheet that contains message map
// 
// @param sheet 엑셀 시트 객체
// @param importMeta 임포트 작업을 위한 메타 정보
//
function beforeLoadSheet(importMeta) {
	importMeta.firstRowNum = 4;
	importMeta.lastRowNum = -1;
	importMeta.sheetIndex = 0;
}

// [엑셀 시트(excel sheet)의 레코드(record or row)를 읽어 들이기 전 메시지 필드 설정]
// 
// - 메시지 필드의 기본값 설정 등을 처리
// 
// @param rowNum 읽어들인 행 번호
// @param row 읽어들인 엑셀 행 객체
// @param fieldItem 빈 메시지 필드 객체
function beforeReadRow(rowNum, row, fieldItem) {
	
	// set default fieldType
	fieldItem.fieldType = "java.lang.String";
	
	// set default IN/OUT type
	fieldItem.inOutType = "Both";
}

// [레코드의 각 셀(cell) 값을 읽어들인 후, 셀 데이터를 이용해 메시지 필드 설정]
// 
// - 셀 데이터를 메시지 필드에 설정하는 작업 처리
//
// @param rowNum 읽어들인 행 번호
// @param colNum 읽어들인 열 번호
// @param cellValue 셀 데이터 (문자열)
// @param fieldItem 메시지 필드 객체
// 
function readCell(rowNum, colNum, cellValue, fieldItem) {

	switch (colNum) {

	// 필드 한글 명칭 (field local name)
	case 1:
		fieldItem.localName = cellValue;
		break;

	// 필드 명칭 (field name)
	case 2:
		fieldItem.name = cellValue;
		break;

	// 필드 길이 (field length)
	case 4:
		fieldItem.length = cellValue;
		break;
		
	// 입력 전문 필드 (input message field)
	case 6:
		if(cellValue == 'O') {
			fieldItem.inOutType = "In";
		}
		break;
	// 출력 전문 필드 (output message field)
	case 7:
		if(cellValue == 'O') {
			fieldItem.inOutType = "Out";
		}
		break;
	// 수치 데이터의 전체 숫자 갯수 (precision)
	case 8:
		fieldItem.precision = 0;
		break;
	// 수치 데이터의 소숫점 이하 숫자 갯수 (scale)
	case 9:
		fieldItem.precision = 0;
		break;
	}
}

// [엑셀 시트(excel sheet)의 레코드(record or row)를 읽어들인 후 메시지 필드 추가 설정]
// 
// - fieldItem 객체에 설정된 값에 따라 추가 보정 작업 등을 처리
//
// @param rowNum 읽어들인 행 번호
// @param row 엑셀 행 객체
// @param fieldItem 메시지 필드 객체
// 
function afterReadRow(rowNum, row, fieldItem) {
	
	// 필드 설명 설정
	fieldItem.description = "";
}

// ----- End of excel import script -----
