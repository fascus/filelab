package cuin.online.cn.ab.bmm.dto;

import java.io.Serializable;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 업무메시지코드관리
 * 파 일 명 : BsnsMsgCdMgSrviUpdateBsnsMsgCdOutDto.java
 * 작 성 자 : 차대현
 * 작 성 일 : 2013.07.22
 * 설     명 : 업무메시지코드수정 출력
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */
public class BsnsMsgCdMgSrviUpdateBsnsMsgCdOutDto implements Serializable {
	private static final long serialVersionUID = -3640833573400132300L;

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("BsnsMsgCdMgSrviUpdateBsnsMsgCdOutDto [");
		sb.append("\n]");

		return sb.toString();
	}

}
