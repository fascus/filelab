package cuin.online.cn.ab.bmm.dto;

import java.io.Serializable;

import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 업무 메시지 코드 관리
 * 파 일 명 : BsnsMsgCdMgSrviRegisterBsnsMsgCdInDto.java
 * 작 성 자 : 차대현
 * 작 성 일 : 2013.06.04
 * 설    명 : 업무 메시지 코드 관리 입력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class BsnsMsgCdMgSrviRegisterBsnsMsgCdInDto implements Serializable, ServiceInDto {
	private static final long serialVersionUID = -7739837151565559663L;

	/**
	 * 상세업무코드
	 */
	private String dtilBsnsCd;
	/**
	 * 업무메시지번호
	 */
	private String bsnsMsgNo;
	/**
	 * 업무메시지구분코드
	 */
	private String bsnsMsgDvCd;
	/**
	 * 업무메시지용도코드
	 */
	private String bsnsMsgUsgCd;
	/**
	 * 업무메시지내용
	 */
	private String bsnsMsgCtt;
	/**
	 * 업무메시지설명
	 */
	private String bsnsMsgDscr;
	/**
	 * 유효시작일시
	 */
	private String vldBgDtm;
	/**
	 * 유효종료일시
	 */
	private String vldEotDtm;

	/**
	 * <pre>
	 * 상세업무코드 반환 (get dtilBsnsCd 4 0)
	 * </pre>
	 */
	public String getDtilBsnsCd() {
		return dtilBsnsCd;
	}

	/**
	 * <pre>
	 * 상세업무코드 설정 (set dtilBsnsCd 4 0)
	 * </pre>
	 */
	public void setDtilBsnsCd(String dtilBsnsCd) {
		this.dtilBsnsCd = dtilBsnsCd;
	}

	/**
	 * <pre>
	 * 업무메시지번호 반환 (get bsnsMsgNo 6 0)
	 * </pre>
	 */
	public String getBsnsMsgNo() {
		return bsnsMsgNo;
	}

	/**
	 * <pre>
	 * 업무메시지번호 설정 (set bsnsMsgNo 6 0)
	 * </pre>
	 */
	public void setBsnsMsgNo(String bsnsMsgNo) {
		this.bsnsMsgNo = bsnsMsgNo;
	}

	/**
	 * <pre>
	 * 업무메시지구분코드 반환 (get bsnsMsgDvCd 1 0)
	 * </pre>
	 */
	public String getBsnsMsgDvCd() {
		return bsnsMsgDvCd;
	}

	/**
	 * <pre>
	 * 업무메시지구분코드 설정 (set bsnsMsgDvCd 1 0)
	 * </pre>
	 */
	public void setBsnsMsgDvCd(String bsnsMsgDvCd) {
		this.bsnsMsgDvCd = bsnsMsgDvCd;
	}

	/**
	 * <pre>
	 * 업무메시지용도코드 반환 (get bsnsMsgUsgCd 3 0)
	 * </pre>
	 */
	public String getBsnsMsgUsgCd() {
		return bsnsMsgUsgCd;
	}

	/**
	 * <pre>
	 * 업무메시지용도코드 설정 (set bsnsMsgUsgCd 3 0)
	 * </pre>
	 */
	public void setBsnsMsgUsgCd(String bsnsMsgUsgCd) {
		this.bsnsMsgUsgCd = bsnsMsgUsgCd;
	}

	/**
	 * <pre>
	 * 업무메시지내용 반환 (get bsnsMsgCtt 200 0)
	 * </pre>
	 */
	public String getBsnsMsgCtt() {
		return bsnsMsgCtt;
	}

	/**
	 * <pre>
	 * 업무메시지내용 설정 (set bsnsMsgCtt 200 0)
	 * </pre>
	 */
	public void setBsnsMsgCtt(String bsnsMsgCtt) {
		this.bsnsMsgCtt = bsnsMsgCtt;
	}

	/**
	 * <pre>
	 * 업무메시지설명 반환 (get bsnsMsgDscr 2000 0)
	 * </pre>
	 */
	public String getBsnsMsgDscr() {
		return bsnsMsgDscr;
	}

	/**
	 * <pre>
	 * 업무메시지설명 설정 (set bsnsMsgDscr 2000 0)
	 * </pre>
	 */
	public void setBsnsMsgDscr(String bsnsMsgDscr) {
		this.bsnsMsgDscr = bsnsMsgDscr;
	}

	/**
	 * <pre>
	 * 유효시작일시 반환 (get vldBgDtm 14 0)
	 * </pre>
	 */
	public String getVldBgDtm() {
		return vldBgDtm;
	}

	/**
	 * <pre>
	 * 유효시작일시 설정 (set vldBgDtm 14 0)
	 * </pre>
	 */
	public void setVldBgDtm(String vldBgDtm) {
		this.vldBgDtm = vldBgDtm;
	}

	/**
	 * <pre>
	 * 유효종료일시 반환 (get vldEotDtm 14 0)
	 * </pre>
	 */
	public String getVldEotDtm() {
		return vldEotDtm;
	}

	/**
	 * <pre>
	 * 유효종료일시 설정 (set vldEotDtm 14 0)
	 * </pre>
	 */
	public void setVldEotDtm(String vldEotDtm) {
		this.vldEotDtm = vldEotDtm;
	}

	/**
	 * 일련번호
	 */
	private long chnSeq;

	/**
	 * <pre>
	 * 일련번호 반환 (get chnSeq 10 0)
	 * </pre>
	 */
	public long getChnSeq() {
		return chnSeq;
	}

	/**
	 * <pre>
	 * 일련번호 설정 (set chnSeq 10 0)
	 * </pre>
	 */
	public void setChnSeq(long chnSeq) {
		this.chnSeq = chnSeq;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("BsnsMsgCdMgSrviRegisterBsnsMsgCdInDto [");

		sb.append("\n    dtilBsnsCd = '").append(getDtilBsnsCd()).append("'");
		sb.append("\n    bsnsMsgNo = '").append(getBsnsMsgNo()).append("'");
		sb.append("\n    chnSeq = '").append(getChnSeq()).append("'");
		sb.append("\n    bsnsMsgDvCd = '").append(getBsnsMsgDvCd()).append("'");
		sb.append("\n    bsnsMsgUsgCd = '").append(getBsnsMsgUsgCd()).append("'");
		sb.append("\n    bsnsMsgCtt = '").append(getBsnsMsgCtt()).append("'");
		sb.append("\n    bsnsMsgDscr = '").append(getBsnsMsgDscr()).append("'");
		sb.append("\n    vldBgDtm = '").append(getVldBgDtm()).append("'");
		sb.append("\n    vldEotDtm = '").append(getVldEotDtm()).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
