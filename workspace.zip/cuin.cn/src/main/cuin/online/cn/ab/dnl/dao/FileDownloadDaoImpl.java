package cuin.online.cn.ab.dnl.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.online.cn.ab.dnl.dto.FileDownloadInquiryGd01Dto;
import cuin.online.cn.ab.dnl.dto.FileDownloadInquiryInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 파일다운로드
 * 파 일 명 : FileDownloadDaoImpl.java
 * 작 성 자 : 구교충
 * 작 성 일 : 2013.08.12
 * 설     명 : 파일다운로드 DAO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.online.cn.ab.dnl.hqml.FileDownload")
public class FileDownloadDaoImpl extends DbioDaoSupport implements FileDownloadDao {

	public List<FileDownloadInquiryGd01Dto> inquiry(FileDownloadInquiryInDto fileDownloadInquiryInDto) {
		String sql = getSql("cuin.online.cn.ab.dnl.hqml.FileDownload.inquiry", fileDownloadInquiryInDto);
		return queryForList(sql, new BeanPropertySqlParameterSource(fileDownloadInquiryInDto), new BeanPropertyRowMapper<FileDownloadInquiryGd01Dto>(FileDownloadInquiryGd01Dto.class));
	}
}
