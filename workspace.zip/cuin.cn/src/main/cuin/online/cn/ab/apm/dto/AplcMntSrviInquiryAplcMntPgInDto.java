package cuin.online.cn.ab.apm.dto;

import cuin.cn.dbio.core.sys.PagingInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 어플리케이션모니터링
 * 파 일 명 : AplcMntSrviInquiryAplcMntPgInDto.java
 * 작 성 자 : 이준우
 * 작 성 일 : 2013.11.19
 * 파 일 명 : 어플리케이션모니터링 조회페이지 입력.java
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */
public class AplcMntSrviInquiryAplcMntPgInDto extends AplcMntSrviInquiryAplcMntInDto implements PagingInDto {

	private static final long serialVersionUID = 154486950050088596L;

	// 페이지 레코드 수
	private int recPerPage = 20;

	// 시작 레코드 번호
	private int beginRowNum;

	// 마지막 레코드 번호
	private int endRowNum;

	/**
	 * 페이�� 당 레코드 수 반환.
	 */
	public int getRecPerPage() {
		return recPerPage;
	}

	/**
	 * 페이지 당 레코드 수 설정.
	 */
	public void setRecPerPage(int recPerPage) {
		this.recPerPage = recPerPage;
	}

	/**
	 * 시작 레코��� 번호 반환.
	 */
	public int getBeginRowNum() {
		return beginRowNum;
	}

	/**
	 * 시작 레코드 번호 설정.
	 */
	public void setBeginRowNum(int beginRowNum) {
		this.beginRowNum = beginRowNum;
	}

	/**
	 * 마지막 레코드 ��호 반환.
	 */
	public int getEndRowNum() {
		return endRowNum;
	}

	/**
	 * 마지막 레코드 번호 설정.
	 */
	public void setEndRowNum(int endRowNum) {
		this.endRowNum = endRowNum;
	}
}
