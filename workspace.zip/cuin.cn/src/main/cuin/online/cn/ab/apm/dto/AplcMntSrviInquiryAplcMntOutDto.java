package cuin.online.cn.ab.apm.dto;

import java.io.Serializable;
import java.util.List;

import cuin.cn.dbio.core.sys.PagingOutDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 어플리케이션모니터링
 * 파 일 명 : AplcMntSrviInquiryAplcMntOutDto.java
 * 작 성 자 : 이준우
 * 작 성 일 : 2013.11.19
 * 설     명 : 어플리케이션모니터링 조회 출력
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */
public class AplcMntSrviInquiryAplcMntOutDto implements Serializable, PagingOutDto {
	private static final long serialVersionUID = -8343540110416393031L;

	/**
	 * 연속유무
	 */
	private int iscont;
	/**
	 * 페이지번호
	 */
	private int pageNo;
	/**
	 * gd01 배열
	 */
	private List<AplcMntSrviInquiryAplcMntGd01Dto> gd01List;

	/**
	 * <pre>
	 * 연속유무 반환 (get iscont 1 0)
	 * </pre>
	 */
	public int getIscont() {
		return iscont;
	}

	/**
	 * <pre>
	 * 연속유무 설정 (set iscont 1 0)
	 * </pre>
	 */
	public void setIscont(int iscont) {
		this.iscont = iscont;
	}

	/**
	 * <pre>
	 * 페이지번호 반환 (get pageNo 4 0)
	 * </pre>
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * <pre>
	 * 페이지번호 설정 (set pageNo 4 0)
	 * </pre>
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * <pre>
	 * gd01 반복 횟수 길이 반환
	 * </pre>
	 */
	public int getGd01Count() {
		return gd01List == null ? 0 : gd01List.size();
	}

	/**
	 * <pre>
	 * gd01 배열 반환 (get gd01List 0 0)
	 * </pre>
	 */
	public List<AplcMntSrviInquiryAplcMntGd01Dto> getGd01List() {
		return gd01List;
	}

	/**
	 * <pre>
	 * gd01 배열 설정 (set gd01List 0 0)
	 * </pre>
	 */
	public void setGd01List(List<AplcMntSrviInquiryAplcMntGd01Dto> gd01List) {
		this.gd01List = gd01List;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("AplcMntSrviInquiryAplcMntOutDto [");

		sb.append("\n    iscont = '").append(getIscont()).append("'");
		sb.append("\n    pageNo = '").append(getPageNo()).append("'");
		sb.append("\n    gd01Count = '").append(getGd01Count()).append("'");
		sb.append("\n    gd01List = '").append(getGd01List()).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
