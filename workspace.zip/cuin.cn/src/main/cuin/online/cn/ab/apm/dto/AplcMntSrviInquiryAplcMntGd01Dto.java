package cuin.online.cn.ab.apm.dto;

import hone.common.util.DateUtils;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 어플리케이션모니터링
 * 파 일 명 : AplcMntSrviInquiryAplcMntGd01Dto.java
 * 작 성 자 : 이준우
 * 작 성 일 : 2013.11.19
 * 설     명 : 어플리케이션모니터링 조회 그리드 출력
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */
public class AplcMntSrviInquiryAplcMntGd01Dto implements Serializable {
	private static final long serialVersionUID = -1025603913781460290L;

	/**
	 * 거래일자
	 */
	private String trnDt;
	/**
	 * 거래시각
	 */
	private String trnTmd;
	/**
	 * GLOBAL_ID
	 */
	private String glbId;
	/**
	 * 거래ID
	 */
	private String trnId;
	/**
	 * 화면ID
	 */
	private String scrnId;
	/**
	 * 설치인가번호
	 */
	private String sueCuocNo;
	/**
	 * 설치지점코드
	 */
	private String sueBroCd;
	/**
	 * 설치단말기ID
	 */
	private String sueTrmlId;
	/**
	 * 인가번호
	 */
	private String cuocNo;
	/**
	 * 지점코드
	 */
	private String broCd;
	/**
	 * 단말기ID
	 */
	private String trmlId;
	/**
	 * 요청응답구분값
	 */
	private String rqstRspnDvVlu;
	/**
	 * 사원번호
	 */
	private String empNo;
	/**
	 * 사용자IP주소
	 */
	private String userIpAdr;
	/**
	 * 처리결과여부
	 */
	private String prceRslYn;
	/**
	 * EAI동기구분값
	 */
	private String eaisyDvVlu;
	/**
	 * EAI비동기속성구분값
	 */
	private String eaiAsyncAtrDvVlu;
	/**
	 * 오류코드값
	 */
	private String errCdVlu;
	/**
	 * 오류내용
	 */
	private String errMesgCtt;

	/**
	 * <pre>
	 * 거래일자 반환 (get trnDt 8 0)
	 * </pre>
	 */
	public String getTrnDt() {
		return trnDt;
	}

	/**
	 * <pre>
	 * 거래일자 Timestamp 타입 반환
	 * </pre>
	 */
	public Timestamp getTrnDtTs() {
		return DateUtils.toTimestamp(trnDt);
	}

	/**
	 * <pre>
	 * 거래일자 설정 (set trnDt 8 0)
	 * </pre>
	 */
	public void setTrnDt(String trnDt) {
		this.trnDt = trnDt;
	}

	/**
	 * <pre>
	 * 거래시각 반환 (get trnTmd 6 0)
	 * </pre>
	 */
	public String getTrnTmd() {
		return trnTmd;
	}

	/**
	 * <pre>
	 * 거래시각 설정 (set trnTmd 6 0)
	 * </pre>
	 */
	public void setTrnTmd(String trnTmd) {
		this.trnTmd = trnTmd;
	}

	/**
	 * <pre>
	 * GLOBAL_ID 반환 (get glbId 32 0)
	 * </pre>
	 */
	public String getGlbId() {
		return glbId;
	}

	/**
	 * <pre>
	 * GLOBAL_ID 설정 (set glbId 32 0)
	 * </pre>
	 */
	public void setGlbId(String glbId) {
		this.glbId = glbId;
	}

	/**
	 * <pre>
	 * 거래ID 반환 (get trnId 12 0)
	 * </pre>
	 */
	public String getTrnId() {
		return trnId;
	}

	/**
	 * <pre>
	 * 거래ID 설정 (set trnId 12 0)
	 * </pre>
	 */
	public void setTrnId(String trnId) {
		this.trnId = trnId;
	}

	/**
	 * <pre>
	 * 화면ID 반환 (get scrnId 10 0)
	 * </pre>
	 */
	public String getScrnId() {
		return scrnId;
	}

	/**
	 * <pre>
	 * 화면ID 설정 (set scrnId 10 0)
	 * </pre>
	 */
	public void setScrnId(String scrnId) {
		this.scrnId = scrnId;
	}

	/**
	 * <pre>
	 * 설치인가번호 반환 (get sueCuocNo 5 0)
	 * </pre>
	 */
	public String getSueCuocNo() {
		return sueCuocNo;
	}

	/**
	 * <pre>
	 * 설치인가번호 설정 (set sueCuocNo 5 0)
	 * </pre>
	 */
	public void setSueCuocNo(String sueCuocNo) {
		this.sueCuocNo = sueCuocNo;
	}

	/**
	 * <pre>
	 * 설치지점코드 반환 (get sueBroCd 2 0)
	 * </pre>
	 */
	public String getSueBroCd() {
		return sueBroCd;
	}

	/**
	 * <pre>
	 * 설치지점코드 설정 (set sueBroCd 2 0)
	 * </pre>
	 */
	public void setSueBroCd(String sueBroCd) {
		this.sueBroCd = sueBroCd;
	}

	/**
	 * <pre>
	 * 설치단말기ID 반환 (get sueTrmlId 10 0)
	 * </pre>
	 */
	public String getSueTrmlId() {
		return sueTrmlId;
	}

	/**
	 * <pre>
	 * 설치단말기ID 설정 (set sueTrmlId 10 0)
	 * </pre>
	 */
	public void setSueTrmlId(String sueTrmlId) {
		this.sueTrmlId = sueTrmlId;
	}

	/**
	 * <pre>
	 * 인가번호 반환 (get cuocNo 5 0)
	 * </pre>
	 */
	public String getCuocNo() {
		return cuocNo;
	}

	/**
	 * <pre>
	 * 인가번호 설정 (set cuocNo 5 0)
	 * </pre>
	 */
	public void setCuocNo(String cuocNo) {
		this.cuocNo = cuocNo;
	}

	/**
	 * <pre>
	 * 지점코드 반환 (get broCd 2 0)
	 * </pre>
	 */
	public String getBroCd() {
		return broCd;
	}

	/**
	 * <pre>
	 * 지점코드 설정 (set broCd 2 0)
	 * </pre>
	 */
	public void setBroCd(String broCd) {
		this.broCd = broCd;
	}

	/**
	 * <pre>
	 * 단말기ID 반환 (get trmlId 10 0)
	 * </pre>
	 */
	public String getTrmlId() {
		return trmlId;
	}

	/**
	 * <pre>
	 * 단말기ID 설정 (set trmlId 10 0)
	 * </pre>
	 */
	public void setTrmlId(String trmlId) {
		this.trmlId = trmlId;
	}

	/**
	 * <pre>
	 * 요청응답구분값 반환 (get rqstRspnDvVlu 10 0)
	 * </pre>
	 */
	public String getRqstRspnDvVlu() {
		return rqstRspnDvVlu;
	}

	/**
	 * <pre>
	 * 요청응답구분값 설정 (set rqstRspnDvVlu 10 0)
	 * </pre>
	 */
	public void setRqstRspnDvVlu(String rqstRspnDvVlu) {
		this.rqstRspnDvVlu = rqstRspnDvVlu;
	}

	/**
	 * <pre>
	 * 사원번호 반환 (get empNo 12 0)
	 * </pre>
	 */
	public String getEmpNo() {
		return empNo;
	}

	/**
	 * <pre>
	 * 사원번호 설정 (set empNo 12 0)
	 * </pre>
	 */
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}

	/**
	 * <pre>
	 * 사용자IP주소 반환 (get userIpAdr 20 0)
	 * </pre>
	 */
	public String getUserIpAdr() {
		return userIpAdr;
	}

	/**
	 * <pre>
	 * 사용자IP주소 설정 (set userIpAdr 20 0)
	 * </pre>
	 */
	public void setUserIpAdr(String userIpAdr) {
		this.userIpAdr = userIpAdr;
	}

	/**
	 * <pre>
	 * 처리결과여부 반환 (get prceRslYn 1 0)
	 * </pre>
	 */
	public String getPrceRslYn() {
		return prceRslYn;
	}

	/**
	 * <pre>
	 * 처리결과여부 설정 (set prceRslYn 1 0)
	 * </pre>
	 */
	public void setPrceRslYn(String prceRslYn) {
		this.prceRslYn = prceRslYn;
	}

	/**
	 * <pre>
	 * EAI동기구분값 반환 (get eaisyDvVlu 10 0)
	 * </pre>
	 */
	public String getEaisyDvVlu() {
		return eaisyDvVlu;
	}

	/**
	 * <pre>
	 * EAI동기구분값 설정 (set eaisyDvVlu 10 0)
	 * </pre>
	 */
	public void setEaisyDvVlu(String eaisyDvVlu) {
		this.eaisyDvVlu = eaisyDvVlu;
	}

	/**
	 * <pre>
	 * EAI비동기속성구분값 반환 (get eaiAsyncAtrDvVlu 10 0)
	 * </pre>
	 */
	public String getEaiAsyncAtrDvVlu() {
		return eaiAsyncAtrDvVlu;
	}

	/**
	 * <pre>
	 * EAI비동기속성구분값 설정 (set eaiAsyncAtrDvVlu 10 0)
	 * </pre>
	 */
	public void setEaiAsyncAtrDvVlu(String eaiAsyncAtrDvVlu) {
		this.eaiAsyncAtrDvVlu = eaiAsyncAtrDvVlu;
	}

	/**
	 * <pre>
	 * 오류코드값 반환 (get errCdVlu 10 0)
	 * </pre>
	 */
	public String getErrCdVlu() {
		return errCdVlu;
	}

	/**
	 * <pre>
	 * 오류코드값 설정 (set errCdVlu 10 0)
	 * </pre>
	 */
	public void setErrCdVlu(String errCdVlu) {
		this.errCdVlu = errCdVlu;
	}

	/**
	 * <pre>
	 * 오류내용 반환 (get errMesgCtt 300 0)
	 * </pre>
	 */
	public String getErrMesgCtt() {
		return errMesgCtt;
	}

	/**
	 * <pre>
	 * 오류내용 설정 (set errMesgCtt 300 0)
	 * </pre>
	 */
	public void setErrMesgCtt(String errMesgCtt) {
		this.errMesgCtt = errMesgCtt;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("AplcMntSrviInquiryAplcMntGd01Dto [");

		sb.append("\n    trnDt = '").append(getTrnDt()).append("'");
		sb.append("\n    trnTmd = '").append(getTrnTmd()).append("'");
		sb.append("\n    glbId = '").append(getGlbId()).append("'");
		sb.append("\n    trnId = '").append(getTrnId()).append("'");
		sb.append("\n    scrnId = '").append(getScrnId()).append("'");
		sb.append("\n    sueCuocNo = '").append(getSueCuocNo()).append("'");
		sb.append("\n    sueBroCd = '").append(getSueBroCd()).append("'");
		sb.append("\n    sueTrmlId = '").append(getSueTrmlId()).append("'");
		sb.append("\n    cuocNo = '").append(getCuocNo()).append("'");
		sb.append("\n    broCd = '").append(getBroCd()).append("'");
		sb.append("\n    trmlId = '").append(getTrmlId()).append("'");
		sb.append("\n    rqstRspnDvVlu = '").append(getRqstRspnDvVlu()).append("'");
		sb.append("\n    empNo = '").append(getEmpNo()).append("'");
		sb.append("\n    userIpAdr = '").append(getUserIpAdr()).append("'");
		sb.append("\n    prceRslYn = '").append(getPrceRslYn()).append("'");
		sb.append("\n    eaisyDvVlu = '").append(getEaisyDvVlu()).append("'");
		sb.append("\n    eaiAsyncAtrDvVlu = '").append(getEaiAsyncAtrDvVlu()).append("'");
		sb.append("\n    errCdVlu = '").append(getErrCdVlu()).append("'");
		sb.append("\n    errMesgCtt = '").append(getErrMesgCtt()).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
