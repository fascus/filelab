package cuin.online.cn.ab.dnl.dto;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 파일 다운로드
 * 파 일 명 : FileDownloadInquiryOutDto.java
 * 작 성 자 : 구교충
 * 작 성 일 : 2013.08.12
 * 설    명 :
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class FileDownloadInquiryOutDto implements Serializable {
	private static final long serialVersionUID = 3148387466171665861L;

	/**
	 * gd01 배열
	 */
	private List<FileDownloadInquiryGd01Dto> gd01List;

	/**
	 * <pre>
	 * gd01 반복 횟수 길이 반환
	 * </pre>
	 */
	public int getGd01Count() {
		return gd01List.size();
	}

	/**
	 * <pre>
	 * gd01 배열 반환 (get gd01List 0 0)
	 * </pre>
	 */
	public List<FileDownloadInquiryGd01Dto> getGd01List() {
		return gd01List;
	}

	/**
	 * <pre>
	 * gd01 배열 설정 (set gd01List 0 0)
	 * </pre>
	 */
	public void setGd01List(List<FileDownloadInquiryGd01Dto> gd01List) {
		this.gd01List = gd01List;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("FileDownloadInquiryOutDto [");

		sb.append("\n    gd01Count = '").append(getGd01Count()).append("'");
		sb.append("\n    gd01List = '").append(getGd01List()).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
