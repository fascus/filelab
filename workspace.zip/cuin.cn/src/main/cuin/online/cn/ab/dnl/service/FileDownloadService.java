package cuin.online.cn.ab.dnl.service;

import cuin.online.cn.ab.dnl.dto.FileDownloadInquiryInDto;
import cuin.online.cn.ab.dnl.dto.FileDownloadInquiryOutDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 파일다운로드
 * 파 일 명 : FileDownloadService.java
 * 작 성 자 : 구교충
 * 작 성 일 : 2013.08.12
 * 설     명 : 파일다운로드 서비스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface FileDownloadService {

	FileDownloadInquiryOutDto inquiry(FileDownloadInquiryInDto fileDownloadInquiryInDto);
}
