package cuin.online.cn.ab.bat.dto;

import hone.common.util.DateUtils;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 배치결과파일다운로드
 * 파 일 명 : BatchResultDownloadInquiryGd01Dto.java
 * 작 성 자 : 구교충
 * 작 성 일 : 2013.08.13
 * 설     명 : 배치결과파일다운로드 그리드 출력
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */
public class BatchResultDownloadInquiryGd01Dto implements Serializable {
	private static final long serialVersionUID = 4627835879209452716L;

	/**
	 * 거래ID
	 */
	private String trnId;
	/**
	 * 경로
	 */
	private String pth;
	/**
	 * 파일명
	 */
	private String flNm;
	/**
	 * 크기
	 */
	private String sz;
	/**
	 * 수정일시
	 */
	private String uptDtm;
	/**
	 * 기본디렉토리경로
	 */
	private String brcPthNm;

	/**
	 * <pre>
	 * JOB 아이디 반환 (get trnId 12 0)
	 * </pre>
	 */
	public String getTrnId() {
		return trnId;
	}

	/**
	 * <pre>
	 * JOB 아이디 설정 (set trnId 12 0)
	 * </pre>
	 */
	public void setTrnId(String trnId) {
		this.trnId = trnId;
	}

	/**
	 * <pre>
	 * 경로 반환 (get pth 100 0)
	 * </pre>
	 */
	public String getPth() {
		return pth;
	}

	/**
	 * <pre>
	 * 경로 설정 (set pth 100 0)
	 * </pre>
	 */
	public void setPth(String pth) {
		this.pth = pth;
	}

	/**
	 * <pre>
	 * 파일명 반환 (get flNm 100 0)
	 * </pre>
	 */
	public String getFlNm() {
		return flNm;
	}

	/**
	 * <pre>
	 * 파일명 설정 (set flNm 100 0)
	 * </pre>
	 */
	public void setFlNm(String flNm) {
		this.flNm = flNm;
	}

	/**
	 * <pre>
	 * 크기 반환 (get sz 20 0)
	 * </pre>
	 */
	public String getSz() {
		return sz;
	}

	/**
	 * <pre>
	 * 크기 설정 (set sz 20 0)
	 * </pre>
	 */
	public void setSz(String sz) {
		this.sz = sz;
	}

	/**
	 * <pre>
	 * 수정일시 반환 (get uptDtm 14 0)
	 * </pre>
	 */
	public String getUptDtm() {
		return uptDtm;
	}

	/**
	 * <pre>
	 * 수정일시 Timestamp 타입 반환
	 * </pre>
	 */
	public Timestamp getUptDtmTs() {
		return DateUtils.toTimestamp(uptDtm);
	}

	/**
	 * <pre>
	 * 수정일시 설정 (set uptDtm 14 0)
	 * </pre>
	 */
	public void setUptDtm(String uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		return "BatchResultDownloadInquiryGd01Dto [trnId=" + trnId + ", pth=" + pth + ", flNm=" + flNm + ", sz=" + sz + ", uptDtm=" + uptDtm + ", brcPthNm=" + brcPthNm + "]";
	}

	/**
	 * <pre>
	 * 기본디렉토리경로 반환 (get brcPthNm 100 0)
	 * </pre>
	 */
	public String getBrcPthNm() {
		return brcPthNm;
	}

	/**
	 * <pre>
	 * 수정일시 설정 (set brcPthNm 100 0)
	 * </pre>
	 */
	public void setBrcPthNm(String brcPthNm) {
		this.brcPthNm = brcPthNm;
	}

}
