package cuin.online.cn.ab.dnl.service;

import hone.omm.bind.anno.OmmBind;
import hone.online.web.bind.anno.ScreenBind;
import hone.online.web.bind.anno.TxBind;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cuin.online.cn.ab.dnl.dao.FileDownloadDao;
import cuin.online.cn.ab.dnl.dto.FileDownloadInquiryGd01Dto;
import cuin.online.cn.ab.dnl.dto.FileDownloadInquiryInDto;
import cuin.online.cn.ab.dnl.dto.FileDownloadInquiryOutDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 파일다운로드
 * 파 일 명 : FileDownloadServiceImpl.java
 * 작 성 자 : 구교충
 * 작 성 일 : 2013.08.12
 * 설     명 : 파일다운로드 서비스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */

@Service
@ScreenBind(id = "M597006A00", name = "파일다운로드")
public class FileDownloadServiceImpl implements FileDownloadService {
	private Logger logger = LoggerFactory.getLogger(FileDownloadServiceImpl.class);

	@Autowired
	private FileDownloadDao fileDownloadDao;

	@TxBind(id = "SMCNSS700601", name = "파일다운로드")
	@OmmBind(in = "cuin.online.cn.ab.dnl.omm.FileDownloadInquiryIn", out = "cuin.online.cn.ab.dnl.omm.FileDownloadInquiryOut")
	public FileDownloadInquiryOutDto inquiry(FileDownloadInquiryInDto fileDownloadInquiryInDto) {

		if (logger.isDebugEnabled()) {
			logger.debug("서비스 입력 DTO : " + fileDownloadInquiryInDto);
		}
		List<FileDownloadInquiryGd01Dto> gd01 = fileDownloadDao.inquiry(fileDownloadInquiryInDto);

		FileDownloadInquiryOutDto fileDownloadInquiryOutDto = new FileDownloadInquiryOutDto();
		fileDownloadInquiryOutDto.setGd01List(gd01);
		return fileDownloadInquiryOutDto;
	}
}
