package cuin.online.cn.ab.bmm.dto;

import cuin.cn.dbio.core.sys.PagingInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 업무메시지코드관리
 * 파 일 명 : 업무메시지코드조회페이지 입력.java
 * 작 성 자 : 차대현
 * 작 성 일 : 2013.07.22
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */
public class BsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto extends BsnsMsgCdMgSrviInquiryBsnsMsgCdInDto implements PagingInDto {

	private static final long serialVersionUID = -841138144721155446L;

	// 페이지 레코드 수
	private int recPerPage = 20;

	// 시작 레코드 번호
	private int beginRowNum;

	// 마지막 레코드 번호
	private int endRowNum;

	/**
	 * 페이�� 당 레코드 수 반환.
	 */
	public int getRecPerPage() {
		return recPerPage;
	}

	/**
	 * 페이지 당 레코드 수 설정.
	 */
	public void setRecPerPage(int recPerPage) {
		this.recPerPage = recPerPage;
	}

	/**
	 * 시작 레코��� 번호 반환.
	 */
	public int getBeginRowNum() {
		return beginRowNum;
	}

	/**
	 * 시작 레코드 번호 설정.
	 */
	public void setBeginRowNum(int beginRowNum) {
		this.beginRowNum = beginRowNum;
	}

	/**
	 * 마지막 레코드 ��호 반환.
	 */
	public int getEndRowNum() {
		return endRowNum;
	}

	/**
	 * 마지막 레코드 번호 설정.
	 */
	public void setEndRowNum(int endRowNum) {
		this.endRowNum = endRowNum;
	}
}
