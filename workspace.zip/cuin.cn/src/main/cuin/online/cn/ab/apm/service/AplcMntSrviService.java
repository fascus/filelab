package cuin.online.cn.ab.apm.service;

import cuin.online.cn.ab.apm.dto.AplcMntSrviInquiryAplcMntInDto;
import cuin.online.cn.ab.apm.dto.AplcMntSrviInquiryAplcMntOutDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 어플리케이션모니터링
 * 파 일 명 : AplcMntSrviService.java
 * 작 성 자 : 이준우
 * 작 성 일 : 2013.11.13
 * 설     명 : 어플리케이션모니터링 서비스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface AplcMntSrviService {

	public AplcMntSrviInquiryAplcMntOutDto inquiryAplcMnt(AplcMntSrviInquiryAplcMntInDto aplcMntSrviInquiryAplcMntInDto);

}