package cuin.online.cn.ab.bat.dto;

import hone.common.util.DateUtils;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 배치결과파일다운로드
 * 파 일 명 : BatchResultDownloadInquiryInDto.java
 * 작 성 자 : 구교충
 * 작 성 일 : 2013.08.13
 * 설     명 : 배치결과파일다운로드 입력
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */
public class BatchResultDownloadInquiryInDto implements Serializable, ServiceInDto {
	private static final long serialVersionUID = 4622508542795532864L;

	/**
	 * 업무구분코드
	 */
	private String bsnsDvCd;
	/**
	 * JOB 아이디
	 */
	private String trnId;
	/**
	 * 시작일자
	 */
	private String bgDt;
	/**
	 * 종료일자
	 */
	private String eotDt;

	/**
	 * <pre>
	 * 업무구분코드 반환 (get bsnsDvCd 2 0)
	 * </pre>
	 */
	public String getBsnsDvCd() {
		return bsnsDvCd;
	}

	/**
	 * <pre>
	 * 업무구분코드 설정 (set bsnsDvCd 2 0)
	 * </pre>
	 */
	public void setBsnsDvCd(String bsnsDvCd) {
		this.bsnsDvCd = bsnsDvCd;
	}

	/**
	 * <pre>
	 * JOB 아이디 반환 (get trnId 12 0)
	 * </pre>
	 */
	public String getTrnId() {
		return trnId;
	}

	/**
	 * <pre>
	 * JOB 아이디 설정 (set trnId 12 0)
	 * </pre>
	 */
	public void setTrnId(String trnId) {
		this.trnId = trnId;
	}

	/**
	 * <pre>
	 * 시작일자 반환 (get bgDt 8 0)
	 * </pre>
	 */
	public String getBgDt() {
		return bgDt;
	}

	/**
	 * <pre>
	 * 시작일자 Timestamp 타입 반환
	 * </pre>
	 */
	public Timestamp getBgDtTs() {
		return DateUtils.toTimestamp(bgDt);
	}

	/**
	 * <pre>
	 * 시작일자 설정 (set bgDt 8 0)
	 * </pre>
	 */
	public void setBgDt(String bgDt) {
		this.bgDt = bgDt;
	}

	/**
	 * <pre>
	 * 종료일자 반환 (get eotDt 8 0)
	 * </pre>
	 */
	public String getEotDt() {
		return eotDt;
	}

	/**
	 * <pre>
	 * 종료일자 Timestamp 타입 반환
	 * </pre>
	 */
	public Timestamp getEotDtTs() {
		return DateUtils.toTimestamp(eotDt);
	}

	/**
	 * <pre>
	 * 종료일자 설정 (set eotDt 8 0)
	 * </pre>
	 */
	public void setEotDt(String eotDt) {
		this.eotDt = eotDt;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("BatchResultDownloadInquiryInDto [");

		sb.append("\n    bsnsDvCd = '").append(getBsnsDvCd()).append("'");
		sb.append("\n    trnId = '").append(getTrnId()).append("'");
		sb.append("\n    bgDt = '").append(getBgDt()).append("'");
		sb.append("\n    eotDt = '").append(getEotDt()).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
