package cuin.online.cn.ab.bat.service;

import hone.common.util.EnvUtils;
import hone.omm.bind.anno.OmmBind;
import hone.online.web.bind.anno.ScreenBind;
import hone.online.web.bind.anno.TxBind;

import java.io.File;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cuin.online.cn.ab.bat.dto.BatchResultDownloadInquiryGd01Dto;
import cuin.online.cn.ab.bat.dto.BatchResultDownloadInquiryInDto;
import cuin.online.cn.ab.bat.dto.BatchResultDownloadInquiryOutDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 배치결과파일다운로드
 * 파 일 명 : BatchResultDownloadServiceImpl.java
 * 작 성 자 : 구교충
 * 작 성 일 : 2013.08.13
 * 설     명 : 배치결과파일다운로드 서비스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */

@Service
@ScreenBind(id = "M597007A00", name = "배치결과파일다운로드")
public class BatchResultDownloadServiceImpl implements BatchResultDownloadService {
	private Logger logger = LoggerFactory.getLogger(BatchResultDownloadServiceImpl.class);

	@TxBind(id = "SMCNSS700701", name = "배치결과파일다운로드")
	@OmmBind(in = "cuin.online.cn.ab.bat.omm.BatchResultDownloadInquiryIn", out = "cuin.online.cn.ab.bat.omm.BatchResultDownloadInquiryOut")
	public BatchResultDownloadInquiryOutDto inquiry(BatchResultDownloadInquiryInDto batchResultDownloadInquiryInDto) {
		if (logger.isDebugEnabled()) {
			logger.debug("서비스 입력 DTO : " + batchResultDownloadInquiryInDto);
		}
		List<BatchResultDownloadInquiryGd01Dto> gd01List = new ArrayList<BatchResultDownloadInquiryGd01Dto>();

		String batchResultBasePath = EnvUtils.getProperty("batch.io.root.path") + "/output/";
		if (System.getProperty("os.name").toLowerCase().startsWith("window")) {
			batchResultBasePath = "c:/app/honebat/hone.batch.container/std/BatchIO/output/";
		} else {
			batchResultBasePath = EnvUtils.getProperty("batch.io.root.path") + "/output/";
		}
		// /app/tmax/jeus/batch.result/
		String searchPath = batchResultBasePath + batchResultDownloadInquiryInDto.getBsnsDvCd().toLowerCase();
		// + "/" + batchResultDownloadInquiryInDto.getBat();

		File searchDir = new File(searchPath);
		DecimalFormat df = new DecimalFormat();
		SimpleDateFormat yyyymmdd = new SimpleDateFormat("yyyyMMdd");

		if (searchDir.isDirectory()) {
			File[] allDirs = searchDir.listFiles();

			for (File dir : allDirs) {
				if (dir.isDirectory()) {

					if (dir.getName().length() >= batchResultDownloadInquiryInDto.getTrnId().length()) {

						if (dir.getName().substring(0, batchResultDownloadInquiryInDto.getTrnId().length()).compareTo(batchResultDownloadInquiryInDto.getTrnId()) == 0) {

							File[] nodes = new File(dir.getPath()).listFiles();
							String trnId = dir.getName();
							for (File node : nodes) {
								BatchResultDownloadInquiryGd01Dto dto = new BatchResultDownloadInquiryGd01Dto();
								dto.setTrnId(trnId);
								dto.setFlNm(node.getName());
								String srvPath = node.getParent();
								if (System.getProperty("os.name").toLowerCase().startsWith("window")) {
									srvPath = srvPath.substring(2).replaceAll("\\\\", "/");
									batchResultBasePath = batchResultBasePath.substring(2).replaceAll("\\\\", "/");
								}

								dto.setBrcPthNm(batchResultBasePath);
								dto.setPth(srvPath.substring(batchResultBasePath.length()));
								dto.setSz(df.format(node.length()));
								String uptDtm = yyyymmdd.format(new Date(node.lastModified()));
								dto.setUptDtm(uptDtm);

								if (batchResultDownloadInquiryInDto.getBgDt().length() > 0 && batchResultDownloadInquiryInDto.getBgDt().length() > 0) {
									if (uptDtm.compareTo(batchResultDownloadInquiryInDto.getBgDt()) >= 0 && uptDtm.compareTo(batchResultDownloadInquiryInDto.getEotDt()) <= 0) {
										gd01List.add(dto);
									}
								} else if (batchResultDownloadInquiryInDto.getBgDt().length() <= 0 && batchResultDownloadInquiryInDto.getBgDt().length() <= 0) {
									gd01List.add(dto);
								}
							}

						}
					}
				}

				// if
				// (dir.getName().compareTo(batchResultDownloadInquiryInDto.getBgDt())
				// >= 0 &&
				// dir.getName().compareTo(batchResultDownloadInquiryInDto.getEotDt())
				// <= 0 && dir.isDirectory()) {
				// File[] nodes = new File(dir.getPath()).listFiles();
				// String workDt = dir.getName();
				// for (File node : nodes) {
				// BatchResultDownloadInquiryGd01Dto dto = new
				// BatchResultDownloadInquiryGd01Dto();
				// dto.setWkDtm(workDt);
				// dto.setFlNm(node.getName());
				// String srvPath = node.getParent();
				// if
				// (System.getProperty("os.name").toLowerCase().startsWith("window"))
				// {
				// srvPath = srvPath.substring(2).replaceAll("\\\\", "/");
				// }
				//
				// dto.setPth(srvPath);
				// dto.setSz(df.format(node.length()));
				// dto.setUptDtm(yyyymmdd.format(new
				// Date(node.lastModified())));
				// gd01List.add(dto);
				// }
				// }
			}
		}
		BatchResultDownloadInquiryOutDto batchResultDownloadInquiryOutDto = new BatchResultDownloadInquiryOutDto();
		batchResultDownloadInquiryOutDto.setGd01List(gd01List);
		return batchResultDownloadInquiryOutDto;
	}
}