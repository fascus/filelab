package cuin.online.cn.ab.bmm.service;

import hone.common.util.DateUtils;
import hone.core.logging.HoneLogger;
import hone.core.logging.HoneLoggerFactory;
import hone.omm.bind.anno.OmmBind;
import hone.online.web.bind.anno.ScreenBind;
import hone.online.web.bind.anno.TxBind;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cuin.cn.dbio.core.sys.DbioUtils;
import cuin.cn.exception.CuinException;
import cuin.cn.util.BeanUtils;
import cuin.dbio.cn.ab.dao.CnAb0003MtCtrl;
import cuin.dbio.cn.ab.dto.CnAb0003MtDto;
import cuin.online.cn.ab.bmm.dao.BsnsMsgCdMgSrviDao;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviDeleteBsnsMsgCdInDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviDeleteBsnsMsgCdOutDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviInquiryBsnsMsgCdGd01Dto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviInquiryBsnsMsgCdInDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviInquiryBsnsMsgCdOutDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviRegisterBsnsMsgCdInDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviRegisterBsnsMsgCdOutDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviUpdateBsnsMsgCdInDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviUpdateBsnsMsgCdOutDto;
import cuin.online.cn.core.service.ServiceControl;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 업무메시지관리
 * 파 일 명 : BsnsMsgCdMgSrviServiceImpl
 * 작 성 자 : 차대현
 * 작 성 일 : 2013.07.15
 * 설     명 :
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */

@Service
@ScreenBind(id = "M596002000", name = "업무메시지코드관리")
public class BsnsMsgCdMgSrviServiceImpl implements BsnsMsgCdMgSrviService {

	// 동일한 메시지코드에 대해 유효기간을 중첩하여 입력할 수 없습니다.
	private static final String CNAB000001 = "CNAB000001";

	@Autowired
	private BsnsMsgCdMgSrviDao bsnsMsgCdMgSrviDao;
	@Autowired
	private CnAb0003MtCtrl cnAb0003MtCtrl;

	@TxBind(id = "SMCNMS600201", name = "업무메시지조회")
	@OmmBind(in = "cuin.online.cn.ab.bmm.omm.BsnsMsgCdMgSrviInquiryBsnsMsgCdIn", out = "cuin.online.cn.ab.bmm.omm.BsnsMsgCdMgSrviInquiryBsnsMsgCdOut")
	public BsnsMsgCdMgSrviInquiryBsnsMsgCdOutDto inquiryBsnsMsgCd(BsnsMsgCdMgSrviInquiryBsnsMsgCdInDto bsnsMsgCdMgSrviInquiryBsnsMsgCdInDto) {
		HoneLogger logger = HoneLoggerFactory.getLogger(BsnsMsgCdMgSrviServiceImpl.class);

		if (logger.isDebugEnabled()) {
			logger.debug("업무메시지조회 입력 : " + bsnsMsgCdMgSrviInquiryBsnsMsgCdInDto);
		}

		// 입력셋팅
		BsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto bsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto = BeanUtils.toBean(bsnsMsgCdMgSrviInquiryBsnsMsgCdInDto, BsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto.class);
		int recPerPage = bsnsMsgCdMgSrviInquiryBsnsMsgCdInDto.getRecPerPage();

		// 쿼리실행
		DbioUtils.setPagingProperties(bsnsMsgCdMgSrviInquiryBsnsMsgCdInDto.getPageNo(), recPerPage, bsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto);
		List<BsnsMsgCdMgSrviInquiryBsnsMsgCdGd01Dto> results = bsnsMsgCdMgSrviDao.inquiryBsnsMsgCd(bsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto);

		// 출력셋팅
		BsnsMsgCdMgSrviInquiryBsnsMsgCdOutDto bsnsMsgCdMgSrviInquiryBsnsMsgCdOutDto = new BsnsMsgCdMgSrviInquiryBsnsMsgCdOutDto();
		results = DbioUtils.filterPaging(recPerPage, bsnsMsgCdMgSrviInquiryBsnsMsgCdInDto.getPageNo(), results, bsnsMsgCdMgSrviInquiryBsnsMsgCdOutDto);
		bsnsMsgCdMgSrviInquiryBsnsMsgCdOutDto.setGd01List(results);

		return bsnsMsgCdMgSrviInquiryBsnsMsgCdOutDto;
	}

	@TxBind(id = "SMCNSI600201", name = "업무메시지등록")
	@OmmBind(in = "cuin.online.cn.ab.bmm.omm.BsnsMsgCdMgSrviRegisterBsnsMsgCdIn", out = "cuin.online.cn.ab.bmm.omm.BsnsMsgCdMgSrviRegisterBsnsMsgCdOut")
	public BsnsMsgCdMgSrviRegisterBsnsMsgCdOutDto registerBsnsMsgCd(BsnsMsgCdMgSrviRegisterBsnsMsgCdInDto bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto) {
		HoneLogger logger = HoneLoggerFactory.getLogger(BsnsMsgCdMgSrviServiceImpl.class);
		if (logger.isDebugEnabled()) {
			logger.debug("업무메시지등록 입력 : " + bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto);
		}

		String vldBgDtm = bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto.getVldBgDtm().substring(0, 8);

		// 유효시작일시가 과거인 경우 허용 안함.
		if (DateUtils.before(vldBgDtm, DateUtils.getTodayString())) {
			ServiceControl.stop(CuinException.DEFAULT_SYS_ERR_CODE, CNAB000001);
		}

		// 일련번호 셋팅
		long chkSeq = bsnsMsgCdMgSrviDao.numberChkSeq(bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto);
		bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto.setChnSeq(chkSeq);

		// 업무메시지 등록
		cnAb0003MtCtrl.insert(bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto);

		// 업무메시지 등록건 조회
		CnAb0003MtDto cnAb0003MtDto = cnAb0003MtCtrl.select(bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto);

		return BeanUtils.toBean(cnAb0003MtDto, BsnsMsgCdMgSrviRegisterBsnsMsgCdOutDto.class);
	}

	@TxBind(id = "SMCNSU600201", name = "업무메시지수정")
	@OmmBind(in = "cuin.online.cn.ab.bmm.omm.BsnsMsgCdMgSrviUpdateBsnsMsgCdIn", out = "cuin.online.cn.ab.bmm.omm.BsnsMsgCdMgSrviUpdateBsnsMsgCdOut")
	public BsnsMsgCdMgSrviUpdateBsnsMsgCdOutDto updateBsnsMsgCd(BsnsMsgCdMgSrviUpdateBsnsMsgCdInDto bsnsMsgCdMgSrviUpdateBsnsMsgCdInDto) {
		HoneLogger logger = HoneLoggerFactory.getLogger(BsnsMsgCdMgSrviServiceImpl.class);

		if (logger.isDebugEnabled()) {
			logger.debug("업무메시지수정 입력 : " + bsnsMsgCdMgSrviUpdateBsnsMsgCdInDto);
		}

		int chkDup = bsnsMsgCdMgSrviDao.chkDup(bsnsMsgCdMgSrviUpdateBsnsMsgCdInDto);

		String vldEotDtm = bsnsMsgCdMgSrviUpdateBsnsMsgCdInDto.getVldEotDtm().substring(0, 8);

		if (logger.isDebugEnabled()) {
			logger.debug("중첩 여부 : " + chkDup);
		}

		// 유효시작일시, 유효종료일시 중첩확인
		if (chkDup > 0) {
			ServiceControl.stop(CuinException.DEFAULT_SYS_ERR_CODE, CNAB000001);
		}

		// 유효종료일시 비교
		if (DateUtils.before(vldEotDtm, DateUtils.getTodayString())) {
			ServiceControl.stop(CuinException.DEFAULT_SYS_ERR_CODE, CNAB000001);
		}

		// 업무메시지 수정
		cnAb0003MtCtrl.update(bsnsMsgCdMgSrviUpdateBsnsMsgCdInDto);

		// 업무메시지 수정건 조회
		CnAb0003MtDto cnAb0003MtDto = cnAb0003MtCtrl.select(bsnsMsgCdMgSrviUpdateBsnsMsgCdInDto);

		return BeanUtils.toBean(cnAb0003MtDto, BsnsMsgCdMgSrviUpdateBsnsMsgCdOutDto.class);
	}

	@TxBind(id = "SMCNSD600201", name = "업무메시지삭제")
	@OmmBind(in = "cuin.online.cn.ab.bmm.omm.BsnsMsgCdMgSrviDeleteBsnsMsgCdIn", out = "cuin.online.cn.ab.bmm.omm.BsnsMsgCdMgSrviDeleteBsnsMsgCdOut")
	public BsnsMsgCdMgSrviDeleteBsnsMsgCdOutDto deleteBsnsMsgCd(BsnsMsgCdMgSrviDeleteBsnsMsgCdInDto bsnsMsgCdMgSrviDeleteBsnsMsgCdInDto) {
		HoneLogger logger = HoneLoggerFactory.getLogger(BsnsMsgCdMgSrviServiceImpl.class);

		if (logger.isDebugEnabled()) {
			logger.debug("업무메시지 삭제 입력 : " + bsnsMsgCdMgSrviDeleteBsnsMsgCdInDto);
		}

		// 업무메시지 삭제
		cnAb0003MtCtrl.delete(bsnsMsgCdMgSrviDeleteBsnsMsgCdInDto);

		return new BsnsMsgCdMgSrviDeleteBsnsMsgCdOutDto();
	}
}