package cuin.online.cn.ab.bmm.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviInquiryBsnsMsgCdGd01Dto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviRegisterBsnsMsgCdInDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviUpdateBsnsMsgCdInDto;

@Repository
@HqmlAnnotation(id = "cuin.online.cn.ab.bmm.hqml.BsnsMsgCdMgSrvi")
/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 업무 메시지 코드 관리
 * 파 일 명 : BsnsMsgCdMgSrviDaoImpl.java
 * 작 성 자 : 차대현
 * 작 성 일 : 2013.06.04
 * 설    명 : 업무메시지코드관리 DAO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class BsnsMsgCdMgSrviDaoImpl extends DbioDaoSupport implements BsnsMsgCdMgSrviDao {

	public List<BsnsMsgCdMgSrviInquiryBsnsMsgCdGd01Dto> inquiryBsnsMsgCd(BsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto bsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto) {
		String sql = getSql("cuin.online.cn.ab.bmm.hqml.BsnsMsgCdMgSrvi.inquiryBsnsMsgCd", bsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(bsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto), new BeanPropertyRowMapper<BsnsMsgCdMgSrviInquiryBsnsMsgCdGd01Dto>(
				BsnsMsgCdMgSrviInquiryBsnsMsgCdGd01Dto.class));
	}

	public int chkDup(BsnsMsgCdMgSrviRegisterBsnsMsgCdInDto bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto) {
		String sql = getSql("cuin.online.cn.ab.bmm.hqml.BsnsMsgCdMgSrvi.chkDup", bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto);
		return queryForInt(sql, new BeanPropertySqlParameterSource(bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto));

	}

	public Long numberChkSeq(BsnsMsgCdMgSrviRegisterBsnsMsgCdInDto bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto) {
		String sql = getSql("cuin.online.cn.ab.bmm.hqml.BsnsMsgCdMgSrvi.numberChkSeq", bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto);
		return queryForLong(sql, new BeanPropertySqlParameterSource(bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto));
	}

	public int chkDup(BsnsMsgCdMgSrviUpdateBsnsMsgCdInDto bsnsMsgCdMgSrviUpdateBsnsMsgCdInDto) {
		String sql = getSql("cuin.online.cn.ab.bmm.hqml.BsnsMsgCdMgSrvi.chkDup", bsnsMsgCdMgSrviUpdateBsnsMsgCdInDto);
		return queryForInt(sql, new BeanPropertySqlParameterSource(bsnsMsgCdMgSrviUpdateBsnsMsgCdInDto));
	}

}
