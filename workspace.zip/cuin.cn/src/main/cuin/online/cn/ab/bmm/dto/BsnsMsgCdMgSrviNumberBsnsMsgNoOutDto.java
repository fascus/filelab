package cuin.online.cn.ab.bmm.dto;

import java.io.Serializable;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 업무 메시지 코드 관리
 * 파 일 명 : BsnsMsgCdMgSrviNumberBsnsMsgNoOutDto.java
 * 작 성 자 : 차대현
 * 작 성 일 : 2013.06.05
 * 설    명 : 업무 메시지 코드 관리 출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class BsnsMsgCdMgSrviNumberBsnsMsgNoOutDto implements Serializable {
	private static final long serialVersionUID = 337401470236969445L;

	/**
	 * 업무메시지번호
	 */
	private String bsnsMsgNo;

	/**
	 * <pre>
	 * 업무메시지번호 반환 (get bsnsMsgNo 6 0)
	 * </pre>
	 */
	public String getBsnsMsgNo() {
		return bsnsMsgNo;
	}

	/**
	 * <pre>
	 * 업무메시지번호 설정 (set bsnsMsgNo 6 0)
	 * </pre>
	 */
	public void setBsnsMsgNo(String bsnsMsgNo) {
		this.bsnsMsgNo = bsnsMsgNo;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("BsnsMsgCdMgSrviNumberBsnsMsgNoOutDto [");

		sb.append("\n    bsnsMsgNo = '").append(getBsnsMsgNo()).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
