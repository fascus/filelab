package cuin.online.cn.ab.apm.service;

import hone.omm.bind.anno.OmmBind;
import hone.online.web.bind.anno.ScreenBind;
import hone.online.web.bind.anno.TxBind;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cuin.cn.dbio.core.sys.DbioUtils;
import cuin.cn.util.BeanUtils;
import cuin.online.cn.ab.apm.dao.AplcMntSrviDao;
import cuin.online.cn.ab.apm.dto.AplcMntSrviInquiryAplcMntGd01Dto;
import cuin.online.cn.ab.apm.dto.AplcMntSrviInquiryAplcMntInDto;
import cuin.online.cn.ab.apm.dto.AplcMntSrviInquiryAplcMntOutDto;
import cuin.online.cn.ab.apm.dto.AplcMntSrviInquiryAplcMntPgInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 어플리케이션모니터링
 * 파 일 명 : AplcMntSrviServiceImpl.java
 * 작 성 자 : 이준우
 * 작 성 일 : 2013.11.13
 * 설     명 : 어플리케이션모니터링 서비스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */

@Service
@ScreenBind(id = "M596004000", name = "어플리케이션모니터링")
public class AplcMntSrviServiceImpl implements AplcMntSrviService {
	private static final Logger logger = LoggerFactory.getLogger(AplcMntSrviServiceImpl.class);

	@Autowired
	private AplcMntSrviDao aplcMntSrviDao;

	@TxBind(id = "SMCNMS600401", name = "어플리케이션모니터링 조회")
	@OmmBind(in = "cuin.online.cn.ab.apm.omm.AplcMntSrviInquiryAplcMntIn", out = "cuin.online.cn.ab.apm.omm.AplcMntSrviInquiryAplcMntOut")
	public AplcMntSrviInquiryAplcMntOutDto inquiryAplcMnt(AplcMntSrviInquiryAplcMntInDto aplcMntSrviInquiryAplcMntInDto) {
		if (logger.isDebugEnabled()) {
			logger.debug("서비스 입력 DTO : " + aplcMntSrviInquiryAplcMntInDto);
		}

		AplcMntSrviInquiryAplcMntPgInDto aplcMntSrviInquiryAplcMntPgInDto = BeanUtils.toBean(aplcMntSrviInquiryAplcMntInDto, AplcMntSrviInquiryAplcMntPgInDto.class);
		int recPerPage = aplcMntSrviInquiryAplcMntPgInDto.getRecPerPage();
		DbioUtils.setPagingProperties(aplcMntSrviInquiryAplcMntInDto.getPageNo(), recPerPage, aplcMntSrviInquiryAplcMntPgInDto);
		List<AplcMntSrviInquiryAplcMntGd01Dto> results = aplcMntSrviDao.inquiryAplcMnt(aplcMntSrviInquiryAplcMntPgInDto);
		AplcMntSrviInquiryAplcMntOutDto aplcMntSrviInquiryAplcMntOutDto = new AplcMntSrviInquiryAplcMntOutDto();
		results = DbioUtils.filterPaging(recPerPage, aplcMntSrviInquiryAplcMntInDto.getPageNo(), results, aplcMntSrviInquiryAplcMntOutDto);
		aplcMntSrviInquiryAplcMntOutDto.setGd01List(results);
		return aplcMntSrviInquiryAplcMntOutDto;
	}
}