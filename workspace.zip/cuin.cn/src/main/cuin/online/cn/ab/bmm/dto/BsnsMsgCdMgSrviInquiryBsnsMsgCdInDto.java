package cuin.online.cn.ab.bmm.dto;

import hone.common.util.DateUtils;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.ServicePgInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 업무메시지코드관리
 * 파 일 명 : BsnsMsgCdMgSrviInquiryBsnsMsgCdInDto.java
 * 작 성 자 : 차대현
 * 작 성 일 : 2013.07.22
 * 설     명 : 업무메시지코드조회 입력
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */
public class BsnsMsgCdMgSrviInquiryBsnsMsgCdInDto implements Serializable, ServicePgInDto {
	private static final long serialVersionUID = -4847919886180792363L;

	/**
	 * 조회상세업무코드
	 */
	private String inqDtilBsnsCd;
	/**
	 * 조회업무메시지번호
	 */
	private String inqBsnsMsgNo;
	/**
	 * 조회업무메시지용도코드
	 */
	private String inqBsnsMsgUsgCd;
	/**
	 * 조회업무메시지구분코드
	 */
	private String inqBsnsMsgDvCd;
	/**
	 * 페이지번호
	 */
	private int pageNo;
	/**
	 * 조회업무메시지내용
	 */
	private String inqBsnsMsgCtt;
	/**
	 * 레코드페이지수
	 */
	private int recPerPage;
	/**
	 * 연속유무
	 */
	private int iscont;
	/**
	 * 조회기준적용일시
	 */
	private String inqBaseAplDtm;

	/**
	 * <pre>
	 * 조회상세업무코드 반환 (get inqDtilBsnsCd 4 0)
	 * </pre>
	 */
	public String getInqDtilBsnsCd() {
		return inqDtilBsnsCd;
	}

	/**
	 * <pre>
	 * 조회상세업무코드 설정 (set inqDtilBsnsCd 4 0)
	 * </pre>
	 */
	public void setInqDtilBsnsCd(String inqDtilBsnsCd) {
		this.inqDtilBsnsCd = inqDtilBsnsCd;
	}

	/**
	 * <pre>
	 * 조회업무메시지번호 반환 (get inqBsnsMsgNo 6 0)
	 * </pre>
	 */
	public String getInqBsnsMsgNo() {
		return inqBsnsMsgNo;
	}

	/**
	 * <pre>
	 * 조회업무메시지번호 설정 (set inqBsnsMsgNo 6 0)
	 * </pre>
	 */
	public void setInqBsnsMsgNo(String inqBsnsMsgNo) {
		this.inqBsnsMsgNo = inqBsnsMsgNo;
	}

	/**
	 * <pre>
	 * 조회업무메시지용도코드 반환 (get inqBsnsMsgUsgCd 3 0)
	 * </pre>
	 */
	public String getInqBsnsMsgUsgCd() {
		return inqBsnsMsgUsgCd;
	}

	/**
	 * <pre>
	 * 조회업무메시지용도코드 설정 (set inqBsnsMsgUsgCd 3 0)
	 * </pre>
	 */
	public void setInqBsnsMsgUsgCd(String inqBsnsMsgUsgCd) {
		this.inqBsnsMsgUsgCd = inqBsnsMsgUsgCd;
	}

	/**
	 * <pre>
	 * 조회업무메시지구분코드 반환 (get inqBsnsMsgDvCd 1 0)
	 * </pre>
	 */
	public String getInqBsnsMsgDvCd() {
		return inqBsnsMsgDvCd;
	}

	/**
	 * <pre>
	 * 조회업무메시지구분코드 설정 (set inqBsnsMsgDvCd 1 0)
	 * </pre>
	 */
	public void setInqBsnsMsgDvCd(String inqBsnsMsgDvCd) {
		this.inqBsnsMsgDvCd = inqBsnsMsgDvCd;
	}

	/**
	 * <pre>
	 * 페이지번호 반환 (get pageNo 4 0)
	 * </pre>
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * <pre>
	 * 페이지번호 설정 (set pageNo 4 0)
	 * </pre>
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * <pre>
	 * 조회업무메시지내용 반환 (get inqBsnsMsgCtt 200 0)
	 * </pre>
	 */
	public String getInqBsnsMsgCtt() {
		return inqBsnsMsgCtt;
	}

	/**
	 * <pre>
	 * 조회업무메시지내용 설정 (set inqBsnsMsgCtt 200 0)
	 * </pre>
	 */
	public void setInqBsnsMsgCtt(String inqBsnsMsgCtt) {
		this.inqBsnsMsgCtt = inqBsnsMsgCtt;
	}

	/**
	 * <pre>
	 * 레코드페이지수 반환 (get recPerPage 4 0)
	 * </pre>
	 */
	public int getRecPerPage() {
		return recPerPage;
	}

	/**
	 * <pre>
	 * 레코드페이지수 설정 (set recPerPage 4 0)
	 * </pre>
	 */
	public void setRecPerPage(int recPerPage) {
		this.recPerPage = recPerPage;
	}

	/**
	 * <pre>
	 * 연속유무 반환 (get iscont 1 0)
	 * </pre>
	 */
	public int getIscont() {
		return iscont;
	}

	/**
	 * <pre>
	 * 연속유무 설정 (set iscont 1 0)
	 * </pre>
	 */
	public void setIscont(int iscont) {
		this.iscont = iscont;
	}

	/**
	 * <pre>
	 * 조회기준적용일시 반환 (get inqBaseAplDtm 14 0)
	 * </pre>
	 */
	public String getInqBaseAplDtm() {
		return inqBaseAplDtm;
	}

	/**
	 * <pre>
	 * 조회기준적용일시 Timestamp 타입 반환
	 * </pre>
	 */
	public Timestamp getInqBaseAplDtmTs() {
		return DateUtils.toTimestamp(inqBaseAplDtm);
	}

	/**
	 * <pre>
	 * 조회기준적용일시 설정 (set inqBaseAplDtm 14 0)
	 * </pre>
	 */
	public void setInqBaseAplDtm(String inqBaseAplDtm) {
		this.inqBaseAplDtm = inqBaseAplDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("BsnsMsgCdMgSrviInquiryBsnsMsgCdInDto [");

		sb.append("\n    inqDtilBsnsCd = '").append(getInqDtilBsnsCd()).append("'");
		sb.append("\n    inqBsnsMsgNo = '").append(getInqBsnsMsgNo()).append("'");
		sb.append("\n    inqBsnsMsgUsgCd = '").append(getInqBsnsMsgUsgCd()).append("'");
		sb.append("\n    inqBsnsMsgDvCd = '").append(getInqBsnsMsgDvCd()).append("'");
		sb.append("\n    pageNo = '").append(getPageNo()).append("'");
		sb.append("\n    inqBsnsMsgCtt = '").append(getInqBsnsMsgCtt()).append("'");
		sb.append("\n    recPerPage = '").append(getRecPerPage()).append("'");
		sb.append("\n    iscont = '").append(getIscont()).append("'");
		sb.append("\n    inqBaseAplDtm = '").append(getInqBaseAplDtm()).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
