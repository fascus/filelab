package cuin.online.cn.ab.bmm.dto;

import java.io.Serializable;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 업무 메시지 코드 관리
 * 파 일 명 : BsnsMsgCdMgSrviRegisterBsnsMsgCdOutDto.java
 * 작 성 자 : 차대현
 * 작 성 일 : 2013.06.04
 * 설    명 : 업무 메시지 코드 관리 출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class BsnsMsgCdMgSrviRegisterBsnsMsgCdOutDto implements Serializable {
	private static final long serialVersionUID = -8535486357252845977L;

	/**
	 * 적용시작일시
	 */
	private String aplBgDtm;
	/**
	 * 적용종료일시
	 */
	private String aplEotDtm;
	/**
	 * 일련번호
	 */
	private long chnSeq;

	/**
	 * <pre>
	 * 적용시작일시 반환 (get aplBgDtm 14 0)
	 * </pre>
	 */
	public String getAplBgDtm() {
		return aplBgDtm;
	}

	/**
	 * <pre>
	 * 적용시작일시 설정 (set aplBgDtm 14 0)
	 * </pre>
	 */
	public void setAplBgDtm(String aplBgDtm) {
		this.aplBgDtm = aplBgDtm;
	}

	/**
	 * <pre>
	 * 적용종료일시 반환 (get aplEotDtm 14 0)
	 * </pre>
	 */
	public String getAplEotDtm() {
		return aplEotDtm;
	}

	/**
	 * <pre>
	 * 적용종료일시 설정 (set aplEotDtm 14 0)
	 * </pre>
	 */
	public void setAplEotDtm(String aplEotDtm) {
		this.aplEotDtm = aplEotDtm;
	}

	/**
	 * <pre>
	 * 일련번호 반환 (get chnSeq 10 0)
	 * </pre>
	 */
	public long getChnSeq() {
		return chnSeq;
	}

	/**
	 * <pre>
	 * 일련번호 설정 (set chnSeq 10 0)
	 * </pre>
	 */
	public void setChnSeq(long chnSeq) {
		this.chnSeq = chnSeq;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("BsnsMsgCdMgSrviRegisterBsnsMsgCdOutDto [");

		sb.append("\n    aplBgDtm = '").append(getAplBgDtm()).append("'");
		sb.append("\n    aplEotDtm = '").append(getAplEotDtm()).append("'");
		sb.append("\n    chnSeq = '").append(getChnSeq()).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
