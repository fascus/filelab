package cuin.online.cn.ab.dnl.dto;

import java.io.Serializable;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 파일다운로드
 * 파 일 명 : FileDownloadInquiryGd01Dto.java
 * 작 성 자 : 구교충
 * 작 성 일 : 2013.08.12
 * 설     명 : 파일다운로드 그리드 출력
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */
public class FileDownloadInquiryGd01Dto implements Serializable {
	private static final long serialVersionUID = -4628276604425321029L;

	/**
	 * attFlNm
	 */
	private String attFlNm;
	/**
	 * attFlPthNm
	 */
	private String attFlPthNm;
	/**
	 * flSeq
	 */
	private String flSeq;

	/**
	 * <pre>
	 * attFlNm 반환 (get attFlNm 0 0)
	 * </pre>
	 */
	public String getAttFlNm() {
		return attFlNm;
	}

	/**
	 * <pre>
	 * attFlNm 설정 (set attFlNm 0 0)
	 * </pre>
	 */
	public void setAttFlNm(String attFlNm) {
		this.attFlNm = attFlNm;
	}

	/**
	 * <pre>
	 * attFlPthNm 반환 (get attFlPthNm 0 0)
	 * </pre>
	 */
	public String getAttFlPthNm() {
		return attFlPthNm;
	}

	/**
	 * <pre>
	 * attFlPthNm 설정 (set attFlPthNm 0 0)
	 * </pre>
	 */
	public void setAttFlPthNm(String attFlPthNm) {
		this.attFlPthNm = attFlPthNm;
	}

	/**
	 * <pre>
	 * flSeq 반환 (get flSeq 0 0)
	 * </pre>
	 */
	public String getFlSeq() {
		return flSeq;
	}

	/**
	 * <pre>
	 * flSeq 설정 (set flSeq 0 0)
	 * </pre>
	 */
	public void setFlSeq(String flSeq) {
		this.flSeq = flSeq;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("FileDownloadInquiryGd01Dto [");

		sb.append("\n    attFlNm = '").append(getAttFlNm()).append("'");
		sb.append("\n    attFlPthNm = '").append(getAttFlPthNm()).append("'");
		sb.append("\n    flSeq = '").append(getFlSeq()).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
