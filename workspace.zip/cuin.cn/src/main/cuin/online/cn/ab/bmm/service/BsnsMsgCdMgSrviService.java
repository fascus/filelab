package cuin.online.cn.ab.bmm.service;

import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviDeleteBsnsMsgCdInDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviDeleteBsnsMsgCdOutDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviInquiryBsnsMsgCdInDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviInquiryBsnsMsgCdOutDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviRegisterBsnsMsgCdInDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviRegisterBsnsMsgCdOutDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviUpdateBsnsMsgCdInDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviUpdateBsnsMsgCdOutDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 업무 메시지 코드 관리
 * 파 일 명 : BsnsMsgCdMgSrviService.java
 * 작 성 자 : 차대현
 * 작 성 일 : 2013.06.04
 * 설    명 : 업무메시지코드관리 서비스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface BsnsMsgCdMgSrviService {

	BsnsMsgCdMgSrviInquiryBsnsMsgCdOutDto inquiryBsnsMsgCd(BsnsMsgCdMgSrviInquiryBsnsMsgCdInDto bsnsMsgCdMgSrviInquiryBsnsMsgCdInDto);

	BsnsMsgCdMgSrviRegisterBsnsMsgCdOutDto registerBsnsMsgCd(BsnsMsgCdMgSrviRegisterBsnsMsgCdInDto bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto);

	BsnsMsgCdMgSrviUpdateBsnsMsgCdOutDto updateBsnsMsgCd(BsnsMsgCdMgSrviUpdateBsnsMsgCdInDto bsnsMsgCdMgSrviUpdateBsnsMsgCdInDto);

	BsnsMsgCdMgSrviDeleteBsnsMsgCdOutDto deleteBsnsMsgCd(BsnsMsgCdMgSrviDeleteBsnsMsgCdInDto bsnsMsgCdMgSrviDeleteBsnsMsgCdInDto);

}
