package cuin.online.cn.ab.bat.service;

import cuin.online.cn.ab.bat.dto.BatchResultDownloadInquiryInDto;
import cuin.online.cn.ab.bat.dto.BatchResultDownloadInquiryOutDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 배치결과파일다운로드
 * 파 일 명 : BatchResultDownloadService.java
 * 작 성 자 : 구교충
 * 작 성 일 : 2013.08.13
 * 설     명 : 배치결과파일다운로드 서비스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface BatchResultDownloadService {

	BatchResultDownloadInquiryOutDto inquiry(BatchResultDownloadInquiryInDto batchResultDownloadInquiryInDto);
}
