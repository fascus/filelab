package cuin.online.cn.ab.dnl.dto;

import java.io.Serializable;

import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 파일다운로드
 * 파 일 명 : FileDownloadInquiryInDto.java
 * 작 성 자 : 구교충
 * 작 성 일 : 2013.08.12
 * 설     명 : 파일다운로드 입력
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */
public class FileDownloadInquiryInDto implements Serializable, ServiceInDto {
	private static final long serialVersionUID = -8232399139429267102L;

	/**
	 * 업무구분코드
	 */
	private String bsnsDvCd;
	/**
	 * 대상식별번호구분코드
	 */
	private String sbjIdfNoDvCd;
	/**
	 * 대상식별번호
	 */
	private String sbjIdfNo;

	/**
	 * <pre>
	 * 업무구분코드 반환 (get bsnsDvCd 2 0)
	 * </pre>
	 */
	public String getBsnsDvCd() {
		return bsnsDvCd;
	}

	/**
	 * <pre>
	 * 업무구분코드 설정 (set bsnsDvCd 2 0)
	 * </pre>
	 */
	public void setBsnsDvCd(String bsnsDvCd) {
		this.bsnsDvCd = bsnsDvCd;
	}

	/**
	 * <pre>
	 * 대상식별번호구분코드 반환 (get sbjIdfNoDvCd 2 0)
	 * </pre>
	 */
	public String getSbjIdfNoDvCd() {
		return sbjIdfNoDvCd;
	}

	/**
	 * <pre>
	 * 대상식별번호구분코드 설정 (set sbjIdfNoDvCd 2 0)
	 * </pre>
	 */
	public void setSbjIdfNoDvCd(String sbjIdfNoDvCd) {
		this.sbjIdfNoDvCd = sbjIdfNoDvCd;
	}

	/**
	 * <pre>
	 * 대상식별번호 반환 (get sbjIdfNo 12 0)
	 * </pre>
	 */
	public String getSbjIdfNo() {
		return sbjIdfNo;
	}

	/**
	 * <pre>
	 * 대상식별번호 설정 (set sbjIdfNo 12 0)
	 * </pre>
	 */
	public void setSbjIdfNo(String sbjIdfNo) {
		this.sbjIdfNo = sbjIdfNo;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("FileDownloadInquiryInDto [");

		sb.append("\n    bsnsDvCd = '").append(getBsnsDvCd()).append("'");
		sb.append("\n    sbjIdfNoDvCd = '").append(getSbjIdfNoDvCd()).append("'");
		sb.append("\n    sbjIdfNo = '").append(getSbjIdfNo()).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
