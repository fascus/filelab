package cuin.online.cn.ab.apm.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.online.cn.ab.apm.dto.AplcMntSrviInquiryAplcMntGd01Dto;
import cuin.online.cn.ab.apm.dto.AplcMntSrviInquiryAplcMntPgInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 어플리케이션모니터링
 * 파 일 명 : AplcMntSrviDaoImpl.java
 * 작 성 자 : 이준우
 * 작 성 일 : 2013.11.13
 * 설     명 : 어플리케이션모니터링 DAO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.online.cn.ab.apm.hqml.AplcMntSrvi")
public class AplcMntSrviDaoImpl extends DbioDaoSupport implements AplcMntSrviDao {

	public List<AplcMntSrviInquiryAplcMntGd01Dto> inquiryAplcMnt(AplcMntSrviInquiryAplcMntPgInDto aplcMntSrviInquiryAplcMntPgInDto) {
		String sql = getSql("cuin.online.cn.ab.apm.hqml.AplcMntSrvi.inquiryAplcMnt", aplcMntSrviInquiryAplcMntPgInDto);
		return queryForList(sql, new BeanPropertySqlParameterSource(aplcMntSrviInquiryAplcMntPgInDto), new BeanPropertyRowMapper<AplcMntSrviInquiryAplcMntGd01Dto>(
				AplcMntSrviInquiryAplcMntGd01Dto.class));
	}

}