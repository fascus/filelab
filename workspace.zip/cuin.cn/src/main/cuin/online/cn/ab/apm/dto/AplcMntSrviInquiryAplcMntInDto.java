package cuin.online.cn.ab.apm.dto;

import hone.common.util.DateUtils;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.ServicePgInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 어플리케이션모니터링
 * 파 일 명 : AplcMntSrviInquiryAplcMntInDto.java
 * 작 성 자 : 이준우
 * 작 성 일 : 2013.11.19
 * 설     명 : 어플리케이션모니터링 조회 입력
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */
public class AplcMntSrviInquiryAplcMntInDto implements Serializable, ServicePgInDto {
	private static final long serialVersionUID = -1256889706962860092L;

	/**
	 * 조회거래시작일자
	 */
	private String inqTranBgDt;
	/**
	 * 조회거래종료일자
	 */
	private String inqTranEotDt;
	/**
	 * GLOBAL_ID
	 */
	private String inqGlbId;
	/**
	 * 거래ID
	 */
	private String inqTrnId;
	/**
	 * 연속유무
	 */
	private int iscont;
	/**
	 * 페이지번호
	 */
	private int pageNo;
	/**
	 * 연속조회
	 */
	private String iscontyn;
	/**
	 * 레코드페이지수
	 */
	private int recPerPage;

	/**
	 * <pre>
	 * 조회거래시작일자 반환 (get inqTranBgDt 8 0)
	 * </pre>
	 */
	public String getInqTranBgDt() {
		return inqTranBgDt;
	}

	/**
	 * <pre>
	 * 조회거래시작일자 Timestamp 타입 반환
	 * </pre>
	 */
	public Timestamp getInqTranBgDtTs() {
		return DateUtils.toTimestamp(inqTranBgDt);
	}

	/**
	 * <pre>
	 * 조회거래시작일자 설정 (set inqTranBgDt 8 0)
	 * </pre>
	 */
	public void setInqTranBgDt(String inqTranBgDt) {
		this.inqTranBgDt = inqTranBgDt;
	}

	/**
	 * <pre>
	 * 조회거래종료일자 반환 (get inqTranEotDt 8 0)
	 * </pre>
	 */
	public String getInqTranEotDt() {
		return inqTranEotDt;
	}

	/**
	 * <pre>
	 * 조회거래종료일자 Timestamp 타입 반환
	 * </pre>
	 */
	public Timestamp getInqTranEotDtTs() {
		return DateUtils.toTimestamp(inqTranEotDt);
	}

	/**
	 * <pre>
	 * 조회거래종료일자 설정 (set inqTranEotDt 8 0)
	 * </pre>
	 */
	public void setInqTranEotDt(String inqTranEotDt) {
		this.inqTranEotDt = inqTranEotDt;
	}

	/**
	 * <pre>
	 * GLOBAL_ID 반환 (get inqGlbId 32 0)
	 * </pre>
	 */
	public String getInqGlbId() {
		return inqGlbId;
	}

	/**
	 * <pre>
	 * GLOBAL_ID 설정 (set inqGlbId 32 0)
	 * </pre>
	 */
	public void setInqGlbId(String inqGlbId) {
		this.inqGlbId = inqGlbId;
	}

	/**
	 * <pre>
	 * 거래ID 반환 (get inqTrnId 12 0)
	 * </pre>
	 */
	public String getInqTrnId() {
		return inqTrnId;
	}

	/**
	 * <pre>
	 * 거래ID 설정 (set inqTrnId 12 0)
	 * </pre>
	 */
	public void setInqTrnId(String inqTrnId) {
		this.inqTrnId = inqTrnId;
	}

	/**
	 * <pre>
	 * 연속유무 반환 (get iscont 1 0)
	 * </pre>
	 */
	public int getIscont() {
		return iscont;
	}

	/**
	 * <pre>
	 * 연속유무 설정 (set iscont 1 0)
	 * </pre>
	 */
	public void setIscont(int iscont) {
		this.iscont = iscont;
	}

	/**
	 * <pre>
	 * 페이지번호 반환 (get pageNo 4 0)
	 * </pre>
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * <pre>
	 * 페이지번호 설정 (set pageNo 4 0)
	 * </pre>
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * <pre>
	 * 연속조회 반환 (get iscontyn 1 0)
	 * </pre>
	 */
	public String getIscontyn() {
		return iscontyn;
	}

	/**
	 * <pre>
	 * 연속조회 설정 (set iscontyn 1 0)
	 * </pre>
	 */
	public void setIscontyn(String iscontyn) {
		this.iscontyn = iscontyn;
	}

	/**
	 * <pre>
	 * 레코드페이지수 반환 (get recPerPage 4 0)
	 * </pre>
	 */
	public int getRecPerPage() {
		return recPerPage;
	}

	/**
	 * <pre>
	 * 레코드페이지수 설정 (set recPerPage 4 0)
	 * </pre>
	 */
	public void setRecPerPage(int recPerPage) {
		this.recPerPage = recPerPage;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("AplcMntSrviInquiryAplcMntInDto [");

		sb.append("\n    inqTranBgDt = '").append(getInqTranBgDt()).append("'");
		sb.append("\n    inqTranEotDt = '").append(getInqTranEotDt()).append("'");
		sb.append("\n    inqGlbId = '").append(getInqGlbId()).append("'");
		sb.append("\n    inqTrnId = '").append(getInqTrnId()).append("'");
		sb.append("\n    iscont = '").append(getIscont()).append("'");
		sb.append("\n    pageNo = '").append(getPageNo()).append("'");
		sb.append("\n    iscontyn = '").append(getIscontyn()).append("'");
		sb.append("\n    recPerPage = '").append(getRecPerPage()).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
