package cuin.online.cn.ab.bmm.dao;

import java.util.List;

import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviInquiryBsnsMsgCdGd01Dto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviRegisterBsnsMsgCdInDto;
import cuin.online.cn.ab.bmm.dto.BsnsMsgCdMgSrviUpdateBsnsMsgCdInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 업무 메시지 코드 관리
 * 파 일 명 : BsnsMsgCdMgSrviDao.java
 * 작 성 자 : 차대현
 * 작 성 일 : 2013.06.04
 * 설    명 : 업무메시지코드관리 DAO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface BsnsMsgCdMgSrviDao {

	List<BsnsMsgCdMgSrviInquiryBsnsMsgCdGd01Dto> inquiryBsnsMsgCd(BsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto bsnsMsgCdMgSrviInquiryBsnsMsgCdPgInDto);

	int chkDup(BsnsMsgCdMgSrviRegisterBsnsMsgCdInDto bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto);

	int chkDup(BsnsMsgCdMgSrviUpdateBsnsMsgCdInDto bsnsMsgCdMgSrviUpdateBsnsMsgCdInDto);

	Long numberChkSeq(BsnsMsgCdMgSrviRegisterBsnsMsgCdInDto bsnsMsgCdMgSrviRegisterBsnsMsgCdInDto);
}
