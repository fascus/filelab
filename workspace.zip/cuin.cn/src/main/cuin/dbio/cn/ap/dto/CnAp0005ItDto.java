/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAp0005ItDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AP0005_IT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnAp0005ItDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -4542070918429458188L;

	/**
	 * 책임자결재문서ID
	 */
	private Long pihApprDcmId;

	/**
	 * 결재정보일련번호
	 */
	private Long apprInfoSeq;

	/**
	 * 결재요청자사원번호
	 */
	private String apprRqtrEmpNo;

	/**
	 * 결재요청일시
	 */
	private Timestamp apprRqstDtm;

	/**
	 * 결재요청조직구분코드
	 */
	private String apprRqstOrzDvCd;

	/**
	 * 결재요청조직코드
	 */
	private String apprRqstOrzCd;

	/**
	 * 결재요청의견내용
	 */
	private String apprRqstOpnnCtt;

	/**
	 * 결재처리조직구분코드
	 */
	private String apprPrceOrzDvCd;

	/**
	 * 결재처리조직코드
	 */
	private String apprPrceOrzCd;

	/**
	 * 결재자사원번호
	 */
	private String apvrEmpNo;

	/**
	 * 실제결재자사원번호
	 */
	private String aclApvrEmpNo;

	/**
	 * 결재일시
	 */
	private Timestamp apprDtm;

	/**
	 * 결재의견내용
	 */
	private String apprOpnnCtt;

	/**
	 * 일괄결재여부
	 */
	private String btcApprYn;

	/**
	 * 결재구분코드
	 */
	private String apprDvCd;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '책임자결재문서ID' 반환
	 */
	public Long getPihApprDcmId() {
		return pihApprDcmId;
	}

	/**
	 * '책임자결재문서ID' 설정
	 */
	public void setPihApprDcmId(Long pihApprDcmId) {
		this.pihApprDcmId = pihApprDcmId;
	}

	/**
	 * '결재정보일련번호' 반환
	 */
	public Long getApprInfoSeq() {
		return apprInfoSeq;
	}

	/**
	 * '결재정보일련번호' 설정
	 */
	public void setApprInfoSeq(Long apprInfoSeq) {
		this.apprInfoSeq = apprInfoSeq;
	}

	/**
	 * '결재요청자사원번호' 반환
	 */
	public String getApprRqtrEmpNo() {
		return apprRqtrEmpNo;
	}

	/**
	 * '결재요청자사원번호' 설정
	 */
	public void setApprRqtrEmpNo(String apprRqtrEmpNo) {
		this.apprRqtrEmpNo = apprRqtrEmpNo;
	}

	/**
	 * '결재요청일시' 반환
	 */
	public Timestamp getApprRqstDtm() {
		return apprRqstDtm;
	}

	/**
	 * '결재요청일시' 설정
	 */
	public void setApprRqstDtm(Timestamp apprRqstDtm) {
		this.apprRqstDtm = apprRqstDtm;
	}

	/**
	 * '결재요청조직구분코드' 반환
	 */
	public String getApprRqstOrzDvCd() {
		return apprRqstOrzDvCd;
	}

	/**
	 * '결재요청조직구분코드' 설정
	 */
	public void setApprRqstOrzDvCd(String apprRqstOrzDvCd) {
		this.apprRqstOrzDvCd = apprRqstOrzDvCd;
	}

	/**
	 * '결재요청조직코드' 반환
	 */
	public String getApprRqstOrzCd() {
		return apprRqstOrzCd;
	}

	/**
	 * '결재요청조직코드' 설정
	 */
	public void setApprRqstOrzCd(String apprRqstOrzCd) {
		this.apprRqstOrzCd = apprRqstOrzCd;
	}

	/**
	 * '결재요청의견내용' 반환
	 */
	public String getApprRqstOpnnCtt() {
		return apprRqstOpnnCtt;
	}

	/**
	 * '결재요청의견내용' 설정
	 */
	public void setApprRqstOpnnCtt(String apprRqstOpnnCtt) {
		this.apprRqstOpnnCtt = apprRqstOpnnCtt;
	}

	/**
	 * '결재처리조직구분코드' 반환
	 */
	public String getApprPrceOrzDvCd() {
		return apprPrceOrzDvCd;
	}

	/**
	 * '결재처리조직구분코드' 설정
	 */
	public void setApprPrceOrzDvCd(String apprPrceOrzDvCd) {
		this.apprPrceOrzDvCd = apprPrceOrzDvCd;
	}

	/**
	 * '결재처리조직코드' 반환
	 */
	public String getApprPrceOrzCd() {
		return apprPrceOrzCd;
	}

	/**
	 * '결재처리조직코드' 설정
	 */
	public void setApprPrceOrzCd(String apprPrceOrzCd) {
		this.apprPrceOrzCd = apprPrceOrzCd;
	}

	/**
	 * '결재자사원번호' 반환
	 */
	public String getApvrEmpNo() {
		return apvrEmpNo;
	}

	/**
	 * '결재자사원번호' 설정
	 */
	public void setApvrEmpNo(String apvrEmpNo) {
		this.apvrEmpNo = apvrEmpNo;
	}

	/**
	 * '실제결재자사원번호' 반환
	 */
	public String getAclApvrEmpNo() {
		return aclApvrEmpNo;
	}

	/**
	 * '실제결재자사원번호' 설정
	 */
	public void setAclApvrEmpNo(String aclApvrEmpNo) {
		this.aclApvrEmpNo = aclApvrEmpNo;
	}

	/**
	 * '결재일시' 반환
	 */
	public Timestamp getApprDtm() {
		return apprDtm;
	}

	/**
	 * '결재일시' 설정
	 */
	public void setApprDtm(Timestamp apprDtm) {
		this.apprDtm = apprDtm;
	}

	/**
	 * '결재의견내용' 반환
	 */
	public String getApprOpnnCtt() {
		return apprOpnnCtt;
	}

	/**
	 * '결재의견내용' 설정
	 */
	public void setApprOpnnCtt(String apprOpnnCtt) {
		this.apprOpnnCtt = apprOpnnCtt;
	}

	/**
	 * '일괄결재여부' 반환
	 */
	public String getBtcApprYn() {
		return btcApprYn;
	}

	/**
	 * '일괄결재여부' 설정
	 */
	public void setBtcApprYn(String btcApprYn) {
		this.btcApprYn = btcApprYn;
	}

	/**
	 * '결재구분코드' 반환
	 */
	public String getApprDvCd() {
		return apprDvCd;
	}

	/**
	 * '결재구분코드' 설정
	 */
	public void setApprDvCd(String apprDvCd) {
		this.apprDvCd = apprDvCd;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAp0005ItDto [");
		sb.append("\n    pihApprDcmId = '").append(pihApprDcmId).append("'");
		sb.append("\n    apprInfoSeq = '").append(apprInfoSeq).append("'");
		sb.append("\n    apprRqtrEmpNo = '").append(apprRqtrEmpNo).append("'");
		sb.append("\n    apprRqstDtm = '").append(apprRqstDtm).append("'");
		sb.append("\n    apprRqstOrzDvCd = '").append(apprRqstOrzDvCd)
				.append("'");
		sb.append("\n    apprRqstOrzCd = '").append(apprRqstOrzCd).append("'");
		sb.append("\n    apprRqstOpnnCtt = '").append(apprRqstOpnnCtt)
				.append("'");
		sb.append("\n    apprPrceOrzDvCd = '").append(apprPrceOrzDvCd)
				.append("'");
		sb.append("\n    apprPrceOrzCd = '").append(apprPrceOrzCd).append("'");
		sb.append("\n    apvrEmpNo = '").append(apvrEmpNo).append("'");
		sb.append("\n    aclApvrEmpNo = '").append(aclApvrEmpNo).append("'");
		sb.append("\n    apprDtm = '").append(apprDtm).append("'");
		sb.append("\n    apprOpnnCtt = '").append(apprOpnnCtt).append("'");
		sb.append("\n    btcApprYn = '").append(btcApprYn).append("'");
		sb.append("\n    apprDvCd = '").append(apprDvCd).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAp0005ItDto : PK [");
		sb.append("\n    pihApprDcmId = '").append(pihApprDcmId).append("'");
		sb.append("\n    apprInfoSeq = '").append(apprInfoSeq).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
