/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ap.dto.CnAp0004MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAp0004MtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AP0004_MT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ap.hqml.CnAp0004Mt")
public class CnAp0004MtDaoImpl extends DbioDaoSupport implements CnAp0004MtDao {

	/**
	 * CN_AP0004_MT (CN_AP0004_MT) 단건 조회.
	 * 
	 */
	public CnAp0004MtDto select(CnAp0004MtDto cnAp0004MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0004Mt.select",
				cnAp0004MtDto);

		CnAp0004MtDto foundCnAp0004MtDto = null;
		try {
			foundCnAp0004MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAp0004MtDto),
					new BeanPropertyRowMapper<CnAp0004MtDto>(
							CnAp0004MtDto.class));
			return foundCnAp0004MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_AP0004_MT (CN_AP0004_MT) 단건 등록.
	 * 
	 */
	public int insert(CnAp0004MtDto cnAp0004MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0004Mt.insert",
				cnAp0004MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0004MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0004_MT (CN_AP0004_MT) 단건 변경.
	 * 
	 */
	public int update(CnAp0004MtDto cnAp0004MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0004Mt.update",
				cnAp0004MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0004MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0004_MT (CN_AP0004_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnAp0004MtDto cnAp0004MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0004Mt.delete",
				cnAp0004MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0004MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0004_MT (CN_AP0004_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnAp0004MtDto> list(CnAp0004MtDto cnAp0004MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0004Mt.list",
				cnAp0004MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnAp0004MtDto), new BeanPropertyRowMapper<CnAp0004MtDto>(
				CnAp0004MtDto.class));
	}

	/**
	 * CN_AP0004_MT (CN_AP0004_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnAp0004MtDto> cnAp0004MtDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0004Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0004MtDtos
				.size()];
		for (int i = 0; i < cnAp0004MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0004MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0004_MT (CN_AP0004_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnAp0004MtDto> cnAp0004MtDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0004Mt.update",
				cnAp0004MtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnAp0004MtDtos
				.size()];
		for (int i = 0; i < cnAp0004MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0004MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0004_MT (CN_AP0004_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnAp0004MtDto> cnAp0004MtDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0004Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0004MtDtos
				.size()];
		for (int i = 0; i < cnAp0004MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0004MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
