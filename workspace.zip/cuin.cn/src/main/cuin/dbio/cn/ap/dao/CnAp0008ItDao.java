/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dao;

import java.util.List;

import cuin.dbio.cn.ap.dto.CnAp0008ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAp0008ItDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AP0008_IT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnAp0008ItDao {

	CnAp0008ItDto select(CnAp0008ItDto cnAp0008ItDto);

	int insert(CnAp0008ItDto cnAp0008ItDto);

	int update(CnAp0008ItDto cnAp0008ItDto);

	int delete(CnAp0008ItDto cnAp0008ItDto);

	List<CnAp0008ItDto> list(CnAp0008ItDto cnAp0008ItDto);

	int[] insertList(List<CnAp0008ItDto> cnAp0008ItDtos);

	int[] updateList(List<CnAp0008ItDto> cnAp0008ItDtos);

	int[] deleteList(List<CnAp0008ItDto> cnAp0008ItDtos);

}
