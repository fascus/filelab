/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ap.dto.CnAp0006MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAp0006MtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AP0006_MT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ap.hqml.CnAp0006Mt")
public class CnAp0006MtDaoImpl extends DbioDaoSupport implements CnAp0006MtDao {

	/**
	 * CN_AP0006_MT (CN_AP0006_MT) 단건 조회.
	 * 
	 */
	public CnAp0006MtDto select(CnAp0006MtDto cnAp0006MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0006Mt.select",
				cnAp0006MtDto);

		CnAp0006MtDto foundCnAp0006MtDto = null;
		try {
			foundCnAp0006MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAp0006MtDto),
					new BeanPropertyRowMapper<CnAp0006MtDto>(
							CnAp0006MtDto.class));
			return foundCnAp0006MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_AP0006_MT (CN_AP0006_MT) 단건 등록.
	 * 
	 */
	public int insert(CnAp0006MtDto cnAp0006MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0006Mt.insert",
				cnAp0006MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0006MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0006_MT (CN_AP0006_MT) 단건 변경.
	 * 
	 */
	public int update(CnAp0006MtDto cnAp0006MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0006Mt.update",
				cnAp0006MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0006MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0006_MT (CN_AP0006_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnAp0006MtDto cnAp0006MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0006Mt.delete",
				cnAp0006MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0006MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0006_MT (CN_AP0006_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnAp0006MtDto> list(CnAp0006MtDto cnAp0006MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0006Mt.list",
				cnAp0006MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnAp0006MtDto), new BeanPropertyRowMapper<CnAp0006MtDto>(
				CnAp0006MtDto.class));
	}

	/**
	 * CN_AP0006_MT (CN_AP0006_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnAp0006MtDto> cnAp0006MtDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0006Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0006MtDtos
				.size()];
		for (int i = 0; i < cnAp0006MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0006MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0006_MT (CN_AP0006_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnAp0006MtDto> cnAp0006MtDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0006Mt.update",
				cnAp0006MtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnAp0006MtDtos
				.size()];
		for (int i = 0; i < cnAp0006MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0006MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0006_MT (CN_AP0006_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnAp0006MtDto> cnAp0006MtDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0006Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0006MtDtos
				.size()];
		for (int i = 0; i < cnAp0006MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0006MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
