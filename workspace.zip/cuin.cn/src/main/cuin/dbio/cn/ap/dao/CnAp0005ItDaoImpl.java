/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ap.dto.CnAp0005ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAp0005ItDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AP0005_IT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ap.hqml.CnAp0005It")
public class CnAp0005ItDaoImpl extends DbioDaoSupport implements CnAp0005ItDao {

	/**
	 * CN_AP0005_IT (CN_AP0005_IT) 단건 조회.
	 * 
	 */
	public CnAp0005ItDto select(CnAp0005ItDto cnAp0005ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0005It.select",
				cnAp0005ItDto);

		CnAp0005ItDto foundCnAp0005ItDto = null;
		try {
			foundCnAp0005ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAp0005ItDto),
					new BeanPropertyRowMapper<CnAp0005ItDto>(
							CnAp0005ItDto.class));
			return foundCnAp0005ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_AP0005_IT (CN_AP0005_IT) 단건 등록.
	 * 
	 */
	public int insert(CnAp0005ItDto cnAp0005ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0005It.insert",
				cnAp0005ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0005ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0005_IT (CN_AP0005_IT) 단건 변경.
	 * 
	 */
	public int update(CnAp0005ItDto cnAp0005ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0005It.update",
				cnAp0005ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0005ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0005_IT (CN_AP0005_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnAp0005ItDto cnAp0005ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0005It.delete",
				cnAp0005ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0005ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0005_IT (CN_AP0005_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnAp0005ItDto> list(CnAp0005ItDto cnAp0005ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0005It.list",
				cnAp0005ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnAp0005ItDto), new BeanPropertyRowMapper<CnAp0005ItDto>(
				CnAp0005ItDto.class));
	}

	/**
	 * CN_AP0005_IT (CN_AP0005_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnAp0005ItDto> cnAp0005ItDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0005It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0005ItDtos
				.size()];
		for (int i = 0; i < cnAp0005ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0005ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0005_IT (CN_AP0005_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnAp0005ItDto> cnAp0005ItDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0005It.update",
				cnAp0005ItDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnAp0005ItDtos
				.size()];
		for (int i = 0; i < cnAp0005ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0005ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0005_IT (CN_AP0005_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnAp0005ItDto> cnAp0005ItDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0005It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0005ItDtos
				.size()];
		for (int i = 0; i < cnAp0005ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0005ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
