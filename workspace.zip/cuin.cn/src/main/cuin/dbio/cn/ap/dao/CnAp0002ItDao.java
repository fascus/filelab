/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dao;

import java.util.List;

import cuin.dbio.cn.ap.dto.CnAp0002ItDto;

/**
 * CN_AP0002_IT (CN_AP0002_IT) DAO 인터페이스.
 *
 * 
 */
public interface CnAp0002ItDao {

	CnAp0002ItDto select(CnAp0002ItDto cnAp0002ItDto);

	int insert(CnAp0002ItDto cnAp0002ItDto);

	int update(CnAp0002ItDto cnAp0002ItDto);

	int delete(CnAp0002ItDto cnAp0002ItDto);

	List<CnAp0002ItDto> list(CnAp0002ItDto cnAp0002ItDto);

	int[] insertList(List<CnAp0002ItDto> cnAp0002ItDtos);

	int[] updateList(List<CnAp0002ItDto> cnAp0002ItDtos);

	int[] deleteList(List<CnAp0002ItDto> cnAp0002ItDtos);

}
