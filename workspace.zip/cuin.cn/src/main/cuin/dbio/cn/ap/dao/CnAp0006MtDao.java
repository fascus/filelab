/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dao;

import java.util.List;

import cuin.dbio.cn.ap.dto.CnAp0006MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAp0006MtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AP0006_MT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnAp0006MtDao {

	CnAp0006MtDto select(CnAp0006MtDto cnAp0006MtDto);

	int insert(CnAp0006MtDto cnAp0006MtDto);

	int update(CnAp0006MtDto cnAp0006MtDto);

	int delete(CnAp0006MtDto cnAp0006MtDto);

	List<CnAp0006MtDto> list(CnAp0006MtDto cnAp0006MtDto);

	int[] insertList(List<CnAp0006MtDto> cnAp0006MtDtos);

	int[] updateList(List<CnAp0006MtDto> cnAp0006MtDtos);

	int[] deleteList(List<CnAp0006MtDto> cnAp0006MtDtos);

}
