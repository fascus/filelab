/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAp0008ItDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AP0008_IT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnAp0008ItDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -3804416859053339121L;

	/**
	 * 사원번호
	 */
	private String empNo;

	/**
	 * 결재상세업무코드
	 */
	private String apprDtilBsnsCd;

	/**
	 * 권한여부
	 */
	private String athYn;

	/**
	 * 다음결재자사원번호
	 */
	private String nxApvrEmpNo;

	/**
	 * 배정일시
	 */
	private Timestamp alcDtm;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '사원번호' 반환
	 */
	public String getEmpNo() {
		return empNo;
	}

	/**
	 * '사원번호' 설정
	 */
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}

	/**
	 * '결재상세업무코드' 반환
	 */
	public String getApprDtilBsnsCd() {
		return apprDtilBsnsCd;
	}

	/**
	 * '결재상세업무코드' 설정
	 */
	public void setApprDtilBsnsCd(String apprDtilBsnsCd) {
		this.apprDtilBsnsCd = apprDtilBsnsCd;
	}

	/**
	 * '권한여부' 반환
	 */
	public String getAthYn() {
		return athYn;
	}

	/**
	 * '권한여부' 설정
	 */
	public void setAthYn(String athYn) {
		this.athYn = athYn;
	}

	/**
	 * '다음결재자사원번호' 반환
	 */
	public String getNxApvrEmpNo() {
		return nxApvrEmpNo;
	}

	/**
	 * '다음결재자사원번호' 설정
	 */
	public void setNxApvrEmpNo(String nxApvrEmpNo) {
		this.nxApvrEmpNo = nxApvrEmpNo;
	}

	/**
	 * '배정일시' 반환
	 */
	public Timestamp getAlcDtm() {
		return alcDtm;
	}

	/**
	 * '배정일시' 설정
	 */
	public void setAlcDtm(Timestamp alcDtm) {
		this.alcDtm = alcDtm;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAp0008ItDto [");
		sb.append("\n    empNo = '").append(empNo).append("'");
		sb.append("\n    apprDtilBsnsCd = '").append(apprDtilBsnsCd)
				.append("'");
		sb.append("\n    athYn = '").append(athYn).append("'");
		sb.append("\n    nxApvrEmpNo = '").append(nxApvrEmpNo).append("'");
		sb.append("\n    alcDtm = '").append(alcDtm).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAp0008ItDto : PK [");
		sb.append("\n    empNo = '").append(empNo).append("'");
		sb.append("\n    apprDtilBsnsCd = '").append(apprDtilBsnsCd)
				.append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
