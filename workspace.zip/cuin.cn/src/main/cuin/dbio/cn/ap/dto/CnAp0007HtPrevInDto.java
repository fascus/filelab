package cuin.dbio.cn.ap.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * CN_AP0007_HT (CN_AP0007_HT) 테이블 이력 단건 조회 DTO.
 */
public class CnAp0007HtPrevInDto implements Serializable {

	private static final long serialVersionUID = -9163199225883770837L;

	/**
	 * 이력 조회를 위한 기준 일시
	 */
	private Timestamp baseDtm;

	/**
	 * 사원번호
	 */
	private String empNo;

	/**
	 * 기준 일시 반환
	 */
	public Timestamp getBaseDtm() {
		return baseDtm;
	}

	/**
	 * 기준 일시 설정
	 */
	public void setBaseDtm(Timestamp baseDtm) {
		this.baseDtm = baseDtm;
	}

	/**
	 * '사원번호' 반환
	 */
	public String getEmpNo() {
		return empNo;
	}

	/**
	 * '사원번호' 설정
	 */
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}

}