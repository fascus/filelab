/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ap.dto.CnAp0002ItDto;

/**
 * CN_AP0002_IT (CN_AP0002_IT) DAO 구현체.
 *
 * @stereotype DAO
 * 
 * 
 */

@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ap.hqml.CnAp0002It")
public class CnAp0002ItDaoImpl extends DbioDaoSupport implements CnAp0002ItDao {

	/**
	 * CN_AP0002_IT (CN_AP0002_IT) 단건 조회.
	 * 
	 */
	public CnAp0002ItDto select(CnAp0002ItDto cnAp0002ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0002It.select",
				cnAp0002ItDto);

		CnAp0002ItDto foundCnAp0002ItDto = null;
		try {
			foundCnAp0002ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAp0002ItDto),
					new BeanPropertyRowMapper<CnAp0002ItDto>(
							CnAp0002ItDto.class));
			return foundCnAp0002ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_AP0002_IT (CN_AP0002_IT) 단건 등록.
	 * 
	 */
	public int insert(CnAp0002ItDto cnAp0002ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0002It.insert",
				cnAp0002ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0002ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0002_IT (CN_AP0002_IT) 단건 변경.
	 * 
	 */
	public int update(CnAp0002ItDto cnAp0002ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0002It.update",
				cnAp0002ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0002ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0002_IT (CN_AP0002_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnAp0002ItDto cnAp0002ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0002It.delete",
				cnAp0002ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0002ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0002_IT (CN_AP0002_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnAp0002ItDto> list(CnAp0002ItDto cnAp0002ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0002It.list",
				cnAp0002ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnAp0002ItDto), new BeanPropertyRowMapper<CnAp0002ItDto>(
				CnAp0002ItDto.class));
	}

	/**
	 * CN_AP0002_IT (CN_AP0002_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnAp0002ItDto> cnAp0002ItDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0002It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0002ItDtos
				.size()];
		for (int i = 0; i < cnAp0002ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0002ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0002_IT (CN_AP0002_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnAp0002ItDto> cnAp0002ItDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0002It.update");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0002ItDtos
				.size()];
		for (int i = 0; i < cnAp0002ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0002ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0002_IT (CN_AP0002_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnAp0002ItDto> cnAp0002ItDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0002It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0002ItDtos
				.size()];
		for (int i = 0; i < cnAp0002ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0002ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
