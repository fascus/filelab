/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ap.dto.CnAp0003ItDto;

/**
 * CN_AP0003_IT (CN_AP0003_IT) DAO 구현체.
 *
 * @stereotype DAO
 * 
 * 
 */

@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ap.hqml.CnAp0003It")
public class CnAp0003ItDaoImpl extends DbioDaoSupport implements CnAp0003ItDao {

	/**
	 * CN_AP0003_IT (CN_AP0003_IT) 단건 조회.
	 * 
	 */
	public CnAp0003ItDto select(CnAp0003ItDto cnAp0003ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0003It.select",
				cnAp0003ItDto);

		CnAp0003ItDto foundCnAp0003ItDto = null;
		try {
			foundCnAp0003ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAp0003ItDto),
					new BeanPropertyRowMapper<CnAp0003ItDto>(
							CnAp0003ItDto.class));
			return foundCnAp0003ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_AP0003_IT (CN_AP0003_IT) 단건 등록.
	 * 
	 */
	public int insert(CnAp0003ItDto cnAp0003ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0003It.insert",
				cnAp0003ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0003ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0003_IT (CN_AP0003_IT) 단건 변경.
	 * 
	 */
	public int update(CnAp0003ItDto cnAp0003ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0003It.update",
				cnAp0003ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0003ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0003_IT (CN_AP0003_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnAp0003ItDto cnAp0003ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0003It.delete",
				cnAp0003ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0003ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0003_IT (CN_AP0003_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnAp0003ItDto> list(CnAp0003ItDto cnAp0003ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0003It.list",
				cnAp0003ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnAp0003ItDto), new BeanPropertyRowMapper<CnAp0003ItDto>(
				CnAp0003ItDto.class));
	}

	/**
	 * CN_AP0003_IT (CN_AP0003_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnAp0003ItDto> cnAp0003ItDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0003It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0003ItDtos
				.size()];
		for (int i = 0; i < cnAp0003ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0003ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0003_IT (CN_AP0003_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnAp0003ItDto> cnAp0003ItDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0003It.update");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0003ItDtos
				.size()];
		for (int i = 0; i < cnAp0003ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0003ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0003_IT (CN_AP0003_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnAp0003ItDto> cnAp0003ItDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0003It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0003ItDtos
				.size()];
		for (int i = 0; i < cnAp0003ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0003ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
