/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAp0004MtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AP0004_MT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnAp0004MtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -6345837318889651296L;

	/**
	 * 책임자결재문서ID
	 */
	private Long pihApprDcmId;

	/**
	 * 결재요청조직구분코드
	 */
	private String apprRqstOrzDvCd;

	/**
	 * 결재요청조직코드
	 */
	private String apprRqstOrzCd;

	/**
	 * 결재요청자사원번호
	 */
	private String apprRqtrEmpNo;

	/**
	 * 결재요청일시
	 */
	private Timestamp apprRqstDtm;

	/**
	 * 결재진행상태코드
	 */
	private String apprPrgsSttCd;

	/**
	 * 결재업무구분코드
	 */
	private String apprBsnsDvCd;

	/**
	 * 결재연결화면ID
	 */
	private String apprCncnScrnId;

	/**
	 * 결재연결화면인자내용
	 */
	private String apprCncnScrnPintCtt;

	/**
	 * 긴급여부
	 */
	private String emgYn;

	/**
	 * 결재상세업무코드
	 */
	private String apprDtilBsnsCd;

	/**
	 * 신청일자
	 */
	private String rqsDt;

	/**
	 * 스캔일자
	 */
	private String scanDt;

	/**
	 * 이미지등록조직구분코드
	 */
	private String imgRgtOrzDvCd;

	/**
	 * 증권번호
	 */
	private String plcyNo;

	/**
	 * 상품명
	 */
	private String godNm;

	/**
	 * 공제료
	 */
	private Long prmm;

	/**
	 * 계약상태코드
	 */
	private String cnrSttCd;

	/**
	 * 계약자명
	 */
	private String ctorNm;

	/**
	 * 피공제자명
	 */
	private String isrNm;

	/**
	 * 수익자명
	 */
	private String bnfcNm;

	/**
	 * 결재진행금액
	 */
	private Long apprPrgsAmt;

	/**
	 * 예금주명
	 */
	private String dpsrNm;

	/**
	 * 은행코드
	 */
	private String bankCd;

	/**
	 * 계좌번호
	 */
	private String acmNo;

	/**
	 * 사고접수번호
	 */
	private String acdRcipNo;

	/**
	 * 사고자번호
	 */
	private Integer vtmNo;

	/**
	 * 사고자명
	 */
	private String vtmNm;

	/**
	 * 공제금결정구분코드
	 */
	private String claDtnDvCd;

	/**
	 * 산출회차
	 */
	private Integer clclTims;

	/**
	 * 회계처리일자
	 */
	private String acPrceDt;

	/**
	 * 직전책임자결재문서ID
	 */
	private Long bfrePihApprDcmId;

	/**
	 * 가입설계번호
	 */
	private String jnaDsgNo;

	/**
	 * 책임자결재문서제목
	 */
	private String pihApprDcmTitl;

	/**
	 * 상담원사원번호
	 */
	private String cnsrEmpNo;

	/**
	 * 부당행위코드
	 */
	private String injActoCd;

	/**
	 * 부당행위등록일자
	 */
	private String injActoRgtDt;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '책임자결재문서ID' 반환
	 */
	public Long getPihApprDcmId() {
		return pihApprDcmId;
	}

	/**
	 * '책임자결재문서ID' 설정
	 */
	public void setPihApprDcmId(Long pihApprDcmId) {
		this.pihApprDcmId = pihApprDcmId;
	}

	/**
	 * '결재요청조직구분코드' 반환
	 */
	public String getApprRqstOrzDvCd() {
		return apprRqstOrzDvCd;
	}

	/**
	 * '결재요청조직구분코드' 설정
	 */
	public void setApprRqstOrzDvCd(String apprRqstOrzDvCd) {
		this.apprRqstOrzDvCd = apprRqstOrzDvCd;
	}

	/**
	 * '결재요청조직코드' 반환
	 */
	public String getApprRqstOrzCd() {
		return apprRqstOrzCd;
	}

	/**
	 * '결재요청조직코드' 설정
	 */
	public void setApprRqstOrzCd(String apprRqstOrzCd) {
		this.apprRqstOrzCd = apprRqstOrzCd;
	}

	/**
	 * '결재요청자사원번호' 반환
	 */
	public String getApprRqtrEmpNo() {
		return apprRqtrEmpNo;
	}

	/**
	 * '결재요청자사원번호' 설정
	 */
	public void setApprRqtrEmpNo(String apprRqtrEmpNo) {
		this.apprRqtrEmpNo = apprRqtrEmpNo;
	}

	/**
	 * '결재요청일시' 반환
	 */
	public Timestamp getApprRqstDtm() {
		return apprRqstDtm;
	}

	/**
	 * '결재요청일시' 설정
	 */
	public void setApprRqstDtm(Timestamp apprRqstDtm) {
		this.apprRqstDtm = apprRqstDtm;
	}

	/**
	 * '결재진행상태코드' 반환
	 */
	public String getApprPrgsSttCd() {
		return apprPrgsSttCd;
	}

	/**
	 * '결재진행상태코드' 설정
	 */
	public void setApprPrgsSttCd(String apprPrgsSttCd) {
		this.apprPrgsSttCd = apprPrgsSttCd;
	}

	/**
	 * '결재업무구분코드' 반환
	 */
	public String getApprBsnsDvCd() {
		return apprBsnsDvCd;
	}

	/**
	 * '결재업무구분코드' 설정
	 */
	public void setApprBsnsDvCd(String apprBsnsDvCd) {
		this.apprBsnsDvCd = apprBsnsDvCd;
	}

	/**
	 * '결재연결화면ID' 반환
	 */
	public String getApprCncnScrnId() {
		return apprCncnScrnId;
	}

	/**
	 * '결재연결화면ID' 설정
	 */
	public void setApprCncnScrnId(String apprCncnScrnId) {
		this.apprCncnScrnId = apprCncnScrnId;
	}

	/**
	 * '결재연결화면인자내용' 반환
	 */
	public String getApprCncnScrnPintCtt() {
		return apprCncnScrnPintCtt;
	}

	/**
	 * '결재연결화면인자내용' 설정
	 */
	public void setApprCncnScrnPintCtt(String apprCncnScrnPintCtt) {
		this.apprCncnScrnPintCtt = apprCncnScrnPintCtt;
	}

	/**
	 * '긴급여부' 반환
	 */
	public String getEmgYn() {
		return emgYn;
	}

	/**
	 * '긴급여부' 설정
	 */
	public void setEmgYn(String emgYn) {
		this.emgYn = emgYn;
	}

	/**
	 * '결재상세업무코드' 반환
	 */
	public String getApprDtilBsnsCd() {
		return apprDtilBsnsCd;
	}

	/**
	 * '결재상세업무코드' 설정
	 */
	public void setApprDtilBsnsCd(String apprDtilBsnsCd) {
		this.apprDtilBsnsCd = apprDtilBsnsCd;
	}

	/**
	 * '신청일자' 반환
	 */
	public String getRqsDt() {
		return rqsDt;
	}

	/**
	 * '신청일자' 설정
	 */
	public void setRqsDt(String rqsDt) {
		this.rqsDt = rqsDt;
	}

	/**
	 * '스캔일자' 반환
	 */
	public String getScanDt() {
		return scanDt;
	}

	/**
	 * '스캔일자' 설정
	 */
	public void setScanDt(String scanDt) {
		this.scanDt = scanDt;
	}

	/**
	 * '이미지등록조직구분코드' 반환
	 */
	public String getImgRgtOrzDvCd() {
		return imgRgtOrzDvCd;
	}

	/**
	 * '이미지등록조직구분코드' 설정
	 */
	public void setImgRgtOrzDvCd(String imgRgtOrzDvCd) {
		this.imgRgtOrzDvCd = imgRgtOrzDvCd;
	}

	/**
	 * '증권번호' 반환
	 */
	public String getPlcyNo() {
		return plcyNo;
	}

	/**
	 * '증권번호' 설정
	 */
	public void setPlcyNo(String plcyNo) {
		this.plcyNo = plcyNo;
	}

	/**
	 * '상품명' 반환
	 */
	public String getGodNm() {
		return godNm;
	}

	/**
	 * '상품명' 설정
	 */
	public void setGodNm(String godNm) {
		this.godNm = godNm;
	}

	/**
	 * '공제료' 반환
	 */
	public Long getPrmm() {
		return prmm;
	}

	/**
	 * '공제료' 설정
	 */
	public void setPrmm(Long prmm) {
		this.prmm = prmm;
	}

	/**
	 * '계약상태코드' 반환
	 */
	public String getCnrSttCd() {
		return cnrSttCd;
	}

	/**
	 * '계약상태코드' 설정
	 */
	public void setCnrSttCd(String cnrSttCd) {
		this.cnrSttCd = cnrSttCd;
	}

	/**
	 * '계약자명' 반환
	 */
	public String getCtorNm() {
		return ctorNm;
	}

	/**
	 * '계약자명' 설정
	 */
	public void setCtorNm(String ctorNm) {
		this.ctorNm = ctorNm;
	}

	/**
	 * '피공제자명' 반환
	 */
	public String getIsrNm() {
		return isrNm;
	}

	/**
	 * '피공제자명' 설정
	 */
	public void setIsrNm(String isrNm) {
		this.isrNm = isrNm;
	}

	/**
	 * '수익자명' 반환
	 */
	public String getBnfcNm() {
		return bnfcNm;
	}

	/**
	 * '수익자명' 설정
	 */
	public void setBnfcNm(String bnfcNm) {
		this.bnfcNm = bnfcNm;
	}

	/**
	 * '결재진행금액' 반환
	 */
	public Long getApprPrgsAmt() {
		return apprPrgsAmt;
	}

	/**
	 * '결재진행금액' 설정
	 */
	public void setApprPrgsAmt(Long apprPrgsAmt) {
		this.apprPrgsAmt = apprPrgsAmt;
	}

	/**
	 * '예금주명' 반환
	 */
	public String getDpsrNm() {
		return dpsrNm;
	}

	/**
	 * '예금주명' 설정
	 */
	public void setDpsrNm(String dpsrNm) {
		this.dpsrNm = dpsrNm;
	}

	/**
	 * '은행코드' 반환
	 */
	public String getBankCd() {
		return bankCd;
	}

	/**
	 * '은행코드' 설정
	 */
	public void setBankCd(String bankCd) {
		this.bankCd = bankCd;
	}

	/**
	 * '계좌번호' 반환
	 */
	public String getAcmNo() {
		return acmNo;
	}

	/**
	 * '계좌번호' 설정
	 */
	public void setAcmNo(String acmNo) {
		this.acmNo = acmNo;
	}

	/**
	 * '사고접수번호' 반환
	 */
	public String getAcdRcipNo() {
		return acdRcipNo;
	}

	/**
	 * '사고접수번호' 설정
	 */
	public void setAcdRcipNo(String acdRcipNo) {
		this.acdRcipNo = acdRcipNo;
	}

	/**
	 * '사고자번호' 반환
	 */
	public Integer getVtmNo() {
		return vtmNo;
	}

	/**
	 * '사고자번호' 설정
	 */
	public void setVtmNo(Integer vtmNo) {
		this.vtmNo = vtmNo;
	}

	/**
	 * '사고자명' 반환
	 */
	public String getVtmNm() {
		return vtmNm;
	}

	/**
	 * '사고자명' 설정
	 */
	public void setVtmNm(String vtmNm) {
		this.vtmNm = vtmNm;
	}

	/**
	 * '공제금결정구분코드' 반환
	 */
	public String getClaDtnDvCd() {
		return claDtnDvCd;
	}

	/**
	 * '공제금결정구분코드' 설정
	 */
	public void setClaDtnDvCd(String claDtnDvCd) {
		this.claDtnDvCd = claDtnDvCd;
	}

	/**
	 * '산출회차' 반환
	 */
	public Integer getClclTims() {
		return clclTims;
	}

	/**
	 * '산출회차' 설정
	 */
	public void setClclTims(Integer clclTims) {
		this.clclTims = clclTims;
	}

	/**
	 * '회계처리일자' 반환
	 */
	public String getAcPrceDt() {
		return acPrceDt;
	}

	/**
	 * '회계처리일자' 설정
	 */
	public void setAcPrceDt(String acPrceDt) {
		this.acPrceDt = acPrceDt;
	}

	/**
	 * '직전책임자결재문서ID' 반환
	 */
	public Long getBfrePihApprDcmId() {
		return bfrePihApprDcmId;
	}

	/**
	 * '직전책임자결재문서ID' 설정
	 */
	public void setBfrePihApprDcmId(Long bfrePihApprDcmId) {
		this.bfrePihApprDcmId = bfrePihApprDcmId;
	}

	/**
	 * '가입설계번호' 반환
	 */
	public String getJnaDsgNo() {
		return jnaDsgNo;
	}

	/**
	 * '가입설계번호' 설정
	 */
	public void setJnaDsgNo(String jnaDsgNo) {
		this.jnaDsgNo = jnaDsgNo;
	}

	/**
	 * '책임자결재문서제목' 반환
	 */
	public String getPihApprDcmTitl() {
		return pihApprDcmTitl;
	}

	/**
	 * '책임자결재문서제목' 설정
	 */
	public void setPihApprDcmTitl(String pihApprDcmTitl) {
		this.pihApprDcmTitl = pihApprDcmTitl;
	}

	/**
	 * '상담원사원번호' 반환
	 */
	public String getCnsrEmpNo() {
		return cnsrEmpNo;
	}

	/**
	 * '상담원사원번호' 설정
	 */
	public void setCnsrEmpNo(String cnsrEmpNo) {
		this.cnsrEmpNo = cnsrEmpNo;
	}

	/**
	 * '부당행위코드' 반환
	 */
	public String getInjActoCd() {
		return injActoCd;
	}

	/**
	 * '부당행위코드' 설정
	 */
	public void setInjActoCd(String injActoCd) {
		this.injActoCd = injActoCd;
	}

	/**
	 * '부당행위등록일자' 반환
	 */
	public String getInjActoRgtDt() {
		return injActoRgtDt;
	}

	/**
	 * '부당행위등록일자' 설정
	 */
	public void setInjActoRgtDt(String injActoRgtDt) {
		this.injActoRgtDt = injActoRgtDt;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAp0004MtDto [");
		sb.append("\n    pihApprDcmId = '").append(pihApprDcmId).append("'");
		sb.append("\n    apprRqstOrzDvCd = '").append(apprRqstOrzDvCd)
				.append("'");
		sb.append("\n    apprRqstOrzCd = '").append(apprRqstOrzCd).append("'");
		sb.append("\n    apprRqtrEmpNo = '").append(apprRqtrEmpNo).append("'");
		sb.append("\n    apprRqstDtm = '").append(apprRqstDtm).append("'");
		sb.append("\n    apprPrgsSttCd = '").append(apprPrgsSttCd).append("'");
		sb.append("\n    apprBsnsDvCd = '").append(apprBsnsDvCd).append("'");
		sb.append("\n    apprCncnScrnId = '").append(apprCncnScrnId)
				.append("'");
		sb.append("\n    apprCncnScrnPintCtt = '").append(apprCncnScrnPintCtt)
				.append("'");
		sb.append("\n    emgYn = '").append(emgYn).append("'");
		sb.append("\n    apprDtilBsnsCd = '").append(apprDtilBsnsCd)
				.append("'");
		sb.append("\n    rqsDt = '").append(rqsDt).append("'");
		sb.append("\n    scanDt = '").append(scanDt).append("'");
		sb.append("\n    imgRgtOrzDvCd = '").append(imgRgtOrzDvCd).append("'");
		sb.append("\n    plcyNo = '").append(plcyNo).append("'");
		sb.append("\n    godNm = '").append(godNm).append("'");
		sb.append("\n    prmm = '").append(prmm).append("'");
		sb.append("\n    cnrSttCd = '").append(cnrSttCd).append("'");
		sb.append("\n    ctorNm = '").append(ctorNm).append("'");
		sb.append("\n    isrNm = '").append(isrNm).append("'");
		sb.append("\n    bnfcNm = '").append(bnfcNm).append("'");
		sb.append("\n    apprPrgsAmt = '").append(apprPrgsAmt).append("'");
		sb.append("\n    dpsrNm = '").append(dpsrNm).append("'");
		sb.append("\n    bankCd = '").append(bankCd).append("'");
		sb.append("\n    acmNo = '").append(acmNo).append("'");
		sb.append("\n    acdRcipNo = '").append(acdRcipNo).append("'");
		sb.append("\n    vtmNo = '").append(vtmNo).append("'");
		sb.append("\n    vtmNm = '").append(vtmNm).append("'");
		sb.append("\n    claDtnDvCd = '").append(claDtnDvCd).append("'");
		sb.append("\n    clclTims = '").append(clclTims).append("'");
		sb.append("\n    acPrceDt = '").append(acPrceDt).append("'");
		sb.append("\n    bfrePihApprDcmId = '").append(bfrePihApprDcmId)
				.append("'");
		sb.append("\n    jnaDsgNo = '").append(jnaDsgNo).append("'");
		sb.append("\n    pihApprDcmTitl = '").append(pihApprDcmTitl)
				.append("'");
		sb.append("\n    cnsrEmpNo = '").append(cnsrEmpNo).append("'");
		sb.append("\n    injActoCd = '").append(injActoCd).append("'");
		sb.append("\n    injActoRgtDt = '").append(injActoRgtDt).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAp0004MtDto : PK [");
		sb.append("\n    pihApprDcmId = '").append(pihApprDcmId).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
