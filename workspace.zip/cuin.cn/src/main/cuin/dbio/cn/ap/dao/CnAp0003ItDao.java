/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dao;

import java.util.List;

import cuin.dbio.cn.ap.dto.CnAp0003ItDto;

/**
 * CN_AP0003_IT (CN_AP0003_IT) DAO 인터페이스.
 *
 * 
 */
public interface CnAp0003ItDao {

	CnAp0003ItDto select(CnAp0003ItDto cnAp0003ItDto);

	int insert(CnAp0003ItDto cnAp0003ItDto);

	int update(CnAp0003ItDto cnAp0003ItDto);

	int delete(CnAp0003ItDto cnAp0003ItDto);

	List<CnAp0003ItDto> list(CnAp0003ItDto cnAp0003ItDto);

	int[] insertList(List<CnAp0003ItDto> cnAp0003ItDtos);

	int[] updateList(List<CnAp0003ItDto> cnAp0003ItDtos);

	int[] deleteList(List<CnAp0003ItDto> cnAp0003ItDtos);

}
