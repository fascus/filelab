/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dao;

import java.util.List;

import cuin.dbio.cn.ap.dto.CnAp0001MtDto;

/**
 * CN_AP0001_MT (CN_AP0001_MT) DAO 인터페이스.
 *
 * 
 */
public interface CnAp0001MtDao {

	CnAp0001MtDto select(CnAp0001MtDto cnAp0001MtDto);

	int insert(CnAp0001MtDto cnAp0001MtDto);

	int update(CnAp0001MtDto cnAp0001MtDto);

	int delete(CnAp0001MtDto cnAp0001MtDto);

	List<CnAp0001MtDto> list(CnAp0001MtDto cnAp0001MtDto);

	int[] insertList(List<CnAp0001MtDto> cnAp0001MtDtos);

	int[] updateList(List<CnAp0001MtDto> cnAp0001MtDtos);

	int[] deleteList(List<CnAp0001MtDto> cnAp0001MtDtos);

}
