/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ap.dto.CnAp0001MtDto;

/**
 * CN_AP0001_MT (CN_AP0001_MT) DAO 구현체.
 *
 * @stereotype DAO
 * 
 * 
 */

@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ap.hqml.CnAp0001Mt")
public class CnAp0001MtDaoImpl extends DbioDaoSupport implements CnAp0001MtDao {

	/**
	 * CN_AP0001_MT (CN_AP0001_MT) 단건 조회.
	 * 
	 */
	public CnAp0001MtDto select(CnAp0001MtDto cnAp0001MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0001Mt.select",
				cnAp0001MtDto);

		CnAp0001MtDto foundCnAp0001MtDto = null;
		try {
			foundCnAp0001MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAp0001MtDto),
					new BeanPropertyRowMapper<CnAp0001MtDto>(
							CnAp0001MtDto.class));
			return foundCnAp0001MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_AP0001_MT (CN_AP0001_MT) 단건 등록.
	 * 
	 */
	public int insert(CnAp0001MtDto cnAp0001MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0001Mt.insert",
				cnAp0001MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0001MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0001_MT (CN_AP0001_MT) 단건 변경.
	 * 
	 */
	public int update(CnAp0001MtDto cnAp0001MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0001Mt.update",
				cnAp0001MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0001MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0001_MT (CN_AP0001_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnAp0001MtDto cnAp0001MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0001Mt.delete",
				cnAp0001MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0001MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0001_MT (CN_AP0001_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnAp0001MtDto> list(CnAp0001MtDto cnAp0001MtDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0001Mt.list",
				cnAp0001MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnAp0001MtDto), new BeanPropertyRowMapper<CnAp0001MtDto>(
				CnAp0001MtDto.class));
	}

	/**
	 * CN_AP0001_MT (CN_AP0001_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnAp0001MtDto> cnAp0001MtDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0001Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0001MtDtos
				.size()];
		for (int i = 0; i < cnAp0001MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0001MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0001_MT (CN_AP0001_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnAp0001MtDto> cnAp0001MtDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0001Mt.update");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0001MtDtos
				.size()];
		for (int i = 0; i < cnAp0001MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0001MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0001_MT (CN_AP0001_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnAp0001MtDto> cnAp0001MtDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0001Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0001MtDtos
				.size()];
		for (int i = 0; i < cnAp0001MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0001MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
