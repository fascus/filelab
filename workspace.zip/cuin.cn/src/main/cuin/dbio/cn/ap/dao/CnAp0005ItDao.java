/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dao;

import java.util.List;

import cuin.dbio.cn.ap.dto.CnAp0005ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAp0005ItDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AP0005_IT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnAp0005ItDao {

	CnAp0005ItDto select(CnAp0005ItDto cnAp0005ItDto);

	int insert(CnAp0005ItDto cnAp0005ItDto);

	int update(CnAp0005ItDto cnAp0005ItDto);

	int delete(CnAp0005ItDto cnAp0005ItDto);

	List<CnAp0005ItDto> list(CnAp0005ItDto cnAp0005ItDto);

	int[] insertList(List<CnAp0005ItDto> cnAp0005ItDtos);

	int[] updateList(List<CnAp0005ItDto> cnAp0005ItDtos);

	int[] deleteList(List<CnAp0005ItDto> cnAp0005ItDtos);

}
