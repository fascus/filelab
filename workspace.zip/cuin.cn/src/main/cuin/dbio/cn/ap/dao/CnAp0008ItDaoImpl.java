/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ap.dto.CnAp0008ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAp0008ItDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AP0008_IT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ap.hqml.CnAp0008It")
public class CnAp0008ItDaoImpl extends DbioDaoSupport implements CnAp0008ItDao {

	/**
	 * CN_AP0008_IT (CN_AP0008_IT) 단건 조회.
	 * 
	 */
	public CnAp0008ItDto select(CnAp0008ItDto cnAp0008ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0008It.select",
				cnAp0008ItDto);

		CnAp0008ItDto foundCnAp0008ItDto = null;
		try {
			foundCnAp0008ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAp0008ItDto),
					new BeanPropertyRowMapper<CnAp0008ItDto>(
							CnAp0008ItDto.class));
			return foundCnAp0008ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_AP0008_IT (CN_AP0008_IT) 단건 등록.
	 * 
	 */
	public int insert(CnAp0008ItDto cnAp0008ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0008It.insert",
				cnAp0008ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0008ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0008_IT (CN_AP0008_IT) 단건 변경.
	 * 
	 */
	public int update(CnAp0008ItDto cnAp0008ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0008It.update",
				cnAp0008ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0008ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0008_IT (CN_AP0008_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnAp0008ItDto cnAp0008ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0008It.delete",
				cnAp0008ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAp0008ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AP0008_IT (CN_AP0008_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnAp0008ItDto> list(CnAp0008ItDto cnAp0008ItDto) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0008It.list",
				cnAp0008ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnAp0008ItDto), new BeanPropertyRowMapper<CnAp0008ItDto>(
				CnAp0008ItDto.class));
	}

	/**
	 * CN_AP0008_IT (CN_AP0008_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnAp0008ItDto> cnAp0008ItDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0008It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0008ItDtos
				.size()];
		for (int i = 0; i < cnAp0008ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0008ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0008_IT (CN_AP0008_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnAp0008ItDto> cnAp0008ItDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0008It.update",
				cnAp0008ItDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnAp0008ItDtos
				.size()];
		for (int i = 0; i < cnAp0008ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0008ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AP0008_IT (CN_AP0008_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnAp0008ItDto> cnAp0008ItDtos) {
		String sql = getSql("cuin.dbio.cn.ap.hqml.CnAp0008It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnAp0008ItDtos
				.size()];
		for (int i = 0; i < cnAp0008ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAp0008ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
