/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

;

/**
 * CN_AP0002_IT (CN_AP0002_IT) 입출력 DTO. 
 * 
 * @stereotype DTO
 * 
 */
public class CnAp0002ItDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -4161223180373898204L;

	/**
	 * 결재문서ID
	 */
	private Long apprDcmId;

	/**
	 * 결재자사원번호
	 */
	private String apvrEmpNo;

	/**
	 * 결재정보일련번호
	 */
	private Long apprInfoSeq;

	/**
	 * 결재일시
	 */
	private Timestamp apprDtm;

	/**
	 * 결재의견내용
	 */
	private String apprOpnnCtt;

	/**
	 * 일괄결재여부
	 */
	private String btcApprYn;

	/**
	 * 실제결재자사원번호
	 */
	private String aclApvrEmpNo;

	/**
	 * 결재구분코드
	 */
	private String apprDvCd;

	/**
	 * 결재방법코드
	 */
	private String apprMthCd;

	/**
	 * 결재선상세유형코드
	 */
	private String aplnDtilTpCd;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '결재문서ID' 반환
	 */
	public Long getApprDcmId() {
		return apprDcmId;
	}

	/**
	 * '결재문서ID' 설정
	 */
	public void setApprDcmId(Long apprDcmId) {
		this.apprDcmId = apprDcmId;
	}

	/**
	 * '결재자사원번호' 반환
	 */
	public String getApvrEmpNo() {
		return apvrEmpNo;
	}

	/**
	 * '결재자사원번호' 설정
	 */
	public void setApvrEmpNo(String apvrEmpNo) {
		this.apvrEmpNo = apvrEmpNo;
	}

	/**
	 * '결재정보일련번호' 반환
	 */
	public Long getApprInfoSeq() {
		return apprInfoSeq;
	}

	/**
	 * '결재정보일련번호' 설정
	 */
	public void setApprInfoSeq(Long apprInfoSeq) {
		this.apprInfoSeq = apprInfoSeq;
	}

	/**
	 * '결재일시' 반환
	 */
	public Timestamp getApprDtm() {
		return apprDtm;
	}

	/**
	 * '결재일시' 설정
	 */
	public void setApprDtm(Timestamp apprDtm) {
		this.apprDtm = apprDtm;
	}

	/**
	 * '결재의견내용' 반환
	 */
	public String getApprOpnnCtt() {
		return apprOpnnCtt;
	}

	/**
	 * '결재의견내용' 설정
	 */
	public void setApprOpnnCtt(String apprOpnnCtt) {
		this.apprOpnnCtt = apprOpnnCtt;
	}

	/**
	 * '일괄결재여부' 반환
	 */
	public String getBtcApprYn() {
		return btcApprYn;
	}

	/**
	 * '일괄결재여부' 설정
	 */
	public void setBtcApprYn(String btcApprYn) {
		this.btcApprYn = btcApprYn;
	}

	/**
	 * '실제결재자사원번호' 반환
	 */
	public String getAclApvrEmpNo() {
		return aclApvrEmpNo;
	}

	/**
	 * '실제결재자사원번호' 설정
	 */
	public void setAclApvrEmpNo(String aclApvrEmpNo) {
		this.aclApvrEmpNo = aclApvrEmpNo;
	}

	/**
	 * '결재구분코드' 반환
	 */
	public String getApprDvCd() {
		return apprDvCd;
	}

	/**
	 * '결재구분코드' 설정
	 */
	public void setApprDvCd(String apprDvCd) {
		this.apprDvCd = apprDvCd;
	}

	/**
	 * '결재방법코드' 반환
	 */
	public String getApprMthCd() {
		return apprMthCd;
	}

	/**
	 * '결재방법코드' 설정
	 */
	public void setApprMthCd(String apprMthCd) {
		this.apprMthCd = apprMthCd;
	}

	/**
	 * '결재선상세유형코드' 반환
	 */
	public String getAplnDtilTpCd() {
		return aplnDtilTpCd;
	}

	/**
	 * '결재선상세유형코드' 설정
	 */
	public void setAplnDtilTpCd(String aplnDtilTpCd) {
		this.aplnDtilTpCd = aplnDtilTpCd;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAp0002ItDto [");
		sb.append("\n    apprDcmId = '").append(apprDcmId).append("'");
		sb.append("\n    apvrEmpNo = '").append(apvrEmpNo).append("'");
		sb.append("\n    apprInfoSeq = '").append(apprInfoSeq).append("'");
		sb.append("\n    apprDtm = '").append(apprDtm).append("'");
		sb.append("\n    apprOpnnCtt = '").append(apprOpnnCtt).append("'");
		sb.append("\n    btcApprYn = '").append(btcApprYn).append("'");
		sb.append("\n    aclApvrEmpNo = '").append(aclApvrEmpNo).append("'");
		sb.append("\n    apprDvCd = '").append(apprDvCd).append("'");
		sb.append("\n    apprMthCd = '").append(apprMthCd).append("'");
		sb.append("\n    aplnDtilTpCd = '").append(aplnDtilTpCd).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAp0002ItDto : PK [");
		sb.append("\n    apprDcmId = '").append(apprDcmId).append("'");
		sb.append("\n    apvrEmpNo = '").append(apvrEmpNo).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
