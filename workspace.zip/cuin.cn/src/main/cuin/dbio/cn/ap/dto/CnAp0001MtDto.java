/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

;

/**
 * CN_AP0001_MT (CN_AP0001_MT) 입출력 DTO. 
 * 
 * @stereotype DTO
 * 
 */
public class CnAp0001MtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -3371824067346808579L;

	/**
	 * 결재문서ID
	 */
	private Long apprDcmId;

	/**
	 * 결재문서제목
	 */
	private String apprDcmTitl;

	/**
	 * 결재요청거래ID
	 */
	private String apprRqstTrnId;

	/**
	 * 결재요청부서코드
	 */
	private String apprRqstDpmCd;

	/**
	 * 결재업무코드
	 */
	private String apprBsnsCd;

	/**
	 * 결재요청자사원번호
	 */
	private String apprRqtrEmpNo;

	/**
	 * 결재요청일시
	 */
	private Timestamp apprRqstDtm;

	/**
	 * 결재진행상태코드
	 */
	private String apprPrgsSttCd;

	/**
	 * 결재연결화면인자내용
	 */
	private String apprCncnScrnPintCtt;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '결재문서ID' 반환
	 */
	public Long getApprDcmId() {
		return apprDcmId;
	}

	/**
	 * '결재문서ID' 설정
	 */
	public void setApprDcmId(Long apprDcmId) {
		this.apprDcmId = apprDcmId;
	}

	/**
	 * '결재문서제목' 반환
	 */
	public String getApprDcmTitl() {
		return apprDcmTitl;
	}

	/**
	 * '결재문서제목' 설정
	 */
	public void setApprDcmTitl(String apprDcmTitl) {
		this.apprDcmTitl = apprDcmTitl;
	}

	/**
	 * '결재요청거래ID' 반환
	 */
	public String getApprRqstTrnId() {
		return apprRqstTrnId;
	}

	/**
	 * '결재요청거래ID' 설정
	 */
	public void setApprRqstTrnId(String apprRqstTrnId) {
		this.apprRqstTrnId = apprRqstTrnId;
	}

	/**
	 * '결재요청부서코드' 반환
	 */
	public String getApprRqstDpmCd() {
		return apprRqstDpmCd;
	}

	/**
	 * '결재요청부서코드' 설정
	 */
	public void setApprRqstDpmCd(String apprRqstDpmCd) {
		this.apprRqstDpmCd = apprRqstDpmCd;
	}

	/**
	 * '결재업무코드' 반환
	 */
	public String getApprBsnsCd() {
		return apprBsnsCd;
	}

	/**
	 * '결재업무코드' 설정
	 */
	public void setApprBsnsCd(String apprBsnsCd) {
		this.apprBsnsCd = apprBsnsCd;
	}

	/**
	 * '결재요청자사원번호' 반환
	 */
	public String getApprRqtrEmpNo() {
		return apprRqtrEmpNo;
	}

	/**
	 * '결재요청자사원번호' 설정
	 */
	public void setApprRqtrEmpNo(String apprRqtrEmpNo) {
		this.apprRqtrEmpNo = apprRqtrEmpNo;
	}

	/**
	 * '결재요청일시' 반환
	 */
	public Timestamp getApprRqstDtm() {
		return apprRqstDtm;
	}

	/**
	 * '결재요청일시' 설정
	 */
	public void setApprRqstDtm(Timestamp apprRqstDtm) {
		this.apprRqstDtm = apprRqstDtm;
	}

	/**
	 * '결재진행상태코드' 반환
	 */
	public String getApprPrgsSttCd() {
		return apprPrgsSttCd;
	}

	/**
	 * '결재진행상태코드' 설정
	 */
	public void setApprPrgsSttCd(String apprPrgsSttCd) {
		this.apprPrgsSttCd = apprPrgsSttCd;
	}

	/**
	 * '결재연결화면인자내용' 반환
	 */
	public String getApprCncnScrnPintCtt() {
		return apprCncnScrnPintCtt;
	}

	/**
	 * '결재연결화면인자내용' 설정
	 */
	public void setApprCncnScrnPintCtt(String apprCncnScrnPintCtt) {
		this.apprCncnScrnPintCtt = apprCncnScrnPintCtt;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAp0001MtDto [");
		sb.append("\n    apprDcmId = '").append(apprDcmId).append("'");
		sb.append("\n    apprDcmTitl = '").append(apprDcmTitl).append("'");
		sb.append("\n    apprRqstTrnId = '").append(apprRqstTrnId).append("'");
		sb.append("\n    apprRqstDpmCd = '").append(apprRqstDpmCd).append("'");
		sb.append("\n    apprBsnsCd = '").append(apprBsnsCd).append("'");
		sb.append("\n    apprRqtrEmpNo = '").append(apprRqtrEmpNo).append("'");
		sb.append("\n    apprRqstDtm = '").append(apprRqstDtm).append("'");
		sb.append("\n    apprPrgsSttCd = '").append(apprPrgsSttCd).append("'");
		sb.append("\n    apprCncnScrnPintCtt = '").append(apprCncnScrnPintCtt)
				.append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAp0001MtDto : PK [");
		sb.append("\n    apprDcmId = '").append(apprDcmId).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
