/**
 * 
 * 
 */
package cuin.dbio.cn.ap.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

;

/**
 * CN_AP0003_IT (CN_AP0003_IT) 입출력 DTO. 
 * 
 * @stereotype DTO
 * 
 */
public class CnAp0003ItDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -6397772522124262806L;

	/**
	 * 결재요청거래ID
	 */
	private String apprRqstTrnId;

	/**
	 * 결재문서제목
	 */
	private String apprDcmTitl;

	/**
	 * 개별결재화면ID
	 */
	private String invApprScrnId;

	/**
	 * 결재거래ID
	 */
	private String apprTrnId;

	/**
	 * 반려결재거래ID
	 */
	private String retApprTrnId;

	/**
	 * 취소결재거래ID
	 */
	private String cnclApprTrnId;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '결재요청거래ID' 반환
	 */
	public String getApprRqstTrnId() {
		return apprRqstTrnId;
	}

	/**
	 * '결재요청거래ID' 설정
	 */
	public void setApprRqstTrnId(String apprRqstTrnId) {
		this.apprRqstTrnId = apprRqstTrnId;
	}

	/**
	 * '결재문서제목' 반환
	 */
	public String getApprDcmTitl() {
		return apprDcmTitl;
	}

	/**
	 * '결재문서제목' 설정
	 */
	public void setApprDcmTitl(String apprDcmTitl) {
		this.apprDcmTitl = apprDcmTitl;
	}

	/**
	 * '개별결재화면ID' 반환
	 */
	public String getInvApprScrnId() {
		return invApprScrnId;
	}

	/**
	 * '개별결재화면ID' 설정
	 */
	public void setInvApprScrnId(String invApprScrnId) {
		this.invApprScrnId = invApprScrnId;
	}

	/**
	 * '결재거래ID' 반환
	 */
	public String getApprTrnId() {
		return apprTrnId;
	}

	/**
	 * '결재거래ID' 설정
	 */
	public void setApprTrnId(String apprTrnId) {
		this.apprTrnId = apprTrnId;
	}

	/**
	 * '반려결재거래ID' 반환
	 */
	public String getRetApprTrnId() {
		return retApprTrnId;
	}

	/**
	 * '반려결재거래ID' 설정
	 */
	public void setRetApprTrnId(String retApprTrnId) {
		this.retApprTrnId = retApprTrnId;
	}

	/**
	 * '취소결재거래ID' 반환
	 */
	public String getCnclApprTrnId() {
		return cnclApprTrnId;
	}

	/**
	 * '취소결재거래ID' 설정
	 */
	public void setCnclApprTrnId(String cnclApprTrnId) {
		this.cnclApprTrnId = cnclApprTrnId;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAp0003ItDto [");
		sb.append("\n    apprRqstTrnId = '").append(apprRqstTrnId).append("'");
		sb.append("\n    apprDcmTitl = '").append(apprDcmTitl).append("'");
		sb.append("\n    invApprScrnId = '").append(invApprScrnId).append("'");
		sb.append("\n    apprTrnId = '").append(apprTrnId).append("'");
		sb.append("\n    retApprTrnId = '").append(retApprTrnId).append("'");
		sb.append("\n    cnclApprTrnId = '").append(cnclApprTrnId).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAp0003ItDto : PK [");
		sb.append("\n    apprRqstTrnId = '").append(apprRqstTrnId).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
