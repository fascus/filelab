/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ii.dto.CnIi0013MtDto;

/**
 * CN_II0013_MT (CN_II0013_MT) DAO 구현체.
 *
 * @stereotype DAO
 * 
 * 
 */

@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ii.hqml.CnIi0013Mt")
public class CnIi0013MtDaoImpl extends DbioDaoSupport implements CnIi0013MtDao {

	/**
	 * CN_II0013_MT (CN_II0013_MT) 단건 조회.
	 * 
	 */
	public CnIi0013MtDto select(CnIi0013MtDto cnIi0013MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0013Mt.select",
				cnIi0013MtDto);

		CnIi0013MtDto foundCnIi0013MtDto = null;
		try {
			foundCnIi0013MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIi0013MtDto),
					new BeanPropertyRowMapper<CnIi0013MtDto>(
							CnIi0013MtDto.class));
			return foundCnIi0013MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_II0013_MT (CN_II0013_MT) 단건 등록.
	 * 
	 */
	public int insert(CnIi0013MtDto cnIi0013MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0013Mt.insert",
				cnIi0013MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0013MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0013_MT (CN_II0013_MT) 단건 변경.
	 * 
	 */
	public int update(CnIi0013MtDto cnIi0013MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0013Mt.update",
				cnIi0013MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0013MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0013_MT (CN_II0013_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIi0013MtDto cnIi0013MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0013Mt.delete",
				cnIi0013MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0013MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0013_MT (CN_II0013_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIi0013MtDto> list(CnIi0013MtDto cnIi0013MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0013Mt.list",
				cnIi0013MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIi0013MtDto), new BeanPropertyRowMapper<CnIi0013MtDto>(
				CnIi0013MtDto.class));
	}

	/**
	 * CN_II0013_MT (CN_II0013_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIi0013MtDto> cnIi0013MtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0013Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0013MtDtos
				.size()];
		for (int i = 0; i < cnIi0013MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0013MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0013_MT (CN_II0013_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIi0013MtDto> cnIi0013MtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0013Mt.update");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0013MtDtos
				.size()];
		for (int i = 0; i < cnIi0013MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0013MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0013_MT (CN_II0013_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIi0013MtDto> cnIi0013MtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0013Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0013MtDtos
				.size()];
		for (int i = 0; i < cnIi0013MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0013MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
