package cuin.dbio.cn.ii.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0001MtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.05
 * 설    명 : CN_II0001_MT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnIi0001MtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = 7247798238874648737L;

	/**
	 * 이미지스캔일련번호
	 */
	private Long imgScanSeq;

	/**
	 * 적용종료일시
	 */
	private Timestamp aplEotDtm;

	/**
	 * 적용시작일시
	 */
	private Timestamp aplBgDtm;

	/**
	 * 스캔인덱스번호
	 */
	private String scanIndxNo;

	/**
	 * 스캔기준일자
	 */
	private String scanBaseDt;

	/**
	 * 스캔일자
	 */
	private String scanDt;

	/**
	 * 이미지대상식별번호구분코드
	 */
	private String imgSbjIdfNoDvCd;

	/**
	 * 이미지대상식별번호
	 */
	private String imgSbjIdfNo;

	/**
	 * 서식관리번호
	 */
	private String formMgNo;

	/**
	 * 이미지서식구분코드
	 */
	private String imgFormDvCd;

	/**
	 * 이미지처리상태코드
	 */
	private String imgPrceSttCd;

	/**
	 * 보정자사원번호
	 */
	private String icorEmpNo;

	/**
	 * 보정일자
	 */
	private String rvnDt;

	/**
	 * 스캔이미지대상식별번호
	 */
	private String scanImgSbjIdfNo;

	/**
	 * 스캔서식관리번호
	 */
	private String scanFormMgNo;

	/**
	 * 스캔서식구분코드
	 */
	private String scanFormDvCd;

	/**
	 * OMR오류여부
	 */
	private String omrErrYn;

	/**
	 * 서류보관박스번호
	 */
	private String dcnSteBoxNo;

	/**
	 * 원본확인자사원번호
	 */
	private String ogcyIcocEmpNo;

	/**
	 * 원본확인일자
	 */
	private String ogcyCnfrDt;

	/**
	 * 필수서식여부
	 */
	private String mndyFormYn;

	/**
	 * 원본사본구분코드
	 */
	private String ogcyCpyDvCd;

	/**
	 * 인가번호
	 */
	private String cuocNo;

	/**
	 * 서식이미지업무구분코드
	 */
	private String formImgBsnsDvCd;

	/**
	 * 서식이미지상세업무구분코드
	 */
	private String formImgDtilBsnsDvCd;

	/**
	 * 관리본지점코드
	 */
	private String mgMobCd;

	/**
	 * 거래구분코드
	 */
	private String trnDvCd;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '이미지스캔일련번호' 반환
	 */
	public Long getImgScanSeq() {
		return imgScanSeq;
	}

	/**
	 * '이미지스캔일련번호' 설정
	 */
	public void setImgScanSeq(Long imgScanSeq) {
		this.imgScanSeq = imgScanSeq;
	}

	/**
	 * '적용종료일시' 반환
	 */
	public Timestamp getAplEotDtm() {
		return aplEotDtm;
	}

	/**
	 * '적용종료일시' 설정
	 */
	public void setAplEotDtm(Timestamp aplEotDtm) {
		this.aplEotDtm = aplEotDtm;
	}

	/**
	 * '적용시작일시' 반환
	 */
	public Timestamp getAplBgDtm() {
		return aplBgDtm;
	}

	/**
	 * '적용시작일시' 설정
	 */
	public void setAplBgDtm(Timestamp aplBgDtm) {
		this.aplBgDtm = aplBgDtm;
	}

	/**
	 * '스캔인덱스번호' 반환
	 */
	public String getScanIndxNo() {
		return scanIndxNo;
	}

	/**
	 * '스캔인덱스번호' 설정
	 */
	public void setScanIndxNo(String scanIndxNo) {
		this.scanIndxNo = scanIndxNo;
	}

	/**
	 * '스캔기준일자' 반환
	 */
	public String getScanBaseDt() {
		return scanBaseDt;
	}

	/**
	 * '스캔기준일자' 설정
	 */
	public void setScanBaseDt(String scanBaseDt) {
		this.scanBaseDt = scanBaseDt;
	}

	/**
	 * '스캔일자' 반환
	 */
	public String getScanDt() {
		return scanDt;
	}

	/**
	 * '스캔일자' 설정
	 */
	public void setScanDt(String scanDt) {
		this.scanDt = scanDt;
	}

	/**
	 * '이미지대상식별번호구분코드' 반환
	 */
	public String getImgSbjIdfNoDvCd() {
		return imgSbjIdfNoDvCd;
	}

	/**
	 * '이미지대상식별번호구분코드' 설정
	 */
	public void setImgSbjIdfNoDvCd(String imgSbjIdfNoDvCd) {
		this.imgSbjIdfNoDvCd = imgSbjIdfNoDvCd;
	}

	/**
	 * '이미지대상식별번호' 반환
	 */
	public String getImgSbjIdfNo() {
		return imgSbjIdfNo;
	}

	/**
	 * '이미지대상식별번호' 설정
	 */
	public void setImgSbjIdfNo(String imgSbjIdfNo) {
		this.imgSbjIdfNo = imgSbjIdfNo;
	}

	/**
	 * '서식관리번호' 반환
	 */
	public String getFormMgNo() {
		return formMgNo;
	}

	/**
	 * '서식관리번호' 설정
	 */
	public void setFormMgNo(String formMgNo) {
		this.formMgNo = formMgNo;
	}

	/**
	 * '이미지서식구분코드' 반환
	 */
	public String getImgFormDvCd() {
		return imgFormDvCd;
	}

	/**
	 * '이미지서식구분코드' 설정
	 */
	public void setImgFormDvCd(String imgFormDvCd) {
		this.imgFormDvCd = imgFormDvCd;
	}

	/**
	 * '이미지처리상태코드' 반환
	 */
	public String getImgPrceSttCd() {
		return imgPrceSttCd;
	}

	/**
	 * '이미지처리상태코드' 설정
	 */
	public void setImgPrceSttCd(String imgPrceSttCd) {
		this.imgPrceSttCd = imgPrceSttCd;
	}

	/**
	 * '보정자사원번호' 반환
	 */
	public String getIcorEmpNo() {
		return icorEmpNo;
	}

	/**
	 * '보정자사원번호' 설정
	 */
	public void setIcorEmpNo(String icorEmpNo) {
		this.icorEmpNo = icorEmpNo;
	}

	/**
	 * '보정일자' 반환
	 */
	public String getRvnDt() {
		return rvnDt;
	}

	/**
	 * '보정일자' 설정
	 */
	public void setRvnDt(String rvnDt) {
		this.rvnDt = rvnDt;
	}

	/**
	 * '스캔이미지대상식별번호' 반환
	 */
	public String getScanImgSbjIdfNo() {
		return scanImgSbjIdfNo;
	}

	/**
	 * '스캔이미지대상식별번호' 설정
	 */
	public void setScanImgSbjIdfNo(String scanImgSbjIdfNo) {
		this.scanImgSbjIdfNo = scanImgSbjIdfNo;
	}

	/**
	 * '스캔서식관리번호' 반환
	 */
	public String getScanFormMgNo() {
		return scanFormMgNo;
	}

	/**
	 * '스캔서식관리번호' 설정
	 */
	public void setScanFormMgNo(String scanFormMgNo) {
		this.scanFormMgNo = scanFormMgNo;
	}

	/**
	 * '스캔서식구분코드' 반환
	 */
	public String getScanFormDvCd() {
		return scanFormDvCd;
	}

	/**
	 * '스캔서식구분코드' 설정
	 */
	public void setScanFormDvCd(String scanFormDvCd) {
		this.scanFormDvCd = scanFormDvCd;
	}

	/**
	 * 'OMR오류여부' 반환
	 */
	public String getOmrErrYn() {
		return omrErrYn;
	}

	/**
	 * 'OMR오류여부' 설정
	 */
	public void setOmrErrYn(String omrErrYn) {
		this.omrErrYn = omrErrYn;
	}

	/**
	 * '서류보관박스번호' 반환
	 */
	public String getDcnSteBoxNo() {
		return dcnSteBoxNo;
	}

	/**
	 * '서류보관박스번호' 설정
	 */
	public void setDcnSteBoxNo(String dcnSteBoxNo) {
		this.dcnSteBoxNo = dcnSteBoxNo;
	}

	/**
	 * '원본확인자사원번호' 반환
	 */
	public String getOgcyIcocEmpNo() {
		return ogcyIcocEmpNo;
	}

	/**
	 * '원본확인자사원번호' 설정
	 */
	public void setOgcyIcocEmpNo(String ogcyIcocEmpNo) {
		this.ogcyIcocEmpNo = ogcyIcocEmpNo;
	}

	/**
	 * '원본확인일자' 반환
	 */
	public String getOgcyCnfrDt() {
		return ogcyCnfrDt;
	}

	/**
	 * '원본확인일자' 설정
	 */
	public void setOgcyCnfrDt(String ogcyCnfrDt) {
		this.ogcyCnfrDt = ogcyCnfrDt;
	}

	/**
	 * '필수서식여부' 반환
	 */
	public String getMndyFormYn() {
		return mndyFormYn;
	}

	/**
	 * '필수서식여부' 설정
	 */
	public void setMndyFormYn(String mndyFormYn) {
		this.mndyFormYn = mndyFormYn;
	}

	/**
	 * '원본사본구분코드' 반환
	 */
	public String getOgcyCpyDvCd() {
		return ogcyCpyDvCd;
	}

	/**
	 * '원본사본구분코드' 설정
	 */
	public void setOgcyCpyDvCd(String ogcyCpyDvCd) {
		this.ogcyCpyDvCd = ogcyCpyDvCd;
	}

	/**
	 * '인가번호' 반환
	 */
	public String getCuocNo() {
		return cuocNo;
	}

	/**
	 * '인가번호' 설정
	 */
	public void setCuocNo(String cuocNo) {
		this.cuocNo = cuocNo;
	}

	/**
	 * '서식이미지업무구분코드' 반환
	 */
	public String getFormImgBsnsDvCd() {
		return formImgBsnsDvCd;
	}

	/**
	 * '서식이미지업무구분코드' 설정
	 */
	public void setFormImgBsnsDvCd(String formImgBsnsDvCd) {
		this.formImgBsnsDvCd = formImgBsnsDvCd;
	}

	/**
	 * '서식이미지상세업무구분코드' 반환
	 */
	public String getFormImgDtilBsnsDvCd() {
		return formImgDtilBsnsDvCd;
	}

	/**
	 * '서식이미지상세업무구분코드' 설정
	 */
	public void setFormImgDtilBsnsDvCd(String formImgDtilBsnsDvCd) {
		this.formImgDtilBsnsDvCd = formImgDtilBsnsDvCd;
	}

	/**
	 * '관리본지점코드' 반환
	 */
	public String getMgMobCd() {
		return mgMobCd;
	}

	/**
	 * '관리본지점코드' 설정
	 */
	public void setMgMobCd(String mgMobCd) {
		this.mgMobCd = mgMobCd;
	}

	/**
	 * '거래구분코드' 반환
	 */
	public String getTrnDvCd() {
		return trnDvCd;
	}

	/**
	 * '거래구분코드' 설정
	 */
	public void setTrnDvCd(String trnDvCd) {
		this.trnDvCd = trnDvCd;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIi0001MtDto [");
		sb.append("\n    imgScanSeq = '").append(imgScanSeq).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n    scanIndxNo = '").append(scanIndxNo).append("'");
		sb.append("\n    scanBaseDt = '").append(scanBaseDt).append("'");
		sb.append("\n    scanDt = '").append(scanDt).append("'");
		sb.append("\n    imgSbjIdfNoDvCd = '").append(imgSbjIdfNoDvCd)
				.append("'");
		sb.append("\n    imgSbjIdfNo = '").append(imgSbjIdfNo).append("'");
		sb.append("\n    formMgNo = '").append(formMgNo).append("'");
		sb.append("\n    imgFormDvCd = '").append(imgFormDvCd).append("'");
		sb.append("\n    imgPrceSttCd = '").append(imgPrceSttCd).append("'");
		sb.append("\n    icorEmpNo = '").append(icorEmpNo).append("'");
		sb.append("\n    rvnDt = '").append(rvnDt).append("'");
		sb.append("\n    scanImgSbjIdfNo = '").append(scanImgSbjIdfNo)
				.append("'");
		sb.append("\n    scanFormMgNo = '").append(scanFormMgNo).append("'");
		sb.append("\n    scanFormDvCd = '").append(scanFormDvCd).append("'");
		sb.append("\n    omrErrYn = '").append(omrErrYn).append("'");
		sb.append("\n    dcnSteBoxNo = '").append(dcnSteBoxNo).append("'");
		sb.append("\n    ogcyIcocEmpNo = '").append(ogcyIcocEmpNo).append("'");
		sb.append("\n    ogcyCnfrDt = '").append(ogcyCnfrDt).append("'");
		sb.append("\n    mndyFormYn = '").append(mndyFormYn).append("'");
		sb.append("\n    ogcyCpyDvCd = '").append(ogcyCpyDvCd).append("'");
		sb.append("\n    cuocNo = '").append(cuocNo).append("'");
		sb.append("\n    formImgBsnsDvCd = '").append(formImgBsnsDvCd)
				.append("'");
		sb.append("\n    formImgDtilBsnsDvCd = '").append(formImgDtilBsnsDvCd)
				.append("'");
		sb.append("\n    mgMobCd = '").append(mgMobCd).append("'");
		sb.append("\n    trnDvCd = '").append(trnDvCd).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIi0001MtDto : PK [");
		sb.append("\n    imgScanSeq = '").append(imgScanSeq).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
