/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ii.dto.CnIi0010MtDto;

/**
 * CN_II0010_MT (CN_II0010_MT) DAO 구현체.
 *
 * @stereotype DAO
 * 
 * 
 */

@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ii.hqml.CnIi0010Mt")
public class CnIi0010MtDaoImpl extends DbioDaoSupport implements CnIi0010MtDao {

	/**
	 * CN_II0010_MT (CN_II0010_MT) 단건 조회.
	 * 
	 */
	public CnIi0010MtDto select(CnIi0010MtDto cnIi0010MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0010Mt.select",
				cnIi0010MtDto);

		CnIi0010MtDto foundCnIi0010MtDto = null;
		try {
			foundCnIi0010MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIi0010MtDto),
					new BeanPropertyRowMapper<CnIi0010MtDto>(
							CnIi0010MtDto.class));
			return foundCnIi0010MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_II0010_MT (CN_II0010_MT) 단건 등록.
	 * 
	 */
	public int insert(CnIi0010MtDto cnIi0010MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0010Mt.insert",
				cnIi0010MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0010MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0010_MT (CN_II0010_MT) 단건 변경.
	 * 
	 */
	public int update(CnIi0010MtDto cnIi0010MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0010Mt.update",
				cnIi0010MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0010MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0010_MT (CN_II0010_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIi0010MtDto cnIi0010MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0010Mt.delete",
				cnIi0010MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0010MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0010_MT (CN_II0010_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIi0010MtDto> list(CnIi0010MtDto cnIi0010MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0010Mt.list",
				cnIi0010MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIi0010MtDto), new BeanPropertyRowMapper<CnIi0010MtDto>(
				CnIi0010MtDto.class));
	}

	/**
	 * CN_II0010_MT (CN_II0010_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIi0010MtDto> cnIi0010MtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0010Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0010MtDtos
				.size()];
		for (int i = 0; i < cnIi0010MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0010MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0010_MT (CN_II0010_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIi0010MtDto> cnIi0010MtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0010Mt.update");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0010MtDtos
				.size()];
		for (int i = 0; i < cnIi0010MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0010MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0010_MT (CN_II0010_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIi0010MtDto> cnIi0010MtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0010Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0010MtDtos
				.size()];
		for (int i = 0; i < cnIi0010MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0010MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
