/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

;

/**
 * CN_II0017_BT (CN_II0017_BT) 입출력 DTO. 
 * 
 * @stereotype DTO
 * 
 */
public class CnIi0017BtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -1576401866491608386L;

	/**
	 * 스캔업무구분코드
	 */
	private String scanBsnsDvCd;

	/**
	 * 이미지대상식별번호구분코드
	 */
	private String imgSbjIdfNoDvCd;

	/**
	 * 이미지대상식별번호
	 */
	private String imgSbjIdfNo;

	/**
	 * 스캔기준일자
	 */
	private String scanBaseDt;

	/**
	 * 이미지스캔완료여부
	 */
	private String imgScanFnsYn;

	/**
	 * 이미지보정완료여부
	 */
	private String imgRvnFnsYn;

	/**
	 * 이미지자동심사대상여부
	 */
	private String imgAuInspSbjYn;

	/**
	 * 이미지스캔서식건수
	 */
	private Integer imgScanFormNcnt;

	/**
	 * 필수스캔대상서식수
	 */
	private Integer mndyScanSbjFormCnt;

	/**
	 * 옵션스캔대상서식수
	 */
	private Integer optnScanSbjFormCnt;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '스캔업무구분코드' 반환
	 */
	public String getScanBsnsDvCd() {
		return scanBsnsDvCd;
	}

	/**
	 * '스캔업무구분코드' 설정
	 */
	public void setScanBsnsDvCd(String scanBsnsDvCd) {
		this.scanBsnsDvCd = scanBsnsDvCd;
	}

	/**
	 * '이미지대상식별번호구분코드' 반환
	 */
	public String getImgSbjIdfNoDvCd() {
		return imgSbjIdfNoDvCd;
	}

	/**
	 * '이미지대상식별번호구분코드' 설정
	 */
	public void setImgSbjIdfNoDvCd(String imgSbjIdfNoDvCd) {
		this.imgSbjIdfNoDvCd = imgSbjIdfNoDvCd;
	}

	/**
	 * '이미지대상식별번호' 반환
	 */
	public String getImgSbjIdfNo() {
		return imgSbjIdfNo;
	}

	/**
	 * '이미지대상식별번호' 설정
	 */
	public void setImgSbjIdfNo(String imgSbjIdfNo) {
		this.imgSbjIdfNo = imgSbjIdfNo;
	}

	/**
	 * '스캔기준일자' 반환
	 */
	public String getScanBaseDt() {
		return scanBaseDt;
	}

	/**
	 * '스캔기준일자' 설정
	 */
	public void setScanBaseDt(String scanBaseDt) {
		this.scanBaseDt = scanBaseDt;
	}

	/**
	 * '이미지스캔완료여부' 반환
	 */
	public String getImgScanFnsYn() {
		return imgScanFnsYn;
	}

	/**
	 * '이미지스캔완료여부' 설정
	 */
	public void setImgScanFnsYn(String imgScanFnsYn) {
		this.imgScanFnsYn = imgScanFnsYn;
	}

	/**
	 * '이미지보정완료여부' 반환
	 */
	public String getImgRvnFnsYn() {
		return imgRvnFnsYn;
	}

	/**
	 * '이미지보정완료여부' 설정
	 */
	public void setImgRvnFnsYn(String imgRvnFnsYn) {
		this.imgRvnFnsYn = imgRvnFnsYn;
	}

	/**
	 * '이미지자동심사대상여부' 반환
	 */
	public String getImgAuInspSbjYn() {
		return imgAuInspSbjYn;
	}

	/**
	 * '이미지자동심사대상여부' 설정
	 */
	public void setImgAuInspSbjYn(String imgAuInspSbjYn) {
		this.imgAuInspSbjYn = imgAuInspSbjYn;
	}

	/**
	 * '이미지스캔서식건수' 반환
	 */
	public Integer getImgScanFormNcnt() {
		return imgScanFormNcnt;
	}

	/**
	 * '이미지스캔서식건수' 설정
	 */
	public void setImgScanFormNcnt(Integer imgScanFormNcnt) {
		this.imgScanFormNcnt = imgScanFormNcnt;
	}

	/**
	 * '필수스캔대상서식수' 반환
	 */
	public Integer getMndyScanSbjFormCnt() {
		return mndyScanSbjFormCnt;
	}

	/**
	 * '필수스캔대상서식수' 설정
	 */
	public void setMndyScanSbjFormCnt(Integer mndyScanSbjFormCnt) {
		this.mndyScanSbjFormCnt = mndyScanSbjFormCnt;
	}

	/**
	 * '옵션스캔대상서식수' 반환
	 */
	public Integer getOptnScanSbjFormCnt() {
		return optnScanSbjFormCnt;
	}

	/**
	 * '옵션스캔대상서식수' 설정
	 */
	public void setOptnScanSbjFormCnt(Integer optnScanSbjFormCnt) {
		this.optnScanSbjFormCnt = optnScanSbjFormCnt;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIi0017BtDto [");
		sb.append("\n    scanBsnsDvCd = '").append(scanBsnsDvCd).append("'");
		sb.append("\n    imgSbjIdfNoDvCd = '").append(imgSbjIdfNoDvCd)
				.append("'");
		sb.append("\n    imgSbjIdfNo = '").append(imgSbjIdfNo).append("'");
		sb.append("\n    scanBaseDt = '").append(scanBaseDt).append("'");
		sb.append("\n    imgScanFnsYn = '").append(imgScanFnsYn).append("'");
		sb.append("\n    imgRvnFnsYn = '").append(imgRvnFnsYn).append("'");
		sb.append("\n    imgAuInspSbjYn = '").append(imgAuInspSbjYn)
				.append("'");
		sb.append("\n    imgScanFormNcnt = '").append(imgScanFormNcnt)
				.append("'");
		sb.append("\n    mndyScanSbjFormCnt = '").append(mndyScanSbjFormCnt)
				.append("'");
		sb.append("\n    optnScanSbjFormCnt = '").append(optnScanSbjFormCnt)
				.append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIi0017BtDto : PK [");
		sb.append("\n    scanBsnsDvCd = '").append(scanBsnsDvCd).append("'");
		sb.append("\n    imgSbjIdfNoDvCd = '").append(imgSbjIdfNoDvCd)
				.append("'");
		sb.append("\n    imgSbjIdfNo = '").append(imgSbjIdfNo).append("'");
		sb.append("\n    scanBaseDt = '").append(scanBaseDt).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
