/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.ii.dto.CnIi0014HtDto;
import cuin.dbio.cn.ii.dto.CnIi0014HtPrevInDto;

/**
 * CN_II0014_HT (CN_II0014_HT) DAO 인터페이스.
 *
 * 
 */
public interface CnIi0014HtDao {

	int insert(CnIi0014HtDto cnIi0014HtDto);

	int closeCurrentHistory(CnIi0014HtDto cnIi0014HtDto);

	int deleteHistory(CnIi0014HtDto cnIi0014HtDto);

	CnIi0014HtDto selectPrevious(CnIi0014HtPrevInDto cnIi0014HtPrevInDto);

	List<CnIi0014HtDto> selectInPeriod(PeriodInDto periodInDto);

}
