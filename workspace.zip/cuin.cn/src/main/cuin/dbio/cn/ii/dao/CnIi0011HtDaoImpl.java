/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.ii.dto.CnIi0011HtDto;
import cuin.dbio.cn.ii.dto.CnIi0011HtPrevInDto;

/**
 * CN_II0011_HT (CN_II0011_HT) DAO 구현체.
 *
 * @stereotype DAO
 * 
 * 
 */

@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ii.hqml.CnIi0011Ht")
public class CnIi0011HtDaoImpl extends DbioDaoSupport implements CnIi0011HtDao {

	/**
	 * CN_II0011_HT (CN_II0011_HT) 단건 등록.
	 * 
	 */
	public int insert(CnIi0011HtDto cnIi0011HtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0011Ht.insert",
				cnIi0011HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0011HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0011_HT (CN_II0011_HT) 현행 이력 업데이트.
	 * 
	 */
	public int closeCurrentHistory(CnIi0011HtDto cnIi0011HtDto) {
		String sql = getSql(
				"cuin.dbio.cn.ii.hqml.CnIi0011Ht.closeCurrentHistory",
				cnIi0011HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0011HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0011_HT (CN_II0011_HT) 이력 삭제.
	 * 
	 */
	public int deleteHistory(CnIi0011HtDto cnIi0011HtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0011Ht.deleteHistory",
				cnIi0011HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0011HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0011_HT (CN_II0011_HT) 특정 시점의 단건 이력 조회.
	 * 
	 */
	public CnIi0011HtDto selectPrevious(CnIi0011HtPrevInDto cnIi0011HtPrevInDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0011Ht.selectPrevious",
				cnIi0011HtPrevInDto);

		CnIi0011HtDto foundCnIi0011HtDto = null;
		try {
			foundCnIi0011HtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIi0011HtPrevInDto),
					new BeanPropertyRowMapper<CnIi0011HtDto>(
							CnIi0011HtDto.class));
			return foundCnIi0011HtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * 특정 기간 동안의 이벤트(변경 내역) 조회
	 * 
	 */
	public List<CnIi0011HtDto> selectInPeriod(PeriodInDto periodInDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0011Ht.selectInPeriod",
				periodInDto);

		return queryForList(sql,
				new BeanPropertySqlParameterSource(periodInDto),
				new BeanPropertyRowMapper<CnIi0011HtDto>(CnIi0011HtDto.class));
	}

}
