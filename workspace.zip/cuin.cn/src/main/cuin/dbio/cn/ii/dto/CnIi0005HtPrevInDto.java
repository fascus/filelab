package cuin.dbio.cn.ii.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * CN_II0005_HT (CN_II0005_HT) 테이블 이력 단건 조회 DTO.
 */
public class CnIi0005HtPrevInDto implements Serializable {

	private static final long serialVersionUID = -6301715226016002250L;

	/**
	 * 이력 조회를 위한 기준 일시
	 */
	private Timestamp baseDtm;

	/**
	 * 이미지스캔일련번호
	 */
	private Long imgScanSeq;

	/**
	 * 기준 일시 반환
	 */
	public Timestamp getBaseDtm() {
		return baseDtm;
	}

	/**
	 * 기준 일시 설정
	 */
	public void setBaseDtm(Timestamp baseDtm) {
		this.baseDtm = baseDtm;
	}

	/**
	 * '이미지스캔일련번호' 반환
	 */
	public Long getImgScanSeq() {
		return imgScanSeq;
	}

	/**
	 * '이미지스캔일련번호' 설정
	 */
	public void setImgScanSeq(Long imgScanSeq) {
		this.imgScanSeq = imgScanSeq;
	}

}