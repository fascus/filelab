/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.dbio.cn.ii.dto.CnIi0008MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0008MtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_II0008_MT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnIi0008MtDao {

	CnIi0008MtDto select(CnIi0008MtDto cnIi0008MtDto);

	int insert(CnIi0008MtDto cnIi0008MtDto);

	int update(CnIi0008MtDto cnIi0008MtDto);

	int delete(CnIi0008MtDto cnIi0008MtDto);

	List<CnIi0008MtDto> list(CnIi0008MtDto cnIi0008MtDto);

	int[] insertList(List<CnIi0008MtDto> cnIi0008MtDtos);

	int[] updateList(List<CnIi0008MtDto> cnIi0008MtDtos);

	int[] deleteList(List<CnIi0008MtDto> cnIi0008MtDtos);

}
