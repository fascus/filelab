/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0019ItDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_II0019_IT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnIi0019ItDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -7947184984157044631L;

	/**
	 * 업무구분코드
	 */
	private String bsnsDvCd;

	/**
	 * 대상식별번호구분코드
	 */
	private String sbjIdfNoDvCd;

	/**
	 * 대상식별번호
	 */
	private String sbjIdfNo;

	/**
	 * 파일일련번호
	 */
	private Long flSeq;

	/**
	 * 첨부파일명
	 */
	private String attFlNm;

	/**
	 * 첨부파일경로명
	 */
	private String attFlPthNm;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '업무구분코드' 반환
	 */
	public String getBsnsDvCd() {
		return bsnsDvCd;
	}

	/**
	 * '업무구분코드' 설정
	 */
	public void setBsnsDvCd(String bsnsDvCd) {
		this.bsnsDvCd = bsnsDvCd;
	}

	/**
	 * '대상식별번호구분코드' 반환
	 */
	public String getSbjIdfNoDvCd() {
		return sbjIdfNoDvCd;
	}

	/**
	 * '대상식별번호구분코드' 설정
	 */
	public void setSbjIdfNoDvCd(String sbjIdfNoDvCd) {
		this.sbjIdfNoDvCd = sbjIdfNoDvCd;
	}

	/**
	 * '대상식별번호' 반환
	 */
	public String getSbjIdfNo() {
		return sbjIdfNo;
	}

	/**
	 * '대상식별번호' 설정
	 */
	public void setSbjIdfNo(String sbjIdfNo) {
		this.sbjIdfNo = sbjIdfNo;
	}

	/**
	 * '파일일련번호' 반환
	 */
	public Long getFlSeq() {
		return flSeq;
	}

	/**
	 * '파일일련번호' 설정
	 */
	public void setFlSeq(Long flSeq) {
		this.flSeq = flSeq;
	}

	/**
	 * '첨부파일명' 반환
	 */
	public String getAttFlNm() {
		return attFlNm;
	}

	/**
	 * '첨부파일명' 설정
	 */
	public void setAttFlNm(String attFlNm) {
		this.attFlNm = attFlNm;
	}

	/**
	 * '첨부파일경로명' 반환
	 */
	public String getAttFlPthNm() {
		return attFlPthNm;
	}

	/**
	 * '첨부파일경로명' 설정
	 */
	public void setAttFlPthNm(String attFlPthNm) {
		this.attFlPthNm = attFlPthNm;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIi0019ItDto [");
		sb.append("\n    bsnsDvCd = '").append(bsnsDvCd).append("'");
		sb.append("\n    sbjIdfNoDvCd = '").append(sbjIdfNoDvCd).append("'");
		sb.append("\n    sbjIdfNo = '").append(sbjIdfNo).append("'");
		sb.append("\n    flSeq = '").append(flSeq).append("'");
		sb.append("\n    attFlNm = '").append(attFlNm).append("'");
		sb.append("\n    attFlPthNm = '").append(attFlPthNm).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIi0019ItDto : PK [");
		sb.append("\n    bsnsDvCd = '").append(bsnsDvCd).append("'");
		sb.append("\n    sbjIdfNoDvCd = '").append(sbjIdfNoDvCd).append("'");
		sb.append("\n    sbjIdfNo = '").append(sbjIdfNo).append("'");
		sb.append("\n    flSeq = '").append(flSeq).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
