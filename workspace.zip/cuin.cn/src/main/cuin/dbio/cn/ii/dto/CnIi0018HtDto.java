package cuin.dbio.cn.ii.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0018HtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.05
 * 설    명 : CN_II0018_HT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnIi0018HtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = 2022855713686112548L;

	/**
	 * 이미지팩스일련번호
	 */
	private Long imgFaxSeq;

	/**
	 * 적용종료일시
	 */
	private Timestamp aplEotDtm;

	/**
	 * 적용시작일시
	 */
	private Timestamp aplBgDtm;

	/**
	 * 팩스송신일자
	 */
	private String faxSndnDt;

	/**
	 * 스캔인덱스번호
	 */
	private String scanIndxNo;

	/**
	 * 이미지서식구분코드
	 */
	private String imgFormDvCd;

	/**
	 * 이미지대상식별번호구분코드
	 */
	private String imgSbjIdfNoDvCd;

	/**
	 * 이미지대상식별번호
	 */
	private String imgSbjIdfNo;

	/**
	 * 이미지처리상태코드
	 */
	private String imgPrceSttCd;

	/**
	 * 이미지서버전송여부
	 */
	private String imgSrrSnYn;

	/**
	 * 출력횟수
	 */
	private Integer prtCunt;

	/**
	 * 이미지파일명
	 */
	private String imgFlNm;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '이미지팩스일련번호' 반환
	 */
	public Long getImgFaxSeq() {
		return imgFaxSeq;
	}

	/**
	 * '이미지팩스일련번호' 설정
	 */
	public void setImgFaxSeq(Long imgFaxSeq) {
		this.imgFaxSeq = imgFaxSeq;
	}

	/**
	 * '적용종료일시' 반환
	 */
	public Timestamp getAplEotDtm() {
		return aplEotDtm;
	}

	/**
	 * '적용종료일시' 설정
	 */
	public void setAplEotDtm(Timestamp aplEotDtm) {
		this.aplEotDtm = aplEotDtm;
	}

	/**
	 * '적용시작일시' 반환
	 */
	public Timestamp getAplBgDtm() {
		return aplBgDtm;
	}

	/**
	 * '적용시작일시' 설정
	 */
	public void setAplBgDtm(Timestamp aplBgDtm) {
		this.aplBgDtm = aplBgDtm;
	}

	/**
	 * '팩스송신일자' 반환
	 */
	public String getFaxSndnDt() {
		return faxSndnDt;
	}

	/**
	 * '팩스송신일자' 설정
	 */
	public void setFaxSndnDt(String faxSndnDt) {
		this.faxSndnDt = faxSndnDt;
	}

	/**
	 * '스캔인덱스번호' 반환
	 */
	public String getScanIndxNo() {
		return scanIndxNo;
	}

	/**
	 * '스캔인덱스번호' 설정
	 */
	public void setScanIndxNo(String scanIndxNo) {
		this.scanIndxNo = scanIndxNo;
	}

	/**
	 * '이미지서식구분코드' 반환
	 */
	public String getImgFormDvCd() {
		return imgFormDvCd;
	}

	/**
	 * '이미지서식구분코드' 설정
	 */
	public void setImgFormDvCd(String imgFormDvCd) {
		this.imgFormDvCd = imgFormDvCd;
	}

	/**
	 * '이미지대상식별번호구분코드' 반환
	 */
	public String getImgSbjIdfNoDvCd() {
		return imgSbjIdfNoDvCd;
	}

	/**
	 * '이미지대상식별번호구분코드' 설정
	 */
	public void setImgSbjIdfNoDvCd(String imgSbjIdfNoDvCd) {
		this.imgSbjIdfNoDvCd = imgSbjIdfNoDvCd;
	}

	/**
	 * '이미지대상식별번호' 반환
	 */
	public String getImgSbjIdfNo() {
		return imgSbjIdfNo;
	}

	/**
	 * '이미지대상식별번호' 설정
	 */
	public void setImgSbjIdfNo(String imgSbjIdfNo) {
		this.imgSbjIdfNo = imgSbjIdfNo;
	}

	/**
	 * '이미지처리상태코드' 반환
	 */
	public String getImgPrceSttCd() {
		return imgPrceSttCd;
	}

	/**
	 * '이미지처리상태코드' 설정
	 */
	public void setImgPrceSttCd(String imgPrceSttCd) {
		this.imgPrceSttCd = imgPrceSttCd;
	}

	/**
	 * '이미지서버전송여부' 반환
	 */
	public String getImgSrrSnYn() {
		return imgSrrSnYn;
	}

	/**
	 * '이미지서버전송여부' 설정
	 */
	public void setImgSrrSnYn(String imgSrrSnYn) {
		this.imgSrrSnYn = imgSrrSnYn;
	}

	/**
	 * '출력횟수' 반환
	 */
	public Integer getPrtCunt() {
		return prtCunt;
	}

	/**
	 * '출력횟수' 설정
	 */
	public void setPrtCunt(Integer prtCunt) {
		this.prtCunt = prtCunt;
	}

	/**
	 * '이미지파일명' 반환
	 */
	public String getImgFlNm() {
		return imgFlNm;
	}

	/**
	 * '이미지파일명' 설정
	 */
	public void setImgFlNm(String imgFlNm) {
		this.imgFlNm = imgFlNm;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIi0018HtDto [");
		sb.append("\n    imgFaxSeq = '").append(imgFaxSeq).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n    faxSndnDt = '").append(faxSndnDt).append("'");
		sb.append("\n    scanIndxNo = '").append(scanIndxNo).append("'");
		sb.append("\n    imgFormDvCd = '").append(imgFormDvCd).append("'");
		sb.append("\n    imgSbjIdfNoDvCd = '").append(imgSbjIdfNoDvCd)
				.append("'");
		sb.append("\n    imgSbjIdfNo = '").append(imgSbjIdfNo).append("'");
		sb.append("\n    imgPrceSttCd = '").append(imgPrceSttCd).append("'");
		sb.append("\n    imgSrrSnYn = '").append(imgSrrSnYn).append("'");
		sb.append("\n    prtCunt = '").append(prtCunt).append("'");
		sb.append("\n    imgFlNm = '").append(imgFlNm).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIi0018HtDto : PK [");
		sb.append("\n    imgFaxSeq = '").append(imgFaxSeq).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
