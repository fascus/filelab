package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.dbio.cn.ii.dto.CnIi0001MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0001MtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.05
 * 설    명 : CN_II0001_MT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnIi0001MtDao {

	CnIi0001MtDto select(CnIi0001MtDto cnIi0001MtDto);

	int insert(CnIi0001MtDto cnIi0001MtDto);

	int update(CnIi0001MtDto cnIi0001MtDto);

	int delete(CnIi0001MtDto cnIi0001MtDto);

	List<CnIi0001MtDto> list(CnIi0001MtDto cnIi0001MtDto);

	int[] insertList(List<CnIi0001MtDto> cnIi0001MtDtos);

	int[] updateList(List<CnIi0001MtDto> cnIi0001MtDtos);

	int[] deleteList(List<CnIi0001MtDto> cnIi0001MtDtos);

}
