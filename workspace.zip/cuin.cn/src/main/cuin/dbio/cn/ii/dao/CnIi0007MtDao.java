package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.dbio.cn.ii.dto.CnIi0007MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0007MtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.05
 * 설    명 : CN_II0007_MT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnIi0007MtDao {

	CnIi0007MtDto select(CnIi0007MtDto cnIi0007MtDto);

	int insert(CnIi0007MtDto cnIi0007MtDto);

	int update(CnIi0007MtDto cnIi0007MtDto);

	int delete(CnIi0007MtDto cnIi0007MtDto);

	List<CnIi0007MtDto> list(CnIi0007MtDto cnIi0007MtDto);

	int[] insertList(List<CnIi0007MtDto> cnIi0007MtDtos);

	int[] updateList(List<CnIi0007MtDto> cnIi0007MtDtos);

	int[] deleteList(List<CnIi0007MtDto> cnIi0007MtDtos);

}
