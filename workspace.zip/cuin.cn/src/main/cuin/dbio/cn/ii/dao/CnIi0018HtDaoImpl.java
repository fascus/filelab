package cuin.dbio.cn.ii.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.ii.dto.CnIi0018HtDto;
import cuin.dbio.cn.ii.dto.CnIi0018HtPrevInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0018HtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.05
 * 설    명 : CN_II0018_HT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ii.hqml.CnIi0018Ht")
public class CnIi0018HtDaoImpl extends DbioDaoSupport implements CnIi0018HtDao {

	/**
	 * CN_II0018_HT (CN_II0018_HT) 단건 등록.
	 * 
	 */
	public int insert(CnIi0018HtDto cnIi0018HtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0018Ht.insert",
				cnIi0018HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0018HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0018_HT (CN_II0018_HT) 현행 이력 업데이트.
	 * 
	 */
	public int closeCurrentHistory(CnIi0018HtDto cnIi0018HtDto) {
		String sql = getSql(
				"cuin.dbio.cn.ii.hqml.CnIi0018Ht.closeCurrentHistory",
				cnIi0018HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0018HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0018_HT (CN_II0018_HT) 이력 삭제.
	 * 
	 */
	public int deleteHistory(CnIi0018HtDto cnIi0018HtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0018Ht.deleteHistory",
				cnIi0018HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0018HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0018_HT (CN_II0018_HT) 특정 시점의 단건 이력 조회.
	 * 
	 */
	public CnIi0018HtDto selectPrevious(CnIi0018HtPrevInDto cnIi0018HtPrevInDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0018Ht.selectPrevious",
				cnIi0018HtPrevInDto);

		CnIi0018HtDto foundCnIi0018HtDto = null;
		try {
			foundCnIi0018HtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIi0018HtPrevInDto),
					new BeanPropertyRowMapper<CnIi0018HtDto>(
							CnIi0018HtDto.class));
			return foundCnIi0018HtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * 특정 기간 동안의 이벤트(변경 내역) 조회
	 * 
	 */
	public List<CnIi0018HtDto> selectInPeriod(PeriodInDto periodInDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0018Ht.selectInPeriod",
				periodInDto);

		return queryForList(sql,
				new BeanPropertySqlParameterSource(periodInDto),
				new BeanPropertyRowMapper<CnIi0018HtDto>(CnIi0018HtDto.class));
	}

}
