/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.ii.dto.CnIi0005HtDto;
import cuin.dbio.cn.ii.dto.CnIi0005HtPrevInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0005HtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_II0005_HT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnIi0005HtDao {

	int insert(CnIi0005HtDto cnIi0005HtDto);

	int closeCurrentHistory(CnIi0005HtDto cnIi0005HtDto);

	int deleteHistory(CnIi0005HtDto cnIi0005HtDto);

	CnIi0005HtDto selectPrevious(CnIi0005HtPrevInDto cnIi0005HtPrevInDto);

	List<CnIi0005HtDto> selectInPeriod(PeriodInDto periodInDto);

}
