/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

;

/**
 * CN_II0010_MT (CN_II0010_MT) 입출력 DTO. 
 * 
 * @stereotype DTO
 * 
 */
public class CnIi0010MtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -999246752080638149L;

	/**
	 * 서식관리번호
	 */
	private String formMgNo;

	/**
	 * 이미지서식구분코드
	 */
	private String imgFormDvCd;

	/**
	 * 서식항목구분코드
	 */
	private String formItmDvCd;

	/**
	 * 변경일련번호
	 */
	private Long chnSeq;

	/**
	 * 적용종료일시
	 */
	private Timestamp aplEotDtm;

	/**
	 * 적용시작일시
	 */
	private Timestamp aplBgDtm;

	/**
	 * 유효종료일시
	 */
	private Timestamp vldEotDtm;

	/**
	 * 유효시작일시
	 */
	private Timestamp vldBgDtm;

	/**
	 * 서식항목상세내용
	 */
	private String formItmDtilCtt;

	/**
	 * 서식항목답변유형코드
	 */
	private String formItmAnsTpCd;

	/**
	 * OMR서식항목응답시작번호
	 */
	private Integer omrFormItmRspnBgNo;

	/**
	 * OMR서식항목응답종료번호
	 */
	private Integer omrFormItmRspnEotNo;

	/**
	 * 상세서식항목답변유형코드
	 */
	private String dtilFormItmAnsTpCd;

	/**
	 * 상세항목통합코드그룹ID
	 */
	private String dtilItmIntgCdGrpId;

	/**
	 * OMR상세서식항목시작번호
	 */
	private Integer omrDtilFormItmBgNo;

	/**
	 * OMR상세서식항목종료번호
	 */
	private Integer omrDtilFormItmEotNo;

	/**
	 * 화면표시순서
	 */
	private Integer scrnExsSqc;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '서식관리번호' 반환
	 */
	public String getFormMgNo() {
		return formMgNo;
	}

	/**
	 * '서식관리번호' 설정
	 */
	public void setFormMgNo(String formMgNo) {
		this.formMgNo = formMgNo;
	}

	/**
	 * '이미지서식구분코드' 반환
	 */
	public String getImgFormDvCd() {
		return imgFormDvCd;
	}

	/**
	 * '이미지서식구분코드' 설정
	 */
	public void setImgFormDvCd(String imgFormDvCd) {
		this.imgFormDvCd = imgFormDvCd;
	}

	/**
	 * '서식항목구분코드' 반환
	 */
	public String getFormItmDvCd() {
		return formItmDvCd;
	}

	/**
	 * '서식항목구분코드' 설정
	 */
	public void setFormItmDvCd(String formItmDvCd) {
		this.formItmDvCd = formItmDvCd;
	}

	/**
	 * '변경일련번호' 반환
	 */
	public Long getChnSeq() {
		return chnSeq;
	}

	/**
	 * '변경일련번호' 설정
	 */
	public void setChnSeq(Long chnSeq) {
		this.chnSeq = chnSeq;
	}

	/**
	 * '적용종료일시' 반환
	 */
	public Timestamp getAplEotDtm() {
		return aplEotDtm;
	}

	/**
	 * '적용종료일시' 설정
	 */
	public void setAplEotDtm(Timestamp aplEotDtm) {
		this.aplEotDtm = aplEotDtm;
	}

	/**
	 * '적용시작일시' 반환
	 */
	public Timestamp getAplBgDtm() {
		return aplBgDtm;
	}

	/**
	 * '적용시작일시' 설정
	 */
	public void setAplBgDtm(Timestamp aplBgDtm) {
		this.aplBgDtm = aplBgDtm;
	}

	/**
	 * '유효종료일시' 반환
	 */
	public Timestamp getVldEotDtm() {
		return vldEotDtm;
	}

	/**
	 * '유효종료일시' 설정
	 */
	public void setVldEotDtm(Timestamp vldEotDtm) {
		this.vldEotDtm = vldEotDtm;
	}

	/**
	 * '유효시작일시' 반환
	 */
	public Timestamp getVldBgDtm() {
		return vldBgDtm;
	}

	/**
	 * '유효시작일시' 설정
	 */
	public void setVldBgDtm(Timestamp vldBgDtm) {
		this.vldBgDtm = vldBgDtm;
	}

	/**
	 * '서식항목상세내용' 반환
	 */
	public String getFormItmDtilCtt() {
		return formItmDtilCtt;
	}

	/**
	 * '서식항목상세내용' 설정
	 */
	public void setFormItmDtilCtt(String formItmDtilCtt) {
		this.formItmDtilCtt = formItmDtilCtt;
	}

	/**
	 * '서식항목답변유형코드' 반환
	 */
	public String getFormItmAnsTpCd() {
		return formItmAnsTpCd;
	}

	/**
	 * '서식항목답변유형코드' 설정
	 */
	public void setFormItmAnsTpCd(String formItmAnsTpCd) {
		this.formItmAnsTpCd = formItmAnsTpCd;
	}

	/**
	 * 'OMR서식항목응답시작번호' 반환
	 */
	public Integer getOmrFormItmRspnBgNo() {
		return omrFormItmRspnBgNo;
	}

	/**
	 * 'OMR서식항목응답시작번호' 설정
	 */
	public void setOmrFormItmRspnBgNo(Integer omrFormItmRspnBgNo) {
		this.omrFormItmRspnBgNo = omrFormItmRspnBgNo;
	}

	/**
	 * 'OMR서식항목응답종료번호' 반환
	 */
	public Integer getOmrFormItmRspnEotNo() {
		return omrFormItmRspnEotNo;
	}

	/**
	 * 'OMR서식항목응답종료번호' 설정
	 */
	public void setOmrFormItmRspnEotNo(Integer omrFormItmRspnEotNo) {
		this.omrFormItmRspnEotNo = omrFormItmRspnEotNo;
	}

	/**
	 * '상세서식항목답변유형코드' 반환
	 */
	public String getDtilFormItmAnsTpCd() {
		return dtilFormItmAnsTpCd;
	}

	/**
	 * '상세서식항목답변유형코드' 설정
	 */
	public void setDtilFormItmAnsTpCd(String dtilFormItmAnsTpCd) {
		this.dtilFormItmAnsTpCd = dtilFormItmAnsTpCd;
	}

	/**
	 * '상세항목통합코드그룹ID' 반환
	 */
	public String getDtilItmIntgCdGrpId() {
		return dtilItmIntgCdGrpId;
	}

	/**
	 * '상세항목통합코드그룹ID' 설정
	 */
	public void setDtilItmIntgCdGrpId(String dtilItmIntgCdGrpId) {
		this.dtilItmIntgCdGrpId = dtilItmIntgCdGrpId;
	}

	/**
	 * 'OMR상세서식항목시작번호' 반환
	 */
	public Integer getOmrDtilFormItmBgNo() {
		return omrDtilFormItmBgNo;
	}

	/**
	 * 'OMR상세서식항목시작번호' 설정
	 */
	public void setOmrDtilFormItmBgNo(Integer omrDtilFormItmBgNo) {
		this.omrDtilFormItmBgNo = omrDtilFormItmBgNo;
	}

	/**
	 * 'OMR상세서식항목종료번호' 반환
	 */
	public Integer getOmrDtilFormItmEotNo() {
		return omrDtilFormItmEotNo;
	}

	/**
	 * 'OMR상세서식항목종료번호' 설정
	 */
	public void setOmrDtilFormItmEotNo(Integer omrDtilFormItmEotNo) {
		this.omrDtilFormItmEotNo = omrDtilFormItmEotNo;
	}

	/**
	 * '화면표시순서' 반환
	 */
	public Integer getScrnExsSqc() {
		return scrnExsSqc;
	}

	/**
	 * '화면표시순서' 설정
	 */
	public void setScrnExsSqc(Integer scrnExsSqc) {
		this.scrnExsSqc = scrnExsSqc;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIi0010MtDto [");
		sb.append("\n    formMgNo = '").append(formMgNo).append("'");
		sb.append("\n    imgFormDvCd = '").append(imgFormDvCd).append("'");
		sb.append("\n    formItmDvCd = '").append(formItmDvCd).append("'");
		sb.append("\n    chnSeq = '").append(chnSeq).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n    vldEotDtm = '").append(vldEotDtm).append("'");
		sb.append("\n    vldBgDtm = '").append(vldBgDtm).append("'");
		sb.append("\n    formItmDtilCtt = '").append(formItmDtilCtt)
				.append("'");
		sb.append("\n    formItmAnsTpCd = '").append(formItmAnsTpCd)
				.append("'");
		sb.append("\n    omrFormItmRspnBgNo = '").append(omrFormItmRspnBgNo)
				.append("'");
		sb.append("\n    omrFormItmRspnEotNo = '").append(omrFormItmRspnEotNo)
				.append("'");
		sb.append("\n    dtilFormItmAnsTpCd = '").append(dtilFormItmAnsTpCd)
				.append("'");
		sb.append("\n    dtilItmIntgCdGrpId = '").append(dtilItmIntgCdGrpId)
				.append("'");
		sb.append("\n    omrDtilFormItmBgNo = '").append(omrDtilFormItmBgNo)
				.append("'");
		sb.append("\n    omrDtilFormItmEotNo = '").append(omrDtilFormItmEotNo)
				.append("'");
		sb.append("\n    scrnExsSqc = '").append(scrnExsSqc).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIi0010MtDto : PK [");
		sb.append("\n    formMgNo = '").append(formMgNo).append("'");
		sb.append("\n    imgFormDvCd = '").append(imgFormDvCd).append("'");
		sb.append("\n    formItmDvCd = '").append(formItmDvCd).append("'");
		sb.append("\n    chnSeq = '").append(chnSeq).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
