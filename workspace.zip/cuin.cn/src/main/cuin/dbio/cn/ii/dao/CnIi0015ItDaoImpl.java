/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ii.dto.CnIi0015ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0015ItDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_II0015_IT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ii.hqml.CnIi0015It")
public class CnIi0015ItDaoImpl extends DbioDaoSupport implements CnIi0015ItDao {

	/**
	 * CN_II0015_IT (CN_II0015_IT) 단건 조회.
	 * 
	 */
	public CnIi0015ItDto select(CnIi0015ItDto cnIi0015ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0015It.select",
				cnIi0015ItDto);

		CnIi0015ItDto foundCnIi0015ItDto = null;
		try {
			foundCnIi0015ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIi0015ItDto),
					new BeanPropertyRowMapper<CnIi0015ItDto>(
							CnIi0015ItDto.class));
			return foundCnIi0015ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_II0015_IT (CN_II0015_IT) 단건 등록.
	 * 
	 */
	public int insert(CnIi0015ItDto cnIi0015ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0015It.insert",
				cnIi0015ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0015ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0015_IT (CN_II0015_IT) 단건 변경.
	 * 
	 */
	public int update(CnIi0015ItDto cnIi0015ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0015It.update",
				cnIi0015ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0015ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0015_IT (CN_II0015_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIi0015ItDto cnIi0015ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0015It.delete",
				cnIi0015ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0015ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0015_IT (CN_II0015_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIi0015ItDto> list(CnIi0015ItDto cnIi0015ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0015It.list",
				cnIi0015ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIi0015ItDto), new BeanPropertyRowMapper<CnIi0015ItDto>(
				CnIi0015ItDto.class));
	}

	/**
	 * CN_II0015_IT (CN_II0015_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIi0015ItDto> cnIi0015ItDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0015It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0015ItDtos
				.size()];
		for (int i = 0; i < cnIi0015ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0015ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0015_IT (CN_II0015_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIi0015ItDto> cnIi0015ItDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0015It.update",
				cnIi0015ItDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnIi0015ItDtos
				.size()];
		for (int i = 0; i < cnIi0015ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0015ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0015_IT (CN_II0015_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIi0015ItDto> cnIi0015ItDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0015It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0015ItDtos
				.size()];
		for (int i = 0; i < cnIi0015ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0015ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
