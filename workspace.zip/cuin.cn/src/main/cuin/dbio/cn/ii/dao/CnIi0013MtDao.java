/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.dbio.cn.ii.dto.CnIi0013MtDto;

/**
 * CN_II0013_MT (CN_II0013_MT) DAO 인터페이스.
 *
 * 
 */
public interface CnIi0013MtDao {

	CnIi0013MtDto select(CnIi0013MtDto cnIi0013MtDto);

	int insert(CnIi0013MtDto cnIi0013MtDto);

	int update(CnIi0013MtDto cnIi0013MtDto);

	int delete(CnIi0013MtDto cnIi0013MtDto);

	List<CnIi0013MtDto> list(CnIi0013MtDto cnIi0013MtDto);

	int[] insertList(List<CnIi0013MtDto> cnIi0013MtDtos);

	int[] updateList(List<CnIi0013MtDto> cnIi0013MtDtos);

	int[] deleteList(List<CnIi0013MtDto> cnIi0013MtDtos);

}
