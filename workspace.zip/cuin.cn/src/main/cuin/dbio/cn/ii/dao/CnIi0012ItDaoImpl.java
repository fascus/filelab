/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ii.dto.CnIi0012ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0012ItDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_II0012_IT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ii.hqml.CnIi0012It")
public class CnIi0012ItDaoImpl extends DbioDaoSupport implements CnIi0012ItDao {

	/**
	 * CN_II0012_IT (CN_II0012_IT) 단건 조회.
	 * 
	 */
	public CnIi0012ItDto select(CnIi0012ItDto cnIi0012ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0012It.select",
				cnIi0012ItDto);

		CnIi0012ItDto foundCnIi0012ItDto = null;
		try {
			foundCnIi0012ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIi0012ItDto),
					new BeanPropertyRowMapper<CnIi0012ItDto>(
							CnIi0012ItDto.class));
			return foundCnIi0012ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_II0012_IT (CN_II0012_IT) 단건 등록.
	 * 
	 */
	public int insert(CnIi0012ItDto cnIi0012ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0012It.insert",
				cnIi0012ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0012ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0012_IT (CN_II0012_IT) 단건 변경.
	 * 
	 */
	public int update(CnIi0012ItDto cnIi0012ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0012It.update",
				cnIi0012ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0012ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0012_IT (CN_II0012_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIi0012ItDto cnIi0012ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0012It.delete",
				cnIi0012ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0012ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0012_IT (CN_II0012_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIi0012ItDto> list(CnIi0012ItDto cnIi0012ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0012It.list",
				cnIi0012ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIi0012ItDto), new BeanPropertyRowMapper<CnIi0012ItDto>(
				CnIi0012ItDto.class));
	}

	/**
	 * CN_II0012_IT (CN_II0012_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIi0012ItDto> cnIi0012ItDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0012It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0012ItDtos
				.size()];
		for (int i = 0; i < cnIi0012ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0012ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0012_IT (CN_II0012_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIi0012ItDto> cnIi0012ItDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0012It.update",
				cnIi0012ItDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnIi0012ItDtos
				.size()];
		for (int i = 0; i < cnIi0012ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0012ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0012_IT (CN_II0012_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIi0012ItDto> cnIi0012ItDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0012It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0012ItDtos
				.size()];
		for (int i = 0; i < cnIi0012ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0012ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
