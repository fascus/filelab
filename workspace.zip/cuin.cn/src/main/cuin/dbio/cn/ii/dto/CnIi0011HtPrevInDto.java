package cuin.dbio.cn.ii.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * CN_II0011_HT (CN_II0011_HT) 테이블 이력 단건 조회 DTO.
 */
public class CnIi0011HtPrevInDto implements Serializable {

	private static final long serialVersionUID = 1201540250578995046L;

	/**
	 * 이력 조회를 위한 기준 일시
	 */
	private Timestamp baseDtm;

	/**
	 * 서식관리번호
	 */
	private String formMgNo;

	/**
	 * 이미지서식구분코드
	 */
	private String imgFormDvCd;

	/**
	 * 서식항목구분코드
	 */
	private String formItmDvCd;

	/**
	 * 변경일련번호
	 */
	private Long chnSeq;

	/**
	 * 기준 일시 반환
	 */
	public Timestamp getBaseDtm() {
		return baseDtm;
	}

	/**
	 * 기준 일시 설정
	 */
	public void setBaseDtm(Timestamp baseDtm) {
		this.baseDtm = baseDtm;
	}

	/**
	 * '서식관리번호' 반환
	 */
	public String getFormMgNo() {
		return formMgNo;
	}

	/**
	 * '서식관리번호' 설정
	 */
	public void setFormMgNo(String formMgNo) {
		this.formMgNo = formMgNo;
	}

	/**
	 * '이미지서식구분코드' 반환
	 */
	public String getImgFormDvCd() {
		return imgFormDvCd;
	}

	/**
	 * '이미지서식구분코드' 설정
	 */
	public void setImgFormDvCd(String imgFormDvCd) {
		this.imgFormDvCd = imgFormDvCd;
	}

	/**
	 * '서식항목구분코드' 반환
	 */
	public String getFormItmDvCd() {
		return formItmDvCd;
	}

	/**
	 * '서식항목구분코드' 설정
	 */
	public void setFormItmDvCd(String formItmDvCd) {
		this.formItmDvCd = formItmDvCd;
	}

	/**
	 * '변경일련번호' 반환
	 */
	public Long getChnSeq() {
		return chnSeq;
	}

	/**
	 * '변경일련번호' 설정
	 */
	public void setChnSeq(Long chnSeq) {
		this.chnSeq = chnSeq;
	}

}