/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.dbio.cn.ii.dto.CnIi0016ItDto;

/**
 * CN_II0016_IT (CN_II0016_IT) DAO 인터페이스.
 *
 * 
 */
public interface CnIi0016ItDao {

	CnIi0016ItDto select(CnIi0016ItDto cnIi0016ItDto);

	int insert(CnIi0016ItDto cnIi0016ItDto);

	int update(CnIi0016ItDto cnIi0016ItDto);

	int delete(CnIi0016ItDto cnIi0016ItDto);

	List<CnIi0016ItDto> list(CnIi0016ItDto cnIi0016ItDto);

	int[] insertList(List<CnIi0016ItDto> cnIi0016ItDtos);

	int[] updateList(List<CnIi0016ItDto> cnIi0016ItDtos);

	int[] deleteList(List<CnIi0016ItDto> cnIi0016ItDtos);

}
