/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

;

/**
 * CN_II0016_IT (CN_II0016_IT) 입출력 DTO. 
 * 
 * @stereotype DTO
 * 
 */
public class CnIi0016ItDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -7151847428463181634L;

	/**
	 * 서식관리번호
	 */
	private String formMgNo;

	/**
	 * 이미지서식구분코드
	 */
	private String imgFormDvCd;

	/**
	 * 서식항목구분코드
	 */
	private String formItmDvCd;

	/**
	 * 변경일련번호
	 */
	private Long chnSeq;

	/**
	 * 계약역할자코드
	 */
	private String cnrRlplCd;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '서식관리번호' 반환
	 */
	public String getFormMgNo() {
		return formMgNo;
	}

	/**
	 * '서식관리번호' 설정
	 */
	public void setFormMgNo(String formMgNo) {
		this.formMgNo = formMgNo;
	}

	/**
	 * '이미지서식구분코드' 반환
	 */
	public String getImgFormDvCd() {
		return imgFormDvCd;
	}

	/**
	 * '이미지서식구분코드' 설정
	 */
	public void setImgFormDvCd(String imgFormDvCd) {
		this.imgFormDvCd = imgFormDvCd;
	}

	/**
	 * '서식항목구분코드' 반환
	 */
	public String getFormItmDvCd() {
		return formItmDvCd;
	}

	/**
	 * '서식항목구분코드' 설정
	 */
	public void setFormItmDvCd(String formItmDvCd) {
		this.formItmDvCd = formItmDvCd;
	}

	/**
	 * '변경일련번호' 반환
	 */
	public Long getChnSeq() {
		return chnSeq;
	}

	/**
	 * '변경일련번호' 설정
	 */
	public void setChnSeq(Long chnSeq) {
		this.chnSeq = chnSeq;
	}

	/**
	 * '계약역할자코드' 반환
	 */
	public String getCnrRlplCd() {
		return cnrRlplCd;
	}

	/**
	 * '계약역할자코드' 설정
	 */
	public void setCnrRlplCd(String cnrRlplCd) {
		this.cnrRlplCd = cnrRlplCd;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIi0016ItDto [");
		sb.append("\n    formMgNo = '").append(formMgNo).append("'");
		sb.append("\n    imgFormDvCd = '").append(imgFormDvCd).append("'");
		sb.append("\n    formItmDvCd = '").append(formItmDvCd).append("'");
		sb.append("\n    chnSeq = '").append(chnSeq).append("'");
		sb.append("\n    cnrRlplCd = '").append(cnrRlplCd).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIi0016ItDto : PK [");
		sb.append("\n    formMgNo = '").append(formMgNo).append("'");
		sb.append("\n    imgFormDvCd = '").append(imgFormDvCd).append("'");
		sb.append("\n    formItmDvCd = '").append(formItmDvCd).append("'");
		sb.append("\n    chnSeq = '").append(chnSeq).append("'");
		sb.append("\n    cnrRlplCd = '").append(cnrRlplCd).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
