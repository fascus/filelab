/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.dbio.cn.ii.dto.CnIi0004MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0004MtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_II0004_MT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnIi0004MtDao {

	CnIi0004MtDto select(CnIi0004MtDto cnIi0004MtDto);

	int insert(CnIi0004MtDto cnIi0004MtDto);

	int update(CnIi0004MtDto cnIi0004MtDto);

	int delete(CnIi0004MtDto cnIi0004MtDto);

	List<CnIi0004MtDto> list(CnIi0004MtDto cnIi0004MtDto);

	int[] insertList(List<CnIi0004MtDto> cnIi0004MtDtos);

	int[] updateList(List<CnIi0004MtDto> cnIi0004MtDtos);

	int[] deleteList(List<CnIi0004MtDto> cnIi0004MtDtos);

}
