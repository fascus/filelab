package cuin.dbio.cn.ii.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * CN_II0014_HT (CN_II0014_HT) 테이블 이력 단건 조회 DTO.
 */
public class CnIi0014HtPrevInDto implements Serializable {

	private static final long serialVersionUID = 6797296434056285568L;

	/**
	 * 이력 조회를 위한 기준 일시
	 */
	private Timestamp baseDtm;

	/**
	 * 서식상세업무코드
	 */
	private String formDtilBsnsCd;

	/**
	 * 서식관리번호
	 */
	private String formMgNo;

	/**
	 * 이미지서식구분코드
	 */
	private String imgFormDvCd;

	/**
	 * 변경일련번호
	 */
	private Long chnSeq;

	/**
	 * 기준 일시 반환
	 */
	public Timestamp getBaseDtm() {
		return baseDtm;
	}

	/**
	 * 기준 일시 설정
	 */
	public void setBaseDtm(Timestamp baseDtm) {
		this.baseDtm = baseDtm;
	}

	/**
	 * '서식상세업무코드' 반환
	 */
	public String getFormDtilBsnsCd() {
		return formDtilBsnsCd;
	}

	/**
	 * '서식상세업무코드' 설정
	 */
	public void setFormDtilBsnsCd(String formDtilBsnsCd) {
		this.formDtilBsnsCd = formDtilBsnsCd;
	}

	/**
	 * '서식관리번호' 반환
	 */
	public String getFormMgNo() {
		return formMgNo;
	}

	/**
	 * '서식관리번호' 설정
	 */
	public void setFormMgNo(String formMgNo) {
		this.formMgNo = formMgNo;
	}

	/**
	 * '이미지서식구분코드' 반환
	 */
	public String getImgFormDvCd() {
		return imgFormDvCd;
	}

	/**
	 * '이미지서식구분코드' 설정
	 */
	public void setImgFormDvCd(String imgFormDvCd) {
		this.imgFormDvCd = imgFormDvCd;
	}

	/**
	 * '변경일련번호' 반환
	 */
	public Long getChnSeq() {
		return chnSeq;
	}

	/**
	 * '변경일련번호' 설정
	 */
	public void setChnSeq(Long chnSeq) {
		this.chnSeq = chnSeq;
	}

}