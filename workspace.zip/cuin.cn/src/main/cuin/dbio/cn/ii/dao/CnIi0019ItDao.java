/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.dbio.cn.ii.dto.CnIi0019ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0019ItDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_II0019_IT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnIi0019ItDao {

	CnIi0019ItDto select(CnIi0019ItDto cnIi0019ItDto);

	int insert(CnIi0019ItDto cnIi0019ItDto);

	int update(CnIi0019ItDto cnIi0019ItDto);

	int delete(CnIi0019ItDto cnIi0019ItDto);

	List<CnIi0019ItDto> list(CnIi0019ItDto cnIi0019ItDto);

	int[] insertList(List<CnIi0019ItDto> cnIi0019ItDtos);

	int[] updateList(List<CnIi0019ItDto> cnIi0019ItDtos);

	int[] deleteList(List<CnIi0019ItDto> cnIi0019ItDtos);

}
