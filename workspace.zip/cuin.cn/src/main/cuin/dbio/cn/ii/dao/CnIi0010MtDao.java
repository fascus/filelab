/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.dbio.cn.ii.dto.CnIi0010MtDto;

/**
 * CN_II0010_MT (CN_II0010_MT) DAO 인터페이스.
 *
 * 
 */
public interface CnIi0010MtDao {

	CnIi0010MtDto select(CnIi0010MtDto cnIi0010MtDto);

	int insert(CnIi0010MtDto cnIi0010MtDto);

	int update(CnIi0010MtDto cnIi0010MtDto);

	int delete(CnIi0010MtDto cnIi0010MtDto);

	List<CnIi0010MtDto> list(CnIi0010MtDto cnIi0010MtDto);

	int[] insertList(List<CnIi0010MtDto> cnIi0010MtDtos);

	int[] updateList(List<CnIi0010MtDto> cnIi0010MtDtos);

	int[] deleteList(List<CnIi0010MtDto> cnIi0010MtDtos);

}
