package cuin.dbio.cn.ii.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ii.dto.CnIi0007MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0007MtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.05
 * 설    명 : CN_II0007_MT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ii.hqml.CnIi0007Mt")
public class CnIi0007MtDaoImpl extends DbioDaoSupport implements CnIi0007MtDao {

	/**
	 * CN_II0007_MT (CN_II0007_MT) 단건 조회.
	 * 
	 */
	public CnIi0007MtDto select(CnIi0007MtDto cnIi0007MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0007Mt.select",
				cnIi0007MtDto);

		CnIi0007MtDto foundCnIi0007MtDto = null;
		try {
			foundCnIi0007MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIi0007MtDto),
					new BeanPropertyRowMapper<CnIi0007MtDto>(
							CnIi0007MtDto.class));
			return foundCnIi0007MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_II0007_MT (CN_II0007_MT) 단건 등록.
	 * 
	 */
	public int insert(CnIi0007MtDto cnIi0007MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0007Mt.insert",
				cnIi0007MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0007MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0007_MT (CN_II0007_MT) 단건 변경.
	 * 
	 */
	public int update(CnIi0007MtDto cnIi0007MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0007Mt.update",
				cnIi0007MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0007MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0007_MT (CN_II0007_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIi0007MtDto cnIi0007MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0007Mt.delete",
				cnIi0007MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0007MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0007_MT (CN_II0007_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIi0007MtDto> list(CnIi0007MtDto cnIi0007MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0007Mt.list",
				cnIi0007MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIi0007MtDto), new BeanPropertyRowMapper<CnIi0007MtDto>(
				CnIi0007MtDto.class));
	}

	/**
	 * CN_II0007_MT (CN_II0007_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIi0007MtDto> cnIi0007MtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0007Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0007MtDtos
				.size()];
		for (int i = 0; i < cnIi0007MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0007MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0007_MT (CN_II0007_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIi0007MtDto> cnIi0007MtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0007Mt.update",
				cnIi0007MtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnIi0007MtDtos
				.size()];
		for (int i = 0; i < cnIi0007MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0007MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0007_MT (CN_II0007_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIi0007MtDto> cnIi0007MtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0007Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0007MtDtos
				.size()];
		for (int i = 0; i < cnIi0007MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0007MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
