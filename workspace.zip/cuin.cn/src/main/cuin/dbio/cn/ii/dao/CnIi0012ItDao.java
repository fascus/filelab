/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.dbio.cn.ii.dto.CnIi0012ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0012ItDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_II0012_IT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnIi0012ItDao {

	CnIi0012ItDto select(CnIi0012ItDto cnIi0012ItDto);

	int insert(CnIi0012ItDto cnIi0012ItDto);

	int update(CnIi0012ItDto cnIi0012ItDto);

	int delete(CnIi0012ItDto cnIi0012ItDto);

	List<CnIi0012ItDto> list(CnIi0012ItDto cnIi0012ItDto);

	int[] insertList(List<CnIi0012ItDto> cnIi0012ItDtos);

	int[] updateList(List<CnIi0012ItDto> cnIi0012ItDtos);

	int[] deleteList(List<CnIi0012ItDto> cnIi0012ItDtos);

}
