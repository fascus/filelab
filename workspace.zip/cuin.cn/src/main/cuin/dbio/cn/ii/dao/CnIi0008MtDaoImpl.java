/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ii.dto.CnIi0008MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0008MtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_II0008_MT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ii.hqml.CnIi0008Mt")
public class CnIi0008MtDaoImpl extends DbioDaoSupport implements CnIi0008MtDao {

	/**
	 * CN_II0008_MT (CN_II0008_MT) 단건 조회.
	 * 
	 */
	public CnIi0008MtDto select(CnIi0008MtDto cnIi0008MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0008Mt.select",
				cnIi0008MtDto);

		CnIi0008MtDto foundCnIi0008MtDto = null;
		try {
			foundCnIi0008MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIi0008MtDto),
					new BeanPropertyRowMapper<CnIi0008MtDto>(
							CnIi0008MtDto.class));
			return foundCnIi0008MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_II0008_MT (CN_II0008_MT) 단건 등록.
	 * 
	 */
	public int insert(CnIi0008MtDto cnIi0008MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0008Mt.insert",
				cnIi0008MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0008MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0008_MT (CN_II0008_MT) 단건 변경.
	 * 
	 */
	public int update(CnIi0008MtDto cnIi0008MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0008Mt.update",
				cnIi0008MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0008MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0008_MT (CN_II0008_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIi0008MtDto cnIi0008MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0008Mt.delete",
				cnIi0008MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0008MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0008_MT (CN_II0008_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIi0008MtDto> list(CnIi0008MtDto cnIi0008MtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0008Mt.list",
				cnIi0008MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIi0008MtDto), new BeanPropertyRowMapper<CnIi0008MtDto>(
				CnIi0008MtDto.class));
	}

	/**
	 * CN_II0008_MT (CN_II0008_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIi0008MtDto> cnIi0008MtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0008Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0008MtDtos
				.size()];
		for (int i = 0; i < cnIi0008MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0008MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0008_MT (CN_II0008_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIi0008MtDto> cnIi0008MtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0008Mt.update",
				cnIi0008MtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnIi0008MtDtos
				.size()];
		for (int i = 0; i < cnIi0008MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0008MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0008_MT (CN_II0008_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIi0008MtDto> cnIi0008MtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0008Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0008MtDtos
				.size()];
		for (int i = 0; i < cnIi0008MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0008MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
