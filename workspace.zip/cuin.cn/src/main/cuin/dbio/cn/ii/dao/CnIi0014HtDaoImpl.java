/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.ii.dto.CnIi0014HtDto;
import cuin.dbio.cn.ii.dto.CnIi0014HtPrevInDto;

/**
 * CN_II0014_HT (CN_II0014_HT) DAO 구현체.
 *
 * @stereotype DAO
 * 
 * 
 */

@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ii.hqml.CnIi0014Ht")
public class CnIi0014HtDaoImpl extends DbioDaoSupport implements CnIi0014HtDao {

	/**
	 * CN_II0014_HT (CN_II0014_HT) 단건 등록.
	 * 
	 */
	public int insert(CnIi0014HtDto cnIi0014HtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0014Ht.insert",
				cnIi0014HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0014HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0014_HT (CN_II0014_HT) 현행 이력 업데이트.
	 * 
	 */
	public int closeCurrentHistory(CnIi0014HtDto cnIi0014HtDto) {
		String sql = getSql(
				"cuin.dbio.cn.ii.hqml.CnIi0014Ht.closeCurrentHistory",
				cnIi0014HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0014HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0014_HT (CN_II0014_HT) 이력 삭제.
	 * 
	 */
	public int deleteHistory(CnIi0014HtDto cnIi0014HtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0014Ht.deleteHistory",
				cnIi0014HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0014HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0014_HT (CN_II0014_HT) 특정 시점의 단건 이력 조회.
	 * 
	 */
	public CnIi0014HtDto selectPrevious(CnIi0014HtPrevInDto cnIi0014HtPrevInDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0014Ht.selectPrevious",
				cnIi0014HtPrevInDto);

		CnIi0014HtDto foundCnIi0014HtDto = null;
		try {
			foundCnIi0014HtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIi0014HtPrevInDto),
					new BeanPropertyRowMapper<CnIi0014HtDto>(
							CnIi0014HtDto.class));
			return foundCnIi0014HtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * 특정 기간 동안의 이벤트(변경 내역) 조회
	 * 
	 */
	public List<CnIi0014HtDto> selectInPeriod(PeriodInDto periodInDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0014Ht.selectInPeriod",
				periodInDto);

		return queryForList(sql,
				new BeanPropertySqlParameterSource(periodInDto),
				new BeanPropertyRowMapper<CnIi0014HtDto>(CnIi0014HtDto.class));
	}

}
