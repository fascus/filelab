/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cuin.cn.dbio.core.sys.DbioUpdateCallback;
import cuin.cn.dbio.core.sys.DbioUtils;
import cuin.cn.dbio.core.sys.ServiceInDto;
import cuin.cn.exception.CuinRecordExistsException;
import cuin.cn.exception.CuinRecordNotExistsException;
import cuin.cn.util.BeanUtils;
import cuin.dbio.cn.ii.dto.CnIi0006HtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0006HtCtrlImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_II0006_HT DBIO 컨트롤러 구현체.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
@Component
public class CnIi0006HtCtrlImpl implements CnIi0006HtCtrl {

	private final static Logger logger = LoggerFactory
			.getLogger(CnIi0006HtCtrlImpl.class);

	// CN_II0006_HT (CN_II0006_HT) DAO
	@Autowired
	private CnIi0006HtDao cnIi0006HtDao;

	private DbioUpdateCallback dbioUpdateCallback;

	/**
	 * 단건 조회 (select single record).
	 *
	 * @param serviceInDto 서비스 입력 DTO (PK 컬럼들을 포함하고 있어야 함).
	 * @return 테이블 DTO (CnIi0006HtDao), 존재하지 않을 경우 null 반환.
	 */
	@Override
	public CnIi0006HtDto select(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnIi0006HtDto cnIi0006HtDto = BeanUtils.toBean(serviceInDto,
				CnIi0006HtDto.class);
		CnIi0006HtDto foundCnIi0006HtDto = cnIi0006HtDao.select(cnIi0006HtDto);
		if (foundCnIi0006HtDto != null
				&& "Y".equals(foundCnIi0006HtDto.getUseYn())) {
			return foundCnIi0006HtDto;
		} else {
			return null;
		}
	}

	/**
	 * 단건 등록 (insert single record).
	 * 이력 테이블이 존재하고, 이력 저장 방식이 '현행'이면 이력 테이블에도 레코드를 추가함.
	 *
	 * @param serviceInDto 서비스 입력 DTO (테이블 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 등록되면 1 반환
	 * @throws CuinRecordExistsException 이미 존재하는 레코드 등록을 시도한 경우 예외 발생
	 */
	@Override
	public int insert(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnIi0006HtDto cnIi0006HtDto = BeanUtils.toBean(serviceInDto,
				CnIi0006HtDto.class);

		CnIi0006HtDto existingDto = cnIi0006HtDao.select(cnIi0006HtDto);
		if (existingDto != null) {
			if ("N".equals(existingDto.getUseYn())) {
				DbioUtils.setSysProperties(cnIi0006HtDto);

				return cnIi0006HtDao.update(cnIi0006HtDto);
			} else {
				String errMsg = "A record with the same identity already exists in database. "
						+ cnIi0006HtDto.getPKValues();
				logger.error(errMsg);
				throw new CuinRecordExistsException(errMsg);
			}
		}

		DbioUtils.setSysProperties(cnIi0006HtDto);
		return cnIi0006HtDao.insert(cnIi0006HtDto);
	}

	/**
	 * 단건 변경 (update single record).
	 * 이력 테이블이 존재하면 이력 테이블에도 레코드를 추가함.
	 *
	 * @param serviceInDto 서비스 입력 DTO (테이블 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 변경되면 1 반환
	 * @throws CuinRecordNotExistsException 변경 대상 레코드가 존재하지 않을 경우 예외 발생.
	 */
	@Override
	public int update(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnIi0006HtDto newCnIi0006HtDto = BeanUtils.toBean(serviceInDto,
				CnIi0006HtDto.class);

		// 마스터 테이블에서 과거 데이터 추출
		CnIi0006HtDto oldCnIi0006HtDto = checkExists(newCnIi0006HtDto);
		// 마스터 레코드 업데이트
		DbioUtils.setSysProperties(newCnIi0006HtDto, oldCnIi0006HtDto);
		return cnIi0006HtDao.update(newCnIi0006HtDto);
	}

	/**
	 * 단건 삭제 (delete single record).
	 * 이력 테이블이 존재하면 이력 테이블 레코드 또한 삭제 처리.
	 *
	 * @param serviceInDto 서비스 입력 DTO (PK 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 변경되면 1 반환
	 * @throws CuinRecordNotExistsException 삭제 대상 레코드가 존재하지 않을 경우 예외 발생.
	 */
	@Override
	public int delete(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnIi0006HtDto cnIi0006HtDto = BeanUtils.toBean(serviceInDto,
				CnIi0006HtDto.class);

		// 삭제 대상 레코드 존재 여부 확인
		CnIi0006HtDto oldCnIi0006HtDto = checkExists(cnIi0006HtDto);

		// 마스터 테이블 삭제
		DbioUtils.setSysProperties(cnIi0006HtDto, oldCnIi0006HtDto);

		int deleteCnt = cnIi0006HtDao.delete(cnIi0006HtDto);

		return deleteCnt;
	}

	/**
	 * 변경 혹은 삭제 대상 레코드 존재 여부 검사.
	 *
	 * @param cnIi0006HtDto 변경 대상 레코드의 primary key 값을 포함한 DTO
	 * @return 변경 혹은 삭제 대상 레코드
	 */
	private CnIi0006HtDto checkExists(CnIi0006HtDto cnIi0006HtDto) {
		CnIi0006HtDto storedDto = cnIi0006HtDao.select(cnIi0006HtDto);
		if (storedDto == null) {
			String errMsg = "Requested record not found. \n"
					+ cnIi0006HtDto.getPKValues();
			logger.error(errMsg);
			throw new CuinRecordNotExistsException(errMsg);
		}

		return storedDto;
	}

	/**
	 * CN_II0006_HT 일괄 등록
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] insertList(List serviceInDtoList) {
		if (dbioUpdateCallback == null) {
			List<CnIi0006HtDto> tablsDtoList = new ArrayList<CnIi0006HtDto>();
			for (Object dto : serviceInDtoList) {
				CnIi0006HtDto tableDto = BeanUtils.toBean(dto,
						CnIi0006HtDto.class);
				DbioUtils.setSysProperties(tableDto);
				tablsDtoList.add(tableDto);
			}
			return cnIi0006HtDao.insertList(tablsDtoList);
		} else {
			int[] results = new int[serviceInDtoList.size()];
			int idx = 0;
			for (Object dto : serviceInDtoList) {
				dbioUpdateCallback.updateDto(dto);
				results[idx++] = insert((ServiceInDto) dto);
			}
			return results;
		}
	}

	/**
	 * CN_II0006_HT 일괄 변경
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] updateList(List serviceInDtoList) {
		int[] results = new int[serviceInDtoList.size()];
		int idx = 0;
		for (Object dto : serviceInDtoList) {
			if (dbioUpdateCallback != null) {
				dbioUpdateCallback.updateDto(dto);
			}
			results[idx++] = update((ServiceInDto) dto);
		}
		return results;
		/* 
		List<CnIi0006HtDto> tablsDtoList = new ArrayList<CnIi0006HtDto>();
		for (Object dto : serviceInDtoList) {
			CnIi0006HtDto tableDto = BeanUtils.toBean(dto, CnIi0006HtDto.class);
			if (dbioUpdateCallback != null) {
				dbioUpdateCallback.updateDto(tableDto);
			}
		    DbioUtils.setSysProperties(tableDto);
			tablsDtoList.add(tableDto);
		}	
		return cnIi0006HtDao.updateList(tablsDtoList);
		 */
	}

	/**
	 * CN_II0006_HT 일괄 삭제
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] deleteList(List serviceInDtoList) {

		int listSize = serviceInDtoList.size();
		int[] deleteResults = new int[listSize];
		for (int idx = 0; idx < listSize; idx++) {
			CnIi0006HtDto tableDto = BeanUtils.toBean(
					serviceInDtoList.get(idx), CnIi0006HtDto.class);

			DbioUtils.setSysProperties(tableDto);
			deleteResults[idx] = cnIi0006HtDao.delete(tableDto);
		}
		return deleteResults;
	}

	public void setBatchCallback(DbioUpdateCallback dbioUpdateCallback) {
		this.dbioUpdateCallback = dbioUpdateCallback;
	}

}
