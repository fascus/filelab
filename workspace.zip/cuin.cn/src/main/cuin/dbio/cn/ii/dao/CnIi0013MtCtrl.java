/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.cn.dbio.core.sys.DbioUpdateCallback;
import cuin.cn.dbio.core.sys.ServiceInDto;
import cuin.dbio.cn.ii.dto.CnIi0013MtDto;

/**
 * CN_II0013_MT (CN_II0013_MT) DBIO  컨트롤러 인터페이스.
 *
 * 
 */
public interface CnIi0013MtCtrl {

	/**
	 *  단건 조회
	 */
	CnIi0013MtDto select(ServiceInDto serviceInDto);

	/**
	 * CN_II0013_MT 등록
	 */
	int insert(ServiceInDto serviceInDto);

	/**
	 * CN_II0013_MT 변경
	 */
	int update(ServiceInDto serviceInDto);

	/**
	 * CN_II0013_MT 논리적 삭제
	 */
	int delete(ServiceInDto serviceInDto);

	/**
	 * CN_II0013_MT 일괄 등록
	 */
	int[] insertList(List serviceInDtoList);

	/**
	 * CN_II0013_MT 일괄 변경
	 */
	int[] updateList(List serviceInDtoList);

	/**
	 * CN_II0013_MT 일괄 삭제
	 */
	int[] deleteList(List serviceInDtoList);

	/**
	 * CN_II0013_MT 일괄 등록 시 레코드 건별 콜백
	 */
	void setBatchCallback(DbioUpdateCallback dbioUpdateCallback);
}
