package cuin.dbio.cn.ii.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.ii.dto.CnIi0002HtDto;
import cuin.dbio.cn.ii.dto.CnIi0002HtPrevInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0002HtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.05
 * 설    명 : CN_II0002_HT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ii.hqml.CnIi0002Ht")
public class CnIi0002HtDaoImpl extends DbioDaoSupport implements CnIi0002HtDao {

	/**
	 * CN_II0002_HT (CN_II0002_HT) 단건 등록.
	 * 
	 */
	public int insert(CnIi0002HtDto cnIi0002HtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0002Ht.insert",
				cnIi0002HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0002HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0002_HT (CN_II0002_HT) 현행 이력 업데이트.
	 * 
	 */
	public int closeCurrentHistory(CnIi0002HtDto cnIi0002HtDto) {
		String sql = getSql(
				"cuin.dbio.cn.ii.hqml.CnIi0002Ht.closeCurrentHistory",
				cnIi0002HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0002HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0002_HT (CN_II0002_HT) 이력 삭제.
	 * 
	 */
	public int deleteHistory(CnIi0002HtDto cnIi0002HtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0002Ht.deleteHistory",
				cnIi0002HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0002HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0002_HT (CN_II0002_HT) 특정 시점의 단건 이력 조회.
	 * 
	 */
	public CnIi0002HtDto selectPrevious(CnIi0002HtPrevInDto cnIi0002HtPrevInDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0002Ht.selectPrevious",
				cnIi0002HtPrevInDto);

		CnIi0002HtDto foundCnIi0002HtDto = null;
		try {
			foundCnIi0002HtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIi0002HtPrevInDto),
					new BeanPropertyRowMapper<CnIi0002HtDto>(
							CnIi0002HtDto.class));
			return foundCnIi0002HtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * 특정 기간 동안의 이벤트(변경 내역) 조회
	 * 
	 */
	public List<CnIi0002HtDto> selectInPeriod(PeriodInDto periodInDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0002Ht.selectInPeriod",
				periodInDto);

		return queryForList(sql,
				new BeanPropertySqlParameterSource(periodInDto),
				new BeanPropertyRowMapper<CnIi0002HtDto>(CnIi0002HtDto.class));
	}

}
