/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cuin.cn.dbio.core.sys.DbioUpdateCallback;
import cuin.cn.dbio.core.sys.DbioUtils;
import cuin.cn.dbio.core.sys.ServiceInDto;
import cuin.cn.exception.CuinRecordExistsException;
import cuin.cn.exception.CuinRecordNotExistsException;
import cuin.cn.util.BeanUtils;
import cuin.dbio.cn.ii.dto.CnIi0015ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0015ItCtrlImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_II0015_IT DBIO 컨트롤러 구현체.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
@Component
public class CnIi0015ItCtrlImpl implements CnIi0015ItCtrl {

	private final static Logger logger = LoggerFactory
			.getLogger(CnIi0015ItCtrlImpl.class);

	// CN_II0015_IT (CN_II0015_IT) DAO
	@Autowired
	private CnIi0015ItDao cnIi0015ItDao;

	private DbioUpdateCallback dbioUpdateCallback;

	/**
	 * 단건 조회 (select single record).
	 *
	 * @param serviceInDto 서비스 입력 DTO (PK 컬럼들을 포함하고 있어야 함).
	 * @return 테이블 DTO (CnIi0015ItDao), 존재하지 않을 경우 null 반환.
	 */
	@Override
	public CnIi0015ItDto select(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnIi0015ItDto cnIi0015ItDto = BeanUtils.toBean(serviceInDto,
				CnIi0015ItDto.class);
		CnIi0015ItDto foundCnIi0015ItDto = cnIi0015ItDao.select(cnIi0015ItDto);
		if (foundCnIi0015ItDto != null
				&& "Y".equals(foundCnIi0015ItDto.getUseYn())) {
			return foundCnIi0015ItDto;
		} else {
			return null;
		}
	}

	/**
	 * 단건 등록 (insert single record).
	 * 이력 테이블이 존재하고, 이력 저장 방식이 '현행'이면 이력 테이블에도 레코드를 추가함.
	 *
	 * @param serviceInDto 서비스 입력 DTO (테이블 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 등록되면 1 반환
	 * @throws CuinRecordExistsException 이미 존재하는 레코드 등록을 시도한 경우 예외 발생
	 */
	@Override
	public int insert(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnIi0015ItDto cnIi0015ItDto = BeanUtils.toBean(serviceInDto,
				CnIi0015ItDto.class);

		CnIi0015ItDto existingDto = cnIi0015ItDao.select(cnIi0015ItDto);
		if (existingDto != null) {
			if ("N".equals(existingDto.getUseYn())) {
				DbioUtils.setSysProperties(cnIi0015ItDto);

				return cnIi0015ItDao.update(cnIi0015ItDto);
			} else {
				String errMsg = "A record with the same identity already exists in database. "
						+ cnIi0015ItDto.getPKValues();
				logger.error(errMsg);
				throw new CuinRecordExistsException(errMsg);
			}
		}

		DbioUtils.setSysProperties(cnIi0015ItDto);
		return cnIi0015ItDao.insert(cnIi0015ItDto);
	}

	/**
	 * 단건 변경 (update single record).
	 * 이력 테이블이 존재하면 이력 테이블에도 레코드를 추가함.
	 *
	 * @param serviceInDto 서비스 입력 DTO (테이블 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 변경되면 1 반환
	 * @throws CuinRecordNotExistsException 변경 대상 레코드가 존재하지 않을 경우 예외 발생.
	 */
	@Override
	public int update(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnIi0015ItDto newCnIi0015ItDto = BeanUtils.toBean(serviceInDto,
				CnIi0015ItDto.class);

		// 마스터 테이블에서 과거 데이터 추출
		CnIi0015ItDto oldCnIi0015ItDto = checkExists(newCnIi0015ItDto);
		// 마스터 레코드 업데이트
		DbioUtils.setSysProperties(newCnIi0015ItDto, oldCnIi0015ItDto);
		return cnIi0015ItDao.update(newCnIi0015ItDto);
	}

	/**
	 * 단건 삭제 (delete single record).
	 * 이력 테이블이 존재하면 이력 테이블 레코드 또한 삭제 처리.
	 *
	 * @param serviceInDto 서비스 입력 DTO (PK 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 변경되면 1 반환
	 * @throws CuinRecordNotExistsException 삭제 대상 레코드가 존재하지 않을 경우 예외 발생.
	 */
	@Override
	public int delete(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnIi0015ItDto cnIi0015ItDto = BeanUtils.toBean(serviceInDto,
				CnIi0015ItDto.class);

		// 삭제 대상 레코드 존재 여부 확인
		CnIi0015ItDto oldCnIi0015ItDto = checkExists(cnIi0015ItDto);

		// 마스터 테이블 삭제
		DbioUtils.setSysProperties(cnIi0015ItDto, oldCnIi0015ItDto);

		int deleteCnt = cnIi0015ItDao.delete(cnIi0015ItDto);

		return deleteCnt;
	}

	/**
	 * 변경 혹은 삭제 대상 레코드 존재 여부 검사.
	 *
	 * @param cnIi0015ItDto 변경 대상 레코드의 primary key 값을 포함한 DTO
	 * @return 변경 혹은 삭제 대상 레코드
	 */
	private CnIi0015ItDto checkExists(CnIi0015ItDto cnIi0015ItDto) {
		CnIi0015ItDto storedDto = cnIi0015ItDao.select(cnIi0015ItDto);
		if (storedDto == null) {
			String errMsg = "Requested record not found. \n"
					+ cnIi0015ItDto.getPKValues();
			logger.error(errMsg);
			throw new CuinRecordNotExistsException(errMsg);
		}

		return storedDto;
	}

	/**
	 * CN_II0015_IT 일괄 등록
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] insertList(List serviceInDtoList) {
		if (dbioUpdateCallback == null) {
			List<CnIi0015ItDto> tablsDtoList = new ArrayList<CnIi0015ItDto>();
			for (Object dto : serviceInDtoList) {
				CnIi0015ItDto tableDto = BeanUtils.toBean(dto,
						CnIi0015ItDto.class);
				DbioUtils.setSysProperties(tableDto);
				tablsDtoList.add(tableDto);
			}
			return cnIi0015ItDao.insertList(tablsDtoList);
		} else {
			int[] results = new int[serviceInDtoList.size()];
			int idx = 0;
			for (Object dto : serviceInDtoList) {
				dbioUpdateCallback.updateDto(dto);
				results[idx++] = insert((ServiceInDto) dto);
			}
			return results;
		}
	}

	/**
	 * CN_II0015_IT 일괄 변경
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] updateList(List serviceInDtoList) {
		int[] results = new int[serviceInDtoList.size()];
		int idx = 0;
		for (Object dto : serviceInDtoList) {
			if (dbioUpdateCallback != null) {
				dbioUpdateCallback.updateDto(dto);
			}
			results[idx++] = update((ServiceInDto) dto);
		}
		return results;
		/* 
		List<CnIi0015ItDto> tablsDtoList = new ArrayList<CnIi0015ItDto>();
		for (Object dto : serviceInDtoList) {
			CnIi0015ItDto tableDto = BeanUtils.toBean(dto, CnIi0015ItDto.class);
			if (dbioUpdateCallback != null) {
				dbioUpdateCallback.updateDto(tableDto);
			}
		    DbioUtils.setSysProperties(tableDto);
			tablsDtoList.add(tableDto);
		}	
		return cnIi0015ItDao.updateList(tablsDtoList);
		 */
	}

	/**
	 * CN_II0015_IT 일괄 삭제
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] deleteList(List serviceInDtoList) {

		int listSize = serviceInDtoList.size();
		int[] deleteResults = new int[listSize];
		for (int idx = 0; idx < listSize; idx++) {
			CnIi0015ItDto tableDto = BeanUtils.toBean(
					serviceInDtoList.get(idx), CnIi0015ItDto.class);

			DbioUtils.setSysProperties(tableDto);
			deleteResults[idx] = cnIi0015ItDao.delete(tableDto);
		}
		return deleteResults;
	}

	public void setBatchCallback(DbioUpdateCallback dbioUpdateCallback) {
		this.dbioUpdateCallback = dbioUpdateCallback;
	}

}
