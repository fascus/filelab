/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.cn.dbio.core.sys.DbioUpdateCallback;
import cuin.cn.dbio.core.sys.ServiceInDto;
import cuin.dbio.cn.ii.dto.CnIi0019ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIi0019ItCtrl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_II0019_IT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface CnIi0019ItCtrl {

	/**
	 *  단건 조회
	 */
	CnIi0019ItDto select(ServiceInDto serviceInDto);

	/**
	 * CN_II0019_IT 등록
	 */
	int insert(ServiceInDto serviceInDto);

	/**
	 * CN_II0019_IT 변경
	 */
	int update(ServiceInDto serviceInDto);

	/**
	 * CN_II0019_IT 논리적 삭제
	 */
	int delete(ServiceInDto serviceInDto);

	/**
	 * CN_II0019_IT 일괄 등록
	 */
	int[] insertList(List serviceInDtoList);

	/**
	 * CN_II0019_IT 일괄 변경
	 */
	int[] updateList(List serviceInDtoList);

	/**
	 * CN_II0019_IT 일괄 삭제
	 */
	int[] deleteList(List serviceInDtoList);

	/**
	 * CN_II0019_IT 일괄 등록 시 레코드 건별 콜백
	 */
	void setBatchCallback(DbioUpdateCallback dbioUpdateCallback);
}
