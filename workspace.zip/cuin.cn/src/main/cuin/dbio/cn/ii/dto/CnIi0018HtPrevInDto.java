package cuin.dbio.cn.ii.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * CN_II0018_HT (CN_II0018_HT) 테이블 이력 단건 조회 DTO.
 */
public class CnIi0018HtPrevInDto implements Serializable {

	private static final long serialVersionUID = -8444507717859983320L;

	/**
	 * 이력 조회를 위한 기준 일시
	 */
	private Timestamp baseDtm;

	/**
	 * 이미지팩스일련번호
	 */
	private Long imgFaxSeq;

	/**
	 * 기준 일시 반환
	 */
	public Timestamp getBaseDtm() {
		return baseDtm;
	}

	/**
	 * 기준 일시 설정
	 */
	public void setBaseDtm(Timestamp baseDtm) {
		this.baseDtm = baseDtm;
	}

	/**
	 * '이미지팩스일련번호' 반환
	 */
	public Long getImgFaxSeq() {
		return imgFaxSeq;
	}

	/**
	 * '이미지팩스일련번호' 설정
	 */
	public void setImgFaxSeq(Long imgFaxSeq) {
		this.imgFaxSeq = imgFaxSeq;
	}

}