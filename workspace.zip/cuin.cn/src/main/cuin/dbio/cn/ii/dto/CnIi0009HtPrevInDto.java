package cuin.dbio.cn.ii.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * CN_II0009_HT (CN_II0009_HT) 테이블 이력 단건 조회 DTO.
 */
public class CnIi0009HtPrevInDto implements Serializable {

	private static final long serialVersionUID = 3431745978966231472L;

	/**
	 * 이력 조회를 위한 기준 일시
	 */
	private Timestamp baseDtm;

	/**
	 * 이미지진단서일련번호
	 */
	private Long imgMdctSeq;

	/**
	 * 기준 일시 반환
	 */
	public Timestamp getBaseDtm() {
		return baseDtm;
	}

	/**
	 * 기준 일시 설정
	 */
	public void setBaseDtm(Timestamp baseDtm) {
		this.baseDtm = baseDtm;
	}

	/**
	 * '이미지진단서일련번호' 반환
	 */
	public Long getImgMdctSeq() {
		return imgMdctSeq;
	}

	/**
	 * '이미지진단서일련번호' 설정
	 */
	public void setImgMdctSeq(Long imgMdctSeq) {
		this.imgMdctSeq = imgMdctSeq;
	}

}