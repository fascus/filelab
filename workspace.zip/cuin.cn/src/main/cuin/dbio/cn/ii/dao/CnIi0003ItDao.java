/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.dbio.cn.ii.dto.CnIi0003ItDto;

/**
 * CN_II0003_IT (CN_II0003_IT) DAO 인터페이스.
 *
 * 
 */
public interface CnIi0003ItDao {

	CnIi0003ItDto select(CnIi0003ItDto cnIi0003ItDto);

	int insert(CnIi0003ItDto cnIi0003ItDto);

	int update(CnIi0003ItDto cnIi0003ItDto);

	int delete(CnIi0003ItDto cnIi0003ItDto);

	List<CnIi0003ItDto> list(CnIi0003ItDto cnIi0003ItDto);

	int[] insertList(List<CnIi0003ItDto> cnIi0003ItDtos);

	int[] updateList(List<CnIi0003ItDto> cnIi0003ItDtos);

	int[] deleteList(List<CnIi0003ItDto> cnIi0003ItDtos);

}
