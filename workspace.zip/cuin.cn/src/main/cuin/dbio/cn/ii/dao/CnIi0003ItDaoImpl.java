/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ii.dto.CnIi0003ItDto;

/**
 * CN_II0003_IT (CN_II0003_IT) DAO 구현체.
 *
 * @stereotype DAO
 * 
 * 
 */

@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ii.hqml.CnIi0003It")
public class CnIi0003ItDaoImpl extends DbioDaoSupport implements CnIi0003ItDao {

	/**
	 * CN_II0003_IT (CN_II0003_IT) 단건 조회.
	 * 
	 */
	public CnIi0003ItDto select(CnIi0003ItDto cnIi0003ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0003It.select",
				cnIi0003ItDto);

		CnIi0003ItDto foundCnIi0003ItDto = null;
		try {
			foundCnIi0003ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIi0003ItDto),
					new BeanPropertyRowMapper<CnIi0003ItDto>(
							CnIi0003ItDto.class));
			return foundCnIi0003ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_II0003_IT (CN_II0003_IT) 단건 등록.
	 * 
	 */
	public int insert(CnIi0003ItDto cnIi0003ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0003It.insert",
				cnIi0003ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0003ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0003_IT (CN_II0003_IT) 단건 변경.
	 * 
	 */
	public int update(CnIi0003ItDto cnIi0003ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0003It.update",
				cnIi0003ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0003ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0003_IT (CN_II0003_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIi0003ItDto cnIi0003ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0003It.delete",
				cnIi0003ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0003ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0003_IT (CN_II0003_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIi0003ItDto> list(CnIi0003ItDto cnIi0003ItDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0003It.list",
				cnIi0003ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIi0003ItDto), new BeanPropertyRowMapper<CnIi0003ItDto>(
				CnIi0003ItDto.class));
	}

	/**
	 * CN_II0003_IT (CN_II0003_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIi0003ItDto> cnIi0003ItDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0003It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0003ItDtos
				.size()];
		for (int i = 0; i < cnIi0003ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0003ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0003_IT (CN_II0003_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIi0003ItDto> cnIi0003ItDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0003It.update");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0003ItDtos
				.size()];
		for (int i = 0; i < cnIi0003ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0003ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0003_IT (CN_II0003_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIi0003ItDto> cnIi0003ItDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0003It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0003ItDtos
				.size()];
		for (int i = 0; i < cnIi0003ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0003ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
