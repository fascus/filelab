/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cuin.cn.dbio.core.sys.DbioUpdateCallback;
import cuin.cn.dbio.core.sys.DbioUtils;
import cuin.cn.dbio.core.sys.ServiceInDto;
import cuin.cn.exception.CuinRecordExistsException;
import cuin.cn.exception.CuinRecordNotExistsException;
import cuin.cn.util.BeanUtils;
import cuin.dbio.cn.ii.dto.CnIi0016ItDto;

/**
 * CN_II0016_IT (CN_II0016_IT) DBIO 컨트롤러 구현체.
 */
@Component
public class CnIi0016ItCtrlImpl implements CnIi0016ItCtrl {

	private final static Logger logger = LoggerFactory
			.getLogger(CnIi0016ItCtrlImpl.class);

	// CN_II0016_IT (CN_II0016_IT) DAO
	@Autowired
	private CnIi0016ItDao cnIi0016ItDao;

	private DbioUpdateCallback dbioUpdateCallback;

	/**
	 * 단건 조회 (select single record).
	 *
	 * @param serviceInDto 서비스 입력 DTO (PK 컬럼들을 포함하고 있어야 함).
	 * @return 테이블 DTO (CnIi0016ItDao), 존재하지 않을 경우 null 반환.
	 */
	@Override
	public CnIi0016ItDto select(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnIi0016ItDto cnIi0016ItDto = BeanUtils.toBean(serviceInDto,
				CnIi0016ItDto.class);
		CnIi0016ItDto foundCnIi0016ItDto = cnIi0016ItDao.select(cnIi0016ItDto);
		if (foundCnIi0016ItDto != null
				&& "Y".equals(foundCnIi0016ItDto.getUseYn())) {
			return foundCnIi0016ItDto;
		} else {
			return null;
		}
	}

	/**
	 * 단건 등록 (insert single record).
	 * 이력 테이블이 존재하고, 이력 저장 방식이 '현행'이면 이력 테이블에도 레코드를 추가함.
	 *
	 * @param serviceInDto 서비스 입력 DTO (테이블 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 등록되면 1 반환
	 * @throws CuinRecordExistsException 이미 존재하는 레코드 등록을 시도한 경우 예외 발생
	 */
	@Override
	public int insert(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnIi0016ItDto cnIi0016ItDto = BeanUtils.toBean(serviceInDto,
				CnIi0016ItDto.class);

		CnIi0016ItDto existingDto = cnIi0016ItDao.select(cnIi0016ItDto);
		if (existingDto != null) {
			if ("N".equals(existingDto.getUseYn())) {
				DbioUtils.setSysProperties(cnIi0016ItDto);

				return cnIi0016ItDao.update(cnIi0016ItDto);
			} else {
				String errMsg = "A record with the same identity already exists in database. "
						+ cnIi0016ItDto.getPKValues();
				logger.error(errMsg);
				throw new CuinRecordExistsException(errMsg);
			}
		}

		DbioUtils.setSysProperties(cnIi0016ItDto);
		return cnIi0016ItDao.insert(cnIi0016ItDto);
	}

	/**
	 * 단건 변경 (update single record).
	 * 이력 테이블이 존재하면 이력 테이블에도 레코드를 추가함.
	 *
	 * @param serviceInDto 서비스 입력 DTO (테이블 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 변경되면 1 반환
	 * @throws CuinRecordNotExistsException 변경 대상 레코드가 존재하지 않을 경우 예외 발생.
	 */
	@Override
	public int update(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnIi0016ItDto newCnIi0016ItDto = BeanUtils.toBean(serviceInDto,
				CnIi0016ItDto.class);

		// 마스터 테이블에서 과거 데이터 추출
		CnIi0016ItDto oldCnIi0016ItDto = checkExists(newCnIi0016ItDto);
		// 마스터 레코드 업데이트
		DbioUtils.setSysProperties(newCnIi0016ItDto, oldCnIi0016ItDto);
		return cnIi0016ItDao.update(newCnIi0016ItDto);
	}

	/**
	 * 단건 삭제 (delete single record).
	 * 이력 테이블이 존재하면 이력 테이블 레코드 또한 삭제 처리.
	 *
	 * @param serviceInDto 서비스 입력 DTO (PK 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 변경되면 1 반환
	 * @throws CuinRecordNotExistsException 삭제 대상 레코드가 존재하지 않을 경우 예외 발생.
	 */
	@Override
	public int delete(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnIi0016ItDto cnIi0016ItDto = BeanUtils.toBean(serviceInDto,
				CnIi0016ItDto.class);

		// 삭제 대상 레코드 존재 여부 확인
		CnIi0016ItDto oldCnIi0016ItDto = checkExists(cnIi0016ItDto);

		// 마스터 테이블 삭제
		DbioUtils.setSysProperties(cnIi0016ItDto, oldCnIi0016ItDto);

		int deleteCnt = cnIi0016ItDao.delete(cnIi0016ItDto);

		return deleteCnt;
	}

	/**
	 * 변경 혹은 삭제 대상 레코드 존재 여부 검사.
	 *
	 * @param cnIi0016ItDto 변경 대상 레코드의 primary key 값을 포함한 DTO
	 * @return 변경 혹은 삭제 대상 레코드
	 */
	private CnIi0016ItDto checkExists(CnIi0016ItDto cnIi0016ItDto) {
		CnIi0016ItDto storedDto = cnIi0016ItDao.select(cnIi0016ItDto);
		if (storedDto == null) {
			String errMsg = "Requested record not found. \n"
					+ cnIi0016ItDto.getPKValues();
			logger.error(errMsg);
			throw new CuinRecordNotExistsException(errMsg);
		}

		return storedDto;
	}

	/**
	 * CN_II0016_IT 일괄 등록
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] insertList(List serviceInDtoList) {
		List<CnIi0016ItDto> tablsDtoList = new ArrayList<CnIi0016ItDto>();
		for (Object dto : serviceInDtoList) {
			if (dbioUpdateCallback != null) {
				dbioUpdateCallback.updateDto(dto);
			}
			CnIi0016ItDto tableDto = BeanUtils.toBean(dto, CnIi0016ItDto.class);
			DbioUtils.setSysProperties(tableDto);
			tablsDtoList.add(tableDto);
		}
		return cnIi0016ItDao.insertList(tablsDtoList);
	}

	/**
	 * CN_II0016_IT 일괄 변경
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] updateList(List serviceInDtoList) {
		List<CnIi0016ItDto> tablsDtoList = new ArrayList<CnIi0016ItDto>();
		for (Object dto : serviceInDtoList) {
			if (dbioUpdateCallback != null) {
				dbioUpdateCallback.updateDto(dto);
			}
			CnIi0016ItDto tableDto = BeanUtils.toBean(dto, CnIi0016ItDto.class);
			DbioUtils.setSysProperties(tableDto);
			tablsDtoList.add(tableDto);
		}
		return cnIi0016ItDao.updateList(tablsDtoList);
	}

	/**
	 * CN_II0016_IT 일괄 삭제
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] deleteList(List serviceInDtoList) {

		int listSize = serviceInDtoList.size();
		int[] deleteResults = new int[listSize];
		for (int idx = 0; idx < listSize; idx++) {
			CnIi0016ItDto tableDto = BeanUtils.toBean(
					serviceInDtoList.get(idx), CnIi0016ItDto.class);

			DbioUtils.setSysProperties(tableDto);
			deleteResults[idx] = cnIi0016ItDao.delete(tableDto);
		}
		return deleteResults;
	}

	public void setBatchCallback(DbioUpdateCallback dbioUpdateCallback) {
		this.dbioUpdateCallback = dbioUpdateCallback;
	}

}
