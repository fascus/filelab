/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ii.dto.CnIi0017BtDto;

/**
 * CN_II0017_BT (CN_II0017_BT) DAO 구현체.
 *
 * @stereotype DAO
 * 
 * 
 */

@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ii.hqml.CnIi0017Bt")
public class CnIi0017BtDaoImpl extends DbioDaoSupport implements CnIi0017BtDao {

	/**
	 * CN_II0017_BT (CN_II0017_BT) 단건 조회.
	 * 
	 */
	public CnIi0017BtDto select(CnIi0017BtDto cnIi0017BtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0017Bt.select",
				cnIi0017BtDto);

		CnIi0017BtDto foundCnIi0017BtDto = null;
		try {
			foundCnIi0017BtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIi0017BtDto),
					new BeanPropertyRowMapper<CnIi0017BtDto>(
							CnIi0017BtDto.class));
			return foundCnIi0017BtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_II0017_BT (CN_II0017_BT) 단건 등록.
	 * 
	 */
	public int insert(CnIi0017BtDto cnIi0017BtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0017Bt.insert",
				cnIi0017BtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0017BtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0017_BT (CN_II0017_BT) 단건 변경.
	 * 
	 */
	public int update(CnIi0017BtDto cnIi0017BtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0017Bt.update",
				cnIi0017BtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0017BtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0017_BT (CN_II0017_BT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIi0017BtDto cnIi0017BtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0017Bt.delete",
				cnIi0017BtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIi0017BtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_II0017_BT (CN_II0017_BT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIi0017BtDto> list(CnIi0017BtDto cnIi0017BtDto) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0017Bt.list",
				cnIi0017BtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIi0017BtDto), new BeanPropertyRowMapper<CnIi0017BtDto>(
				CnIi0017BtDto.class));
	}

	/**
	 * CN_II0017_BT (CN_II0017_BT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIi0017BtDto> cnIi0017BtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0017Bt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0017BtDtos
				.size()];
		for (int i = 0; i < cnIi0017BtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0017BtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0017_BT (CN_II0017_BT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIi0017BtDto> cnIi0017BtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0017Bt.update");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0017BtDtos
				.size()];
		for (int i = 0; i < cnIi0017BtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0017BtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_II0017_BT (CN_II0017_BT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIi0017BtDto> cnIi0017BtDtos) {
		String sql = getSql("cuin.dbio.cn.ii.hqml.CnIi0017Bt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIi0017BtDtos
				.size()];
		for (int i = 0; i < cnIi0017BtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIi0017BtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
