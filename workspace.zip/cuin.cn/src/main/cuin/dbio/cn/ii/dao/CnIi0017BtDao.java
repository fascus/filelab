/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.dbio.cn.ii.dto.CnIi0017BtDto;

/**
 * CN_II0017_BT (CN_II0017_BT) DAO 인터페이스.
 *
 * 
 */
public interface CnIi0017BtDao {

	CnIi0017BtDto select(CnIi0017BtDto cnIi0017BtDto);

	int insert(CnIi0017BtDto cnIi0017BtDto);

	int update(CnIi0017BtDto cnIi0017BtDto);

	int delete(CnIi0017BtDto cnIi0017BtDto);

	List<CnIi0017BtDto> list(CnIi0017BtDto cnIi0017BtDto);

	int[] insertList(List<CnIi0017BtDto> cnIi0017BtDtos);

	int[] updateList(List<CnIi0017BtDto> cnIi0017BtDtos);

	int[] deleteList(List<CnIi0017BtDto> cnIi0017BtDtos);

}
