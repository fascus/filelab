/**
 * 
 * 
 */
package cuin.dbio.cn.ii.dao;

import java.util.List;

import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.ii.dto.CnIi0011HtDto;
import cuin.dbio.cn.ii.dto.CnIi0011HtPrevInDto;

/**
 * CN_II0011_HT (CN_II0011_HT) DAO 인터페이스.
 *
 * 
 */
public interface CnIi0011HtDao {

	int insert(CnIi0011HtDto cnIi0011HtDto);

	int closeCurrentHistory(CnIi0011HtDto cnIi0011HtDto);

	int deleteHistory(CnIi0011HtDto cnIi0011HtDto);

	CnIi0011HtDto selectPrevious(CnIi0011HtPrevInDto cnIi0011HtPrevInDto);

	List<CnIi0011HtDto> selectInPeriod(PeriodInDto periodInDto);

}
