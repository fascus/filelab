/**
 * 
 * 
 */
package cuin.dbio.cn.mh.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;

/**
 * 전자책이력 (CN_MH0004_HT) 입출력 DTO. 
 * 
 *  @author 차대현(dhcha3347@hanwha.com) 
 */
public class CnMh0004HtDto implements Serializable, EntityDto {
	private static final long serialVersionUID = 6740542071052454994L;

	// 전자책ID
	private String ebkId;

	// 적용종료일시
	private Timestamp aplEotDtm;

	// 적용시작일시
	private Timestamp aplBgDtm;

	// 업무구분코드
	private String bsnsDvCd;

	// 전자책구분코드
	private String ebkDvCd;

	// 제개정내용
	private String earnCtt;

	// 요청자사원번호
	private String rqtrEmpNo;

	// 요청일자
	private String rqstDt;

	// 원본파일경로명
	private String ogcyFlPthNm;

	// 폐기여부
	private String dscYn;

	// 사용여부
	private String useYn;

	// 프로그램ID
	private String prgId;

	// 생성일시
	private Timestamp crtnDtm;

	// 생성자번호
	private String cnrrNo;

	// 수정일시
	private Timestamp uptDtm;

	// 수정자번호
	private String ameNo;

	/**
	 * '전자책ID' 반환
	 */
	public String getEbkId() {
		return ebkId;
	}

	/**
	 * '전자책ID' 설정
	 */
	public void setEbkId(String ebkId) {
		this.ebkId = ebkId;
	}

	/**
	 * '적용종료일시' 반환
	 */
	public Timestamp getAplEotDtm() {
		return aplEotDtm;
	}

	/**
	 * '적용종료일시' 설정
	 */
	public void setAplEotDtm(Timestamp aplEotDtm) {
		this.aplEotDtm = aplEotDtm;
	}

	/**
	 * '적용시작일시' 반환
	 */
	public Timestamp getAplBgDtm() {
		return aplBgDtm;
	}

	/**
	 * '적용시작일시' 설정
	 */
	public void setAplBgDtm(Timestamp aplBgDtm) {
		this.aplBgDtm = aplBgDtm;
	}

	/**
	 * '업무구분코드' 반환
	 */
	public String getBsnsDvCd() {
		return bsnsDvCd;
	}

	/**
	 * '업무구분코드' 설정
	 */
	public void setBsnsDvCd(String bsnsDvCd) {
		this.bsnsDvCd = bsnsDvCd;
	}

	/**
	 * '전자책구분코드' 반환
	 */
	public String getEbkDvCd() {
		return ebkDvCd;
	}

	/**
	 * '전자책구분코드' 설정
	 */
	public void setEbkDvCd(String ebkDvCd) {
		this.ebkDvCd = ebkDvCd;
	}

	/**
	 * '제개정내용' 반환
	 */
	public String getEarnCtt() {
		return earnCtt;
	}

	/**
	 * '제개정내용' 설정
	 */
	public void setEarnCtt(String earnCtt) {
		this.earnCtt = earnCtt;
	}

	/**
	 * '요청자사원번호' 반환
	 */
	public String getRqtrEmpNo() {
		return rqtrEmpNo;
	}

	/**
	 * '요청자사원번호' 설정
	 */
	public void setRqtrEmpNo(String rqtrEmpNo) {
		this.rqtrEmpNo = rqtrEmpNo;
	}

	/**
	 * '요청일자' 반환
	 */
	public String getRqstDt() {
		return rqstDt;
	}

	/**
	 * '요청일자' 설정
	 */
	public void setRqstDt(String rqstDt) {
		this.rqstDt = rqstDt;
	}

	/**
	 * '원본파일경로명' 반환
	 */
	public String getOgcyFlPthNm() {
		return ogcyFlPthNm;
	}

	/**
	 * '원본파일경로명' 설정
	 */
	public void setOgcyFlPthNm(String ogcyFlPthNm) {
		this.ogcyFlPthNm = ogcyFlPthNm;
	}

	/**
	 * '폐기여부' 반환
	 */
	public String getDscYn() {
		return dscYn;
	}

	/**
	 * '폐기여부' 설정
	 */
	public void setDscYn(String dscYn) {
		this.dscYn = dscYn;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnMh0004HtDto [");
		sb.append("\n    ebkId = '").append(ebkId).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n    bsnsDvCd = '").append(bsnsDvCd).append("'");
		sb.append("\n    ebkDvCd = '").append(ebkDvCd).append("'");
		sb.append("\n    earnCtt = '").append(earnCtt).append("'");
		sb.append("\n    rqtrEmpNo = '").append(rqtrEmpNo).append("'");
		sb.append("\n    rqstDt = '").append(rqstDt).append("'");
		sb.append("\n    ogcyFlPthNm = '").append(ogcyFlPthNm).append("'");
		sb.append("\n    dscYn = '").append(dscYn).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnMh0004HtDto : PK [");
		sb.append("\n    ebkId = '").append(ebkId).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
