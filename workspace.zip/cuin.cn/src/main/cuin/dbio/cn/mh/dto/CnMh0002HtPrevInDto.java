package cuin.dbio.cn.mh.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * CN_MH0002_HT (CN_MH0002_HT) 테이블 이력 단건 조회 DTO.
 */
public class CnMh0002HtPrevInDto implements Serializable {

	private static final long serialVersionUID = 1738737320966703165L;

	/**
	 * 이력 조회를 위한 기준 일시
	 */
	private Timestamp baseDtm;

	/**
	 * 전자책ID
	 */
	private String ebkId;

	/**
	 * 변경일련번호
	 */
	private Long chnSeq;

	/**
	 * 기준 일시 반환
	 */
	public Timestamp getBaseDtm() {
		return baseDtm;
	}

	/**
	 * 기준 일시 설정
	 */
	public void setBaseDtm(Timestamp baseDtm) {
		this.baseDtm = baseDtm;
	}

	/**
	 * '전자책ID' 반환
	 */
	public String getEbkId() {
		return ebkId;
	}

	/**
	 * '전자책ID' 설정
	 */
	public void setEbkId(String ebkId) {
		this.ebkId = ebkId;
	}

	/**
	 * '변경일련번호' 반환
	 */
	public Long getChnSeq() {
		return chnSeq;
	}

	/**
	 * '변경일련번호' 설정
	 */
	public void setChnSeq(Long chnSeq) {
		this.chnSeq = chnSeq;
	}

}