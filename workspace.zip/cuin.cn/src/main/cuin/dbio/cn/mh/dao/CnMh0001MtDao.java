/**
 * 
 * 
 */
package cuin.dbio.cn.mh.dao;

import java.util.List;

import cuin.dbio.cn.mh.dto.CnMh0001MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnMh0001MtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_MH0001_MT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnMh0001MtDao {

	CnMh0001MtDto select(CnMh0001MtDto cnMh0001MtDto);

	int insert(CnMh0001MtDto cnMh0001MtDto);

	int update(CnMh0001MtDto cnMh0001MtDto);

	int delete(CnMh0001MtDto cnMh0001MtDto);

	List<CnMh0001MtDto> list(CnMh0001MtDto cnMh0001MtDto);

	int[] insertList(List<CnMh0001MtDto> cnMh0001MtDtos);

	int[] updateList(List<CnMh0001MtDto> cnMh0001MtDtos);

	int[] deleteList(List<CnMh0001MtDto> cnMh0001MtDtos);

}
