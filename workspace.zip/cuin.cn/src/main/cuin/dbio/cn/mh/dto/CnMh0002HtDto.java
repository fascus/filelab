/**
 * 
 * 
 */
package cuin.dbio.cn.mh.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnMh0002HtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_MH0002_HT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnMh0002HtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -4265448722827097575L;

	/**
	 * 전자책ID
	 */
	private String ebkId;

	/**
	 * 변경일련번호
	 */
	private Long chnSeq;

	/**
	 * 적용종료일시
	 */
	private Timestamp aplEotDtm;

	/**
	 * 적용시작일시
	 */
	private Timestamp aplBgDtm;

	/**
	 * 유효종료일시
	 */
	private Timestamp vldEotDtm;

	/**
	 * 유효시작일시
	 */
	private Timestamp vldBgDtm;

	/**
	 * 업무구분코드
	 */
	private String bsnsDvCd;

	/**
	 * 전자책구분코드
	 */
	private String ebkDvCd;

	/**
	 * 제개정내용
	 */
	private String earnCtt;

	/**
	 * 요청자사원번호
	 */
	private String rqtrEmpNo;

	/**
	 * 요청일자
	 */
	private String rqstDt;

	/**
	 * 원본파일경로명
	 */
	private String ogcyFlPthNm;

	/**
	 * 전자책일련번호
	 */
	private Long ebkSeq;

	/**
	 * 폐기여부
	 */
	private String dscYn;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '전자책ID' 반환
	 */
	public String getEbkId() {
		return ebkId;
	}

	/**
	 * '전자책ID' 설정
	 */
	public void setEbkId(String ebkId) {
		this.ebkId = ebkId;
	}

	/**
	 * '변경일련번호' 반환
	 */
	public Long getChnSeq() {
		return chnSeq;
	}

	/**
	 * '변경일련번호' 설정
	 */
	public void setChnSeq(Long chnSeq) {
		this.chnSeq = chnSeq;
	}

	/**
	 * '적용종료일시' 반환
	 */
	public Timestamp getAplEotDtm() {
		return aplEotDtm;
	}

	/**
	 * '적용종료일시' 설정
	 */
	public void setAplEotDtm(Timestamp aplEotDtm) {
		this.aplEotDtm = aplEotDtm;
	}

	/**
	 * '적용시작일시' 반환
	 */
	public Timestamp getAplBgDtm() {
		return aplBgDtm;
	}

	/**
	 * '적용시작일시' 설정
	 */
	public void setAplBgDtm(Timestamp aplBgDtm) {
		this.aplBgDtm = aplBgDtm;
	}

	/**
	 * '유효종료일시' 반환
	 */
	public Timestamp getVldEotDtm() {
		return vldEotDtm;
	}

	/**
	 * '유효종료일시' 설정
	 */
	public void setVldEotDtm(Timestamp vldEotDtm) {
		this.vldEotDtm = vldEotDtm;
	}

	/**
	 * '유효시작일시' 반환
	 */
	public Timestamp getVldBgDtm() {
		return vldBgDtm;
	}

	/**
	 * '유효시작일시' 설정
	 */
	public void setVldBgDtm(Timestamp vldBgDtm) {
		this.vldBgDtm = vldBgDtm;
	}

	/**
	 * '업무구분코드' 반환
	 */
	public String getBsnsDvCd() {
		return bsnsDvCd;
	}

	/**
	 * '업무구분코드' 설정
	 */
	public void setBsnsDvCd(String bsnsDvCd) {
		this.bsnsDvCd = bsnsDvCd;
	}

	/**
	 * '전자책구분코드' 반환
	 */
	public String getEbkDvCd() {
		return ebkDvCd;
	}

	/**
	 * '전자책구분코드' 설정
	 */
	public void setEbkDvCd(String ebkDvCd) {
		this.ebkDvCd = ebkDvCd;
	}

	/**
	 * '제개정내용' 반환
	 */
	public String getEarnCtt() {
		return earnCtt;
	}

	/**
	 * '제개정내용' 설정
	 */
	public void setEarnCtt(String earnCtt) {
		this.earnCtt = earnCtt;
	}

	/**
	 * '요청자사원번호' 반환
	 */
	public String getRqtrEmpNo() {
		return rqtrEmpNo;
	}

	/**
	 * '요청자사원번호' 설정
	 */
	public void setRqtrEmpNo(String rqtrEmpNo) {
		this.rqtrEmpNo = rqtrEmpNo;
	}

	/**
	 * '요청일자' 반환
	 */
	public String getRqstDt() {
		return rqstDt;
	}

	/**
	 * '요청일자' 설정
	 */
	public void setRqstDt(String rqstDt) {
		this.rqstDt = rqstDt;
	}

	/**
	 * '원본파일경로명' 반환
	 */
	public String getOgcyFlPthNm() {
		return ogcyFlPthNm;
	}

	/**
	 * '원본파일경로명' 설정
	 */
	public void setOgcyFlPthNm(String ogcyFlPthNm) {
		this.ogcyFlPthNm = ogcyFlPthNm;
	}

	/**
	 * '전자책일련번호' 반환
	 */
	public Long getEbkSeq() {
		return ebkSeq;
	}

	/**
	 * '전자책일련번호' 설정
	 */
	public void setEbkSeq(Long ebkSeq) {
		this.ebkSeq = ebkSeq;
	}

	/**
	 * '폐기여부' 반환
	 */
	public String getDscYn() {
		return dscYn;
	}

	/**
	 * '폐기여부' 설정
	 */
	public void setDscYn(String dscYn) {
		this.dscYn = dscYn;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnMh0002HtDto [");
		sb.append("\n    ebkId = '").append(ebkId).append("'");
		sb.append("\n    chnSeq = '").append(chnSeq).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n    vldEotDtm = '").append(vldEotDtm).append("'");
		sb.append("\n    vldBgDtm = '").append(vldBgDtm).append("'");
		sb.append("\n    bsnsDvCd = '").append(bsnsDvCd).append("'");
		sb.append("\n    ebkDvCd = '").append(ebkDvCd).append("'");
		sb.append("\n    earnCtt = '").append(earnCtt).append("'");
		sb.append("\n    rqtrEmpNo = '").append(rqtrEmpNo).append("'");
		sb.append("\n    rqstDt = '").append(rqstDt).append("'");
		sb.append("\n    ogcyFlPthNm = '").append(ogcyFlPthNm).append("'");
		sb.append("\n    ebkSeq = '").append(ebkSeq).append("'");
		sb.append("\n    dscYn = '").append(dscYn).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnMh0002HtDto : PK [");
		sb.append("\n    ebkId = '").append(ebkId).append("'");
		sb.append("\n    chnSeq = '").append(chnSeq).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
