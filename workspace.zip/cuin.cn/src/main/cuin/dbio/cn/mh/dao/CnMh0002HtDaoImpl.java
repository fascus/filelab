/**
 * 
 * 
 */
package cuin.dbio.cn.mh.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.mh.dto.CnMh0002HtDto;
import cuin.dbio.cn.mh.dto.CnMh0002HtPrevInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnMh0002HtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_MH0002_HT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.mh.hqml.CnMh0002Ht")
public class CnMh0002HtDaoImpl extends DbioDaoSupport implements CnMh0002HtDao {

	/**
	 * CN_MH0002_HT (CN_MH0002_HT) 단건 등록.
	 * 
	 */
	public int insert(CnMh0002HtDto cnMh0002HtDto) {
		String sql = getSql("cuin.dbio.cn.mh.hqml.CnMh0002Ht.insert",
				cnMh0002HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnMh0002HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_MH0002_HT (CN_MH0002_HT) 현행 이력 업데이트.
	 * 
	 */
	public int closeCurrentHistory(CnMh0002HtDto cnMh0002HtDto) {
		String sql = getSql(
				"cuin.dbio.cn.mh.hqml.CnMh0002Ht.closeCurrentHistory",
				cnMh0002HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnMh0002HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_MH0002_HT (CN_MH0002_HT) 이력 삭제.
	 * 
	 */
	public int deleteHistory(CnMh0002HtDto cnMh0002HtDto) {
		String sql = getSql("cuin.dbio.cn.mh.hqml.CnMh0002Ht.deleteHistory",
				cnMh0002HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnMh0002HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_MH0002_HT (CN_MH0002_HT) 특정 시점의 단건 이력 조회.
	 * 
	 */
	public CnMh0002HtDto selectPrevious(CnMh0002HtPrevInDto cnMh0002HtPrevInDto) {
		String sql = getSql("cuin.dbio.cn.mh.hqml.CnMh0002Ht.selectPrevious",
				cnMh0002HtPrevInDto);

		CnMh0002HtDto foundCnMh0002HtDto = null;
		try {
			foundCnMh0002HtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnMh0002HtPrevInDto),
					new BeanPropertyRowMapper<CnMh0002HtDto>(
							CnMh0002HtDto.class));
			return foundCnMh0002HtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * 특정 기간 동안의 이벤트(변경 내역) 조회
	 * 
	 */
	public List<CnMh0002HtDto> selectInPeriod(PeriodInDto periodInDto) {
		String sql = getSql("cuin.dbio.cn.mh.hqml.CnMh0002Ht.selectInPeriod",
				periodInDto);

		return queryForList(sql,
				new BeanPropertySqlParameterSource(periodInDto),
				new BeanPropertyRowMapper<CnMh0002HtDto>(CnMh0002HtDto.class));
	}

}
