/**
 * 
 * 
 */
package cuin.dbio.cn.mh.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.mh.dto.CnMh0001MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnMh0001MtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_MH0001_MT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.mh.hqml.CnMh0001Mt")
public class CnMh0001MtDaoImpl extends DbioDaoSupport implements CnMh0001MtDao {

	/**
	 * CN_MH0001_MT (CN_MH0001_MT) 단건 조회.
	 * 
	 */
	public CnMh0001MtDto select(CnMh0001MtDto cnMh0001MtDto) {
		String sql = getSql("cuin.dbio.cn.mh.hqml.CnMh0001Mt.select",
				cnMh0001MtDto);

		CnMh0001MtDto foundCnMh0001MtDto = null;
		try {
			foundCnMh0001MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnMh0001MtDto),
					new BeanPropertyRowMapper<CnMh0001MtDto>(
							CnMh0001MtDto.class));
			return foundCnMh0001MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_MH0001_MT (CN_MH0001_MT) 단건 등록.
	 * 
	 */
	public int insert(CnMh0001MtDto cnMh0001MtDto) {
		String sql = getSql("cuin.dbio.cn.mh.hqml.CnMh0001Mt.insert",
				cnMh0001MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnMh0001MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_MH0001_MT (CN_MH0001_MT) 단건 변경.
	 * 
	 */
	public int update(CnMh0001MtDto cnMh0001MtDto) {
		String sql = getSql("cuin.dbio.cn.mh.hqml.CnMh0001Mt.update",
				cnMh0001MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnMh0001MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_MH0001_MT (CN_MH0001_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnMh0001MtDto cnMh0001MtDto) {
		String sql = getSql("cuin.dbio.cn.mh.hqml.CnMh0001Mt.delete",
				cnMh0001MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnMh0001MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_MH0001_MT (CN_MH0001_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnMh0001MtDto> list(CnMh0001MtDto cnMh0001MtDto) {
		String sql = getSql("cuin.dbio.cn.mh.hqml.CnMh0001Mt.list",
				cnMh0001MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnMh0001MtDto), new BeanPropertyRowMapper<CnMh0001MtDto>(
				CnMh0001MtDto.class));
	}

	/**
	 * CN_MH0001_MT (CN_MH0001_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnMh0001MtDto> cnMh0001MtDtos) {
		String sql = getSql("cuin.dbio.cn.mh.hqml.CnMh0001Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnMh0001MtDtos
				.size()];
		for (int i = 0; i < cnMh0001MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnMh0001MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_MH0001_MT (CN_MH0001_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnMh0001MtDto> cnMh0001MtDtos) {
		String sql = getSql("cuin.dbio.cn.mh.hqml.CnMh0001Mt.update",
				cnMh0001MtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnMh0001MtDtos
				.size()];
		for (int i = 0; i < cnMh0001MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnMh0001MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_MH0001_MT (CN_MH0001_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnMh0001MtDto> cnMh0001MtDtos) {
		String sql = getSql("cuin.dbio.cn.mh.hqml.CnMh0001Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnMh0001MtDtos
				.size()];
		for (int i = 0; i < cnMh0001MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnMh0001MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
