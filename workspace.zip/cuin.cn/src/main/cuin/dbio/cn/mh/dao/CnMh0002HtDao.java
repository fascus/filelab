/**
 * 
 * 
 */
package cuin.dbio.cn.mh.dao;

import java.util.List;

import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.mh.dto.CnMh0002HtDto;
import cuin.dbio.cn.mh.dto.CnMh0002HtPrevInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnMh0002HtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_MH0002_HT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnMh0002HtDao {

	int insert(CnMh0002HtDto cnMh0002HtDto);

	int closeCurrentHistory(CnMh0002HtDto cnMh0002HtDto);

	int deleteHistory(CnMh0002HtDto cnMh0002HtDto);

	CnMh0002HtDto selectPrevious(CnMh0002HtPrevInDto cnMh0002HtPrevInDto);

	List<CnMh0002HtDto> selectInPeriod(PeriodInDto periodInDto);

}
