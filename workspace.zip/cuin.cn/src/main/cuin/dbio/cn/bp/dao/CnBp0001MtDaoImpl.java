/**
 * 
 * 
 */
package cuin.dbio.cn.bp.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.bp.dto.CnBp0001MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnBp0001MtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_BP0001_MT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.bp.hqml.CnBp0001Mt")
public class CnBp0001MtDaoImpl extends DbioDaoSupport implements CnBp0001MtDao {

	/**
	 * CN_BP0001_MT (CN_BP0001_MT) 단건 조회.
	 * 
	 */
	public CnBp0001MtDto select(CnBp0001MtDto cnBp0001MtDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0001Mt.select",
				cnBp0001MtDto);

		CnBp0001MtDto foundCnBp0001MtDto = null;
		try {
			foundCnBp0001MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnBp0001MtDto),
					new BeanPropertyRowMapper<CnBp0001MtDto>(
							CnBp0001MtDto.class));
			return foundCnBp0001MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_BP0001_MT (CN_BP0001_MT) 단건 등록.
	 * 
	 */
	public int insert(CnBp0001MtDto cnBp0001MtDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0001Mt.insert",
				cnBp0001MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnBp0001MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_BP0001_MT (CN_BP0001_MT) 단건 변경.
	 * 
	 */
	public int update(CnBp0001MtDto cnBp0001MtDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0001Mt.update",
				cnBp0001MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnBp0001MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_BP0001_MT (CN_BP0001_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnBp0001MtDto cnBp0001MtDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0001Mt.delete",
				cnBp0001MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnBp0001MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_BP0001_MT (CN_BP0001_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnBp0001MtDto> list(CnBp0001MtDto cnBp0001MtDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0001Mt.list",
				cnBp0001MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnBp0001MtDto), new BeanPropertyRowMapper<CnBp0001MtDto>(
				CnBp0001MtDto.class));
	}

	/**
	 * CN_BP0001_MT (CN_BP0001_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnBp0001MtDto> cnBp0001MtDtos) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0001Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnBp0001MtDtos
				.size()];
		for (int i = 0; i < cnBp0001MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnBp0001MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_BP0001_MT (CN_BP0001_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnBp0001MtDto> cnBp0001MtDtos) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0001Mt.update",
				cnBp0001MtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnBp0001MtDtos
				.size()];
		for (int i = 0; i < cnBp0001MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnBp0001MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_BP0001_MT (CN_BP0001_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnBp0001MtDto> cnBp0001MtDtos) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0001Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnBp0001MtDtos
				.size()];
		for (int i = 0; i < cnBp0001MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnBp0001MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
