package cuin.dbio.cn.bp.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * CN_BP0004_HT (CN_BP0004_HT) 테이블 이력 단건 조회 DTO.
 */
public class CnBp0004HtPrevInDto implements Serializable {

	private static final long serialVersionUID = -8726255430626685565L;

	/**
	 * 이력 조회를 위한 기준 일시
	 */
	private Timestamp baseDtm;

	/**
	 * 진행업무일련번호
	 */
	private Long prgsBsnsSeq;

	/**
	 * 진행작업번호
	 */
	private String prgsWkNo;

	/**
	 * 기준 일시 반환
	 */
	public Timestamp getBaseDtm() {
		return baseDtm;
	}

	/**
	 * 기준 일시 설정
	 */
	public void setBaseDtm(Timestamp baseDtm) {
		this.baseDtm = baseDtm;
	}

	/**
	 * '진행업무일련번호' 반환
	 */
	public Long getPrgsBsnsSeq() {
		return prgsBsnsSeq;
	}

	/**
	 * '진행업무일련번호' 설정
	 */
	public void setPrgsBsnsSeq(Long prgsBsnsSeq) {
		this.prgsBsnsSeq = prgsBsnsSeq;
	}

	/**
	 * '진행작업번호' 반환
	 */
	public String getPrgsWkNo() {
		return prgsWkNo;
	}

	/**
	 * '진행작업번호' 설정
	 */
	public void setPrgsWkNo(String prgsWkNo) {
		this.prgsWkNo = prgsWkNo;
	}

}