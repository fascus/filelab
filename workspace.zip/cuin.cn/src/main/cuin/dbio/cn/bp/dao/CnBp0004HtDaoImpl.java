/**
 * 
 * 
 */
package cuin.dbio.cn.bp.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.bp.dto.CnBp0004HtDto;
import cuin.dbio.cn.bp.dto.CnBp0004HtPrevInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnBp0004HtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_BP0004_HT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.bp.hqml.CnBp0004Ht")
public class CnBp0004HtDaoImpl extends DbioDaoSupport implements CnBp0004HtDao {

	/**
	 * CN_BP0004_HT (CN_BP0004_HT) 단건 등록.
	 * 
	 */
	public int insert(CnBp0004HtDto cnBp0004HtDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0004Ht.insert",
				cnBp0004HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnBp0004HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_BP0004_HT (CN_BP0004_HT) 현행 이력 업데이트.
	 * 
	 */
	public int closeCurrentHistory(CnBp0004HtDto cnBp0004HtDto) {
		String sql = getSql(
				"cuin.dbio.cn.bp.hqml.CnBp0004Ht.closeCurrentHistory",
				cnBp0004HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnBp0004HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_BP0004_HT (CN_BP0004_HT) 이력 삭제.
	 * 
	 */
	public int deleteHistory(CnBp0004HtDto cnBp0004HtDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0004Ht.deleteHistory",
				cnBp0004HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnBp0004HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_BP0004_HT (CN_BP0004_HT) 특정 시점의 단건 이력 조회.
	 * 
	 */
	public CnBp0004HtDto selectPrevious(CnBp0004HtPrevInDto cnBp0004HtPrevInDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0004Ht.selectPrevious",
				cnBp0004HtPrevInDto);

		CnBp0004HtDto foundCnBp0004HtDto = null;
		try {
			foundCnBp0004HtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnBp0004HtPrevInDto),
					new BeanPropertyRowMapper<CnBp0004HtDto>(
							CnBp0004HtDto.class));
			return foundCnBp0004HtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * 특정 기간 동안의 이벤트(변경 내역) 조회
	 * 
	 */
	public List<CnBp0004HtDto> selectInPeriod(PeriodInDto periodInDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0004Ht.selectInPeriod",
				periodInDto);

		return queryForList(sql,
				new BeanPropertySqlParameterSource(periodInDto),
				new BeanPropertyRowMapper<CnBp0004HtDto>(CnBp0004HtDto.class));
	}

}
