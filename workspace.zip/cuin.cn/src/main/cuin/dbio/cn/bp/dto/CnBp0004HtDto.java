/**
 * 
 * 
 */
package cuin.dbio.cn.bp.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnBp0004HtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_BP0004_HT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnBp0004HtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = 5700195104492963648L;

	/**
	 * 진행업무일련번호
	 */
	private Long prgsBsnsSeq;

	/**
	 * 진행작업번호
	 */
	private String prgsWkNo;

	/**
	 * 적용종료일시
	 */
	private Timestamp aplEotDtm;

	/**
	 * 적용시작일시
	 */
	private Timestamp aplBgDtm;

	/**
	 * 작업순서
	 */
	private Integer wkSqc;

	/**
	 * 작업명
	 */
	private String wkNm;

	/**
	 * 작업담당부서코드
	 */
	private String wkInchDpmCd;

	/**
	 * 작업담당자사원번호
	 */
	private String wkAdmiEmpNo;

	/**
	 * 작업계획시작일시
	 */
	private Timestamp wkPlBgDtm;

	/**
	 * 작업계획소요시분
	 */
	private String wkPlNedTmm;

	/**
	 * 작업진행상태코드
	 */
	private String wkPrgsSttCd;

	/**
	 * 관련프로그램ID
	 */
	private String rlnPrgId;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '진행업무일련번호' 반환
	 */
	public Long getPrgsBsnsSeq() {
		return prgsBsnsSeq;
	}

	/**
	 * '진행업무일련번호' 설정
	 */
	public void setPrgsBsnsSeq(Long prgsBsnsSeq) {
		this.prgsBsnsSeq = prgsBsnsSeq;
	}

	/**
	 * '진행작업번호' 반환
	 */
	public String getPrgsWkNo() {
		return prgsWkNo;
	}

	/**
	 * '진행작업번호' 설정
	 */
	public void setPrgsWkNo(String prgsWkNo) {
		this.prgsWkNo = prgsWkNo;
	}

	/**
	 * '적용종료일시' 반환
	 */
	public Timestamp getAplEotDtm() {
		return aplEotDtm;
	}

	/**
	 * '적용종료일시' 설정
	 */
	public void setAplEotDtm(Timestamp aplEotDtm) {
		this.aplEotDtm = aplEotDtm;
	}

	/**
	 * '적용시작일시' 반환
	 */
	public Timestamp getAplBgDtm() {
		return aplBgDtm;
	}

	/**
	 * '적용시작일시' 설정
	 */
	public void setAplBgDtm(Timestamp aplBgDtm) {
		this.aplBgDtm = aplBgDtm;
	}

	/**
	 * '작업순서' 반환
	 */
	public Integer getWkSqc() {
		return wkSqc;
	}

	/**
	 * '작업순서' 설정
	 */
	public void setWkSqc(Integer wkSqc) {
		this.wkSqc = wkSqc;
	}

	/**
	 * '작업명' 반환
	 */
	public String getWkNm() {
		return wkNm;
	}

	/**
	 * '작업명' 설정
	 */
	public void setWkNm(String wkNm) {
		this.wkNm = wkNm;
	}

	/**
	 * '작업담당부서코드' 반환
	 */
	public String getWkInchDpmCd() {
		return wkInchDpmCd;
	}

	/**
	 * '작업담당부서코드' 설정
	 */
	public void setWkInchDpmCd(String wkInchDpmCd) {
		this.wkInchDpmCd = wkInchDpmCd;
	}

	/**
	 * '작업담당자사원번호' 반환
	 */
	public String getWkAdmiEmpNo() {
		return wkAdmiEmpNo;
	}

	/**
	 * '작업담당자사원번호' 설정
	 */
	public void setWkAdmiEmpNo(String wkAdmiEmpNo) {
		this.wkAdmiEmpNo = wkAdmiEmpNo;
	}

	/**
	 * '작업계획시작일시' 반환
	 */
	public Timestamp getWkPlBgDtm() {
		return wkPlBgDtm;
	}

	/**
	 * '작업계획시작일시' 설정
	 */
	public void setWkPlBgDtm(Timestamp wkPlBgDtm) {
		this.wkPlBgDtm = wkPlBgDtm;
	}

	/**
	 * '작업계획소요시분' 반환
	 */
	public String getWkPlNedTmm() {
		return wkPlNedTmm;
	}

	/**
	 * '작업계획소요시분' 설정
	 */
	public void setWkPlNedTmm(String wkPlNedTmm) {
		this.wkPlNedTmm = wkPlNedTmm;
	}

	/**
	 * '작업진행상태코드' 반환
	 */
	public String getWkPrgsSttCd() {
		return wkPrgsSttCd;
	}

	/**
	 * '작업진행상태코드' 설정
	 */
	public void setWkPrgsSttCd(String wkPrgsSttCd) {
		this.wkPrgsSttCd = wkPrgsSttCd;
	}

	/**
	 * '관련프로그램ID' 반환
	 */
	public String getRlnPrgId() {
		return rlnPrgId;
	}

	/**
	 * '관련프로그램ID' 설정
	 */
	public void setRlnPrgId(String rlnPrgId) {
		this.rlnPrgId = rlnPrgId;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnBp0004HtDto [");
		sb.append("\n    prgsBsnsSeq = '").append(prgsBsnsSeq).append("'");
		sb.append("\n    prgsWkNo = '").append(prgsWkNo).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n    wkSqc = '").append(wkSqc).append("'");
		sb.append("\n    wkNm = '").append(wkNm).append("'");
		sb.append("\n    wkInchDpmCd = '").append(wkInchDpmCd).append("'");
		sb.append("\n    wkAdmiEmpNo = '").append(wkAdmiEmpNo).append("'");
		sb.append("\n    wkPlBgDtm = '").append(wkPlBgDtm).append("'");
		sb.append("\n    wkPlNedTmm = '").append(wkPlNedTmm).append("'");
		sb.append("\n    wkPrgsSttCd = '").append(wkPrgsSttCd).append("'");
		sb.append("\n    rlnPrgId = '").append(rlnPrgId).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnBp0004HtDto : PK [");
		sb.append("\n    prgsBsnsSeq = '").append(prgsBsnsSeq).append("'");
		sb.append("\n    prgsWkNo = '").append(prgsWkNo).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
