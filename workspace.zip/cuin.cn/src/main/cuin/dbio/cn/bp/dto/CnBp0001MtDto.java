/**
 * 
 * 
 */
package cuin.dbio.cn.bp.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnBp0001MtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_BP0001_MT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnBp0001MtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = 2457240589197921768L;

	/**
	 * 진행업무일련번호
	 */
	private Long prgsBsnsSeq;

	/**
	 * 적용종료일시
	 */
	private Timestamp aplEotDtm;

	/**
	 * 적용시작일시
	 */
	private Timestamp aplBgDtm;

	/**
	 * 업무구분코드
	 */
	private String bsnsDvCd;

	/**
	 * 진행업무명
	 */
	private String prgsBsnsNm;

	/**
	 * 업무담당부서코드
	 */
	private String bsnsInchDpmCd;

	/**
	 * 업무담당자사원번호
	 */
	private String bsnsAdmiEmpNo;

	/**
	 * 작업지정일내용
	 */
	private String wkAsgDayCtt;

	/**
	 * 업무계획시작일시
	 */
	private Timestamp bsnsPlBgDtm;

	/**
	 * 업무계획종료일시
	 */
	private Timestamp bsnsPlEotDtm;

	/**
	 * 업무진행상태코드
	 */
	private String bsnsPrgsSttCd;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '진행업무일련번호' 반환
	 */
	public Long getPrgsBsnsSeq() {
		return prgsBsnsSeq;
	}

	/**
	 * '진행업무일련번호' 설정
	 */
	public void setPrgsBsnsSeq(Long prgsBsnsSeq) {
		this.prgsBsnsSeq = prgsBsnsSeq;
	}

	/**
	 * '적용종료일시' 반환
	 */
	public Timestamp getAplEotDtm() {
		return aplEotDtm;
	}

	/**
	 * '적용종료일시' 설정
	 */
	public void setAplEotDtm(Timestamp aplEotDtm) {
		this.aplEotDtm = aplEotDtm;
	}

	/**
	 * '적용시작일시' 반환
	 */
	public Timestamp getAplBgDtm() {
		return aplBgDtm;
	}

	/**
	 * '적용시작일시' 설정
	 */
	public void setAplBgDtm(Timestamp aplBgDtm) {
		this.aplBgDtm = aplBgDtm;
	}

	/**
	 * '업무구분코드' 반환
	 */
	public String getBsnsDvCd() {
		return bsnsDvCd;
	}

	/**
	 * '업무구분코드' 설정
	 */
	public void setBsnsDvCd(String bsnsDvCd) {
		this.bsnsDvCd = bsnsDvCd;
	}

	/**
	 * '진행업무명' 반환
	 */
	public String getPrgsBsnsNm() {
		return prgsBsnsNm;
	}

	/**
	 * '진행업무명' 설정
	 */
	public void setPrgsBsnsNm(String prgsBsnsNm) {
		this.prgsBsnsNm = prgsBsnsNm;
	}

	/**
	 * '업무담당부서코드' 반환
	 */
	public String getBsnsInchDpmCd() {
		return bsnsInchDpmCd;
	}

	/**
	 * '업무담당부서코드' 설정
	 */
	public void setBsnsInchDpmCd(String bsnsInchDpmCd) {
		this.bsnsInchDpmCd = bsnsInchDpmCd;
	}

	/**
	 * '업무담당자사원번호' 반환
	 */
	public String getBsnsAdmiEmpNo() {
		return bsnsAdmiEmpNo;
	}

	/**
	 * '업무담당자사원번호' 설정
	 */
	public void setBsnsAdmiEmpNo(String bsnsAdmiEmpNo) {
		this.bsnsAdmiEmpNo = bsnsAdmiEmpNo;
	}

	/**
	 * '작업지정일내용' 반환
	 */
	public String getWkAsgDayCtt() {
		return wkAsgDayCtt;
	}

	/**
	 * '작업지정일내용' 설정
	 */
	public void setWkAsgDayCtt(String wkAsgDayCtt) {
		this.wkAsgDayCtt = wkAsgDayCtt;
	}

	/**
	 * '업무계획시작일시' 반환
	 */
	public Timestamp getBsnsPlBgDtm() {
		return bsnsPlBgDtm;
	}

	/**
	 * '업무계획시작일시' 설정
	 */
	public void setBsnsPlBgDtm(Timestamp bsnsPlBgDtm) {
		this.bsnsPlBgDtm = bsnsPlBgDtm;
	}

	/**
	 * '업무계획종료일시' 반환
	 */
	public Timestamp getBsnsPlEotDtm() {
		return bsnsPlEotDtm;
	}

	/**
	 * '업무계획종료일시' 설정
	 */
	public void setBsnsPlEotDtm(Timestamp bsnsPlEotDtm) {
		this.bsnsPlEotDtm = bsnsPlEotDtm;
	}

	/**
	 * '업무진행상태코드' 반환
	 */
	public String getBsnsPrgsSttCd() {
		return bsnsPrgsSttCd;
	}

	/**
	 * '업무진행상태코드' 설정
	 */
	public void setBsnsPrgsSttCd(String bsnsPrgsSttCd) {
		this.bsnsPrgsSttCd = bsnsPrgsSttCd;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnBp0001MtDto [");
		sb.append("\n    prgsBsnsSeq = '").append(prgsBsnsSeq).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n    bsnsDvCd = '").append(bsnsDvCd).append("'");
		sb.append("\n    prgsBsnsNm = '").append(prgsBsnsNm).append("'");
		sb.append("\n    bsnsInchDpmCd = '").append(bsnsInchDpmCd).append("'");
		sb.append("\n    bsnsAdmiEmpNo = '").append(bsnsAdmiEmpNo).append("'");
		sb.append("\n    wkAsgDayCtt = '").append(wkAsgDayCtt).append("'");
		sb.append("\n    bsnsPlBgDtm = '").append(bsnsPlBgDtm).append("'");
		sb.append("\n    bsnsPlEotDtm = '").append(bsnsPlEotDtm).append("'");
		sb.append("\n    bsnsPrgsSttCd = '").append(bsnsPrgsSttCd).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnBp0001MtDto : PK [");
		sb.append("\n    prgsBsnsSeq = '").append(prgsBsnsSeq).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
