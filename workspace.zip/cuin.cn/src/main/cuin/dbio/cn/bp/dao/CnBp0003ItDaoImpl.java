/**
 * 
 * 
 */
package cuin.dbio.cn.bp.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.bp.dto.CnBp0003ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnBp0003ItDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_BP0003_IT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.bp.hqml.CnBp0003It")
public class CnBp0003ItDaoImpl extends DbioDaoSupport implements CnBp0003ItDao {

	/**
	 * CN_BP0003_IT (CN_BP0003_IT) 단건 조회.
	 * 
	 */
	public CnBp0003ItDto select(CnBp0003ItDto cnBp0003ItDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0003It.select",
				cnBp0003ItDto);

		CnBp0003ItDto foundCnBp0003ItDto = null;
		try {
			foundCnBp0003ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnBp0003ItDto),
					new BeanPropertyRowMapper<CnBp0003ItDto>(
							CnBp0003ItDto.class));
			return foundCnBp0003ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_BP0003_IT (CN_BP0003_IT) 단건 등록.
	 * 
	 */
	public int insert(CnBp0003ItDto cnBp0003ItDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0003It.insert",
				cnBp0003ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnBp0003ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_BP0003_IT (CN_BP0003_IT) 단건 변경.
	 * 
	 */
	public int update(CnBp0003ItDto cnBp0003ItDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0003It.update",
				cnBp0003ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnBp0003ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_BP0003_IT (CN_BP0003_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnBp0003ItDto cnBp0003ItDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0003It.delete",
				cnBp0003ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnBp0003ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_BP0003_IT (CN_BP0003_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnBp0003ItDto> list(CnBp0003ItDto cnBp0003ItDto) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0003It.list",
				cnBp0003ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnBp0003ItDto), new BeanPropertyRowMapper<CnBp0003ItDto>(
				CnBp0003ItDto.class));
	}

	/**
	 * CN_BP0003_IT (CN_BP0003_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnBp0003ItDto> cnBp0003ItDtos) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0003It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnBp0003ItDtos
				.size()];
		for (int i = 0; i < cnBp0003ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnBp0003ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_BP0003_IT (CN_BP0003_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnBp0003ItDto> cnBp0003ItDtos) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0003It.update",
				cnBp0003ItDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnBp0003ItDtos
				.size()];
		for (int i = 0; i < cnBp0003ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnBp0003ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_BP0003_IT (CN_BP0003_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnBp0003ItDto> cnBp0003ItDtos) {
		String sql = getSql("cuin.dbio.cn.bp.hqml.CnBp0003It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnBp0003ItDtos
				.size()];
		for (int i = 0; i < cnBp0003ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnBp0003ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
