/**
 * 
 * 
 */
package cuin.dbio.cn.bp.dao;

import java.util.List;

import cuin.dbio.cn.bp.dto.CnBp0003ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnBp0003ItDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_BP0003_IT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnBp0003ItDao {

	CnBp0003ItDto select(CnBp0003ItDto cnBp0003ItDto);

	int insert(CnBp0003ItDto cnBp0003ItDto);

	int update(CnBp0003ItDto cnBp0003ItDto);

	int delete(CnBp0003ItDto cnBp0003ItDto);

	List<CnBp0003ItDto> list(CnBp0003ItDto cnBp0003ItDto);

	int[] insertList(List<CnBp0003ItDto> cnBp0003ItDtos);

	int[] updateList(List<CnBp0003ItDto> cnBp0003ItDtos);

	int[] deleteList(List<CnBp0003ItDto> cnBp0003ItDtos);

}
