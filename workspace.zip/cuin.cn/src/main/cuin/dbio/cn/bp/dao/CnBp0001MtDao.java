/**
 * 
 * 
 */
package cuin.dbio.cn.bp.dao;

import java.util.List;

import cuin.dbio.cn.bp.dto.CnBp0001MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnBp0001MtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_BP0001_MT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnBp0001MtDao {

	CnBp0001MtDto select(CnBp0001MtDto cnBp0001MtDto);

	int insert(CnBp0001MtDto cnBp0001MtDto);

	int update(CnBp0001MtDto cnBp0001MtDto);

	int delete(CnBp0001MtDto cnBp0001MtDto);

	List<CnBp0001MtDto> list(CnBp0001MtDto cnBp0001MtDto);

	int[] insertList(List<CnBp0001MtDto> cnBp0001MtDtos);

	int[] updateList(List<CnBp0001MtDto> cnBp0001MtDtos);

	int[] deleteList(List<CnBp0001MtDto> cnBp0001MtDtos);

}
