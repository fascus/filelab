package cuin.dbio.cn.bp.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * CN_BP0002_HT (CN_BP0002_HT) 테이블 이력 단건 조회 DTO.
 */
public class CnBp0002HtPrevInDto implements Serializable {

	private static final long serialVersionUID = 5095163069126363660L;

	/**
	 * 이력 조회를 위한 기준 일시
	 */
	private Timestamp baseDtm;

	/**
	 * 진행업무일련번호
	 */
	private Long prgsBsnsSeq;

	/**
	 * 기준 일시 반환
	 */
	public Timestamp getBaseDtm() {
		return baseDtm;
	}

	/**
	 * 기준 일시 설정
	 */
	public void setBaseDtm(Timestamp baseDtm) {
		this.baseDtm = baseDtm;
	}

	/**
	 * '진행업무일련번호' 반환
	 */
	public Long getPrgsBsnsSeq() {
		return prgsBsnsSeq;
	}

	/**
	 * '진행업무일련번호' 설정
	 */
	public void setPrgsBsnsSeq(Long prgsBsnsSeq) {
		this.prgsBsnsSeq = prgsBsnsSeq;
	}

}