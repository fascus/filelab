/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ab.dto.CnAb0003MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0003MtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0003_MT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ab.hqml.CnAb0003Mt")
public class CnAb0003MtDaoImpl extends DbioDaoSupport implements CnAb0003MtDao {

	/**
	 * CN_AB0003_MT (CN_AB0003_MT) 단건 조회.
	 * 
	 */
	public CnAb0003MtDto select(CnAb0003MtDto cnAb0003MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0003Mt.select",
				cnAb0003MtDto);

		CnAb0003MtDto foundCnAb0003MtDto = null;
		try {
			foundCnAb0003MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAb0003MtDto),
					new BeanPropertyRowMapper<CnAb0003MtDto>(
							CnAb0003MtDto.class));
			return foundCnAb0003MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_AB0003_MT (CN_AB0003_MT) 단건 등록.
	 * 
	 */
	public int insert(CnAb0003MtDto cnAb0003MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0003Mt.insert",
				cnAb0003MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0003MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0003_MT (CN_AB0003_MT) 단건 변경.
	 * 
	 */
	public int update(CnAb0003MtDto cnAb0003MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0003Mt.update",
				cnAb0003MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0003MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0003_MT (CN_AB0003_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnAb0003MtDto cnAb0003MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0003Mt.delete",
				cnAb0003MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0003MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0003_MT (CN_AB0003_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnAb0003MtDto> list(CnAb0003MtDto cnAb0003MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0003Mt.list",
				cnAb0003MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnAb0003MtDto), new BeanPropertyRowMapper<CnAb0003MtDto>(
				CnAb0003MtDto.class));
	}

	/**
	 * CN_AB0003_MT (CN_AB0003_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnAb0003MtDto> cnAb0003MtDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0003Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnAb0003MtDtos
				.size()];
		for (int i = 0; i < cnAb0003MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0003MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AB0003_MT (CN_AB0003_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnAb0003MtDto> cnAb0003MtDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0003Mt.update",
				cnAb0003MtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnAb0003MtDtos
				.size()];
		for (int i = 0; i < cnAb0003MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0003MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AB0003_MT (CN_AB0003_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnAb0003MtDto> cnAb0003MtDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0003Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnAb0003MtDtos
				.size()];
		for (int i = 0; i < cnAb0003MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0003MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
