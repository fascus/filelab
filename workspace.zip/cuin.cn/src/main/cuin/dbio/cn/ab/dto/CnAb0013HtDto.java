/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0013HtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0013_HT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnAb0013HtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = 4841278502236867964L;

	/**
	 * 서식관리번호
	 */
	private String formMgNo;

	/**
	 * 서식이미지일련번호
	 */
	private Long formImgSeq;

	/**
	 * 적용종료일시
	 */
	private Timestamp aplEotDtm;

	/**
	 * 적용시작일시
	 */
	private Timestamp aplBgDtm;

	/**
	 * 서식이미지명
	 */
	private String formImgNm;

	/**
	 * 서식이미지상세설명
	 */
	private String formImgDtilDscr;

	/**
	 * 페이지번호
	 */
	private Integer pgNo;

	/**
	 * 이미지서식구분코드
	 */
	private String imgFormDvCd;

	/**
	 * 서식이미지업무구분코드
	 */
	private String formImgBsnsDvCd;

	/**
	 * 서식이미지상세업무구분코드
	 */
	private String formImgDtilBsnsDvCd;

	/**
	 * 이미지대상식별번호구분코드
	 */
	private String imgSbjIdfNoDvCd;

	/**
	 * 이미지대상식별번호길이
	 */
	private Integer imgSbjIdfNoLng;

	/**
	 * 앞면뒷면구분코드
	 */
	private String hdsTilsDvCd;

	/**
	 * 이미지OMR정보존재여부
	 */
	private String imgOmrInfoExscYn;

	/**
	 * 전송대상여부
	 */
	private String snSbjYn;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '서식관리번호' 반환
	 */
	public String getFormMgNo() {
		return formMgNo;
	}

	/**
	 * '서식관리번호' 설정
	 */
	public void setFormMgNo(String formMgNo) {
		this.formMgNo = formMgNo;
	}

	/**
	 * '서식이미지일련번호' 반환
	 */
	public Long getFormImgSeq() {
		return formImgSeq;
	}

	/**
	 * '서식이미지일련번호' 설정
	 */
	public void setFormImgSeq(Long formImgSeq) {
		this.formImgSeq = formImgSeq;
	}

	/**
	 * '적용종료일시' 반환
	 */
	public Timestamp getAplEotDtm() {
		return aplEotDtm;
	}

	/**
	 * '적용종료일시' 설정
	 */
	public void setAplEotDtm(Timestamp aplEotDtm) {
		this.aplEotDtm = aplEotDtm;
	}

	/**
	 * '적용시작일시' 반환
	 */
	public Timestamp getAplBgDtm() {
		return aplBgDtm;
	}

	/**
	 * '적용시작일시' 설정
	 */
	public void setAplBgDtm(Timestamp aplBgDtm) {
		this.aplBgDtm = aplBgDtm;
	}

	/**
	 * '서식이미지명' 반환
	 */
	public String getFormImgNm() {
		return formImgNm;
	}

	/**
	 * '서식이미지명' 설정
	 */
	public void setFormImgNm(String formImgNm) {
		this.formImgNm = formImgNm;
	}

	/**
	 * '서식이미지상세설명' 반환
	 */
	public String getFormImgDtilDscr() {
		return formImgDtilDscr;
	}

	/**
	 * '서식이미지상세설명' 설정
	 */
	public void setFormImgDtilDscr(String formImgDtilDscr) {
		this.formImgDtilDscr = formImgDtilDscr;
	}

	/**
	 * '페이지번호' 반환
	 */
	public Integer getPgNo() {
		return pgNo;
	}

	/**
	 * '페이지번호' 설정
	 */
	public void setPgNo(Integer pgNo) {
		this.pgNo = pgNo;
	}

	/**
	 * '이미지서식구분코드' 반환
	 */
	public String getImgFormDvCd() {
		return imgFormDvCd;
	}

	/**
	 * '이미지서식구분코드' 설정
	 */
	public void setImgFormDvCd(String imgFormDvCd) {
		this.imgFormDvCd = imgFormDvCd;
	}

	/**
	 * '서식이미지업무구분코드' 반환
	 */
	public String getFormImgBsnsDvCd() {
		return formImgBsnsDvCd;
	}

	/**
	 * '서식이미지업무구분코드' 설정
	 */
	public void setFormImgBsnsDvCd(String formImgBsnsDvCd) {
		this.formImgBsnsDvCd = formImgBsnsDvCd;
	}

	/**
	 * '서식이미지상세업무구분코드' 반환
	 */
	public String getFormImgDtilBsnsDvCd() {
		return formImgDtilBsnsDvCd;
	}

	/**
	 * '서식이미지상세업무구분코드' 설정
	 */
	public void setFormImgDtilBsnsDvCd(String formImgDtilBsnsDvCd) {
		this.formImgDtilBsnsDvCd = formImgDtilBsnsDvCd;
	}

	/**
	 * '이미지대상식별번호구분코드' 반환
	 */
	public String getImgSbjIdfNoDvCd() {
		return imgSbjIdfNoDvCd;
	}

	/**
	 * '이미지대상식별번호구분코드' 설정
	 */
	public void setImgSbjIdfNoDvCd(String imgSbjIdfNoDvCd) {
		this.imgSbjIdfNoDvCd = imgSbjIdfNoDvCd;
	}

	/**
	 * '이미지대상식별번호길이' 반환
	 */
	public Integer getImgSbjIdfNoLng() {
		return imgSbjIdfNoLng;
	}

	/**
	 * '이미지대상식별번호길이' 설정
	 */
	public void setImgSbjIdfNoLng(Integer imgSbjIdfNoLng) {
		this.imgSbjIdfNoLng = imgSbjIdfNoLng;
	}

	/**
	 * '앞면뒷면구분코드' 반환
	 */
	public String getHdsTilsDvCd() {
		return hdsTilsDvCd;
	}

	/**
	 * '앞면뒷면구분코드' 설정
	 */
	public void setHdsTilsDvCd(String hdsTilsDvCd) {
		this.hdsTilsDvCd = hdsTilsDvCd;
	}

	/**
	 * '이미지OMR정보존재여부' 반환
	 */
	public String getImgOmrInfoExscYn() {
		return imgOmrInfoExscYn;
	}

	/**
	 * '이미지OMR정보존재여부' 설정
	 */
	public void setImgOmrInfoExscYn(String imgOmrInfoExscYn) {
		this.imgOmrInfoExscYn = imgOmrInfoExscYn;
	}

	/**
	 * '전송대상여부' 반환
	 */
	public String getSnSbjYn() {
		return snSbjYn;
	}

	/**
	 * '전송대상여부' 설정
	 */
	public void setSnSbjYn(String snSbjYn) {
		this.snSbjYn = snSbjYn;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0013HtDto [");
		sb.append("\n    formMgNo = '").append(formMgNo).append("'");
		sb.append("\n    formImgSeq = '").append(formImgSeq).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n    formImgNm = '").append(formImgNm).append("'");
		sb.append("\n    formImgDtilDscr = '").append(formImgDtilDscr)
				.append("'");
		sb.append("\n    pgNo = '").append(pgNo).append("'");
		sb.append("\n    imgFormDvCd = '").append(imgFormDvCd).append("'");
		sb.append("\n    formImgBsnsDvCd = '").append(formImgBsnsDvCd)
				.append("'");
		sb.append("\n    formImgDtilBsnsDvCd = '").append(formImgDtilBsnsDvCd)
				.append("'");
		sb.append("\n    imgSbjIdfNoDvCd = '").append(imgSbjIdfNoDvCd)
				.append("'");
		sb.append("\n    imgSbjIdfNoLng = '").append(imgSbjIdfNoLng)
				.append("'");
		sb.append("\n    hdsTilsDvCd = '").append(hdsTilsDvCd).append("'");
		sb.append("\n    imgOmrInfoExscYn = '").append(imgOmrInfoExscYn)
				.append("'");
		sb.append("\n    snSbjYn = '").append(snSbjYn).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0013HtDto : PK [");
		sb.append("\n    formMgNo = '").append(formMgNo).append("'");
		sb.append("\n    formImgSeq = '").append(formImgSeq).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
