package cuin.dbio.cn.ab.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * CN_AB0010_HT (CN_AB0010_HT) 테이블 이력 단건 조회 DTO.
 */
public class CnAb0010HtPrevInDto implements Serializable {

	private static final long serialVersionUID = -3205408430307196147L;

	/**
	 * 이력 조회를 위한 기준 일시
	 */
	private Timestamp baseDtm;

	/**
	 * 상세업무코드
	 */
	private String dtilBsnsCd;

	/**
	 * 업무메시지번호
	 */
	private String bsnsMsgNo;

	/**
	 * 변경일련번호
	 */
	private Long chnSeq;

	/**
	 * 기준 일시 반환
	 */
	public Timestamp getBaseDtm() {
		return baseDtm;
	}

	/**
	 * 기준 일시 설정
	 */
	public void setBaseDtm(Timestamp baseDtm) {
		this.baseDtm = baseDtm;
	}

	/**
	 * '상세업무코드' 반환
	 */
	public String getDtilBsnsCd() {
		return dtilBsnsCd;
	}

	/**
	 * '상세업무코드' 설정
	 */
	public void setDtilBsnsCd(String dtilBsnsCd) {
		this.dtilBsnsCd = dtilBsnsCd;
	}

	/**
	 * '업무메시지번호' 반환
	 */
	public String getBsnsMsgNo() {
		return bsnsMsgNo;
	}

	/**
	 * '업무메시지번호' 설정
	 */
	public void setBsnsMsgNo(String bsnsMsgNo) {
		this.bsnsMsgNo = bsnsMsgNo;
	}

	/**
	 * '변경일련번호' 반환
	 */
	public Long getChnSeq() {
		return chnSeq;
	}

	/**
	 * '변경일련번호' 설정
	 */
	public void setChnSeq(Long chnSeq) {
		this.chnSeq = chnSeq;
	}

}