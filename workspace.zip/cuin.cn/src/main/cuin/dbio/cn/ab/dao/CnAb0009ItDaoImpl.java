/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ab.dto.CnAb0009ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0009ItDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0009_IT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ab.hqml.CnAb0009It")
public class CnAb0009ItDaoImpl extends DbioDaoSupport implements CnAb0009ItDao {

	/**
	 * CN_AB0009_IT (CN_AB0009_IT) 단건 조회.
	 * 
	 */
	public CnAb0009ItDto select(CnAb0009ItDto cnAb0009ItDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0009It.select",
				cnAb0009ItDto);

		CnAb0009ItDto foundCnAb0009ItDto = null;
		try {
			foundCnAb0009ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAb0009ItDto),
					new BeanPropertyRowMapper<CnAb0009ItDto>(
							CnAb0009ItDto.class));
			return foundCnAb0009ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_AB0009_IT (CN_AB0009_IT) 단건 등록.
	 * 
	 */
	public int insert(CnAb0009ItDto cnAb0009ItDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0009It.insert",
				cnAb0009ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0009ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0009_IT (CN_AB0009_IT) 단건 변경.
	 * 
	 */
	public int update(CnAb0009ItDto cnAb0009ItDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0009It.update",
				cnAb0009ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0009ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0009_IT (CN_AB0009_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnAb0009ItDto cnAb0009ItDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0009It.delete",
				cnAb0009ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0009ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0009_IT (CN_AB0009_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnAb0009ItDto> list(CnAb0009ItDto cnAb0009ItDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0009It.list",
				cnAb0009ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnAb0009ItDto), new BeanPropertyRowMapper<CnAb0009ItDto>(
				CnAb0009ItDto.class));
	}

	/**
	 * CN_AB0009_IT (CN_AB0009_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnAb0009ItDto> cnAb0009ItDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0009It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnAb0009ItDtos
				.size()];
		for (int i = 0; i < cnAb0009ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0009ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AB0009_IT (CN_AB0009_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnAb0009ItDto> cnAb0009ItDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0009It.update",
				cnAb0009ItDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnAb0009ItDtos
				.size()];
		for (int i = 0; i < cnAb0009ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0009ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AB0009_IT (CN_AB0009_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnAb0009ItDto> cnAb0009ItDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0009It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnAb0009ItDtos
				.size()];
		for (int i = 0; i < cnAb0009ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0009ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
