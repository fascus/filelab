package cuin.dbio.cn.ab.dao;

import java.sql.Timestamp;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cuin.cn.dbio.core.sys.DbioUpdateCallback;
import cuin.cn.dbio.core.sys.DbioUtils;
import cuin.cn.dbio.core.sys.ServiceInDto;
import cuin.cn.exception.CuinRecordExistsException;
import cuin.cn.exception.CuinRecordNotExistsException;
import cuin.cn.service.ServiceContext;
import cuin.cn.service.ServiceContext.ContextSysAttr;
import cuin.cn.util.BeanUtils;
import cuin.dbio.cn.ab.dto.CnAb0006MtDto;
import cuin.dbio.cn.ab.dto.CnAb0007HtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0006MtCtrlImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.12
 * 설    명 : CN_AB0006_MT DBIO 컨트롤러 구현체.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
@Component
public class CnAb0006MtCtrlImpl implements CnAb0006MtCtrl {

	private final static Logger logger = LoggerFactory
			.getLogger(CnAb0006MtCtrlImpl.class);

	// CN_AB0006_MT (CN_AB0006_MT) DAO
	@Autowired
	private CnAb0006MtDao cnAb0006MtDao;

	private DbioUpdateCallback dbioUpdateCallback;

	// CN_AB0006_MT 이력 DAO
	@Autowired
	CnAb0007HtDao cnAb0007HtDao;

	/**
	 * 단건 조회 (select single record).
	 *
	 * @param serviceInDto 서비스 입력 DTO (PK 컬럼들을 포함하고 있어야 함).
	 * @return 테이블 DTO (CnAb0006MtDao), 존재하지 않을 경우 null 반환.
	 */
	@Override
	public CnAb0006MtDto select(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnAb0006MtDto cnAb0006MtDto = BeanUtils.toBean(serviceInDto,
				CnAb0006MtDto.class);
		CnAb0006MtDto foundCnAb0006MtDto = cnAb0006MtDao.select(cnAb0006MtDto);
		if (foundCnAb0006MtDto != null
				&& "Y".equals(foundCnAb0006MtDto.getUseYn())) {
			return foundCnAb0006MtDto;
		} else {
			return null;
		}
	}

	/**
	 * 단건 등록 (insert single record).
	 * 이력 테이블이 존재하고, 이력 저장 방식이 '현행'이면 이력 테이블에도 레코드를 추가함.
	 *
	 * @param serviceInDto 서비스 입력 DTO (테이블 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 등록되면 1 반환
	 * @throws CuinRecordExistsException 이미 존재하는 레코드 등록을 시도한 경우 예외 발생
	 */
	@Override
	public int insert(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnAb0006MtDto cnAb0006MtDto = BeanUtils.toBean(serviceInDto,
				CnAb0006MtDto.class);

		CnAb0006MtDto existingDto = cnAb0006MtDao.select(cnAb0006MtDto);
		if (existingDto != null) {
			if ("N".equals(existingDto.getUseYn())) {
				DbioUtils.setSysProperties(cnAb0006MtDto);

				// 이력 테이블에 레코드 등록
				CnAb0007HtDto cnAb0007HtDto = BeanUtils.toBean(cnAb0006MtDto,
						CnAb0007HtDto.class);
				DbioUtils.setDefaultApplyTerm(cnAb0007HtDto);
				cnAb0007HtDao.insert(cnAb0007HtDto);
				return cnAb0006MtDao.update(cnAb0006MtDto);
			} else {
				String errMsg = "A record with the same identity already exists in database. "
						+ cnAb0006MtDto.getPKValues();
				logger.error(errMsg);
				throw new CuinRecordExistsException(errMsg);
			}
		}

		// 마스터 테이블에 신규 레코드 등록
		DbioUtils.setDefaultApplyTerm(cnAb0006MtDto);
		DbioUtils.setSysProperties(cnAb0006MtDto);
		return cnAb0006MtDao.insert(cnAb0006MtDto);
	}

	/**
	 * 단건 변경 (update single record).
	 * 이력 테이블이 존재하면 이력 테이블에도 레코드를 추가함.
	 *
	 * @param serviceInDto 서비스 입력 DTO (테이블 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 변경되면 1 반환
	 * @throws CuinRecordNotExistsException 변경 대상 레코드가 존재하지 않을 경우 예외 발생.
	 */
	@Override
	public int update(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnAb0006MtDto newCnAb0006MtDto = BeanUtils.toBean(serviceInDto,
				CnAb0006MtDto.class);

		// 마스터 테이블에서 과거 데이터 추출
		CnAb0006MtDto oldCnAb0006MtDto = checkExists(newCnAb0006MtDto);
		// 이력 테이블에 과거 레코드 추가
		CnAb0007HtDto cnAb0007HtDto = DbioUtils.createHistoryDto(
				oldCnAb0006MtDto, CnAb0007HtDto.class);
		cnAb0007HtDao.insert(cnAb0007HtDto);

		// 마스터 레코드 적용 시작일시를 현재 시간으로 변경
		BeanUtils.setProperty(newCnAb0006MtDto,
				DbioUtils.APPLY_BEGIN_DATETIME_FIELD,
				ServiceContext.getSysAttr(ContextSysAttr.TX_TIMESTAMP));
		// 마스터 레코드 업데이트
		DbioUtils.setSysProperties(newCnAb0006MtDto, oldCnAb0006MtDto);
		return cnAb0006MtDao.update(newCnAb0006MtDto);
	}

	/**
	 * 단건 삭제 (delete single record).
	 * 이력 테이블이 존재하면 이력 테이블 레코드 또한 삭제 처리.
	 *
	 * @param serviceInDto 서비스 입력 DTO (PK 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 변경되면 1 반환
	 * @throws CuinRecordNotExistsException 삭제 대상 레코드가 존재하지 않을 경우 예외 발생.
	 */
	@Override
	public int delete(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnAb0006MtDto cnAb0006MtDto = BeanUtils.toBean(serviceInDto,
				CnAb0006MtDto.class);

		// 삭제 대상 레코드 존재 여부 확인
		CnAb0006MtDto oldCnAb0006MtDto = checkExists(cnAb0006MtDto);

		// 이력 테이블에 과거 데이터 추가
		CnAb0007HtDto cnAb0007HtDto = DbioUtils.createHistoryDto(
				oldCnAb0006MtDto, CnAb0007HtDto.class);
		cnAb0007HtDao.insert(cnAb0007HtDto);
		// 마스터 테이블 삭제
		DbioUtils.setSysProperties(cnAb0006MtDto, oldCnAb0006MtDto);
		Timestamp now = (Timestamp) ServiceContext
				.getSysAttr(ContextSysAttr.TX_TIMESTAMP);
		BeanUtils.setProperty(cnAb0006MtDto,
				DbioUtils.APPLY_END_DATETIME_FIELD, now);

		int deleteCnt = cnAb0006MtDao.delete(cnAb0006MtDto);

		return deleteCnt;
	}

	/**
	 * 변경 혹은 삭제 대상 레코드 존재 여부 검사.
	 *
	 * @param cnAb0006MtDto 변경 대상 레코드의 primary key 값을 포함한 DTO
	 * @return 변경 혹은 삭제 대상 레코드
	 */
	private CnAb0006MtDto checkExists(CnAb0006MtDto cnAb0006MtDto) {
		CnAb0006MtDto storedDto = cnAb0006MtDao.select(cnAb0006MtDto);
		if (storedDto == null) {
			String errMsg = "Requested record not found. \n"
					+ cnAb0006MtDto.getPKValues();
			logger.error(errMsg);
			throw new CuinRecordNotExistsException(errMsg);
		}

		return storedDto;
	}

	/**
	 * CN_AB0006_MT 일괄 등록
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] insertList(List serviceInDtoList) {
		int[] results = new int[serviceInDtoList.size()];
		int idx = 0;
		for (Object dto : serviceInDtoList) {
			if (dbioUpdateCallback != null) {
				dbioUpdateCallback.updateDto(dto);
			}
			results[idx++] = insert((ServiceInDto) dto);
		}
		return results;
	}

	/**
	 * CN_AB0006_MT 일괄 변경
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] updateList(List serviceInDtoList) {
		int[] results = new int[serviceInDtoList.size()];
		int idx = 0;
		for (Object dto : serviceInDtoList) {
			if (dbioUpdateCallback != null) {
				dbioUpdateCallback.updateDto(dto);
			}
			results[idx++] = update((ServiceInDto) dto);
		}
		return results;
	}

	/**
	 * CN_AB0006_MT 일괄 삭제
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] deleteList(List serviceInDtoList) {

		int listSize = serviceInDtoList.size();
		int[] deleteResults = new int[listSize];
		for (int idx = 0; idx < listSize; idx++) {
			CnAb0006MtDto tableDto = BeanUtils.toBean(
					serviceInDtoList.get(idx), CnAb0006MtDto.class);

			DbioUtils.setSysProperties(tableDto);
			Timestamp now = (Timestamp) ServiceContext
					.getSysAttr(ContextSysAttr.TX_TIMESTAMP);
			BeanUtils.setProperty(tableDto, DbioUtils.APPLY_END_DATETIME_FIELD,
					now);

			// 이력 테이블에 과거 데이터 추가
			CnAb0007HtDto historyDto = DbioUtils.createHistoryDto(tableDto,
					CnAb0007HtDto.class);
			cnAb0007HtDao.insert(historyDto);
			deleteResults[idx] = cnAb0006MtDao.delete(tableDto);
		}
		return deleteResults;
	}

	public void setBatchCallback(DbioUpdateCallback dbioUpdateCallback) {
		this.dbioUpdateCallback = dbioUpdateCallback;
	}

}
