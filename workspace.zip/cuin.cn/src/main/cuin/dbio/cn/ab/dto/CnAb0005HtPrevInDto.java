package cuin.dbio.cn.ab.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * CN_AB0005_HT (CN_AB0005_HT) 테이블 이력 단건 조회 DTO.
 */
public class CnAb0005HtPrevInDto implements Serializable {

	private static final long serialVersionUID = -2182026528786789436L;

	/**
	 * 이력 조회를 위한 기준 일시
	 */
	private Timestamp baseDtm;

	/**
	 * 서식코드
	 */
	private String formCd;

	/**
	 * 기준 일시 반환
	 */
	public Timestamp getBaseDtm() {
		return baseDtm;
	}

	/**
	 * 기준 일시 설정
	 */
	public void setBaseDtm(Timestamp baseDtm) {
		this.baseDtm = baseDtm;
	}

	/**
	 * '서식코드' 반환
	 */
	public String getFormCd() {
		return formCd;
	}

	/**
	 * '서식코드' 설정
	 */
	public void setFormCd(String formCd) {
		this.formCd = formCd;
	}

}