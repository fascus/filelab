/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0005HtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0005_HT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnAb0005HtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -2644753867790204035L;

	/**
	 * 서식코드
	 */
	private String formCd;

	/**
	 * 적용종료일시
	 */
	private Timestamp aplEotDtm;

	/**
	 * 적용시작일시
	 */
	private Timestamp aplBgDtm;

	/**
	 * 유효종료일시
	 */
	private Timestamp vldEotDtm;

	/**
	 * 유효시작일시
	 */
	private Timestamp vldBgDtm;

	/**
	 * 업무구분코드
	 */
	private String bsnsDvCd;

	/**
	 * 서식상세업무코드
	 */
	private String formDtilBsnsCd;

	/**
	 * 서식공제분류코드
	 */
	private String formMtClfCd;

	/**
	 * 상품군분류코드
	 */
	private String godMlkCd;

	/**
	 * 서식명
	 */
	private String formNm;

	/**
	 * 서식상세설명
	 */
	private String formDtilDscr;

	/**
	 * 양식구분코드
	 */
	private String frmDvCd;

	/**
	 * 양면단면구분코드
	 */
	private String dbsdDbdDvCd;

	/**
	 * 조합보관용도페이지수
	 */
	private Integer crunSteUsgPgCnt;

	/**
	 * 신협중앙회보관용도페이지수
	 */
	private Integer nacufokSteUsgPgCnt;

	/**
	 * 고객보관용도페이지수
	 */
	private Integer custSteUsgPgCnt;

	/**
	 * 용지크기코드
	 */
	private String pprSzCd;

	/**
	 * 용지방향코드
	 */
	private String pprDrtCd;

	/**
	 * 서식관리부서코드
	 */
	private String formMgDpmCd;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '서식코드' 반환
	 */
	public String getFormCd() {
		return formCd;
	}

	/**
	 * '서식코드' 설정
	 */
	public void setFormCd(String formCd) {
		this.formCd = formCd;
	}

	/**
	 * '적용종료일시' 반환
	 */
	public Timestamp getAplEotDtm() {
		return aplEotDtm;
	}

	/**
	 * '적용종료일시' 설정
	 */
	public void setAplEotDtm(Timestamp aplEotDtm) {
		this.aplEotDtm = aplEotDtm;
	}

	/**
	 * '적용시작일시' 반환
	 */
	public Timestamp getAplBgDtm() {
		return aplBgDtm;
	}

	/**
	 * '적용시작일시' 설정
	 */
	public void setAplBgDtm(Timestamp aplBgDtm) {
		this.aplBgDtm = aplBgDtm;
	}

	/**
	 * '유효종료일시' 반환
	 */
	public Timestamp getVldEotDtm() {
		return vldEotDtm;
	}

	/**
	 * '유효종료일시' 설정
	 */
	public void setVldEotDtm(Timestamp vldEotDtm) {
		this.vldEotDtm = vldEotDtm;
	}

	/**
	 * '유효시작일시' 반환
	 */
	public Timestamp getVldBgDtm() {
		return vldBgDtm;
	}

	/**
	 * '유효시작일시' 설정
	 */
	public void setVldBgDtm(Timestamp vldBgDtm) {
		this.vldBgDtm = vldBgDtm;
	}

	/**
	 * '업무구분코드' 반환
	 */
	public String getBsnsDvCd() {
		return bsnsDvCd;
	}

	/**
	 * '업무구분코드' 설정
	 */
	public void setBsnsDvCd(String bsnsDvCd) {
		this.bsnsDvCd = bsnsDvCd;
	}

	/**
	 * '서식상세업무코드' 반환
	 */
	public String getFormDtilBsnsCd() {
		return formDtilBsnsCd;
	}

	/**
	 * '서식상세업무코드' 설정
	 */
	public void setFormDtilBsnsCd(String formDtilBsnsCd) {
		this.formDtilBsnsCd = formDtilBsnsCd;
	}

	/**
	 * '서식공제분류코드' 반환
	 */
	public String getFormMtClfCd() {
		return formMtClfCd;
	}

	/**
	 * '서식공제분류코드' 설정
	 */
	public void setFormMtClfCd(String formMtClfCd) {
		this.formMtClfCd = formMtClfCd;
	}

	/**
	 * '상품군분류코드' 반환
	 */
	public String getGodMlkCd() {
		return godMlkCd;
	}

	/**
	 * '상품군분류코드' 설정
	 */
	public void setGodMlkCd(String godMlkCd) {
		this.godMlkCd = godMlkCd;
	}

	/**
	 * '서식명' 반환
	 */
	public String getFormNm() {
		return formNm;
	}

	/**
	 * '서식명' 설정
	 */
	public void setFormNm(String formNm) {
		this.formNm = formNm;
	}

	/**
	 * '서식상세설명' 반환
	 */
	public String getFormDtilDscr() {
		return formDtilDscr;
	}

	/**
	 * '서식상세설명' 설정
	 */
	public void setFormDtilDscr(String formDtilDscr) {
		this.formDtilDscr = formDtilDscr;
	}

	/**
	 * '양식구분코드' 반환
	 */
	public String getFrmDvCd() {
		return frmDvCd;
	}

	/**
	 * '양식구분코드' 설정
	 */
	public void setFrmDvCd(String frmDvCd) {
		this.frmDvCd = frmDvCd;
	}

	/**
	 * '양면단면구분코드' 반환
	 */
	public String getDbsdDbdDvCd() {
		return dbsdDbdDvCd;
	}

	/**
	 * '양면단면구분코드' 설정
	 */
	public void setDbsdDbdDvCd(String dbsdDbdDvCd) {
		this.dbsdDbdDvCd = dbsdDbdDvCd;
	}

	/**
	 * '조합보관용도페이지수' 반환
	 */
	public Integer getCrunSteUsgPgCnt() {
		return crunSteUsgPgCnt;
	}

	/**
	 * '조합보관용도페이지수' 설정
	 */
	public void setCrunSteUsgPgCnt(Integer crunSteUsgPgCnt) {
		this.crunSteUsgPgCnt = crunSteUsgPgCnt;
	}

	/**
	 * '신협중앙회보관용도페이지수' 반환
	 */
	public Integer getNacufokSteUsgPgCnt() {
		return nacufokSteUsgPgCnt;
	}

	/**
	 * '신협중앙회보관용도페이지수' 설정
	 */
	public void setNacufokSteUsgPgCnt(Integer nacufokSteUsgPgCnt) {
		this.nacufokSteUsgPgCnt = nacufokSteUsgPgCnt;
	}

	/**
	 * '고객보관용도페이지수' 반환
	 */
	public Integer getCustSteUsgPgCnt() {
		return custSteUsgPgCnt;
	}

	/**
	 * '고객보관용도페이지수' 설정
	 */
	public void setCustSteUsgPgCnt(Integer custSteUsgPgCnt) {
		this.custSteUsgPgCnt = custSteUsgPgCnt;
	}

	/**
	 * '용지크기코드' 반환
	 */
	public String getPprSzCd() {
		return pprSzCd;
	}

	/**
	 * '용지크기코드' 설정
	 */
	public void setPprSzCd(String pprSzCd) {
		this.pprSzCd = pprSzCd;
	}

	/**
	 * '용지방향코드' 반환
	 */
	public String getPprDrtCd() {
		return pprDrtCd;
	}

	/**
	 * '용지방향코드' 설정
	 */
	public void setPprDrtCd(String pprDrtCd) {
		this.pprDrtCd = pprDrtCd;
	}

	/**
	 * '서식관리부서코드' 반환
	 */
	public String getFormMgDpmCd() {
		return formMgDpmCd;
	}

	/**
	 * '서식관리부서코드' 설정
	 */
	public void setFormMgDpmCd(String formMgDpmCd) {
		this.formMgDpmCd = formMgDpmCd;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0005HtDto [");
		sb.append("\n    formCd = '").append(formCd).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n    vldEotDtm = '").append(vldEotDtm).append("'");
		sb.append("\n    vldBgDtm = '").append(vldBgDtm).append("'");
		sb.append("\n    bsnsDvCd = '").append(bsnsDvCd).append("'");
		sb.append("\n    formDtilBsnsCd = '").append(formDtilBsnsCd)
				.append("'");
		sb.append("\n    formMtClfCd = '").append(formMtClfCd).append("'");
		sb.append("\n    godMlkCd = '").append(godMlkCd).append("'");
		sb.append("\n    formNm = '").append(formNm).append("'");
		sb.append("\n    formDtilDscr = '").append(formDtilDscr).append("'");
		sb.append("\n    frmDvCd = '").append(frmDvCd).append("'");
		sb.append("\n    dbsdDbdDvCd = '").append(dbsdDbdDvCd).append("'");
		sb.append("\n    crunSteUsgPgCnt = '").append(crunSteUsgPgCnt)
				.append("'");
		sb.append("\n    nacufokSteUsgPgCnt = '").append(nacufokSteUsgPgCnt)
				.append("'");
		sb.append("\n    custSteUsgPgCnt = '").append(custSteUsgPgCnt)
				.append("'");
		sb.append("\n    pprSzCd = '").append(pprSzCd).append("'");
		sb.append("\n    pprDrtCd = '").append(pprDrtCd).append("'");
		sb.append("\n    formMgDpmCd = '").append(formMgDpmCd).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0005HtDto : PK [");
		sb.append("\n    formCd = '").append(formCd).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
