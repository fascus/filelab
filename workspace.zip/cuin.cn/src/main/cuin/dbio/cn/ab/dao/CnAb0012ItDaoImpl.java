/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ab.dto.CnAb0012ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0012ItDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0012_IT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ab.hqml.CnAb0012It")
public class CnAb0012ItDaoImpl extends DbioDaoSupport implements CnAb0012ItDao {

	/**
	 * CN_AB0012_IT (CN_AB0012_IT) 단건 조회.
	 * 
	 */
	public CnAb0012ItDto select(CnAb0012ItDto cnAb0012ItDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0012It.select",
				cnAb0012ItDto);

		CnAb0012ItDto foundCnAb0012ItDto = null;
		try {
			foundCnAb0012ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAb0012ItDto),
					new BeanPropertyRowMapper<CnAb0012ItDto>(
							CnAb0012ItDto.class));
			return foundCnAb0012ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_AB0012_IT (CN_AB0012_IT) 단건 등록.
	 * 
	 */
	public int insert(CnAb0012ItDto cnAb0012ItDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0012It.insert",
				cnAb0012ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0012ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0012_IT (CN_AB0012_IT) 단건 변경.
	 * 
	 */
	public int update(CnAb0012ItDto cnAb0012ItDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0012It.update",
				cnAb0012ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0012ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0012_IT (CN_AB0012_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnAb0012ItDto cnAb0012ItDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0012It.delete",
				cnAb0012ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0012ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0012_IT (CN_AB0012_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnAb0012ItDto> list(CnAb0012ItDto cnAb0012ItDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0012It.list",
				cnAb0012ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnAb0012ItDto), new BeanPropertyRowMapper<CnAb0012ItDto>(
				CnAb0012ItDto.class));
	}

	/**
	 * CN_AB0012_IT (CN_AB0012_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnAb0012ItDto> cnAb0012ItDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0012It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnAb0012ItDtos
				.size()];
		for (int i = 0; i < cnAb0012ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0012ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AB0012_IT (CN_AB0012_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnAb0012ItDto> cnAb0012ItDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0012It.update",
				cnAb0012ItDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnAb0012ItDtos
				.size()];
		for (int i = 0; i < cnAb0012ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0012ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AB0012_IT (CN_AB0012_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnAb0012ItDto> cnAb0012ItDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0012It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnAb0012ItDtos
				.size()];
		for (int i = 0; i < cnAb0012ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0012ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
