/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0012ItDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0012_IT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnAb0012ItDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = 2474099449968478611L;

	/**
	 * 송신요청ID
	 */
	private Integer sndnRqstId;

	/**
	 * 목적지내용
	 */
	private String dstnCtt;

	/**
	 * 송신결과코드
	 */
	private String sndnRslCd;

	/**
	 * 실패코드
	 */
	private String falrCd;

	/**
	 * 송신페이지수
	 */
	private Integer sndnPgCnt;

	/**
	 * 전체페이지수
	 */
	private Integer allPgCnt;

	/**
	 * 송신완료일시
	 */
	private Timestamp sndnFnsDtm;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '송신요청ID' 반환
	 */
	public Integer getSndnRqstId() {
		return sndnRqstId;
	}

	/**
	 * '송신요청ID' 설정
	 */
	public void setSndnRqstId(Integer sndnRqstId) {
		this.sndnRqstId = sndnRqstId;
	}

	/**
	 * '목적지내용' 반환
	 */
	public String getDstnCtt() {
		return dstnCtt;
	}

	/**
	 * '목적지내용' 설정
	 */
	public void setDstnCtt(String dstnCtt) {
		this.dstnCtt = dstnCtt;
	}

	/**
	 * '송신결과코드' 반환
	 */
	public String getSndnRslCd() {
		return sndnRslCd;
	}

	/**
	 * '송신결과코드' 설정
	 */
	public void setSndnRslCd(String sndnRslCd) {
		this.sndnRslCd = sndnRslCd;
	}

	/**
	 * '실패코드' 반환
	 */
	public String getFalrCd() {
		return falrCd;
	}

	/**
	 * '실패코드' 설정
	 */
	public void setFalrCd(String falrCd) {
		this.falrCd = falrCd;
	}

	/**
	 * '송신페이지수' 반환
	 */
	public Integer getSndnPgCnt() {
		return sndnPgCnt;
	}

	/**
	 * '송신페이지수' 설정
	 */
	public void setSndnPgCnt(Integer sndnPgCnt) {
		this.sndnPgCnt = sndnPgCnt;
	}

	/**
	 * '전체페이지수' 반환
	 */
	public Integer getAllPgCnt() {
		return allPgCnt;
	}

	/**
	 * '전체페이지수' 설정
	 */
	public void setAllPgCnt(Integer allPgCnt) {
		this.allPgCnt = allPgCnt;
	}

	/**
	 * '송신완료일시' 반환
	 */
	public Timestamp getSndnFnsDtm() {
		return sndnFnsDtm;
	}

	/**
	 * '송신완료일시' 설정
	 */
	public void setSndnFnsDtm(Timestamp sndnFnsDtm) {
		this.sndnFnsDtm = sndnFnsDtm;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0012ItDto [");
		sb.append("\n    sndnRqstId = '").append(sndnRqstId).append("'");
		sb.append("\n    dstnCtt = '").append(dstnCtt).append("'");
		sb.append("\n    sndnRslCd = '").append(sndnRslCd).append("'");
		sb.append("\n    falrCd = '").append(falrCd).append("'");
		sb.append("\n    sndnPgCnt = '").append(sndnPgCnt).append("'");
		sb.append("\n    allPgCnt = '").append(allPgCnt).append("'");
		sb.append("\n    sndnFnsDtm = '").append(sndnFnsDtm).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0012ItDto : PK [");
		sb.append("\n    sndnRqstId = '").append(sndnRqstId).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
