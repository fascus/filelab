/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ab.dto.CnAb0004MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0004MtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0004_MT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ab.hqml.CnAb0004Mt")
public class CnAb0004MtDaoImpl extends DbioDaoSupport implements CnAb0004MtDao {

	/**
	 * CN_AB0004_MT (CN_AB0004_MT) 단건 조회.
	 * 
	 */
	public CnAb0004MtDto select(CnAb0004MtDto cnAb0004MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0004Mt.select",
				cnAb0004MtDto);

		CnAb0004MtDto foundCnAb0004MtDto = null;
		try {
			foundCnAb0004MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAb0004MtDto),
					new BeanPropertyRowMapper<CnAb0004MtDto>(
							CnAb0004MtDto.class));
			return foundCnAb0004MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_AB0004_MT (CN_AB0004_MT) 단건 등록.
	 * 
	 */
	public int insert(CnAb0004MtDto cnAb0004MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0004Mt.insert",
				cnAb0004MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0004MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0004_MT (CN_AB0004_MT) 단건 변경.
	 * 
	 */
	public int update(CnAb0004MtDto cnAb0004MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0004Mt.update",
				cnAb0004MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0004MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0004_MT (CN_AB0004_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnAb0004MtDto cnAb0004MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0004Mt.delete",
				cnAb0004MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0004MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0004_MT (CN_AB0004_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnAb0004MtDto> list(CnAb0004MtDto cnAb0004MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0004Mt.list",
				cnAb0004MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnAb0004MtDto), new BeanPropertyRowMapper<CnAb0004MtDto>(
				CnAb0004MtDto.class));
	}

	/**
	 * CN_AB0004_MT (CN_AB0004_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnAb0004MtDto> cnAb0004MtDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0004Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnAb0004MtDtos
				.size()];
		for (int i = 0; i < cnAb0004MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0004MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AB0004_MT (CN_AB0004_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnAb0004MtDto> cnAb0004MtDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0004Mt.update",
				cnAb0004MtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnAb0004MtDtos
				.size()];
		for (int i = 0; i < cnAb0004MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0004MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AB0004_MT (CN_AB0004_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnAb0004MtDto> cnAb0004MtDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0004Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnAb0004MtDtos
				.size()];
		for (int i = 0; i < cnAb0004MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0004MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
