/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.ab.dto.CnAb0013HtDto;
import cuin.dbio.cn.ab.dto.CnAb0013HtPrevInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0013HtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0013_HT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ab.hqml.CnAb0013Ht")
public class CnAb0013HtDaoImpl extends DbioDaoSupport implements CnAb0013HtDao {

	/**
	 * CN_AB0013_HT (CN_AB0013_HT) 단건 등록.
	 * 
	 */
	public int insert(CnAb0013HtDto cnAb0013HtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0013Ht.insert",
				cnAb0013HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0013HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0013_HT (CN_AB0013_HT) 현행 이력 업데이트.
	 * 
	 */
	public int closeCurrentHistory(CnAb0013HtDto cnAb0013HtDto) {
		String sql = getSql(
				"cuin.dbio.cn.ab.hqml.CnAb0013Ht.closeCurrentHistory",
				cnAb0013HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0013HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0013_HT (CN_AB0013_HT) 이력 삭제.
	 * 
	 */
	public int deleteHistory(CnAb0013HtDto cnAb0013HtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0013Ht.deleteHistory",
				cnAb0013HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0013HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0013_HT (CN_AB0013_HT) 특정 시점의 단건 이력 조회.
	 * 
	 */
	public CnAb0013HtDto selectPrevious(CnAb0013HtPrevInDto cnAb0013HtPrevInDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0013Ht.selectPrevious",
				cnAb0013HtPrevInDto);

		CnAb0013HtDto foundCnAb0013HtDto = null;
		try {
			foundCnAb0013HtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAb0013HtPrevInDto),
					new BeanPropertyRowMapper<CnAb0013HtDto>(
							CnAb0013HtDto.class));
			return foundCnAb0013HtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * 특정 기간 동안의 이벤트(변경 내역) 조회
	 * 
	 */
	public List<CnAb0013HtDto> selectInPeriod(PeriodInDto periodInDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0013Ht.selectInPeriod",
				periodInDto);

		return queryForList(sql,
				new BeanPropertySqlParameterSource(periodInDto),
				new BeanPropertyRowMapper<CnAb0013HtDto>(CnAb0013HtDto.class));
	}

}
