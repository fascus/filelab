/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dao;

import java.util.List;

import cuin.dbio.cn.ab.dto.CnAb0004MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0004MtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0004_MT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnAb0004MtDao {

	CnAb0004MtDto select(CnAb0004MtDto cnAb0004MtDto);

	int insert(CnAb0004MtDto cnAb0004MtDto);

	int update(CnAb0004MtDto cnAb0004MtDto);

	int delete(CnAb0004MtDto cnAb0004MtDto);

	List<CnAb0004MtDto> list(CnAb0004MtDto cnAb0004MtDto);

	int[] insertList(List<CnAb0004MtDto> cnAb0004MtDtos);

	int[] updateList(List<CnAb0004MtDto> cnAb0004MtDtos);

	int[] deleteList(List<CnAb0004MtDto> cnAb0004MtDtos);

}
