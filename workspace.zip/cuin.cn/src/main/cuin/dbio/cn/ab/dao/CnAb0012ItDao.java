/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dao;

import java.util.List;

import cuin.dbio.cn.ab.dto.CnAb0012ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0012ItDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0012_IT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnAb0012ItDao {

	CnAb0012ItDto select(CnAb0012ItDto cnAb0012ItDto);

	int insert(CnAb0012ItDto cnAb0012ItDto);

	int update(CnAb0012ItDto cnAb0012ItDto);

	int delete(CnAb0012ItDto cnAb0012ItDto);

	List<CnAb0012ItDto> list(CnAb0012ItDto cnAb0012ItDto);

	int[] insertList(List<CnAb0012ItDto> cnAb0012ItDtos);

	int[] updateList(List<CnAb0012ItDto> cnAb0012ItDtos);

	int[] deleteList(List<CnAb0012ItDto> cnAb0012ItDtos);

}
