package cuin.dbio.cn.ab.dao;

import java.util.List;

import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.ab.dto.CnAb0007HtDto;
import cuin.dbio.cn.ab.dto.CnAb0007HtPrevInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0007HtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.12
 * 설    명 : CN_AB0007_HT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnAb0007HtDao {

	int insert(CnAb0007HtDto cnAb0007HtDto);

	int closeCurrentHistory(CnAb0007HtDto cnAb0007HtDto);

	int deleteHistory(CnAb0007HtDto cnAb0007HtDto);

	CnAb0007HtDto selectPrevious(CnAb0007HtPrevInDto cnAb0007HtPrevInDto);

	List<CnAb0007HtDto> selectInPeriod(PeriodInDto periodInDto);

}
