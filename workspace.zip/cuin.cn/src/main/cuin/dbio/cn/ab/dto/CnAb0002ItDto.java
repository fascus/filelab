/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dto;

import java.io.Serializable;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0002ItDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0002_IT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnAb0002ItDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = 6799915644387675910L;

	/**
	 * 표준응답코드
	 */
	private String stndRespCode;

	/**
	 * MCI채널구분코드
	 */
	private String chlDvCd;

	/**
	 * 채널응답코드
	 */
	private String chlRespCode;

	/**
	 * 현재사용여부
	 */
	private String useYn;

	/**
	 * 적용시작일자
	 */
	private String aplSchdDd;

	/**
	 * 최종등록일시
	 */
	private String fistRegDtim;

	/**
	 * 최종변경일시
	 */
	private String lastChngDtim;

	/**
	 * 조작자번호
	 */
	private String oprno;

	/**
	 * '표준응답코드' 반환
	 */
	public String getStndRespCode() {
		return stndRespCode;
	}

	/**
	 * '표준응답코드' 설정
	 */
	public void setStndRespCode(String stndRespCode) {
		this.stndRespCode = stndRespCode;
	}

	/**
	 * 'MCI채널구분코드' 반환
	 */
	public String getChlDvCd() {
		return chlDvCd;
	}

	/**
	 * 'MCI채널구분코드' 설정
	 */
	public void setChlDvCd(String chlDvCd) {
		this.chlDvCd = chlDvCd;
	}

	/**
	 * '채널응답코드' 반환
	 */
	public String getChlRespCode() {
		return chlRespCode;
	}

	/**
	 * '채널응답코드' 설정
	 */
	public void setChlRespCode(String chlRespCode) {
		this.chlRespCode = chlRespCode;
	}

	/**
	 * '현재사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '현재사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '적용시작일자' 반환
	 */
	public String getAplSchdDd() {
		return aplSchdDd;
	}

	/**
	 * '적용시작일자' 설정
	 */
	public void setAplSchdDd(String aplSchdDd) {
		this.aplSchdDd = aplSchdDd;
	}

	/**
	 * '최종등록일시' 반환
	 */
	public String getFistRegDtim() {
		return fistRegDtim;
	}

	/**
	 * '최종등록일시' 설정
	 */
	public void setFistRegDtim(String fistRegDtim) {
		this.fistRegDtim = fistRegDtim;
	}

	/**
	 * '최종변경일시' 반환
	 */
	public String getLastChngDtim() {
		return lastChngDtim;
	}

	/**
	 * '최종변경일시' 설정
	 */
	public void setLastChngDtim(String lastChngDtim) {
		this.lastChngDtim = lastChngDtim;
	}

	/**
	 * '조작자번호' 반환
	 */
	public String getOprno() {
		return oprno;
	}

	/**
	 * '조작자번호' 설정
	 */
	public void setOprno(String oprno) {
		this.oprno = oprno;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0002ItDto [");
		sb.append("\n    stndRespCode = '").append(stndRespCode).append("'");
		sb.append("\n    chlDvCd = '").append(chlDvCd).append("'");
		sb.append("\n    chlRespCode = '").append(chlRespCode).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    aplSchdDd = '").append(aplSchdDd).append("'");
		sb.append("\n    fistRegDtim = '").append(fistRegDtim).append("'");
		sb.append("\n    lastChngDtim = '").append(lastChngDtim).append("'");
		sb.append("\n    oprno = '").append(oprno).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0002ItDto : PK [");
		sb.append("\n    stndRespCode = '").append(stndRespCode).append("'");
		sb.append("\n    chlDvCd = '").append(chlDvCd).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
