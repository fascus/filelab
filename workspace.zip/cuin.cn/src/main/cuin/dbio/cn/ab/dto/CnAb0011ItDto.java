/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0011ItDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0011_IT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnAb0011ItDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = 7087482261342079765L;

	/**
	 * 송신요청ID
	 */
	private Integer sndnRqstId;

	/**
	 * 송신요청횟수
	 */
	private Integer sndnRqstCunt;

	/**
	 * 요청자사원번호
	 */
	private String rqtrEmpNo;

	/**
	 * 송신파일경로명
	 */
	private String sndnFlPthNm;

	/**
	 * 송신파일명
	 */
	private String sndnFlNm;

	/**
	 * 목적지내용
	 */
	private String dstnCtt;

	/**
	 * 요청상태코드
	 */
	private String rqstSttCd;

	/**
	 * 요청등록일시
	 */
	private Timestamp rqstRgtDtm;

	/**
	 * 요청처리일시
	 */
	private Timestamp rqstPrceDtm;

	/**
	 * 전송완료일시
	 */
	private Timestamp snFnsDtm;

	/**
	 * 팩스제목
	 */
	private String faxTitl;

	/**
	 * 즉시전송여부
	 */
	private String imdSnYn;

	/**
	 * 예약일시
	 */
	private Timestamp rsvDtm;

	/**
	 * 우선순위
	 */
	private Integer frstRnk;

	/**
	 * 재전송횟수
	 */
	private Integer rtfCunt;

	/**
	 * 재전송간격분
	 */
	private String rtfIntvMi;

	/**
	 * 승인이후발송여부
	 */
	private String apvAfhSnnYn;

	/**
	 * 미리보기여부
	 */
	private String lkaYn;

	/**
	 * 표지사용여부
	 */
	private String cvrUseYn;

	/**
	 * 표지내용
	 */
	private String cvrCtt;

	/**
	 * 어플리케이션명
	 */
	private String aplcNm;

	/**
	 * 연동키문자값
	 */
	private String lnkKeyChcVlu;

	/**
	 * 연동키숫자수
	 */
	private Long lnkKeyNmbrCnt;

	/**
	 * 표지수신회사명
	 */
	private String cvrRcveCmpyNm;

	/**
	 * 표지수신자명
	 */
	private String cvrRcvrNm;

	/**
	 * 표지수신팩스번호
	 */
	private String cvrRcveFaxno;

	/**
	 * 표지수신전화번호
	 */
	private String cvrRcveTelno;

	/**
	 * 표지수신이메일주소
	 */
	private String cvrRcveEmalAdr;

	/**
	 * 표지수신참조자명
	 */
	private String cvrRcveRfnNm;

	/**
	 * 표지송신회사명
	 */
	private String cvrSndnCmpyNm;

	/**
	 * 표지송신자명
	 */
	private String cvrSndrNm;

	/**
	 * 표지송신팩스번호
	 */
	private String cvrSndnFaxno;

	/**
	 * 표지송신전화번호
	 */
	private String cvrSndnTelno;

	/**
	 * 표지송신이메일주소
	 */
	private String cvrSndnEmalAdr;

	/**
	 * 표지메모내용
	 */
	private String cvrMmoCtt;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '송신요청ID' 반환
	 */
	public Integer getSndnRqstId() {
		return sndnRqstId;
	}

	/**
	 * '송신요청ID' 설정
	 */
	public void setSndnRqstId(Integer sndnRqstId) {
		this.sndnRqstId = sndnRqstId;
	}

	/**
	 * '송신요청횟수' 반환
	 */
	public Integer getSndnRqstCunt() {
		return sndnRqstCunt;
	}

	/**
	 * '송신요청횟수' 설정
	 */
	public void setSndnRqstCunt(Integer sndnRqstCunt) {
		this.sndnRqstCunt = sndnRqstCunt;
	}

	/**
	 * '요청자사원번호' 반환
	 */
	public String getRqtrEmpNo() {
		return rqtrEmpNo;
	}

	/**
	 * '요청자사원번호' 설정
	 */
	public void setRqtrEmpNo(String rqtrEmpNo) {
		this.rqtrEmpNo = rqtrEmpNo;
	}

	/**
	 * '송신파일경로명' 반환
	 */
	public String getSndnFlPthNm() {
		return sndnFlPthNm;
	}

	/**
	 * '송신파일경로명' 설정
	 */
	public void setSndnFlPthNm(String sndnFlPthNm) {
		this.sndnFlPthNm = sndnFlPthNm;
	}

	/**
	 * '송신파일명' 반환
	 */
	public String getSndnFlNm() {
		return sndnFlNm;
	}

	/**
	 * '송신파일명' 설정
	 */
	public void setSndnFlNm(String sndnFlNm) {
		this.sndnFlNm = sndnFlNm;
	}

	/**
	 * '목적지내용' 반환
	 */
	public String getDstnCtt() {
		return dstnCtt;
	}

	/**
	 * '목적지내용' 설정
	 */
	public void setDstnCtt(String dstnCtt) {
		this.dstnCtt = dstnCtt;
	}

	/**
	 * '요청상태코드' 반환
	 */
	public String getRqstSttCd() {
		return rqstSttCd;
	}

	/**
	 * '요청상태코드' 설정
	 */
	public void setRqstSttCd(String rqstSttCd) {
		this.rqstSttCd = rqstSttCd;
	}

	/**
	 * '요청등록일시' 반환
	 */
	public Timestamp getRqstRgtDtm() {
		return rqstRgtDtm;
	}

	/**
	 * '요청등록일시' 설정
	 */
	public void setRqstRgtDtm(Timestamp rqstRgtDtm) {
		this.rqstRgtDtm = rqstRgtDtm;
	}

	/**
	 * '요청처리일시' 반환
	 */
	public Timestamp getRqstPrceDtm() {
		return rqstPrceDtm;
	}

	/**
	 * '요청처리일시' 설정
	 */
	public void setRqstPrceDtm(Timestamp rqstPrceDtm) {
		this.rqstPrceDtm = rqstPrceDtm;
	}

	/**
	 * '전송완료일시' 반환
	 */
	public Timestamp getSnFnsDtm() {
		return snFnsDtm;
	}

	/**
	 * '전송완료일시' 설정
	 */
	public void setSnFnsDtm(Timestamp snFnsDtm) {
		this.snFnsDtm = snFnsDtm;
	}

	/**
	 * '팩스제목' 반환
	 */
	public String getFaxTitl() {
		return faxTitl;
	}

	/**
	 * '팩스제목' 설정
	 */
	public void setFaxTitl(String faxTitl) {
		this.faxTitl = faxTitl;
	}

	/**
	 * '즉시전송여부' 반환
	 */
	public String getImdSnYn() {
		return imdSnYn;
	}

	/**
	 * '즉시전송여부' 설정
	 */
	public void setImdSnYn(String imdSnYn) {
		this.imdSnYn = imdSnYn;
	}

	/**
	 * '예약일시' 반환
	 */
	public Timestamp getRsvDtm() {
		return rsvDtm;
	}

	/**
	 * '예약일시' 설정
	 */
	public void setRsvDtm(Timestamp rsvDtm) {
		this.rsvDtm = rsvDtm;
	}

	/**
	 * '우선순위' 반환
	 */
	public Integer getFrstRnk() {
		return frstRnk;
	}

	/**
	 * '우선순위' 설정
	 */
	public void setFrstRnk(Integer frstRnk) {
		this.frstRnk = frstRnk;
	}

	/**
	 * '재전송횟수' 반환
	 */
	public Integer getRtfCunt() {
		return rtfCunt;
	}

	/**
	 * '재전송횟수' 설정
	 */
	public void setRtfCunt(Integer rtfCunt) {
		this.rtfCunt = rtfCunt;
	}

	/**
	 * '재전송간격분' 반환
	 */
	public String getRtfIntvMi() {
		return rtfIntvMi;
	}

	/**
	 * '재전송간격분' 설정
	 */
	public void setRtfIntvMi(String rtfIntvMi) {
		this.rtfIntvMi = rtfIntvMi;
	}

	/**
	 * '승인이후발송여부' 반환
	 */
	public String getApvAfhSnnYn() {
		return apvAfhSnnYn;
	}

	/**
	 * '승인이후발송여부' 설정
	 */
	public void setApvAfhSnnYn(String apvAfhSnnYn) {
		this.apvAfhSnnYn = apvAfhSnnYn;
	}

	/**
	 * '미리보기여부' 반환
	 */
	public String getLkaYn() {
		return lkaYn;
	}

	/**
	 * '미리보기여부' 설정
	 */
	public void setLkaYn(String lkaYn) {
		this.lkaYn = lkaYn;
	}

	/**
	 * '표지사용여부' 반환
	 */
	public String getCvrUseYn() {
		return cvrUseYn;
	}

	/**
	 * '표지사용여부' 설정
	 */
	public void setCvrUseYn(String cvrUseYn) {
		this.cvrUseYn = cvrUseYn;
	}

	/**
	 * '표지내용' 반환
	 */
	public String getCvrCtt() {
		return cvrCtt;
	}

	/**
	 * '표지내용' 설정
	 */
	public void setCvrCtt(String cvrCtt) {
		this.cvrCtt = cvrCtt;
	}

	/**
	 * '어플리케이션명' 반환
	 */
	public String getAplcNm() {
		return aplcNm;
	}

	/**
	 * '어플리케이션명' 설정
	 */
	public void setAplcNm(String aplcNm) {
		this.aplcNm = aplcNm;
	}

	/**
	 * '연동키문자값' 반환
	 */
	public String getLnkKeyChcVlu() {
		return lnkKeyChcVlu;
	}

	/**
	 * '연동키문자값' 설정
	 */
	public void setLnkKeyChcVlu(String lnkKeyChcVlu) {
		this.lnkKeyChcVlu = lnkKeyChcVlu;
	}

	/**
	 * '연동키숫자수' 반환
	 */
	public Long getLnkKeyNmbrCnt() {
		return lnkKeyNmbrCnt;
	}

	/**
	 * '연동키숫자수' 설정
	 */
	public void setLnkKeyNmbrCnt(Long lnkKeyNmbrCnt) {
		this.lnkKeyNmbrCnt = lnkKeyNmbrCnt;
	}

	/**
	 * '표지수신회사명' 반환
	 */
	public String getCvrRcveCmpyNm() {
		return cvrRcveCmpyNm;
	}

	/**
	 * '표지수신회사명' 설정
	 */
	public void setCvrRcveCmpyNm(String cvrRcveCmpyNm) {
		this.cvrRcveCmpyNm = cvrRcveCmpyNm;
	}

	/**
	 * '표지수신자명' 반환
	 */
	public String getCvrRcvrNm() {
		return cvrRcvrNm;
	}

	/**
	 * '표지수신자명' 설정
	 */
	public void setCvrRcvrNm(String cvrRcvrNm) {
		this.cvrRcvrNm = cvrRcvrNm;
	}

	/**
	 * '표지수신팩스번호' 반환
	 */
	public String getCvrRcveFaxno() {
		return cvrRcveFaxno;
	}

	/**
	 * '표지수신팩스번호' 설정
	 */
	public void setCvrRcveFaxno(String cvrRcveFaxno) {
		this.cvrRcveFaxno = cvrRcveFaxno;
	}

	/**
	 * '표지수신전화번호' 반환
	 */
	public String getCvrRcveTelno() {
		return cvrRcveTelno;
	}

	/**
	 * '표지수신전화번호' 설정
	 */
	public void setCvrRcveTelno(String cvrRcveTelno) {
		this.cvrRcveTelno = cvrRcveTelno;
	}

	/**
	 * '표지수신이메일주소' 반환
	 */
	public String getCvrRcveEmalAdr() {
		return cvrRcveEmalAdr;
	}

	/**
	 * '표지수신이메일주소' 설정
	 */
	public void setCvrRcveEmalAdr(String cvrRcveEmalAdr) {
		this.cvrRcveEmalAdr = cvrRcveEmalAdr;
	}

	/**
	 * '표지수신참조자명' 반환
	 */
	public String getCvrRcveRfnNm() {
		return cvrRcveRfnNm;
	}

	/**
	 * '표지수신참조자명' 설정
	 */
	public void setCvrRcveRfnNm(String cvrRcveRfnNm) {
		this.cvrRcveRfnNm = cvrRcveRfnNm;
	}

	/**
	 * '표지송신회사명' 반환
	 */
	public String getCvrSndnCmpyNm() {
		return cvrSndnCmpyNm;
	}

	/**
	 * '표지송신회사명' 설정
	 */
	public void setCvrSndnCmpyNm(String cvrSndnCmpyNm) {
		this.cvrSndnCmpyNm = cvrSndnCmpyNm;
	}

	/**
	 * '표지송신자명' 반환
	 */
	public String getCvrSndrNm() {
		return cvrSndrNm;
	}

	/**
	 * '표지송신자명' 설정
	 */
	public void setCvrSndrNm(String cvrSndrNm) {
		this.cvrSndrNm = cvrSndrNm;
	}

	/**
	 * '표지송신팩스번호' 반환
	 */
	public String getCvrSndnFaxno() {
		return cvrSndnFaxno;
	}

	/**
	 * '표지송신팩스번호' 설정
	 */
	public void setCvrSndnFaxno(String cvrSndnFaxno) {
		this.cvrSndnFaxno = cvrSndnFaxno;
	}

	/**
	 * '표지송신전화번호' 반환
	 */
	public String getCvrSndnTelno() {
		return cvrSndnTelno;
	}

	/**
	 * '표지송신전화번호' 설정
	 */
	public void setCvrSndnTelno(String cvrSndnTelno) {
		this.cvrSndnTelno = cvrSndnTelno;
	}

	/**
	 * '표지송신이메일주소' 반환
	 */
	public String getCvrSndnEmalAdr() {
		return cvrSndnEmalAdr;
	}

	/**
	 * '표지송신이메일주소' 설정
	 */
	public void setCvrSndnEmalAdr(String cvrSndnEmalAdr) {
		this.cvrSndnEmalAdr = cvrSndnEmalAdr;
	}

	/**
	 * '표지메모내용' 반환
	 */
	public String getCvrMmoCtt() {
		return cvrMmoCtt;
	}

	/**
	 * '표지메모내용' 설정
	 */
	public void setCvrMmoCtt(String cvrMmoCtt) {
		this.cvrMmoCtt = cvrMmoCtt;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0011ItDto [");
		sb.append("\n    sndnRqstId = '").append(sndnRqstId).append("'");
		sb.append("\n    sndnRqstCunt = '").append(sndnRqstCunt).append("'");
		sb.append("\n    rqtrEmpNo = '").append(rqtrEmpNo).append("'");
		sb.append("\n    sndnFlPthNm = '").append(sndnFlPthNm).append("'");
		sb.append("\n    sndnFlNm = '").append(sndnFlNm).append("'");
		sb.append("\n    dstnCtt = '").append(dstnCtt).append("'");
		sb.append("\n    rqstSttCd = '").append(rqstSttCd).append("'");
		sb.append("\n    rqstRgtDtm = '").append(rqstRgtDtm).append("'");
		sb.append("\n    rqstPrceDtm = '").append(rqstPrceDtm).append("'");
		sb.append("\n    snFnsDtm = '").append(snFnsDtm).append("'");
		sb.append("\n    faxTitl = '").append(faxTitl).append("'");
		sb.append("\n    imdSnYn = '").append(imdSnYn).append("'");
		sb.append("\n    rsvDtm = '").append(rsvDtm).append("'");
		sb.append("\n    frstRnk = '").append(frstRnk).append("'");
		sb.append("\n    rtfCunt = '").append(rtfCunt).append("'");
		sb.append("\n    rtfIntvMi = '").append(rtfIntvMi).append("'");
		sb.append("\n    apvAfhSnnYn = '").append(apvAfhSnnYn).append("'");
		sb.append("\n    lkaYn = '").append(lkaYn).append("'");
		sb.append("\n    cvrUseYn = '").append(cvrUseYn).append("'");
		sb.append("\n    cvrCtt = '").append(cvrCtt).append("'");
		sb.append("\n    aplcNm = '").append(aplcNm).append("'");
		sb.append("\n    lnkKeyChcVlu = '").append(lnkKeyChcVlu).append("'");
		sb.append("\n    lnkKeyNmbrCnt = '").append(lnkKeyNmbrCnt).append("'");
		sb.append("\n    cvrRcveCmpyNm = '").append(cvrRcveCmpyNm).append("'");
		sb.append("\n    cvrRcvrNm = '").append(cvrRcvrNm).append("'");
		sb.append("\n    cvrRcveFaxno = '").append(cvrRcveFaxno).append("'");
		sb.append("\n    cvrRcveTelno = '").append(cvrRcveTelno).append("'");
		sb.append("\n    cvrRcveEmalAdr = '").append(cvrRcveEmalAdr)
				.append("'");
		sb.append("\n    cvrRcveRfnNm = '").append(cvrRcveRfnNm).append("'");
		sb.append("\n    cvrSndnCmpyNm = '").append(cvrSndnCmpyNm).append("'");
		sb.append("\n    cvrSndrNm = '").append(cvrSndrNm).append("'");
		sb.append("\n    cvrSndnFaxno = '").append(cvrSndnFaxno).append("'");
		sb.append("\n    cvrSndnTelno = '").append(cvrSndnTelno).append("'");
		sb.append("\n    cvrSndnEmalAdr = '").append(cvrSndnEmalAdr)
				.append("'");
		sb.append("\n    cvrMmoCtt = '").append(cvrMmoCtt).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0011ItDto : PK [");
		sb.append("\n    sndnRqstId = '").append(sndnRqstId).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
