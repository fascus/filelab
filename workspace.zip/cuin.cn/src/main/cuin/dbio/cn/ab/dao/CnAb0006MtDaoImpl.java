package cuin.dbio.cn.ab.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.ab.dto.CnAb0006MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0006MtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.12
 * 설    명 : CN_AB0006_MT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ab.hqml.CnAb0006Mt")
public class CnAb0006MtDaoImpl extends DbioDaoSupport implements CnAb0006MtDao {

	/**
	 * CN_AB0006_MT (CN_AB0006_MT) 단건 조회.
	 * 
	 */
	public CnAb0006MtDto select(CnAb0006MtDto cnAb0006MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0006Mt.select",
				cnAb0006MtDto);

		CnAb0006MtDto foundCnAb0006MtDto = null;
		try {
			foundCnAb0006MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAb0006MtDto),
					new BeanPropertyRowMapper<CnAb0006MtDto>(
							CnAb0006MtDto.class));
			return foundCnAb0006MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_AB0006_MT (CN_AB0006_MT) 단건 등록.
	 * 
	 */
	public int insert(CnAb0006MtDto cnAb0006MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0006Mt.insert",
				cnAb0006MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0006MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0006_MT (CN_AB0006_MT) 단건 변경.
	 * 
	 */
	public int update(CnAb0006MtDto cnAb0006MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0006Mt.update",
				cnAb0006MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0006MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0006_MT (CN_AB0006_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnAb0006MtDto cnAb0006MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0006Mt.delete",
				cnAb0006MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0006MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0006_MT (CN_AB0006_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnAb0006MtDto> list(CnAb0006MtDto cnAb0006MtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0006Mt.list",
				cnAb0006MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnAb0006MtDto), new BeanPropertyRowMapper<CnAb0006MtDto>(
				CnAb0006MtDto.class));
	}

	/**
	 * CN_AB0006_MT (CN_AB0006_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnAb0006MtDto> cnAb0006MtDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0006Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnAb0006MtDtos
				.size()];
		for (int i = 0; i < cnAb0006MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0006MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AB0006_MT (CN_AB0006_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnAb0006MtDto> cnAb0006MtDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0006Mt.update",
				cnAb0006MtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnAb0006MtDtos
				.size()];
		for (int i = 0; i < cnAb0006MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0006MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_AB0006_MT (CN_AB0006_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnAb0006MtDto> cnAb0006MtDtos) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0006Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnAb0006MtDtos
				.size()];
		for (int i = 0; i < cnAb0006MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnAb0006MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
