/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.ab.dto.CnAb0005HtDto;
import cuin.dbio.cn.ab.dto.CnAb0005HtPrevInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0005HtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0005_HT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.ab.hqml.CnAb0005Ht")
public class CnAb0005HtDaoImpl extends DbioDaoSupport implements CnAb0005HtDao {

	/**
	 * CN_AB0005_HT (CN_AB0005_HT) 단건 등록.
	 * 
	 */
	public int insert(CnAb0005HtDto cnAb0005HtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0005Ht.insert",
				cnAb0005HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0005HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0005_HT (CN_AB0005_HT) 현행 이력 업데이트.
	 * 
	 */
	public int closeCurrentHistory(CnAb0005HtDto cnAb0005HtDto) {
		String sql = getSql(
				"cuin.dbio.cn.ab.hqml.CnAb0005Ht.closeCurrentHistory",
				cnAb0005HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0005HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0005_HT (CN_AB0005_HT) 이력 삭제.
	 * 
	 */
	public int deleteHistory(CnAb0005HtDto cnAb0005HtDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0005Ht.deleteHistory",
				cnAb0005HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnAb0005HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_AB0005_HT (CN_AB0005_HT) 특정 시점의 단건 이력 조회.
	 * 
	 */
	public CnAb0005HtDto selectPrevious(CnAb0005HtPrevInDto cnAb0005HtPrevInDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0005Ht.selectPrevious",
				cnAb0005HtPrevInDto);

		CnAb0005HtDto foundCnAb0005HtDto = null;
		try {
			foundCnAb0005HtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnAb0005HtPrevInDto),
					new BeanPropertyRowMapper<CnAb0005HtDto>(
							CnAb0005HtDto.class));
			return foundCnAb0005HtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * 특정 기간 동안의 이벤트(변경 내역) 조회
	 * 
	 */
	public List<CnAb0005HtDto> selectInPeriod(PeriodInDto periodInDto) {
		String sql = getSql("cuin.dbio.cn.ab.hqml.CnAb0005Ht.selectInPeriod",
				periodInDto);

		return queryForList(sql,
				new BeanPropertySqlParameterSource(periodInDto),
				new BeanPropertyRowMapper<CnAb0005HtDto>(CnAb0005HtDto.class));
	}

}
