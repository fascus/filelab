package cuin.dbio.cn.ab.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0007HtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.12
 * 설    명 : CN_AB0007_HT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnAb0007HtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -2922851052271549699L;

	/**
	 * 서식관리번호
	 */
	private String formMgNo;

	/**
	 * 적용종료일시
	 */
	private Timestamp aplEotDtm;

	/**
	 * 적용시작일시
	 */
	private Timestamp aplBgDtm;

	/**
	 * 유효종료일시
	 */
	private Timestamp vldEotDtm;

	/**
	 * 유효시작일시
	 */
	private Timestamp vldBgDtm;

	/**
	 * 업무구분코드
	 */
	private String bsnsDvCd;

	/**
	 * 서식업무구분코드
	 */
	private String formBsnsDvCd;

	/**
	 * 서식상세업무코드
	 */
	private String formDtilBsnsCd;

	/**
	 * 서식공제분류코드
	 */
	private String formMtClfCd;

	/**
	 * 서식상세설명
	 */
	private String formDtilDscr;

	/**
	 * 서식코드
	 */
	private String formCd;

	/**
	 * 서식명
	 */
	private String formNm;

	/**
	 * 책임자결재문서ID
	 */
	private Long pihApprDcmId;

	/**
	 * 서식출력식별번호
	 */
	private String formPrtIdfNo;

	/**
	 * 계약안내자료여부
	 */
	private String cnrGdeDatYn;

	/**
	 * 첨부파일명
	 */
	private String attFlNm;

	/**
	 * 첨부파일경로명
	 */
	private String attFlPthNm;

	/**
	 * 제정여부
	 */
	private String eslYn;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '서식관리번호' 반환
	 */
	public String getFormMgNo() {
		return formMgNo;
	}

	/**
	 * '서식관리번호' 설정
	 */
	public void setFormMgNo(String formMgNo) {
		this.formMgNo = formMgNo;
	}

	/**
	 * '적용종료일시' 반환
	 */
	public Timestamp getAplEotDtm() {
		return aplEotDtm;
	}

	/**
	 * '적용종료일시' 설정
	 */
	public void setAplEotDtm(Timestamp aplEotDtm) {
		this.aplEotDtm = aplEotDtm;
	}

	/**
	 * '적용시작일시' 반환
	 */
	public Timestamp getAplBgDtm() {
		return aplBgDtm;
	}

	/**
	 * '적용시작일시' 설정
	 */
	public void setAplBgDtm(Timestamp aplBgDtm) {
		this.aplBgDtm = aplBgDtm;
	}

	/**
	 * '유효종료일시' 반환
	 */
	public Timestamp getVldEotDtm() {
		return vldEotDtm;
	}

	/**
	 * '유효종료일시' 설정
	 */
	public void setVldEotDtm(Timestamp vldEotDtm) {
		this.vldEotDtm = vldEotDtm;
	}

	/**
	 * '유효시작일시' 반환
	 */
	public Timestamp getVldBgDtm() {
		return vldBgDtm;
	}

	/**
	 * '유효시작일시' 설정
	 */
	public void setVldBgDtm(Timestamp vldBgDtm) {
		this.vldBgDtm = vldBgDtm;
	}

	/**
	 * '업무구분코드' 반환
	 */
	public String getBsnsDvCd() {
		return bsnsDvCd;
	}

	/**
	 * '업무구분코드' 설정
	 */
	public void setBsnsDvCd(String bsnsDvCd) {
		this.bsnsDvCd = bsnsDvCd;
	}

	/**
	 * '서식업무구분코드' 반환
	 */
	public String getFormBsnsDvCd() {
		return formBsnsDvCd;
	}

	/**
	 * '서식업무구분코드' 설정
	 */
	public void setFormBsnsDvCd(String formBsnsDvCd) {
		this.formBsnsDvCd = formBsnsDvCd;
	}

	/**
	 * '서식상세업무코드' 반환
	 */
	public String getFormDtilBsnsCd() {
		return formDtilBsnsCd;
	}

	/**
	 * '서식상세업무코드' 설정
	 */
	public void setFormDtilBsnsCd(String formDtilBsnsCd) {
		this.formDtilBsnsCd = formDtilBsnsCd;
	}

	/**
	 * '서식공제분류코드' 반환
	 */
	public String getFormMtClfCd() {
		return formMtClfCd;
	}

	/**
	 * '서식공제분류코드' 설정
	 */
	public void setFormMtClfCd(String formMtClfCd) {
		this.formMtClfCd = formMtClfCd;
	}

	/**
	 * '서식상세설명' 반환
	 */
	public String getFormDtilDscr() {
		return formDtilDscr;
	}

	/**
	 * '서식상세설명' 설정
	 */
	public void setFormDtilDscr(String formDtilDscr) {
		this.formDtilDscr = formDtilDscr;
	}

	/**
	 * '서식코드' 반환
	 */
	public String getFormCd() {
		return formCd;
	}

	/**
	 * '서식코드' 설정
	 */
	public void setFormCd(String formCd) {
		this.formCd = formCd;
	}

	/**
	 * '서식명' 반환
	 */
	public String getFormNm() {
		return formNm;
	}

	/**
	 * '서식명' 설정
	 */
	public void setFormNm(String formNm) {
		this.formNm = formNm;
	}

	/**
	 * '책임자결재문서ID' 반환
	 */
	public Long getPihApprDcmId() {
		return pihApprDcmId;
	}

	/**
	 * '책임자결재문서ID' 설정
	 */
	public void setPihApprDcmId(Long pihApprDcmId) {
		this.pihApprDcmId = pihApprDcmId;
	}

	/**
	 * '서식출력식별번호' 반환
	 */
	public String getFormPrtIdfNo() {
		return formPrtIdfNo;
	}

	/**
	 * '서식출력식별번호' 설정
	 */
	public void setFormPrtIdfNo(String formPrtIdfNo) {
		this.formPrtIdfNo = formPrtIdfNo;
	}

	/**
	 * '계약안내자료여부' 반환
	 */
	public String getCnrGdeDatYn() {
		return cnrGdeDatYn;
	}

	/**
	 * '계약안내자료여부' 설정
	 */
	public void setCnrGdeDatYn(String cnrGdeDatYn) {
		this.cnrGdeDatYn = cnrGdeDatYn;
	}

	/**
	 * '첨부파일명' 반환
	 */
	public String getAttFlNm() {
		return attFlNm;
	}

	/**
	 * '첨부파일명' 설정
	 */
	public void setAttFlNm(String attFlNm) {
		this.attFlNm = attFlNm;
	}

	/**
	 * '첨부파일경로명' 반환
	 */
	public String getAttFlPthNm() {
		return attFlPthNm;
	}

	/**
	 * '첨부파일경로명' 설정
	 */
	public void setAttFlPthNm(String attFlPthNm) {
		this.attFlPthNm = attFlPthNm;
	}

	/**
	 * '제정여부' 반환
	 */
	public String getEslYn() {
		return eslYn;
	}

	/**
	 * '제정여부' 설정
	 */
	public void setEslYn(String eslYn) {
		this.eslYn = eslYn;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0007HtDto [");
		sb.append("\n    formMgNo = '").append(formMgNo).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n    vldEotDtm = '").append(vldEotDtm).append("'");
		sb.append("\n    vldBgDtm = '").append(vldBgDtm).append("'");
		sb.append("\n    bsnsDvCd = '").append(bsnsDvCd).append("'");
		sb.append("\n    formBsnsDvCd = '").append(formBsnsDvCd).append("'");
		sb.append("\n    formDtilBsnsCd = '").append(formDtilBsnsCd)
				.append("'");
		sb.append("\n    formMtClfCd = '").append(formMtClfCd).append("'");
		sb.append("\n    formDtilDscr = '").append(formDtilDscr).append("'");
		sb.append("\n    formCd = '").append(formCd).append("'");
		sb.append("\n    formNm = '").append(formNm).append("'");
		sb.append("\n    pihApprDcmId = '").append(pihApprDcmId).append("'");
		sb.append("\n    formPrtIdfNo = '").append(formPrtIdfNo).append("'");
		sb.append("\n    cnrGdeDatYn = '").append(cnrGdeDatYn).append("'");
		sb.append("\n    attFlNm = '").append(attFlNm).append("'");
		sb.append("\n    attFlPthNm = '").append(attFlPthNm).append("'");
		sb.append("\n    eslYn = '").append(eslYn).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0007HtDto : PK [");
		sb.append("\n    formMgNo = '").append(formMgNo).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
