/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dao;

import java.util.List;

import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.ab.dto.CnAb0013HtDto;
import cuin.dbio.cn.ab.dto.CnAb0013HtPrevInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0013HtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0013_HT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnAb0013HtDao {

	int insert(CnAb0013HtDto cnAb0013HtDto);

	int closeCurrentHistory(CnAb0013HtDto cnAb0013HtDto);

	int deleteHistory(CnAb0013HtDto cnAb0013HtDto);

	CnAb0013HtDto selectPrevious(CnAb0013HtPrevInDto cnAb0013HtPrevInDto);

	List<CnAb0013HtDto> selectInPeriod(PeriodInDto periodInDto);

}
