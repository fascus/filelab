package cuin.dbio.cn.ab.dao;

import java.util.List;

import cuin.dbio.cn.ab.dto.CnAb0006MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0006MtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.12
 * 설    명 : CN_AB0006_MT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnAb0006MtDao {

	CnAb0006MtDto select(CnAb0006MtDto cnAb0006MtDto);

	int insert(CnAb0006MtDto cnAb0006MtDto);

	int update(CnAb0006MtDto cnAb0006MtDto);

	int delete(CnAb0006MtDto cnAb0006MtDto);

	List<CnAb0006MtDto> list(CnAb0006MtDto cnAb0006MtDto);

	int[] insertList(List<CnAb0006MtDto> cnAb0006MtDtos);

	int[] updateList(List<CnAb0006MtDto> cnAb0006MtDtos);

	int[] deleteList(List<CnAb0006MtDto> cnAb0006MtDtos);

}
