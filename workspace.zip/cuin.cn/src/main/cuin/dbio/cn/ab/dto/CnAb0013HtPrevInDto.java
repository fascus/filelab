package cuin.dbio.cn.ab.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * CN_AB0013_HT (CN_AB0013_HT) 테이블 이력 단건 조회 DTO.
 */
public class CnAb0013HtPrevInDto implements Serializable {

	private static final long serialVersionUID = -1872502539552863603L;

	/**
	 * 이력 조회를 위한 기준 일시
	 */
	private Timestamp baseDtm;

	/**
	 * 서식관리번호
	 */
	private String formMgNo;

	/**
	 * 서식이미지일련번호
	 */
	private Long formImgSeq;

	/**
	 * 기준 일시 반환
	 */
	public Timestamp getBaseDtm() {
		return baseDtm;
	}

	/**
	 * 기준 일시 설정
	 */
	public void setBaseDtm(Timestamp baseDtm) {
		this.baseDtm = baseDtm;
	}

	/**
	 * '서식관리번호' 반환
	 */
	public String getFormMgNo() {
		return formMgNo;
	}

	/**
	 * '서식관리번호' 설정
	 */
	public void setFormMgNo(String formMgNo) {
		this.formMgNo = formMgNo;
	}

	/**
	 * '서식이미지일련번호' 반환
	 */
	public Long getFormImgSeq() {
		return formImgSeq;
	}

	/**
	 * '서식이미지일련번호' 설정
	 */
	public void setFormImgSeq(Long formImgSeq) {
		this.formImgSeq = formImgSeq;
	}

}