/**
 * 
 * 
 */
package cuin.dbio.cn.ab.dto;

import java.io.Serializable;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnAb0001MtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_AB0001_MT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnAb0001MtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -1981334831549496857L;

	/**
	 * 표준응답코드
	 */
	private String stndRespCode;

	/**
	 * 기본원인메시지
	 */
	private String baseCausMsg;

	/**
	 * 추가메시지1
	 */
	private String addMsg1;

	/**
	 * 추가메시지2
	 */
	private String addMsg2;

	/**
	 * 추가메시지3
	 */
	private String addMsg3;

	/**
	 * 추가메시지4
	 */
	private String addMsg4;

	/**
	 * 자동이체용메시지
	 */
	private String addMsg5;

	/**
	 * 현재사용여부
	 */
	private String useYn;

	/**
	 * 적용시작일자
	 */
	private String aplBgDt;

	/**
	 * 최초등록일시
	 */
	private String fistRegDtim;

	/**
	 * 최종변경일시
	 */
	private String lastChngDtim;

	/**
	 * 조작자번호
	 */
	private String oprno;

	/**
	 * '표준응답코드' 반환
	 */
	public String getStndRespCode() {
		return stndRespCode;
	}

	/**
	 * '표준응답코드' 설정
	 */
	public void setStndRespCode(String stndRespCode) {
		this.stndRespCode = stndRespCode;
	}

	/**
	 * '기본원인메시지' 반환
	 */
	public String getBaseCausMsg() {
		return baseCausMsg;
	}

	/**
	 * '기본원인메시지' 설정
	 */
	public void setBaseCausMsg(String baseCausMsg) {
		this.baseCausMsg = baseCausMsg;
	}

	/**
	 * '추가메시지1' 반환
	 */
	public String getAddMsg1() {
		return addMsg1;
	}

	/**
	 * '추가메시지1' 설정
	 */
	public void setAddMsg1(String addMsg1) {
		this.addMsg1 = addMsg1;
	}

	/**
	 * '추가메시지2' 반환
	 */
	public String getAddMsg2() {
		return addMsg2;
	}

	/**
	 * '추가메시지2' 설정
	 */
	public void setAddMsg2(String addMsg2) {
		this.addMsg2 = addMsg2;
	}

	/**
	 * '추가메시지3' 반환
	 */
	public String getAddMsg3() {
		return addMsg3;
	}

	/**
	 * '추가메시지3' 설정
	 */
	public void setAddMsg3(String addMsg3) {
		this.addMsg3 = addMsg3;
	}

	/**
	 * '추가메시지4' 반환
	 */
	public String getAddMsg4() {
		return addMsg4;
	}

	/**
	 * '추가메시지4' 설정
	 */
	public void setAddMsg4(String addMsg4) {
		this.addMsg4 = addMsg4;
	}

	/**
	 * '자동이체용메시지' 반환
	 */
	public String getAddMsg5() {
		return addMsg5;
	}

	/**
	 * '자동이체용메시지' 설정
	 */
	public void setAddMsg5(String addMsg5) {
		this.addMsg5 = addMsg5;
	}

	/**
	 * '현재사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '현재사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '적용시작일자' 반환
	 */
	public String getAplBgDt() {
		return aplBgDt;
	}

	/**
	 * '적용시작일자' 설정
	 */
	public void setAplBgDt(String aplBgDt) {
		this.aplBgDt = aplBgDt;
	}

	/**
	 * '최초등록일시' 반환
	 */
	public String getFistRegDtim() {
		return fistRegDtim;
	}

	/**
	 * '최초등록일시' 설정
	 */
	public void setFistRegDtim(String fistRegDtim) {
		this.fistRegDtim = fistRegDtim;
	}

	/**
	 * '최종변경일시' 반환
	 */
	public String getLastChngDtim() {
		return lastChngDtim;
	}

	/**
	 * '최종변경일시' 설정
	 */
	public void setLastChngDtim(String lastChngDtim) {
		this.lastChngDtim = lastChngDtim;
	}

	/**
	 * '조작자번호' 반환
	 */
	public String getOprno() {
		return oprno;
	}

	/**
	 * '조작자번호' 설정
	 */
	public void setOprno(String oprno) {
		this.oprno = oprno;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0001MtDto [");
		sb.append("\n    stndRespCode = '").append(stndRespCode).append("'");
		sb.append("\n    baseCausMsg = '").append(baseCausMsg).append("'");
		sb.append("\n    addMsg1 = '").append(addMsg1).append("'");
		sb.append("\n    addMsg2 = '").append(addMsg2).append("'");
		sb.append("\n    addMsg3 = '").append(addMsg3).append("'");
		sb.append("\n    addMsg4 = '").append(addMsg4).append("'");
		sb.append("\n    addMsg5 = '").append(addMsg5).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    aplBgDt = '").append(aplBgDt).append("'");
		sb.append("\n    fistRegDtim = '").append(fistRegDtim).append("'");
		sb.append("\n    lastChngDtim = '").append(lastChngDtim).append("'");
		sb.append("\n    oprno = '").append(oprno).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnAb0001MtDto : PK [");
		sb.append("\n    stndRespCode = '").append(stndRespCode).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
