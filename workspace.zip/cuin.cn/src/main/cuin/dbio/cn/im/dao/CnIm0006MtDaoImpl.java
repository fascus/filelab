/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.im.dto.CnIm0006MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0006MtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0006_MT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.im.hqml.CnIm0006Mt")
public class CnIm0006MtDaoImpl extends DbioDaoSupport implements CnIm0006MtDao {

	/**
	 * CN_IM0006_MT (CN_IM0006_MT) 단건 조회.
	 * 
	 */
	public CnIm0006MtDto select(CnIm0006MtDto cnIm0006MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0006Mt.select",
				cnIm0006MtDto);

		CnIm0006MtDto foundCnIm0006MtDto = null;
		try {
			foundCnIm0006MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIm0006MtDto),
					new BeanPropertyRowMapper<CnIm0006MtDto>(
							CnIm0006MtDto.class));
			return foundCnIm0006MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_IM0006_MT (CN_IM0006_MT) 단건 등록.
	 * 
	 */
	public int insert(CnIm0006MtDto cnIm0006MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0006Mt.insert",
				cnIm0006MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0006MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0006_MT (CN_IM0006_MT) 단건 변경.
	 * 
	 */
	public int update(CnIm0006MtDto cnIm0006MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0006Mt.update",
				cnIm0006MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0006MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0006_MT (CN_IM0006_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIm0006MtDto cnIm0006MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0006Mt.delete",
				cnIm0006MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0006MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0006_MT (CN_IM0006_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIm0006MtDto> list(CnIm0006MtDto cnIm0006MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0006Mt.list",
				cnIm0006MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIm0006MtDto), new BeanPropertyRowMapper<CnIm0006MtDto>(
				CnIm0006MtDto.class));
	}

	/**
	 * CN_IM0006_MT (CN_IM0006_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIm0006MtDto> cnIm0006MtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0006Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0006MtDtos
				.size()];
		for (int i = 0; i < cnIm0006MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0006MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0006_MT (CN_IM0006_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIm0006MtDto> cnIm0006MtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0006Mt.update",
				cnIm0006MtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnIm0006MtDtos
				.size()];
		for (int i = 0; i < cnIm0006MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0006MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0006_MT (CN_IM0006_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIm0006MtDto> cnIm0006MtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0006Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0006MtDtos
				.size()];
		for (int i = 0; i < cnIm0006MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0006MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
