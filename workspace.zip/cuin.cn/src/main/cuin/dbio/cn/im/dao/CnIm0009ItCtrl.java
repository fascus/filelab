/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import java.util.List;

import cuin.cn.dbio.core.sys.DbioUpdateCallback;
import cuin.cn.dbio.core.sys.ServiceInDto;
import cuin.dbio.cn.im.dto.CnIm0009ItDto;

/**
 * CN_IM0009_IT (CN_IM0009_IT) DBIO  컨트롤러 인터페이스.
 *
 * 
 */
public interface CnIm0009ItCtrl {

	/**
	 *  단건 조회
	 */
	CnIm0009ItDto select(ServiceInDto serviceInDto);

	/**
	 * CN_IM0009_IT 등록
	 */
	int insert(ServiceInDto serviceInDto);

	/**
	 * CN_IM0009_IT 변경
	 */
	int update(ServiceInDto serviceInDto);

	/**
	 * CN_IM0009_IT 논리적 삭제
	 */
	int delete(ServiceInDto serviceInDto);

	/**
	 * CN_IM0009_IT 일괄 등록
	 */
	int[] insertList(List serviceInDtoList);

	/**
	 * CN_IM0009_IT 일괄 변경
	 */
	int[] updateList(List serviceInDtoList);

	/**
	 * CN_IM0009_IT 일괄 삭제
	 */
	int[] deleteList(List serviceInDtoList);

	/**
	 * CN_IM0009_IT 일괄 등록 시 레코드 건별 콜백
	 */
	void setBatchCallback(DbioUpdateCallback dbioUpdateCallback);
}
