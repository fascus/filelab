/**
 * 
 * 
 */
package cuin.dbio.cn.im.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0008HtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0008_HT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnIm0008HtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -786596039466398711L;

	/**
	 * 메시지전송일련번호
	 */
	private Long msgSnSeq;

	/**
	 * 메시지전송상세일련번호
	 */
	private Long msgSnDtilSeq;

	/**
	 * EAI인터페이스ID
	 */
	private String eaiIfId;

	/**
	 * 통합메시지업무ID
	 */
	private String intgMsgBsnsId;

	/**
	 * 요청자사원번호
	 */
	private String rqtrEmpNo;

	/**
	 * 상세업무코드
	 */
	private String dtilBsnsCd;

	/**
	 * 고객접촉종류코드
	 */
	private String custCtcKdCd;

	/**
	 * 고객번호
	 */
	private String custNo;

	/**
	 * 증권번호
	 */
	private String plcyNo;

	/**
	 * 업무구분코드
	 */
	private String bsnsDvCd;

	/**
	 * 대상식별번호구분코드
	 */
	private String sbjIdfNoDvCd;

	/**
	 * 대상식별번호
	 */
	private String sbjIdfNo;

	/**
	 * 메시지제목
	 */
	private String msgTitl;

	/**
	 * 메시지내용
	 */
	private String msgCtt;

	/**
	 * 예약일시
	 */
	private Timestamp rsvDtm;

	/**
	 * 발송일시
	 */
	private Timestamp snnDtm;

	/**
	 * 요청등록일시
	 */
	private Timestamp rqstRgtDtm;

	/**
	 * 발송지식별번호
	 */
	private String seplIdfNo;

	/**
	 * 발송구분코드
	 */
	private String snnDvCd;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '메시지전송일련번호' 반환
	 */
	public Long getMsgSnSeq() {
		return msgSnSeq;
	}

	/**
	 * '메시지전송일련번호' 설정
	 */
	public void setMsgSnSeq(Long msgSnSeq) {
		this.msgSnSeq = msgSnSeq;
	}

	/**
	 * '메시지전송상세일련번호' 반환
	 */
	public Long getMsgSnDtilSeq() {
		return msgSnDtilSeq;
	}

	/**
	 * '메시지전송상세일련번호' 설정
	 */
	public void setMsgSnDtilSeq(Long msgSnDtilSeq) {
		this.msgSnDtilSeq = msgSnDtilSeq;
	}

	/**
	 * 'EAI인터페이스ID' 반환
	 */
	public String getEaiIfId() {
		return eaiIfId;
	}

	/**
	 * 'EAI인터페이스ID' 설정
	 */
	public void setEaiIfId(String eaiIfId) {
		this.eaiIfId = eaiIfId;
	}

	/**
	 * '통합메시지업무ID' 반환
	 */
	public String getIntgMsgBsnsId() {
		return intgMsgBsnsId;
	}

	/**
	 * '통합메시지업무ID' 설정
	 */
	public void setIntgMsgBsnsId(String intgMsgBsnsId) {
		this.intgMsgBsnsId = intgMsgBsnsId;
	}

	/**
	 * '요청자사원번호' 반환
	 */
	public String getRqtrEmpNo() {
		return rqtrEmpNo;
	}

	/**
	 * '요청자사원번호' 설정
	 */
	public void setRqtrEmpNo(String rqtrEmpNo) {
		this.rqtrEmpNo = rqtrEmpNo;
	}

	/**
	 * '상세업무코드' 반환
	 */
	public String getDtilBsnsCd() {
		return dtilBsnsCd;
	}

	/**
	 * '상세업무코드' 설정
	 */
	public void setDtilBsnsCd(String dtilBsnsCd) {
		this.dtilBsnsCd = dtilBsnsCd;
	}

	/**
	 * '고객접촉종류코드' 반환
	 */
	public String getCustCtcKdCd() {
		return custCtcKdCd;
	}

	/**
	 * '고객접촉종류코드' 설정
	 */
	public void setCustCtcKdCd(String custCtcKdCd) {
		this.custCtcKdCd = custCtcKdCd;
	}

	/**
	 * '고객번호' 반환
	 */
	public String getCustNo() {
		return custNo;
	}

	/**
	 * '고객번호' 설정
	 */
	public void setCustNo(String custNo) {
		this.custNo = custNo;
	}

	/**
	 * '증권번호' 반환
	 */
	public String getPlcyNo() {
		return plcyNo;
	}

	/**
	 * '증권번호' 설정
	 */
	public void setPlcyNo(String plcyNo) {
		this.plcyNo = plcyNo;
	}

	/**
	 * '업무구분코드' 반환
	 */
	public String getBsnsDvCd() {
		return bsnsDvCd;
	}

	/**
	 * '업무구분코드' 설정
	 */
	public void setBsnsDvCd(String bsnsDvCd) {
		this.bsnsDvCd = bsnsDvCd;
	}

	/**
	 * '대상식별번호구분코드' 반환
	 */
	public String getSbjIdfNoDvCd() {
		return sbjIdfNoDvCd;
	}

	/**
	 * '대상식별번호구분코드' 설정
	 */
	public void setSbjIdfNoDvCd(String sbjIdfNoDvCd) {
		this.sbjIdfNoDvCd = sbjIdfNoDvCd;
	}

	/**
	 * '대상식별번호' 반환
	 */
	public String getSbjIdfNo() {
		return sbjIdfNo;
	}

	/**
	 * '대상식별번호' 설정
	 */
	public void setSbjIdfNo(String sbjIdfNo) {
		this.sbjIdfNo = sbjIdfNo;
	}

	/**
	 * '메시지제목' 반환
	 */
	public String getMsgTitl() {
		return msgTitl;
	}

	/**
	 * '메시지제목' 설정
	 */
	public void setMsgTitl(String msgTitl) {
		this.msgTitl = msgTitl;
	}

	/**
	 * '메시지내용' 반환
	 */
	public String getMsgCtt() {
		return msgCtt;
	}

	/**
	 * '메시지내용' 설정
	 */
	public void setMsgCtt(String msgCtt) {
		this.msgCtt = msgCtt;
	}

	/**
	 * '예약일시' 반환
	 */
	public Timestamp getRsvDtm() {
		return rsvDtm;
	}

	/**
	 * '예약일시' 설정
	 */
	public void setRsvDtm(Timestamp rsvDtm) {
		this.rsvDtm = rsvDtm;
	}

	/**
	 * '발송일시' 반환
	 */
	public Timestamp getSnnDtm() {
		return snnDtm;
	}

	/**
	 * '발송일시' 설정
	 */
	public void setSnnDtm(Timestamp snnDtm) {
		this.snnDtm = snnDtm;
	}

	/**
	 * '요청등록일시' 반환
	 */
	public Timestamp getRqstRgtDtm() {
		return rqstRgtDtm;
	}

	/**
	 * '요청등록일시' 설정
	 */
	public void setRqstRgtDtm(Timestamp rqstRgtDtm) {
		this.rqstRgtDtm = rqstRgtDtm;
	}

	/**
	 * '발송지식별번호' 반환
	 */
	public String getSeplIdfNo() {
		return seplIdfNo;
	}

	/**
	 * '발송지식별번호' 설정
	 */
	public void setSeplIdfNo(String seplIdfNo) {
		this.seplIdfNo = seplIdfNo;
	}

	/**
	 * '발송구분코드' 반환
	 */
	public String getSnnDvCd() {
		return snnDvCd;
	}

	/**
	 * '발송구분코드' 설정
	 */
	public void setSnnDvCd(String snnDvCd) {
		this.snnDvCd = snnDvCd;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0008HtDto [");
		sb.append("\n    msgSnSeq = '").append(msgSnSeq).append("'");
		sb.append("\n    msgSnDtilSeq = '").append(msgSnDtilSeq).append("'");
		sb.append("\n    eaiIfId = '").append(eaiIfId).append("'");
		sb.append("\n    intgMsgBsnsId = '").append(intgMsgBsnsId).append("'");
		sb.append("\n    rqtrEmpNo = '").append(rqtrEmpNo).append("'");
		sb.append("\n    dtilBsnsCd = '").append(dtilBsnsCd).append("'");
		sb.append("\n    custCtcKdCd = '").append(custCtcKdCd).append("'");
		sb.append("\n    custNo = '").append(custNo).append("'");
		sb.append("\n    plcyNo = '").append(plcyNo).append("'");
		sb.append("\n    bsnsDvCd = '").append(bsnsDvCd).append("'");
		sb.append("\n    sbjIdfNoDvCd = '").append(sbjIdfNoDvCd).append("'");
		sb.append("\n    sbjIdfNo = '").append(sbjIdfNo).append("'");
		sb.append("\n    msgTitl = '").append(msgTitl).append("'");
		sb.append("\n    msgCtt = '").append(msgCtt).append("'");
		sb.append("\n    rsvDtm = '").append(rsvDtm).append("'");
		sb.append("\n    snnDtm = '").append(snnDtm).append("'");
		sb.append("\n    rqstRgtDtm = '").append(rqstRgtDtm).append("'");
		sb.append("\n    seplIdfNo = '").append(seplIdfNo).append("'");
		sb.append("\n    snnDvCd = '").append(snnDvCd).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0008HtDto : PK [");
		sb.append("\n    msgSnSeq = '").append(msgSnSeq).append("'");
		sb.append("\n    msgSnDtilSeq = '").append(msgSnDtilSeq).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
