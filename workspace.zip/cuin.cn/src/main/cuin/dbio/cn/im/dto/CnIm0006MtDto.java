/**
 * 
 * 
 */
package cuin.dbio.cn.im.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0006MtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0006_MT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnIm0006MtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -1373838834697548623L;

	/**
	 * 거래ID
	 */
	private String trnId;

	/**
	 * 적용종료일시
	 */
	private Timestamp aplEotDtm;

	/**
	 * 적용시작일시
	 */
	private Timestamp aplBgDtm;

	/**
	 * 거래명
	 */
	private String trnNm;

	/**
	 * 서비스중지여부
	 */
	private String srviStpYn;

	/**
	 * 영업일여부
	 */
	private String bsyYn;

	/**
	 * 업무구분코드
	 */
	private String bsnsDvCd;

	/**
	 * 유효종료일시
	 */
	private Timestamp vldEotDtm;

	/**
	 * 유효시작일시
	 */
	private Timestamp vldBgDtm;

	/**
	 * 온라인운영시작시분
	 */
	private String onlOpBgTmm;

	/**
	 * 온라인운영종료시분
	 */
	private String onlOpEotTmm;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '거래ID' 반환
	 */
	public String getTrnId() {
		return trnId;
	}

	/**
	 * '거래ID' 설정
	 */
	public void setTrnId(String trnId) {
		this.trnId = trnId;
	}

	/**
	 * '적용종료일시' 반환
	 */
	public Timestamp getAplEotDtm() {
		return aplEotDtm;
	}

	/**
	 * '적용종료일시' 설정
	 */
	public void setAplEotDtm(Timestamp aplEotDtm) {
		this.aplEotDtm = aplEotDtm;
	}

	/**
	 * '적용시작일시' 반환
	 */
	public Timestamp getAplBgDtm() {
		return aplBgDtm;
	}

	/**
	 * '적용시작일시' 설정
	 */
	public void setAplBgDtm(Timestamp aplBgDtm) {
		this.aplBgDtm = aplBgDtm;
	}

	/**
	 * '거래명' 반환
	 */
	public String getTrnNm() {
		return trnNm;
	}

	/**
	 * '거래명' 설정
	 */
	public void setTrnNm(String trnNm) {
		this.trnNm = trnNm;
	}

	/**
	 * '서비스중지여부' 반환
	 */
	public String getSrviStpYn() {
		return srviStpYn;
	}

	/**
	 * '서비스중지여부' 설정
	 */
	public void setSrviStpYn(String srviStpYn) {
		this.srviStpYn = srviStpYn;
	}

	/**
	 * '영업일여부' 반환
	 */
	public String getBsyYn() {
		return bsyYn;
	}

	/**
	 * '영업일여부' 설정
	 */
	public void setBsyYn(String bsyYn) {
		this.bsyYn = bsyYn;
	}

	/**
	 * '업무구분코드' 반환
	 */
	public String getBsnsDvCd() {
		return bsnsDvCd;
	}

	/**
	 * '업무구분코드' 설정
	 */
	public void setBsnsDvCd(String bsnsDvCd) {
		this.bsnsDvCd = bsnsDvCd;
	}

	/**
	 * '유효종료일시' 반환
	 */
	public Timestamp getVldEotDtm() {
		return vldEotDtm;
	}

	/**
	 * '유효종료일시' 설정
	 */
	public void setVldEotDtm(Timestamp vldEotDtm) {
		this.vldEotDtm = vldEotDtm;
	}

	/**
	 * '유효시작일시' 반환
	 */
	public Timestamp getVldBgDtm() {
		return vldBgDtm;
	}

	/**
	 * '유효시작일시' 설정
	 */
	public void setVldBgDtm(Timestamp vldBgDtm) {
		this.vldBgDtm = vldBgDtm;
	}

	/**
	 * '온라인운영시작시분' 반환
	 */
	public String getOnlOpBgTmm() {
		return onlOpBgTmm;
	}

	/**
	 * '온라인운영시작시분' 설정
	 */
	public void setOnlOpBgTmm(String onlOpBgTmm) {
		this.onlOpBgTmm = onlOpBgTmm;
	}

	/**
	 * '온라인운영종료시분' 반환
	 */
	public String getOnlOpEotTmm() {
		return onlOpEotTmm;
	}

	/**
	 * '온라인운영종료시분' 설정
	 */
	public void setOnlOpEotTmm(String onlOpEotTmm) {
		this.onlOpEotTmm = onlOpEotTmm;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0006MtDto [");
		sb.append("\n    trnId = '").append(trnId).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n    trnNm = '").append(trnNm).append("'");
		sb.append("\n    srviStpYn = '").append(srviStpYn).append("'");
		sb.append("\n    bsyYn = '").append(bsyYn).append("'");
		sb.append("\n    bsnsDvCd = '").append(bsnsDvCd).append("'");
		sb.append("\n    vldEotDtm = '").append(vldEotDtm).append("'");
		sb.append("\n    vldBgDtm = '").append(vldBgDtm).append("'");
		sb.append("\n    onlOpBgTmm = '").append(onlOpBgTmm).append("'");
		sb.append("\n    onlOpEotTmm = '").append(onlOpEotTmm).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0006MtDto : PK [");
		sb.append("\n    trnId = '").append(trnId).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
