/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.im.dto.CnIm0009TtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0009TtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.04
 * 설    명 : CN_IM0009_TT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.im.hqml.CnIm0009Tt")
public class CnIm0009TtDaoImpl extends DbioDaoSupport implements CnIm0009TtDao {

	/**
	 * CN_IM0009_TT (CN_IM0009_TT) 단건 조회.
	 * 
	 */
	public CnIm0009TtDto select(CnIm0009TtDto cnIm0009TtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009Tt.select",
				cnIm0009TtDto);

		CnIm0009TtDto foundCnIm0009TtDto = null;
		try {
			foundCnIm0009TtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIm0009TtDto),
					new BeanPropertyRowMapper<CnIm0009TtDto>(
							CnIm0009TtDto.class));
			return foundCnIm0009TtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_IM0009_TT (CN_IM0009_TT) 단건 등록.
	 * 
	 */
	public int insert(CnIm0009TtDto cnIm0009TtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009Tt.insert",
				cnIm0009TtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0009TtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0009_TT (CN_IM0009_TT) 단건 변경.
	 * 
	 */
	public int update(CnIm0009TtDto cnIm0009TtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009Tt.update",
				cnIm0009TtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0009TtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0009_TT (CN_IM0009_TT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIm0009TtDto cnIm0009TtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009Tt.delete",
				cnIm0009TtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0009TtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0009_TT (CN_IM0009_TT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIm0009TtDto> list(CnIm0009TtDto cnIm0009TtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009Tt.list",
				cnIm0009TtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIm0009TtDto), new BeanPropertyRowMapper<CnIm0009TtDto>(
				CnIm0009TtDto.class));
	}

	/**
	 * CN_IM0009_TT (CN_IM0009_TT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIm0009TtDto> cnIm0009TtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009Tt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0009TtDtos
				.size()];
		for (int i = 0; i < cnIm0009TtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0009TtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0009_TT (CN_IM0009_TT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIm0009TtDto> cnIm0009TtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009Tt.update",
				cnIm0009TtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnIm0009TtDtos
				.size()];
		for (int i = 0; i < cnIm0009TtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0009TtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0009_TT (CN_IM0009_TT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIm0009TtDto> cnIm0009TtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009Tt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0009TtDtos
				.size()];
		for (int i = 0; i < cnIm0009TtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0009TtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
