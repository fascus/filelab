/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import java.util.List;

import cuin.dbio.cn.im.dto.CnIm0010MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0010MtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.04
 * 설    명 : CN_IM0010_MT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnIm0010MtDao {

	CnIm0010MtDto select(CnIm0010MtDto cnIm0010MtDto);

	int insert(CnIm0010MtDto cnIm0010MtDto);

	int update(CnIm0010MtDto cnIm0010MtDto);

	int delete(CnIm0010MtDto cnIm0010MtDto);

	List<CnIm0010MtDto> list(CnIm0010MtDto cnIm0010MtDto);

	int[] insertList(List<CnIm0010MtDto> cnIm0010MtDtos);

	int[] updateList(List<CnIm0010MtDto> cnIm0010MtDtos);

	int[] deleteList(List<CnIm0010MtDto> cnIm0010MtDtos);

}
