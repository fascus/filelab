/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import java.util.List;

import cuin.dbio.cn.im.dto.CnIm0001MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0001MtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0001_MT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnIm0001MtDao {

	CnIm0001MtDto select(CnIm0001MtDto cnIm0001MtDto);

	int insert(CnIm0001MtDto cnIm0001MtDto);

	int update(CnIm0001MtDto cnIm0001MtDto);

	int delete(CnIm0001MtDto cnIm0001MtDto);

	List<CnIm0001MtDto> list(CnIm0001MtDto cnIm0001MtDto);

	int[] insertList(List<CnIm0001MtDto> cnIm0001MtDtos);

	int[] updateList(List<CnIm0001MtDto> cnIm0001MtDtos);

	int[] deleteList(List<CnIm0001MtDto> cnIm0001MtDtos);

}
