/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.im.dto.CnIm0002MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0002MtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0002_MT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.im.hqml.CnIm0002Mt")
public class CnIm0002MtDaoImpl extends DbioDaoSupport implements CnIm0002MtDao {

	/**
	 * CN_IM0002_MT (CN_IM0002_MT) 단건 조회.
	 * 
	 */
	public CnIm0002MtDto select(CnIm0002MtDto cnIm0002MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0002Mt.select",
				cnIm0002MtDto);

		CnIm0002MtDto foundCnIm0002MtDto = null;
		try {
			foundCnIm0002MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIm0002MtDto),
					new BeanPropertyRowMapper<CnIm0002MtDto>(
							CnIm0002MtDto.class));
			return foundCnIm0002MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_IM0002_MT (CN_IM0002_MT) 단건 등록.
	 * 
	 */
	public int insert(CnIm0002MtDto cnIm0002MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0002Mt.insert",
				cnIm0002MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0002MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0002_MT (CN_IM0002_MT) 단건 변경.
	 * 
	 */
	public int update(CnIm0002MtDto cnIm0002MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0002Mt.update",
				cnIm0002MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0002MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0002_MT (CN_IM0002_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIm0002MtDto cnIm0002MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0002Mt.delete",
				cnIm0002MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0002MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0002_MT (CN_IM0002_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIm0002MtDto> list(CnIm0002MtDto cnIm0002MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0002Mt.list",
				cnIm0002MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIm0002MtDto), new BeanPropertyRowMapper<CnIm0002MtDto>(
				CnIm0002MtDto.class));
	}

	/**
	 * CN_IM0002_MT (CN_IM0002_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIm0002MtDto> cnIm0002MtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0002Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0002MtDtos
				.size()];
		for (int i = 0; i < cnIm0002MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0002MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0002_MT (CN_IM0002_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIm0002MtDto> cnIm0002MtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0002Mt.update",
				cnIm0002MtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnIm0002MtDtos
				.size()];
		for (int i = 0; i < cnIm0002MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0002MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0002_MT (CN_IM0002_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIm0002MtDto> cnIm0002MtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0002Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0002MtDtos
				.size()];
		for (int i = 0; i < cnIm0002MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0002MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
