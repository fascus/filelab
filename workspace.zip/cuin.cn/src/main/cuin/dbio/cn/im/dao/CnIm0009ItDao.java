/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import java.util.List;

import cuin.dbio.cn.im.dto.CnIm0009ItDto;

/**
 * CN_IM0009_IT (CN_IM0009_IT) DAO 인터페이스.
 *
 * 
 */
public interface CnIm0009ItDao {

	CnIm0009ItDto select(CnIm0009ItDto cnIm0009ItDto);

	int insert(CnIm0009ItDto cnIm0009ItDto);

	int update(CnIm0009ItDto cnIm0009ItDto);

	int delete(CnIm0009ItDto cnIm0009ItDto);

	List<CnIm0009ItDto> list(CnIm0009ItDto cnIm0009ItDto);

	int[] insertList(List<CnIm0009ItDto> cnIm0009ItDtos);

	int[] updateList(List<CnIm0009ItDto> cnIm0009ItDtos);

	int[] deleteList(List<CnIm0009ItDto> cnIm0009ItDtos);

}
