/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.im.dto.CnIm0008HtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0008HtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0008_HT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.im.hqml.CnIm0008Ht")
public class CnIm0008HtDaoImpl extends DbioDaoSupport implements CnIm0008HtDao {

	/**
	 * CN_IM0008_HT (CN_IM0008_HT) 단건 조회.
	 * 
	 */
	public CnIm0008HtDto select(CnIm0008HtDto cnIm0008HtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0008Ht.select",
				cnIm0008HtDto);

		CnIm0008HtDto foundCnIm0008HtDto = null;
		try {
			foundCnIm0008HtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIm0008HtDto),
					new BeanPropertyRowMapper<CnIm0008HtDto>(
							CnIm0008HtDto.class));
			return foundCnIm0008HtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_IM0008_HT (CN_IM0008_HT) 단건 등록.
	 * 
	 */
	public int insert(CnIm0008HtDto cnIm0008HtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0008Ht.insert",
				cnIm0008HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0008HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0008_HT (CN_IM0008_HT) 단건 변경.
	 * 
	 */
	public int update(CnIm0008HtDto cnIm0008HtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0008Ht.update",
				cnIm0008HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0008HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0008_HT (CN_IM0008_HT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIm0008HtDto cnIm0008HtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0008Ht.delete",
				cnIm0008HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0008HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0008_HT (CN_IM0008_HT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIm0008HtDto> list(CnIm0008HtDto cnIm0008HtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0008Ht.list",
				cnIm0008HtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIm0008HtDto), new BeanPropertyRowMapper<CnIm0008HtDto>(
				CnIm0008HtDto.class));
	}

	/**
	 * CN_IM0008_HT (CN_IM0008_HT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIm0008HtDto> cnIm0008HtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0008Ht.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0008HtDtos
				.size()];
		for (int i = 0; i < cnIm0008HtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0008HtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0008_HT (CN_IM0008_HT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIm0008HtDto> cnIm0008HtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0008Ht.update",
				cnIm0008HtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnIm0008HtDtos
				.size()];
		for (int i = 0; i < cnIm0008HtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0008HtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0008_HT (CN_IM0008_HT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIm0008HtDto> cnIm0008HtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0008Ht.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0008HtDtos
				.size()];
		for (int i = 0; i < cnIm0008HtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0008HtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
