package cuin.dbio.cn.im.dto;

import java.io.Serializable;
import java.util.List;

/**
 * 사용자환경정보 (CN_IM0003_MT) 테이블 단위 페이지 출력 DTO.
 */
public class CnIm0003MtPgOutDto implements Serializable {

	private static final long serialVersionUID = 4844883319490823260L;

	// 페이지 단위 조회 결과
	private List<CnIm0003MtDto> resultList;

	// 추가 페이지 존재 여부
	private boolean isCont;

	public CnIm0003MtPgOutDto(List<CnIm0003MtDto> resultList, boolean isCont) {
		this.resultList = resultList;
		this.isCont = isCont;
	}

	/**
	 * 페이지 단위 레코드 목록 반환.
	 */
	public List<CnIm0003MtDto> getResultList() {
		return resultList;
	}

	/**
	 * 다음 페이지 존재 유무.
	 */
	public boolean isCont() {
		return isCont;
	}
}
