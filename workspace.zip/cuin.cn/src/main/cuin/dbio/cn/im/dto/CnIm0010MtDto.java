/**
 * 
 * 
 */
package cuin.dbio.cn.im.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0010MtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.04
 * 설    명 : CN_IM0010_MT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnIm0010MtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = 5639113336175414044L;

	/**
	 * 로그일련번호
	 */
	private Long logSeq;

	/**
	 * 발송서버명
	 */
	private String snnSrrNm;

	/**
	 * GLOBAL_ID
	 */
	private String glbId;

	/**
	 * 조건순서
	 */
	private Integer cndnSqc;

	/**
	 * 로그제목
	 */
	private String logTitl;

	/**
	 * 로그출력일시
	 */
	private Timestamp logPrtDtm;

	/**
	 * 구간수행시간
	 */
	private Integer sctPrfrTm;

	/**
	 * 서비스수행시간
	 */
	private Integer srviPrfrTm;

	/**
	 * 거래ID
	 */
	private String trnId;

	/**
	 * 화면ID
	 */
	private String scrnId;

	/**
	 * 사용자IP주소
	 */
	private String userIpAdr;

	/**
	 * 사용자ID
	 */
	private String userId;

	/**
	 * 전문데이터내용
	 */
	private String mesgDataCtt;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '로그일련번호' 반환
	 */
	public Long getLogSeq() {
		return logSeq;
	}

	/**
	 * '로그일련번호' 설정
	 */
	public void setLogSeq(Long logSeq) {
		this.logSeq = logSeq;
	}

	/**
	 * '발송서버명' 반환
	 */
	public String getSnnSrrNm() {
		return snnSrrNm;
	}

	/**
	 * '발송서버명' 설정
	 */
	public void setSnnSrrNm(String snnSrrNm) {
		this.snnSrrNm = snnSrrNm;
	}

	/**
	 * 'GLOBAL_ID' 반환
	 */
	public String getGlbId() {
		return glbId;
	}

	/**
	 * 'GLOBAL_ID' 설정
	 */
	public void setGlbId(String glbId) {
		this.glbId = glbId;
	}

	/**
	 * '조건순서' 반환
	 */
	public Integer getCndnSqc() {
		return cndnSqc;
	}

	/**
	 * '조건순서' 설정
	 */
	public void setCndnSqc(Integer cndnSqc) {
		this.cndnSqc = cndnSqc;
	}

	/**
	 * '로그제목' 반환
	 */
	public String getLogTitl() {
		return logTitl;
	}

	/**
	 * '로그제목' 설정
	 */
	public void setLogTitl(String logTitl) {
		this.logTitl = logTitl;
	}

	/**
	 * '로그출력일시' 반환
	 */
	public Timestamp getLogPrtDtm() {
		return logPrtDtm;
	}

	/**
	 * '로그출력일시' 설정
	 */
	public void setLogPrtDtm(Timestamp logPrtDtm) {
		this.logPrtDtm = logPrtDtm;
	}

	/**
	 * '구간수행시간' 반환
	 */
	public Integer getSctPrfrTm() {
		return sctPrfrTm;
	}

	/**
	 * '구간수행시간' 설정
	 */
	public void setSctPrfrTm(Integer sctPrfrTm) {
		this.sctPrfrTm = sctPrfrTm;
	}

	/**
	 * '서비스수행시간' 반환
	 */
	public Integer getSrviPrfrTm() {
		return srviPrfrTm;
	}

	/**
	 * '서비스수행시간' 설정
	 */
	public void setSrviPrfrTm(Integer srviPrfrTm) {
		this.srviPrfrTm = srviPrfrTm;
	}

	/**
	 * '거래ID' 반환
	 */
	public String getTrnId() {
		return trnId;
	}

	/**
	 * '거래ID' 설정
	 */
	public void setTrnId(String trnId) {
		this.trnId = trnId;
	}

	/**
	 * '화면ID' 반환
	 */
	public String getScrnId() {
		return scrnId;
	}

	/**
	 * '화면ID' 설정
	 */
	public void setScrnId(String scrnId) {
		this.scrnId = scrnId;
	}

	/**
	 * '사용자IP주소' 반환
	 */
	public String getUserIpAdr() {
		return userIpAdr;
	}

	/**
	 * '사용자IP주소' 설정
	 */
	public void setUserIpAdr(String userIpAdr) {
		this.userIpAdr = userIpAdr;
	}

	/**
	 * '사용자ID' 반환
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * '사용자ID' 설정
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * '전문데이터내용' 반환
	 */
	public String getMesgDataCtt() {
		return mesgDataCtt;
	}

	/**
	 * '전문데이터내용' 설정
	 */
	public void setMesgDataCtt(String mesgDataCtt) {
		this.mesgDataCtt = mesgDataCtt;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0010MtDto [");
		sb.append("\n    logSeq = '").append(logSeq).append("'");
		sb.append("\n    snnSrrNm = '").append(snnSrrNm).append("'");
		sb.append("\n    glbId = '").append(glbId).append("'");
		sb.append("\n    cndnSqc = '").append(cndnSqc).append("'");
		sb.append("\n    logTitl = '").append(logTitl).append("'");
		sb.append("\n    logPrtDtm = '").append(logPrtDtm).append("'");
		sb.append("\n    sctPrfrTm = '").append(sctPrfrTm).append("'");
		sb.append("\n    srviPrfrTm = '").append(srviPrfrTm).append("'");
		sb.append("\n    trnId = '").append(trnId).append("'");
		sb.append("\n    scrnId = '").append(scrnId).append("'");
		sb.append("\n    userIpAdr = '").append(userIpAdr).append("'");
		sb.append("\n    userId = '").append(userId).append("'");
		sb.append("\n    mesgDataCtt = '").append(mesgDataCtt).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0010MtDto : PK [");
		sb.append("\n    logSeq = '").append(logSeq).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
