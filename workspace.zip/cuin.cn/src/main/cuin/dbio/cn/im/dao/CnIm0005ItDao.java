/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import java.util.List;

import cuin.dbio.cn.im.dto.CnIm0005ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0005ItDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0005_IT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnIm0005ItDao {

	CnIm0005ItDto select(CnIm0005ItDto cnIm0005ItDto);

	int insert(CnIm0005ItDto cnIm0005ItDto);

	int update(CnIm0005ItDto cnIm0005ItDto);

	int delete(CnIm0005ItDto cnIm0005ItDto);

	List<CnIm0005ItDto> list(CnIm0005ItDto cnIm0005ItDto);

	int[] insertList(List<CnIm0005ItDto> cnIm0005ItDtos);

	int[] updateList(List<CnIm0005ItDto> cnIm0005ItDtos);

	int[] deleteList(List<CnIm0005ItDto> cnIm0005ItDtos);

}
