/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.cn.dbio.core.sys.PeriodInDto;
import cuin.dbio.cn.im.dto.CnIm0007HtDto;
import cuin.dbio.cn.im.dto.CnIm0007HtPrevInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0007HtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0007_HT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.im.hqml.CnIm0007Ht")
public class CnIm0007HtDaoImpl extends DbioDaoSupport implements CnIm0007HtDao {

	/**
	 * CN_IM0007_HT (CN_IM0007_HT) 단건 등록.
	 * 
	 */
	public int insert(CnIm0007HtDto cnIm0007HtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0007Ht.insert",
				cnIm0007HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0007HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0007_HT (CN_IM0007_HT) 현행 이력 업데이트.
	 * 
	 */
	public int closeCurrentHistory(CnIm0007HtDto cnIm0007HtDto) {
		String sql = getSql(
				"cuin.dbio.cn.im.hqml.CnIm0007Ht.closeCurrentHistory",
				cnIm0007HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0007HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0007_HT (CN_IM0007_HT) 이력 삭제.
	 * 
	 */
	public int deleteHistory(CnIm0007HtDto cnIm0007HtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0007Ht.deleteHistory",
				cnIm0007HtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0007HtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0007_HT (CN_IM0007_HT) 특정 시점의 단건 이력 조회.
	 * 
	 */
	public CnIm0007HtDto selectPrevious(CnIm0007HtPrevInDto cnIm0007HtPrevInDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0007Ht.selectPrevious",
				cnIm0007HtPrevInDto);

		CnIm0007HtDto foundCnIm0007HtDto = null;
		try {
			foundCnIm0007HtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIm0007HtPrevInDto),
					new BeanPropertyRowMapper<CnIm0007HtDto>(
							CnIm0007HtDto.class));
			return foundCnIm0007HtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * 특정 기간 동안의 이벤트(변경 내역) 조회
	 * 
	 */
	public List<CnIm0007HtDto> selectInPeriod(PeriodInDto periodInDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0007Ht.selectInPeriod",
				periodInDto);

		return queryForList(sql,
				new BeanPropertySqlParameterSource(periodInDto),
				new BeanPropertyRowMapper<CnIm0007HtDto>(CnIm0007HtDto.class));
	}

}
