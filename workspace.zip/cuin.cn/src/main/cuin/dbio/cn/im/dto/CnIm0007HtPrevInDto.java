package cuin.dbio.cn.im.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * CN_IM0007_HT (CN_IM0007_HT) 테이블 이력 단건 조회 DTO.
 */
public class CnIm0007HtPrevInDto implements Serializable {

	private static final long serialVersionUID = -7456011808078475291L;

	/**
	 * 이력 조회를 위한 기준 일시
	 */
	private Timestamp baseDtm;

	/**
	 * 거래ID
	 */
	private String trnId;

	/**
	 * 기준 일시 반환
	 */
	public Timestamp getBaseDtm() {
		return baseDtm;
	}

	/**
	 * 기준 일시 설정
	 */
	public void setBaseDtm(Timestamp baseDtm) {
		this.baseDtm = baseDtm;
	}

	/**
	 * '거래ID' 반환
	 */
	public String getTrnId() {
		return trnId;
	}

	/**
	 * '거래ID' 설정
	 */
	public void setTrnId(String trnId) {
		this.trnId = trnId;
	}

}