/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.im.dto.CnIm0010MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0010MtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.04
 * 설    명 : CN_IM0010_MT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.im.hqml.CnIm0010Mt")
public class CnIm0010MtDaoImpl extends DbioDaoSupport implements CnIm0010MtDao {

	/**
	 * CN_IM0010_MT (CN_IM0010_MT) 단건 조회.
	 * 
	 */
	public CnIm0010MtDto select(CnIm0010MtDto cnIm0010MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0010Mt.select",
				cnIm0010MtDto);

		CnIm0010MtDto foundCnIm0010MtDto = null;
		try {
			foundCnIm0010MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIm0010MtDto),
					new BeanPropertyRowMapper<CnIm0010MtDto>(
							CnIm0010MtDto.class));
			return foundCnIm0010MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_IM0010_MT (CN_IM0010_MT) 단건 등록.
	 * 
	 */
	public int insert(CnIm0010MtDto cnIm0010MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0010Mt.insert",
				cnIm0010MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0010MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0010_MT (CN_IM0010_MT) 단건 변경.
	 * 
	 */
	public int update(CnIm0010MtDto cnIm0010MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0010Mt.update",
				cnIm0010MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0010MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0010_MT (CN_IM0010_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIm0010MtDto cnIm0010MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0010Mt.delete",
				cnIm0010MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0010MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0010_MT (CN_IM0010_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIm0010MtDto> list(CnIm0010MtDto cnIm0010MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0010Mt.list",
				cnIm0010MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIm0010MtDto), new BeanPropertyRowMapper<CnIm0010MtDto>(
				CnIm0010MtDto.class));
	}

	/**
	 * CN_IM0010_MT (CN_IM0010_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIm0010MtDto> cnIm0010MtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0010Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0010MtDtos
				.size()];
		for (int i = 0; i < cnIm0010MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0010MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0010_MT (CN_IM0010_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIm0010MtDto> cnIm0010MtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0010Mt.update",
				cnIm0010MtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnIm0010MtDtos
				.size()];
		for (int i = 0; i < cnIm0010MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0010MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0010_MT (CN_IM0010_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIm0010MtDto> cnIm0010MtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0010Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0010MtDtos
				.size()];
		for (int i = 0; i < cnIm0010MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0010MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
