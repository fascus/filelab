package cuin.dbio.cn.im.dto;

import cuin.cn.dbio.core.sys.PagingInDto;

/**
 * 사용자환경정보 (CN_IM0003_MT) 테이블 단위 페이지 입력 DTO.
 */
public class CnIm0003MtPgInDto extends CnIm0003MtDto implements PagingInDto {

	private static final long serialVersionUID = -4258282370642982618L;

	// 페이지 당 레코드 수
	private int recPerPage;

	// 시작 레코드 번호
	private int beginRowNum;

	// 마지막 레코드 번호
	private int endRowNum;

	/**
	 * 페이지 당 레코드 수 반환.
	 */
	public int getRecPerPage() {
		return recPerPage;
	}

	/**
	 * 페이지 당 레코드 수 설정.
	 */
	public void setRecPerPage(int recPerPage) {
		this.recPerPage = recPerPage;
	}

	/**
	 * 시작 레코드 번호 반환.
	 */
	public int getBeginRowNum() {
		return beginRowNum;
	}

	/**
	 * 시작 레코드 번호 설정.
	 */
	public void setBeginRowNum(int beginRowNum) {
		this.beginRowNum = beginRowNum;
	}

	/**
	 * 마지막 레코드 번호 반환.
	 */
	public int getEndRowNum() {
		return endRowNum;
	}

	/**
	 * 마지막 레코드 번호 설정.
	 */
	public void setEndRowNum(int endRowNum) {
		this.endRowNum = endRowNum;
	}
}
