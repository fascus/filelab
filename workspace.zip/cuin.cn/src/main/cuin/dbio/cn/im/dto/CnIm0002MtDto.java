/**
 * 
 * 
 */
package cuin.dbio.cn.im.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0002MtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0002_MT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnIm0002MtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -893938358504634889L;

	/**
	 * 통합코드그룹ID
	 */
	private String intgCdGrpId;

	/**
	 * 통합코드
	 */
	private String intgCd;

	/**
	 * 상위통합코드
	 */
	private String hgrIntgCd;

	/**
	 * 통합코드명
	 */
	private String intgCdNm;

	/**
	 * 통합코드영문명
	 */
	private String intgCdEngNm;

	/**
	 * 통합코드설명
	 */
	private String intgCdDscr;

	/**
	 * 통합코드화면순서
	 */
	private Integer intgCdScrnSqc;

	/**
	 * 유효시작일자
	 */
	private String vldBgDt;

	/**
	 * 유효종료일자
	 */
	private String vldEotDt;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '통합코드그룹ID' 반환
	 */
	public String getIntgCdGrpId() {
		return intgCdGrpId;
	}

	/**
	 * '통합코드그룹ID' 설정
	 */
	public void setIntgCdGrpId(String intgCdGrpId) {
		this.intgCdGrpId = intgCdGrpId;
	}

	/**
	 * '통합코드' 반환
	 */
	public String getIntgCd() {
		return intgCd;
	}

	/**
	 * '통합코드' 설정
	 */
	public void setIntgCd(String intgCd) {
		this.intgCd = intgCd;
	}

	/**
	 * '상위통합코드' 반환
	 */
	public String getHgrIntgCd() {
		return hgrIntgCd;
	}

	/**
	 * '상위통합코드' 설정
	 */
	public void setHgrIntgCd(String hgrIntgCd) {
		this.hgrIntgCd = hgrIntgCd;
	}

	/**
	 * '통합코드명' 반환
	 */
	public String getIntgCdNm() {
		return intgCdNm;
	}

	/**
	 * '통합코드명' 설정
	 */
	public void setIntgCdNm(String intgCdNm) {
		this.intgCdNm = intgCdNm;
	}

	/**
	 * '통합코드영문명' 반환
	 */
	public String getIntgCdEngNm() {
		return intgCdEngNm;
	}

	/**
	 * '통합코드영문명' 설정
	 */
	public void setIntgCdEngNm(String intgCdEngNm) {
		this.intgCdEngNm = intgCdEngNm;
	}

	/**
	 * '통합코드설명' 반환
	 */
	public String getIntgCdDscr() {
		return intgCdDscr;
	}

	/**
	 * '통합코드설명' 설정
	 */
	public void setIntgCdDscr(String intgCdDscr) {
		this.intgCdDscr = intgCdDscr;
	}

	/**
	 * '통합코드화면순서' 반환
	 */
	public Integer getIntgCdScrnSqc() {
		return intgCdScrnSqc;
	}

	/**
	 * '통합코드화면순서' 설정
	 */
	public void setIntgCdScrnSqc(Integer intgCdScrnSqc) {
		this.intgCdScrnSqc = intgCdScrnSqc;
	}

	/**
	 * '유효시작일자' 반환
	 */
	public String getVldBgDt() {
		return vldBgDt;
	}

	/**
	 * '유효시작일자' 설정
	 */
	public void setVldBgDt(String vldBgDt) {
		this.vldBgDt = vldBgDt;
	}

	/**
	 * '유효종료일자' 반환
	 */
	public String getVldEotDt() {
		return vldEotDt;
	}

	/**
	 * '유효종료일자' 설정
	 */
	public void setVldEotDt(String vldEotDt) {
		this.vldEotDt = vldEotDt;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0002MtDto [");
		sb.append("\n    intgCdGrpId = '").append(intgCdGrpId).append("'");
		sb.append("\n    intgCd = '").append(intgCd).append("'");
		sb.append("\n    hgrIntgCd = '").append(hgrIntgCd).append("'");
		sb.append("\n    intgCdNm = '").append(intgCdNm).append("'");
		sb.append("\n    intgCdEngNm = '").append(intgCdEngNm).append("'");
		sb.append("\n    intgCdDscr = '").append(intgCdDscr).append("'");
		sb.append("\n    intgCdScrnSqc = '").append(intgCdScrnSqc).append("'");
		sb.append("\n    vldBgDt = '").append(vldBgDt).append("'");
		sb.append("\n    vldEotDt = '").append(vldEotDt).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0002MtDto : PK [");
		sb.append("\n    intgCdGrpId = '").append(intgCdGrpId).append("'");
		sb.append("\n    intgCd = '").append(intgCd).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
