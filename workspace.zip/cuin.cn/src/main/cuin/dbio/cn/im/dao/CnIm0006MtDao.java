/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import java.util.List;

import cuin.dbio.cn.im.dto.CnIm0006MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0006MtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0006_MT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnIm0006MtDao {

	CnIm0006MtDto select(CnIm0006MtDto cnIm0006MtDto);

	int insert(CnIm0006MtDto cnIm0006MtDto);

	int update(CnIm0006MtDto cnIm0006MtDto);

	int delete(CnIm0006MtDto cnIm0006MtDto);

	List<CnIm0006MtDto> list(CnIm0006MtDto cnIm0006MtDto);

	int[] insertList(List<CnIm0006MtDto> cnIm0006MtDtos);

	int[] updateList(List<CnIm0006MtDto> cnIm0006MtDtos);

	int[] deleteList(List<CnIm0006MtDto> cnIm0006MtDtos);

}
