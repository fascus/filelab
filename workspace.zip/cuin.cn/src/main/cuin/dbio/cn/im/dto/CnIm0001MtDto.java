/**
 * 
 * 
 */
package cuin.dbio.cn.im.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0001MtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0001_MT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnIm0001MtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = 3737997481396880585L;

	/**
	 * 통합코드그룹ID
	 */
	private String intgCdGrpId;

	/**
	 * 통합코드그룹명
	 */
	private String intgCdGrpNm;

	/**
	 * 통합코드그룹설명
	 */
	private String intgCdGrpDscr;

	/**
	 * 기준통합코드그룹ID
	 */
	private String baseIntgCdGrpId;

	/**
	 * 상위통합코드그룹ID
	 */
	private String hgrIntgCdGrpId;

	/**
	 * 유효시작일자
	 */
	private String vldBgDt;

	/**
	 * 유효종료일자
	 */
	private String vldEotDt;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '통합코드그룹ID' 반환
	 */
	public String getIntgCdGrpId() {
		return intgCdGrpId;
	}

	/**
	 * '통합코드그룹ID' 설정
	 */
	public void setIntgCdGrpId(String intgCdGrpId) {
		this.intgCdGrpId = intgCdGrpId;
	}

	/**
	 * '통합코드그룹명' 반환
	 */
	public String getIntgCdGrpNm() {
		return intgCdGrpNm;
	}

	/**
	 * '통합코드그룹명' 설정
	 */
	public void setIntgCdGrpNm(String intgCdGrpNm) {
		this.intgCdGrpNm = intgCdGrpNm;
	}

	/**
	 * '통합코드그룹설명' 반환
	 */
	public String getIntgCdGrpDscr() {
		return intgCdGrpDscr;
	}

	/**
	 * '통합코드그룹설명' 설정
	 */
	public void setIntgCdGrpDscr(String intgCdGrpDscr) {
		this.intgCdGrpDscr = intgCdGrpDscr;
	}

	/**
	 * '기준통합코드그룹ID' 반환
	 */
	public String getBaseIntgCdGrpId() {
		return baseIntgCdGrpId;
	}

	/**
	 * '기준통합코드그룹ID' 설정
	 */
	public void setBaseIntgCdGrpId(String baseIntgCdGrpId) {
		this.baseIntgCdGrpId = baseIntgCdGrpId;
	}

	/**
	 * '상위통합코드그룹ID' 반환
	 */
	public String getHgrIntgCdGrpId() {
		return hgrIntgCdGrpId;
	}

	/**
	 * '상위통합코드그룹ID' 설정
	 */
	public void setHgrIntgCdGrpId(String hgrIntgCdGrpId) {
		this.hgrIntgCdGrpId = hgrIntgCdGrpId;
	}

	/**
	 * '유효시작일자' 반환
	 */
	public String getVldBgDt() {
		return vldBgDt;
	}

	/**
	 * '유효시작일자' 설정
	 */
	public void setVldBgDt(String vldBgDt) {
		this.vldBgDt = vldBgDt;
	}

	/**
	 * '유효종료일자' 반환
	 */
	public String getVldEotDt() {
		return vldEotDt;
	}

	/**
	 * '유효종료일자' 설정
	 */
	public void setVldEotDt(String vldEotDt) {
		this.vldEotDt = vldEotDt;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0001MtDto [");
		sb.append("\n    intgCdGrpId = '").append(intgCdGrpId).append("'");
		sb.append("\n    intgCdGrpNm = '").append(intgCdGrpNm).append("'");
		sb.append("\n    intgCdGrpDscr = '").append(intgCdGrpDscr).append("'");
		sb.append("\n    baseIntgCdGrpId = '").append(baseIntgCdGrpId)
				.append("'");
		sb.append("\n    hgrIntgCdGrpId = '").append(hgrIntgCdGrpId)
				.append("'");
		sb.append("\n    vldBgDt = '").append(vldBgDt).append("'");
		sb.append("\n    vldEotDt = '").append(vldEotDt).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0001MtDto : PK [");
		sb.append("\n    intgCdGrpId = '").append(intgCdGrpId).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
