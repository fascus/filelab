/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import java.util.List;

import cuin.dbio.cn.im.dto.CnIm0008HtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0008HtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0008_HT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnIm0008HtDao {

	CnIm0008HtDto select(CnIm0008HtDto cnIm0008HtDto);

	int insert(CnIm0008HtDto cnIm0008HtDto);

	int update(CnIm0008HtDto cnIm0008HtDto);

	int delete(CnIm0008HtDto cnIm0008HtDto);

	List<CnIm0008HtDto> list(CnIm0008HtDto cnIm0008HtDto);

	int[] insertList(List<CnIm0008HtDto> cnIm0008HtDtos);

	int[] updateList(List<CnIm0008HtDto> cnIm0008HtDtos);

	int[] deleteList(List<CnIm0008HtDto> cnIm0008HtDtos);

}
