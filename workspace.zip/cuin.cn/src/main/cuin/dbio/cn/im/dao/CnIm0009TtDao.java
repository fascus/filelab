/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import java.util.List;

import cuin.dbio.cn.im.dto.CnIm0009TtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0009TtDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.04
 * 설    명 : CN_IM0009_TT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnIm0009TtDao {

	CnIm0009TtDto select(CnIm0009TtDto cnIm0009TtDto);

	int insert(CnIm0009TtDto cnIm0009TtDto);

	int update(CnIm0009TtDto cnIm0009TtDto);

	int delete(CnIm0009TtDto cnIm0009TtDto);

	List<CnIm0009TtDto> list(CnIm0009TtDto cnIm0009TtDto);

	int[] insertList(List<CnIm0009TtDto> cnIm0009TtDtos);

	int[] updateList(List<CnIm0009TtDto> cnIm0009TtDtos);

	int[] deleteList(List<CnIm0009TtDto> cnIm0009TtDtos);

}
