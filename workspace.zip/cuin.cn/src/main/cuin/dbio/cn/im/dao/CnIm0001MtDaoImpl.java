/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.im.dto.CnIm0001MtDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0001MtDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0001_MT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.im.hqml.CnIm0001Mt")
public class CnIm0001MtDaoImpl extends DbioDaoSupport implements CnIm0001MtDao {

	/**
	 * CN_IM0001_MT (CN_IM0001_MT) 단건 조회.
	 * 
	 */
	public CnIm0001MtDto select(CnIm0001MtDto cnIm0001MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0001Mt.select",
				cnIm0001MtDto);

		CnIm0001MtDto foundCnIm0001MtDto = null;
		try {
			foundCnIm0001MtDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIm0001MtDto),
					new BeanPropertyRowMapper<CnIm0001MtDto>(
							CnIm0001MtDto.class));
			return foundCnIm0001MtDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_IM0001_MT (CN_IM0001_MT) 단건 등록.
	 * 
	 */
	public int insert(CnIm0001MtDto cnIm0001MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0001Mt.insert",
				cnIm0001MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0001MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0001_MT (CN_IM0001_MT) 단건 변경.
	 * 
	 */
	public int update(CnIm0001MtDto cnIm0001MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0001Mt.update",
				cnIm0001MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0001MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0001_MT (CN_IM0001_MT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIm0001MtDto cnIm0001MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0001Mt.delete",
				cnIm0001MtDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0001MtDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0001_MT (CN_IM0001_MT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIm0001MtDto> list(CnIm0001MtDto cnIm0001MtDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0001Mt.list",
				cnIm0001MtDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIm0001MtDto), new BeanPropertyRowMapper<CnIm0001MtDto>(
				CnIm0001MtDto.class));
	}

	/**
	 * CN_IM0001_MT (CN_IM0001_MT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIm0001MtDto> cnIm0001MtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0001Mt.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0001MtDtos
				.size()];
		for (int i = 0; i < cnIm0001MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0001MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0001_MT (CN_IM0001_MT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIm0001MtDto> cnIm0001MtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0001Mt.update",
				cnIm0001MtDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnIm0001MtDtos
				.size()];
		for (int i = 0; i < cnIm0001MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0001MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0001_MT (CN_IM0001_MT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIm0001MtDto> cnIm0001MtDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0001Mt.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0001MtDtos
				.size()];
		for (int i = 0; i < cnIm0001MtDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0001MtDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
