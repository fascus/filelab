/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.im.dto.CnIm0009ItDto;

/**
 * CN_IM0009_IT (CN_IM0009_IT) DAO 구현체.
 *
 * @stereotype DAO
 * 
 * 
 */

@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.im.hqml.CnIm0009It")
public class CnIm0009ItDaoImpl extends DbioDaoSupport implements CnIm0009ItDao {

	/**
	 * CN_IM0009_IT (CN_IM0009_IT) 단건 조회.
	 * 
	 */
	public CnIm0009ItDto select(CnIm0009ItDto cnIm0009ItDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009It.select",
				cnIm0009ItDto);

		CnIm0009ItDto foundCnIm0009ItDto = null;
		try {
			foundCnIm0009ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIm0009ItDto),
					new BeanPropertyRowMapper<CnIm0009ItDto>(
							CnIm0009ItDto.class));
			return foundCnIm0009ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_IM0009_IT (CN_IM0009_IT) 단건 등록.
	 * 
	 */
	public int insert(CnIm0009ItDto cnIm0009ItDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009It.insert",
				cnIm0009ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0009ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0009_IT (CN_IM0009_IT) 단건 변경.
	 * 
	 */
	public int update(CnIm0009ItDto cnIm0009ItDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009It.update",
				cnIm0009ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0009ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0009_IT (CN_IM0009_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIm0009ItDto cnIm0009ItDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009It.delete",
				cnIm0009ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0009ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0009_IT (CN_IM0009_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIm0009ItDto> list(CnIm0009ItDto cnIm0009ItDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009It.list",
				cnIm0009ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIm0009ItDto), new BeanPropertyRowMapper<CnIm0009ItDto>(
				CnIm0009ItDto.class));
	}

	/**
	 * CN_IM0009_IT (CN_IM0009_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIm0009ItDto> cnIm0009ItDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0009ItDtos
				.size()];
		for (int i = 0; i < cnIm0009ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0009ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0009_IT (CN_IM0009_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIm0009ItDto> cnIm0009ItDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009It.update",
				cnIm0009ItDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnIm0009ItDtos
				.size()];
		for (int i = 0; i < cnIm0009ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0009ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0009_IT (CN_IM0009_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIm0009ItDto> cnIm0009ItDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0009It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0009ItDtos
				.size()];
		for (int i = 0; i < cnIm0009ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0009ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
