/**
 * 
 * 
 */
package cuin.dbio.cn.im.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

;

/**
 * 사용자환경정보이력 (CN_IM0004_HT) 입출력 DTO. 
 * 
 * @stereotype DTO
 * 
 */
public class CnIm0004HtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -4624895736821233638L;

	/**
	 * 사원번호
	 */
	private String empNo;

	/**
	 * 적용종료일시
	 */
	private Timestamp aplEotDtm;

	/**
	 * 적용시작일시
	 */
	private Timestamp aplBgDtm;

	/**
	 * 유효종료일시
	 */
	private Timestamp vldEotDtm;

	/**
	 * 유효시작일시
	 */
	private Timestamp vldBgDtm;

	/**
	 * 대리결재자사원번호
	 */
	private String prxApvrEmpNo;

	/**
	 * 알림메시지수신여부
	 */
	private String notcMsgRcveYn;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '사원번호' 반환
	 */
	public String getEmpNo() {
		return empNo;
	}

	/**
	 * '사원번호' 설정
	 */
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}

	/**
	 * '적용종료일시' 반환
	 */
	public Timestamp getAplEotDtm() {
		return aplEotDtm;
	}

	/**
	 * '적용종료일시' 설정
	 */
	public void setAplEotDtm(Timestamp aplEotDtm) {
		this.aplEotDtm = aplEotDtm;
	}

	/**
	 * '적용시작일시' 반환
	 */
	public Timestamp getAplBgDtm() {
		return aplBgDtm;
	}

	/**
	 * '적용시작일시' 설정
	 */
	public void setAplBgDtm(Timestamp aplBgDtm) {
		this.aplBgDtm = aplBgDtm;
	}

	/**
	 * '유효종료일시' 반환
	 */
	public Timestamp getVldEotDtm() {
		return vldEotDtm;
	}

	/**
	 * '유효종료일시' 설정
	 */
	public void setVldEotDtm(Timestamp vldEotDtm) {
		this.vldEotDtm = vldEotDtm;
	}

	/**
	 * '유효시작일시' 반환
	 */
	public Timestamp getVldBgDtm() {
		return vldBgDtm;
	}

	/**
	 * '유효시작일시' 설정
	 */
	public void setVldBgDtm(Timestamp vldBgDtm) {
		this.vldBgDtm = vldBgDtm;
	}

	/**
	 * '대리결재자사원번호' 반환
	 */
	public String getPrxApvrEmpNo() {
		return prxApvrEmpNo;
	}

	/**
	 * '대리결재자사원번호' 설정
	 */
	public void setPrxApvrEmpNo(String prxApvrEmpNo) {
		this.prxApvrEmpNo = prxApvrEmpNo;
	}

	/**
	 * '알림메시지수신여부' 반환
	 */
	public String getNotcMsgRcveYn() {
		return notcMsgRcveYn;
	}

	/**
	 * '알림메시지수신여부' 설정
	 */
	public void setNotcMsgRcveYn(String notcMsgRcveYn) {
		this.notcMsgRcveYn = notcMsgRcveYn;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0004HtDto [");
		sb.append("\n    empNo = '").append(empNo).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n    vldEotDtm = '").append(vldEotDtm).append("'");
		sb.append("\n    vldBgDtm = '").append(vldBgDtm).append("'");
		sb.append("\n    prxApvrEmpNo = '").append(prxApvrEmpNo).append("'");
		sb.append("\n    notcMsgRcveYn = '").append(notcMsgRcveYn).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0004HtDto : PK [");
		sb.append("\n    empNo = '").append(empNo).append("'");
		sb.append("\n    aplEotDtm = '").append(aplEotDtm).append("'");
		sb.append("\n    aplBgDtm = '").append(aplBgDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
