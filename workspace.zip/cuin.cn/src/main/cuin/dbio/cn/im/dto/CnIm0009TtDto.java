/**
 * 
 * 
 */
package cuin.dbio.cn.im.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0009TtDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.04
 * 설    명 : CN_IM0009_TT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnIm0009TtDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -7348087092188396231L;

	/**
	 * 모니터링일련번호
	 */
	private Long mntnSeq;

	/**
	 * GLOBAL_ID
	 */
	private String glbId;

	/**
	 * 거래ID
	 */
	private String trnId;

	/**
	 * 거래일자
	 */
	private String trnDt;

	/**
	 * 결과거래ID
	 */
	private String rslTrnId;

	/**
	 * 전문전송일시
	 */
	private Timestamp mesgSnDtm;

	/**
	 * 요청응답구분값
	 */
	private String rqstRspnDvVlu;

	/**
	 * 사용자IP주소
	 */
	private String userIpAdr;

	/**
	 * EAI동기구분값
	 */
	private String eaisyDvVlu;

	/**
	 * EAI비동기속성구분값
	 */
	private String eaiAsyncAtrDvVlu;

	/**
	 * 화면ID
	 */
	private String scrnId;

	/**
	 * 설치인가번호
	 */
	private String sueCuocNo;

	/**
	 * 설치지점코드
	 */
	private String sueBroCd;

	/**
	 * 설치단말기ID
	 */
	private String sueTrmlId;

	/**
	 * 설치사원번호
	 */
	private String sueEmpNo;

	/**
	 * 인가번호
	 */
	private String cuocNo;

	/**
	 * 지점코드
	 */
	private String broCd;

	/**
	 * 단말기ID
	 */
	private String trmlId;

	/**
	 * 사원번호
	 */
	private String empNo;

	/**
	 * 처리결과여부
	 */
	private String prceRslYn;

	/**
	 * 오류코드값
	 */
	private String errCdVlu;

	/**
	 * 오류전문내용
	 */
	private String errMesgCtt;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '모니터링일련번호' 반환
	 */
	public Long getMntnSeq() {
		return mntnSeq;
	}

	/**
	 * '모니터링일련번호' 설정
	 */
	public void setMntnSeq(Long mntnSeq) {
		this.mntnSeq = mntnSeq;
	}

	/**
	 * 'GLOBAL_ID' 반환
	 */
	public String getGlbId() {
		return glbId;
	}

	/**
	 * 'GLOBAL_ID' 설정
	 */
	public void setGlbId(String glbId) {
		this.glbId = glbId;
	}

	/**
	 * '거래ID' 반환
	 */
	public String getTrnId() {
		return trnId;
	}

	/**
	 * '거래ID' 설정
	 */
	public void setTrnId(String trnId) {
		this.trnId = trnId;
	}

	/**
	 * '거래일자' 반환
	 */
	public String getTrnDt() {
		return trnDt;
	}

	/**
	 * '거래일자' 설정
	 */
	public void setTrnDt(String trnDt) {
		this.trnDt = trnDt;
	}

	/**
	 * '결과거래ID' 반환
	 */
	public String getRslTrnId() {
		return rslTrnId;
	}

	/**
	 * '결과거래ID' 설정
	 */
	public void setRslTrnId(String rslTrnId) {
		this.rslTrnId = rslTrnId;
	}

	/**
	 * '전문전송일시' 반환
	 */
	public Timestamp getMesgSnDtm() {
		return mesgSnDtm;
	}

	/**
	 * '전문전송일시' 설정
	 */
	public void setMesgSnDtm(Timestamp mesgSnDtm) {
		this.mesgSnDtm = mesgSnDtm;
	}

	/**
	 * '요청응답구분값' 반환
	 */
	public String getRqstRspnDvVlu() {
		return rqstRspnDvVlu;
	}

	/**
	 * '요청응답구분값' 설정
	 */
	public void setRqstRspnDvVlu(String rqstRspnDvVlu) {
		this.rqstRspnDvVlu = rqstRspnDvVlu;
	}

	/**
	 * '사용자IP주소' 반환
	 */
	public String getUserIpAdr() {
		return userIpAdr;
	}

	/**
	 * '사용자IP주소' 설정
	 */
	public void setUserIpAdr(String userIpAdr) {
		this.userIpAdr = userIpAdr;
	}

	/**
	 * 'EAI동기구분값' 반환
	 */
	public String getEaisyDvVlu() {
		return eaisyDvVlu;
	}

	/**
	 * 'EAI동기구분값' 설정
	 */
	public void setEaisyDvVlu(String eaisyDvVlu) {
		this.eaisyDvVlu = eaisyDvVlu;
	}

	/**
	 * 'EAI비동기속성구분값' 반환
	 */
	public String getEaiAsyncAtrDvVlu() {
		return eaiAsyncAtrDvVlu;
	}

	/**
	 * 'EAI비동기속성구분값' 설정
	 */
	public void setEaiAsyncAtrDvVlu(String eaiAsyncAtrDvVlu) {
		this.eaiAsyncAtrDvVlu = eaiAsyncAtrDvVlu;
	}

	/**
	 * '화면ID' 반환
	 */
	public String getScrnId() {
		return scrnId;
	}

	/**
	 * '화면ID' 설정
	 */
	public void setScrnId(String scrnId) {
		this.scrnId = scrnId;
	}

	/**
	 * '설치인가번호' 반환
	 */
	public String getSueCuocNo() {
		return sueCuocNo;
	}

	/**
	 * '설치인가번호' 설정
	 */
	public void setSueCuocNo(String sueCuocNo) {
		this.sueCuocNo = sueCuocNo;
	}

	/**
	 * '설치지점코드' 반환
	 */
	public String getSueBroCd() {
		return sueBroCd;
	}

	/**
	 * '설치지점코드' 설정
	 */
	public void setSueBroCd(String sueBroCd) {
		this.sueBroCd = sueBroCd;
	}

	/**
	 * '설치단말기ID' 반환
	 */
	public String getSueTrmlId() {
		return sueTrmlId;
	}

	/**
	 * '설치단말기ID' 설정
	 */
	public void setSueTrmlId(String sueTrmlId) {
		this.sueTrmlId = sueTrmlId;
	}

	/**
	 * '설치사원번호' 반환
	 */
	public String getSueEmpNo() {
		return sueEmpNo;
	}

	/**
	 * '설치사원번호' 설정
	 */
	public void setSueEmpNo(String sueEmpNo) {
		this.sueEmpNo = sueEmpNo;
	}

	/**
	 * '인가번호' 반환
	 */
	public String getCuocNo() {
		return cuocNo;
	}

	/**
	 * '인가번호' 설정
	 */
	public void setCuocNo(String cuocNo) {
		this.cuocNo = cuocNo;
	}

	/**
	 * '지점코드' 반환
	 */
	public String getBroCd() {
		return broCd;
	}

	/**
	 * '지점코드' 설정
	 */
	public void setBroCd(String broCd) {
		this.broCd = broCd;
	}

	/**
	 * '단말기ID' 반환
	 */
	public String getTrmlId() {
		return trmlId;
	}

	/**
	 * '단말기ID' 설정
	 */
	public void setTrmlId(String trmlId) {
		this.trmlId = trmlId;
	}

	/**
	 * '사원번호' 반환
	 */
	public String getEmpNo() {
		return empNo;
	}

	/**
	 * '사원번호' 설정
	 */
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}

	/**
	 * '처리결과여부' 반환
	 */
	public String getPrceRslYn() {
		return prceRslYn;
	}

	/**
	 * '처리결과여부' 설정
	 */
	public void setPrceRslYn(String prceRslYn) {
		this.prceRslYn = prceRslYn;
	}

	/**
	 * '오류코드값' 반환
	 */
	public String getErrCdVlu() {
		return errCdVlu;
	}

	/**
	 * '오류코드값' 설정
	 */
	public void setErrCdVlu(String errCdVlu) {
		this.errCdVlu = errCdVlu;
	}

	/**
	 * '오류전문내용' 반환
	 */
	public String getErrMesgCtt() {
		return errMesgCtt;
	}

	/**
	 * '오류전문내용' 설정
	 */
	public void setErrMesgCtt(String errMesgCtt) {
		this.errMesgCtt = errMesgCtt;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0009TtDto [");
		sb.append("\n    mntnSeq = '").append(mntnSeq).append("'");
		sb.append("\n    glbId = '").append(glbId).append("'");
		sb.append("\n    trnId = '").append(trnId).append("'");
		sb.append("\n    trnDt = '").append(trnDt).append("'");
		sb.append("\n    rslTrnId = '").append(rslTrnId).append("'");
		sb.append("\n    mesgSnDtm = '").append(mesgSnDtm).append("'");
		sb.append("\n    rqstRspnDvVlu = '").append(rqstRspnDvVlu).append("'");
		sb.append("\n    userIpAdr = '").append(userIpAdr).append("'");
		sb.append("\n    eaisyDvVlu = '").append(eaisyDvVlu).append("'");
		sb.append("\n    eaiAsyncAtrDvVlu = '").append(eaiAsyncAtrDvVlu)
				.append("'");
		sb.append("\n    scrnId = '").append(scrnId).append("'");
		sb.append("\n    sueCuocNo = '").append(sueCuocNo).append("'");
		sb.append("\n    sueBroCd = '").append(sueBroCd).append("'");
		sb.append("\n    sueTrmlId = '").append(sueTrmlId).append("'");
		sb.append("\n    sueEmpNo = '").append(sueEmpNo).append("'");
		sb.append("\n    cuocNo = '").append(cuocNo).append("'");
		sb.append("\n    broCd = '").append(broCd).append("'");
		sb.append("\n    trmlId = '").append(trmlId).append("'");
		sb.append("\n    empNo = '").append(empNo).append("'");
		sb.append("\n    prceRslYn = '").append(prceRslYn).append("'");
		sb.append("\n    errCdVlu = '").append(errCdVlu).append("'");
		sb.append("\n    errMesgCtt = '").append(errMesgCtt).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0009TtDto : PK [");
		sb.append("\n    mntnSeq = '").append(mntnSeq).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
