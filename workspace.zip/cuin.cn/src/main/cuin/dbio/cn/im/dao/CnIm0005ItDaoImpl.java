/**
 * 
 * 
 */
package cuin.dbio.cn.im.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.im.dto.CnIm0005ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0005ItDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0005_IT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.im.hqml.CnIm0005It")
public class CnIm0005ItDaoImpl extends DbioDaoSupport implements CnIm0005ItDao {

	/**
	 * CN_IM0005_IT (CN_IM0005_IT) 단건 조회.
	 * 
	 */
	public CnIm0005ItDto select(CnIm0005ItDto cnIm0005ItDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0005It.select",
				cnIm0005ItDto);

		CnIm0005ItDto foundCnIm0005ItDto = null;
		try {
			foundCnIm0005ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnIm0005ItDto),
					new BeanPropertyRowMapper<CnIm0005ItDto>(
							CnIm0005ItDto.class));
			return foundCnIm0005ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_IM0005_IT (CN_IM0005_IT) 단건 등록.
	 * 
	 */
	public int insert(CnIm0005ItDto cnIm0005ItDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0005It.insert",
				cnIm0005ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0005ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0005_IT (CN_IM0005_IT) 단건 변경.
	 * 
	 */
	public int update(CnIm0005ItDto cnIm0005ItDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0005It.update",
				cnIm0005ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0005ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0005_IT (CN_IM0005_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnIm0005ItDto cnIm0005ItDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0005It.delete",
				cnIm0005ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnIm0005ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_IM0005_IT (CN_IM0005_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnIm0005ItDto> list(CnIm0005ItDto cnIm0005ItDto) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0005It.list",
				cnIm0005ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnIm0005ItDto), new BeanPropertyRowMapper<CnIm0005ItDto>(
				CnIm0005ItDto.class));
	}

	/**
	 * CN_IM0005_IT (CN_IM0005_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnIm0005ItDto> cnIm0005ItDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0005It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0005ItDtos
				.size()];
		for (int i = 0; i < cnIm0005ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0005ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0005_IT (CN_IM0005_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnIm0005ItDto> cnIm0005ItDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0005It.update",
				cnIm0005ItDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnIm0005ItDtos
				.size()];
		for (int i = 0; i < cnIm0005ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0005ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_IM0005_IT (CN_IM0005_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnIm0005ItDto> cnIm0005ItDtos) {
		String sql = getSql("cuin.dbio.cn.im.hqml.CnIm0005It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnIm0005ItDtos
				.size()];
		for (int i = 0; i < cnIm0005ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnIm0005ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
