/**
 * 
 * 
 */
package cuin.dbio.cn.im.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnIm0005ItDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_IM0005_IT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnIm0005ItDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = 7194407564351195465L;

	/**
	 * 건물관리번호
	 */
	private String bldgMgNo;

	/**
	 * 앞자리번지
	 */
	private String frpsHsn;

	/**
	 * 뒷자리번지
	 */
	private String rrlHsn;

	/**
	 * 산여부
	 */
	private String myn;

	/**
	 * 법정읍면동코드
	 */
	private String crjEmdCd;

	/**
	 * 시도명
	 */
	private String ctdNm;

	/**
	 * 군구명
	 */
	private String gnguNm;

	/**
	 * 법정읍면동명
	 */
	private String crjEmdNm;

	/**
	 * 법정리명
	 */
	private String crjRnm;

	/**
	 * 도로명코드
	 */
	private String rdNmCd;

	/**
	 * 도로명
	 */
	private String rdNm;

	/**
	 * 지하층수
	 */
	private Integer bsmnFln;

	/**
	 * 건물주번호
	 */
	private String bldgMnno;

	/**
	 * 건물보조번호
	 */
	private String bldgSptNo;

	/**
	 * 건물명
	 */
	private String bldgNm;

	/**
	 * 건물상세명
	 */
	private String bldgDtilNm;

	/**
	 * 읍면동일련번호
	 */
	private Long emdSeq;

	/**
	 * 행정읍면동코드
	 */
	private String adnEmdCd;

	/**
	 * 행정읍면동명
	 */
	private String adnEmdNm;

	/**
	 * 우편번호
	 */
	private String psn;

	/**
	 * 우편일련번호
	 */
	private String pslSeq;

	/**
	 * 대표건물명
	 */
	private String repBldgNm;

	/**
	 * 다량배송지명
	 */
	private String lgqtDlplNm;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '건물관리번호' 반환
	 */
	public String getBldgMgNo() {
		return bldgMgNo;
	}

	/**
	 * '건물관리번호' 설정
	 */
	public void setBldgMgNo(String bldgMgNo) {
		this.bldgMgNo = bldgMgNo;
	}

	/**
	 * '앞자리번지' 반환
	 */
	public String getFrpsHsn() {
		return frpsHsn;
	}

	/**
	 * '앞자리번지' 설정
	 */
	public void setFrpsHsn(String frpsHsn) {
		this.frpsHsn = frpsHsn;
	}

	/**
	 * '뒷자리번지' 반환
	 */
	public String getRrlHsn() {
		return rrlHsn;
	}

	/**
	 * '뒷자리번지' 설정
	 */
	public void setRrlHsn(String rrlHsn) {
		this.rrlHsn = rrlHsn;
	}

	/**
	 * '산여부' 반환
	 */
	public String getMyn() {
		return myn;
	}

	/**
	 * '산여부' 설정
	 */
	public void setMyn(String myn) {
		this.myn = myn;
	}

	/**
	 * '법정읍면동코드' 반환
	 */
	public String getCrjEmdCd() {
		return crjEmdCd;
	}

	/**
	 * '법정읍면동코드' 설정
	 */
	public void setCrjEmdCd(String crjEmdCd) {
		this.crjEmdCd = crjEmdCd;
	}

	/**
	 * '시도명' 반환
	 */
	public String getCtdNm() {
		return ctdNm;
	}

	/**
	 * '시도명' 설정
	 */
	public void setCtdNm(String ctdNm) {
		this.ctdNm = ctdNm;
	}

	/**
	 * '군구명' 반환
	 */
	public String getGnguNm() {
		return gnguNm;
	}

	/**
	 * '군구명' 설정
	 */
	public void setGnguNm(String gnguNm) {
		this.gnguNm = gnguNm;
	}

	/**
	 * '법정읍면동명' 반환
	 */
	public String getCrjEmdNm() {
		return crjEmdNm;
	}

	/**
	 * '법정읍면동명' 설정
	 */
	public void setCrjEmdNm(String crjEmdNm) {
		this.crjEmdNm = crjEmdNm;
	}

	/**
	 * '법정리명' 반환
	 */
	public String getCrjRnm() {
		return crjRnm;
	}

	/**
	 * '법정리명' 설정
	 */
	public void setCrjRnm(String crjRnm) {
		this.crjRnm = crjRnm;
	}

	/**
	 * '도로명코드' 반환
	 */
	public String getRdNmCd() {
		return rdNmCd;
	}

	/**
	 * '도로명코드' 설정
	 */
	public void setRdNmCd(String rdNmCd) {
		this.rdNmCd = rdNmCd;
	}

	/**
	 * '도로명' 반환
	 */
	public String getRdNm() {
		return rdNm;
	}

	/**
	 * '도로명' 설정
	 */
	public void setRdNm(String rdNm) {
		this.rdNm = rdNm;
	}

	/**
	 * '지하층수' 반환
	 */
	public Integer getBsmnFln() {
		return bsmnFln;
	}

	/**
	 * '지하층수' 설정
	 */
	public void setBsmnFln(Integer bsmnFln) {
		this.bsmnFln = bsmnFln;
	}

	/**
	 * '건물주번호' 반환
	 */
	public String getBldgMnno() {
		return bldgMnno;
	}

	/**
	 * '건물주번호' 설정
	 */
	public void setBldgMnno(String bldgMnno) {
		this.bldgMnno = bldgMnno;
	}

	/**
	 * '건물보조번호' 반환
	 */
	public String getBldgSptNo() {
		return bldgSptNo;
	}

	/**
	 * '건물보조번호' 설정
	 */
	public void setBldgSptNo(String bldgSptNo) {
		this.bldgSptNo = bldgSptNo;
	}

	/**
	 * '건물명' 반환
	 */
	public String getBldgNm() {
		return bldgNm;
	}

	/**
	 * '건물명' 설정
	 */
	public void setBldgNm(String bldgNm) {
		this.bldgNm = bldgNm;
	}

	/**
	 * '건물상세명' 반환
	 */
	public String getBldgDtilNm() {
		return bldgDtilNm;
	}

	/**
	 * '건물상세명' 설정
	 */
	public void setBldgDtilNm(String bldgDtilNm) {
		this.bldgDtilNm = bldgDtilNm;
	}

	/**
	 * '읍면동일련번호' 반환
	 */
	public Long getEmdSeq() {
		return emdSeq;
	}

	/**
	 * '읍면동일련번호' 설정
	 */
	public void setEmdSeq(Long emdSeq) {
		this.emdSeq = emdSeq;
	}

	/**
	 * '행정읍면동코드' 반환
	 */
	public String getAdnEmdCd() {
		return adnEmdCd;
	}

	/**
	 * '행정읍면동코드' 설정
	 */
	public void setAdnEmdCd(String adnEmdCd) {
		this.adnEmdCd = adnEmdCd;
	}

	/**
	 * '행정읍면동명' 반환
	 */
	public String getAdnEmdNm() {
		return adnEmdNm;
	}

	/**
	 * '행정읍면동명' 설정
	 */
	public void setAdnEmdNm(String adnEmdNm) {
		this.adnEmdNm = adnEmdNm;
	}

	/**
	 * '우편번호' 반환
	 */
	public String getPsn() {
		return psn;
	}

	/**
	 * '우편번호' 설정
	 */
	public void setPsn(String psn) {
		this.psn = psn;
	}

	/**
	 * '우편일련번호' 반환
	 */
	public String getPslSeq() {
		return pslSeq;
	}

	/**
	 * '우편일련번호' 설정
	 */
	public void setPslSeq(String pslSeq) {
		this.pslSeq = pslSeq;
	}

	/**
	 * '대표건물명' 반환
	 */
	public String getRepBldgNm() {
		return repBldgNm;
	}

	/**
	 * '대표건물명' 설정
	 */
	public void setRepBldgNm(String repBldgNm) {
		this.repBldgNm = repBldgNm;
	}

	/**
	 * '다량배송지명' 반환
	 */
	public String getLgqtDlplNm() {
		return lgqtDlplNm;
	}

	/**
	 * '다량배송지명' 설정
	 */
	public void setLgqtDlplNm(String lgqtDlplNm) {
		this.lgqtDlplNm = lgqtDlplNm;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0005ItDto [");
		sb.append("\n    bldgMgNo = '").append(bldgMgNo).append("'");
		sb.append("\n    frpsHsn = '").append(frpsHsn).append("'");
		sb.append("\n    rrlHsn = '").append(rrlHsn).append("'");
		sb.append("\n    myn = '").append(myn).append("'");
		sb.append("\n    crjEmdCd = '").append(crjEmdCd).append("'");
		sb.append("\n    ctdNm = '").append(ctdNm).append("'");
		sb.append("\n    gnguNm = '").append(gnguNm).append("'");
		sb.append("\n    crjEmdNm = '").append(crjEmdNm).append("'");
		sb.append("\n    crjRnm = '").append(crjRnm).append("'");
		sb.append("\n    rdNmCd = '").append(rdNmCd).append("'");
		sb.append("\n    rdNm = '").append(rdNm).append("'");
		sb.append("\n    bsmnFln = '").append(bsmnFln).append("'");
		sb.append("\n    bldgMnno = '").append(bldgMnno).append("'");
		sb.append("\n    bldgSptNo = '").append(bldgSptNo).append("'");
		sb.append("\n    bldgNm = '").append(bldgNm).append("'");
		sb.append("\n    bldgDtilNm = '").append(bldgDtilNm).append("'");
		sb.append("\n    emdSeq = '").append(emdSeq).append("'");
		sb.append("\n    adnEmdCd = '").append(adnEmdCd).append("'");
		sb.append("\n    adnEmdNm = '").append(adnEmdNm).append("'");
		sb.append("\n    psn = '").append(psn).append("'");
		sb.append("\n    pslSeq = '").append(pslSeq).append("'");
		sb.append("\n    repBldgNm = '").append(repBldgNm).append("'");
		sb.append("\n    lgqtDlplNm = '").append(lgqtDlplNm).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnIm0005ItDto : PK [");
		sb.append("\n    bldgMgNo = '").append(bldgMgNo).append("'");
		sb.append("\n    frpsHsn = '").append(frpsHsn).append("'");
		sb.append("\n    rrlHsn = '").append(rrlHsn).append("'");
		sb.append("\n    myn = '").append(myn).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
