/**
 * 
 * 
 */
package cuin.dbio.cn.sm.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.sm.dto.CnSm0002ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnSm0002ItDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_SM0002_IT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.sm.hqml.CnSm0002It")
public class CnSm0002ItDaoImpl extends DbioDaoSupport implements CnSm0002ItDao {

	/**
	 * CN_SM0002_IT (CN_SM0002_IT) 단건 조회.
	 * 
	 */
	public CnSm0002ItDto select(CnSm0002ItDto cnSm0002ItDto) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0002It.select",
				cnSm0002ItDto);

		CnSm0002ItDto foundCnSm0002ItDto = null;
		try {
			foundCnSm0002ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnSm0002ItDto),
					new BeanPropertyRowMapper<CnSm0002ItDto>(
							CnSm0002ItDto.class));
			return foundCnSm0002ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_SM0002_IT (CN_SM0002_IT) 단건 등록.
	 * 
	 */
	public int insert(CnSm0002ItDto cnSm0002ItDto) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0002It.insert",
				cnSm0002ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnSm0002ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_SM0002_IT (CN_SM0002_IT) 단건 변경.
	 * 
	 */
	public int update(CnSm0002ItDto cnSm0002ItDto) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0002It.update",
				cnSm0002ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnSm0002ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_SM0002_IT (CN_SM0002_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnSm0002ItDto cnSm0002ItDto) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0002It.delete",
				cnSm0002ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnSm0002ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_SM0002_IT (CN_SM0002_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnSm0002ItDto> list(CnSm0002ItDto cnSm0002ItDto) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0002It.list",
				cnSm0002ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnSm0002ItDto), new BeanPropertyRowMapper<CnSm0002ItDto>(
				CnSm0002ItDto.class));
	}

	/**
	 * CN_SM0002_IT (CN_SM0002_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnSm0002ItDto> cnSm0002ItDtos) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0002It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnSm0002ItDtos
				.size()];
		for (int i = 0; i < cnSm0002ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnSm0002ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_SM0002_IT (CN_SM0002_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnSm0002ItDto> cnSm0002ItDtos) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0002It.update",
				cnSm0002ItDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnSm0002ItDtos
				.size()];
		for (int i = 0; i < cnSm0002ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnSm0002ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_SM0002_IT (CN_SM0002_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnSm0002ItDto> cnSm0002ItDtos) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0002It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnSm0002ItDtos
				.size()];
		for (int i = 0; i < cnSm0002ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnSm0002ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
