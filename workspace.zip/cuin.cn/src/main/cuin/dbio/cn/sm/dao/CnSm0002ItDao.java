/**
 * 
 * 
 */
package cuin.dbio.cn.sm.dao;

import java.util.List;

import cuin.dbio.cn.sm.dto.CnSm0002ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnSm0002ItDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_SM0002_IT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnSm0002ItDao {

	CnSm0002ItDto select(CnSm0002ItDto cnSm0002ItDto);

	int insert(CnSm0002ItDto cnSm0002ItDto);

	int update(CnSm0002ItDto cnSm0002ItDto);

	int delete(CnSm0002ItDto cnSm0002ItDto);

	List<CnSm0002ItDto> list(CnSm0002ItDto cnSm0002ItDto);

	int[] insertList(List<CnSm0002ItDto> cnSm0002ItDtos);

	int[] updateList(List<CnSm0002ItDto> cnSm0002ItDtos);

	int[] deleteList(List<CnSm0002ItDto> cnSm0002ItDtos);

}
