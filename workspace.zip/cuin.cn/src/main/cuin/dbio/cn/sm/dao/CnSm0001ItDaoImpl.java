/**
 * 
 * 
 */
package cuin.dbio.cn.sm.dao;

import hone.dbio.annotation.HqmlAnnotation;
import hone.dbio.support.DbioDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.dbio.cn.sm.dto.CnSm0001ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnSm0001ItDaoImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_SM0001_IT DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 * @stereotype DAO
 */
@Repository
@HqmlAnnotation(id = "cuin.dbio.cn.sm.hqml.CnSm0001It")
public class CnSm0001ItDaoImpl extends DbioDaoSupport implements CnSm0001ItDao {

	/**
	 * CN_SM0001_IT (CN_SM0001_IT) 단건 조회.
	 * 
	 */
	public CnSm0001ItDto select(CnSm0001ItDto cnSm0001ItDto) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0001It.select",
				cnSm0001ItDto);

		CnSm0001ItDto foundCnSm0001ItDto = null;
		try {
			foundCnSm0001ItDto = queryForObject(sql,
					new BeanPropertySqlParameterSource(cnSm0001ItDto),
					new BeanPropertyRowMapper<CnSm0001ItDto>(
							CnSm0001ItDto.class));
			return foundCnSm0001ItDto;
		} catch (EmptyResultDataAccessException ignored) {
			return null;
		}
	}

	/**
	 * CN_SM0001_IT (CN_SM0001_IT) 단건 등록.
	 * 
	 */
	public int insert(CnSm0001ItDto cnSm0001ItDto) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0001It.insert",
				cnSm0001ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnSm0001ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_SM0001_IT (CN_SM0001_IT) 단건 변경.
	 * 
	 */
	public int update(CnSm0001ItDto cnSm0001ItDto) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0001It.update",
				cnSm0001ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnSm0001ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_SM0001_IT (CN_SM0001_IT) 단건 삭제 (논리).
	 * 
	 */
	public int delete(CnSm0001ItDto cnSm0001ItDto) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0001It.delete",
				cnSm0001ItDto);
		BeanPropertySqlParameterSource sqlParam = new BeanPropertySqlParameterSource(
				cnSm0001ItDto);
		return update(sql, sqlParam);
	}

	/**
	 * CN_SM0001_IT (CN_SM0001_IT) 동적 목록 쿼리.
	 * 
	 */
	public List<CnSm0001ItDto> list(CnSm0001ItDto cnSm0001ItDto) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0001It.list",
				cnSm0001ItDto);

		return queryForList(sql, new BeanPropertySqlParameterSource(
				cnSm0001ItDto), new BeanPropertyRowMapper<CnSm0001ItDto>(
				CnSm0001ItDto.class));
	}

	/**
	 * CN_SM0001_IT (CN_SM0001_IT) 일괄 등록.
	 * 
	 */
	public int[] insertList(List<CnSm0001ItDto> cnSm0001ItDtos) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0001It.insert");

		SqlParameterSource[] params = new SqlParameterSource[cnSm0001ItDtos
				.size()];
		for (int i = 0; i < cnSm0001ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnSm0001ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_SM0001_IT (CN_SM0001_IT) 일괄 변경.
	 * 
	 */
	public int[] updateList(List<CnSm0001ItDto> cnSm0001ItDtos) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0001It.update",
				cnSm0001ItDtos.get(0));

		SqlParameterSource[] params = new SqlParameterSource[cnSm0001ItDtos
				.size()];
		for (int i = 0; i < cnSm0001ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnSm0001ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

	/**
	 * CN_SM0001_IT (CN_SM0001_IT) 일괄 삭제.
	 * 
	 */
	public int[] deleteList(List<CnSm0001ItDto> cnSm0001ItDtos) {
		String sql = getSql("cuin.dbio.cn.sm.hqml.CnSm0001It.delete");

		SqlParameterSource[] params = new SqlParameterSource[cnSm0001ItDtos
				.size()];
		for (int i = 0; i < cnSm0001ItDtos.size(); i++) {
			params[i] = new BeanPropertySqlParameterSource(
					cnSm0001ItDtos.get(i));
		}

		return batchUpdate(sql, params);
	}

}
