/**
 * 
 * 
 */
package cuin.dbio.cn.sm.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import cuin.cn.dbio.core.sys.EntityDto;
import cuin.cn.dbio.core.sys.ServiceInDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnSm0001ItDto.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_SM0001_IT 입출력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnSm0001ItDto implements Serializable, EntityDto, ServiceInDto {
	private static final long serialVersionUID = -2285650020531090943L;

	/**
	 * 달력일자
	 */
	private String cldDt;

	/**
	 * 요일구분코드
	 */
	private String dywDvCd;

	/**
	 * 휴일여부
	 */
	private String hdyYn;

	/**
	 * 사용여부
	 */
	private String useYn;

	/**
	 * 프로그램ID
	 */
	private String prgId;

	/**
	 * 생성자번호
	 */
	private String cnrrNo;

	/**
	 * 생성일시
	 */
	private Timestamp crtnDtm;

	/**
	 * 수정자번호
	 */
	private String ameNo;

	/**
	 * 수정일시
	 */
	private Timestamp uptDtm;

	/**
	 * '달력일자' 반환
	 */
	public String getCldDt() {
		return cldDt;
	}

	/**
	 * '달력일자' 설정
	 */
	public void setCldDt(String cldDt) {
		this.cldDt = cldDt;
	}

	/**
	 * '요일구분코드' 반환
	 */
	public String getDywDvCd() {
		return dywDvCd;
	}

	/**
	 * '요일구분코드' 설정
	 */
	public void setDywDvCd(String dywDvCd) {
		this.dywDvCd = dywDvCd;
	}

	/**
	 * '휴일여부' 반환
	 */
	public String getHdyYn() {
		return hdyYn;
	}

	/**
	 * '휴일여부' 설정
	 */
	public void setHdyYn(String hdyYn) {
		this.hdyYn = hdyYn;
	}

	/**
	 * '사용여부' 반환
	 */
	public String getUseYn() {
		return useYn;
	}

	/**
	 * '사용여부' 설정
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	/**
	 * '프로그램ID' 반환
	 */
	public String getPrgId() {
		return prgId;
	}

	/**
	 * '프로그램ID' 설정
	 */
	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	/**
	 * '생성자번호' 반환
	 */
	public String getCnrrNo() {
		return cnrrNo;
	}

	/**
	 * '생성자번호' 설정
	 */
	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	/**
	 * '생성일시' 반환
	 */
	public Timestamp getCrtnDtm() {
		return crtnDtm;
	}

	/**
	 * '생성일시' 설정
	 */
	public void setCrtnDtm(Timestamp crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	/**
	 * '수정자번호' 반환
	 */
	public String getAmeNo() {
		return ameNo;
	}

	/**
	 * '수정자번호' 설정
	 */
	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}

	/**
	 * '수정일시' 반환
	 */
	public Timestamp getUptDtm() {
		return uptDtm;
	}

	/**
	 * '수정일시' 설정
	 */
	public void setUptDtm(Timestamp uptDtm) {
		this.uptDtm = uptDtm;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnSm0001ItDto [");
		sb.append("\n    cldDt = '").append(cldDt).append("'");
		sb.append("\n    dywDvCd = '").append(dywDvCd).append("'");
		sb.append("\n    hdyYn = '").append(hdyYn).append("'");
		sb.append("\n    useYn = '").append(useYn).append("'");
		sb.append("\n    prgId = '").append(prgId).append("'");
		sb.append("\n    cnrrNo = '").append(cnrrNo).append("'");
		sb.append("\n    crtnDtm = '").append(crtnDtm).append("'");
		sb.append("\n    ameNo = '").append(ameNo).append("'");
		sb.append("\n    uptDtm = '").append(uptDtm).append("'");
		sb.append("\n]");

		return sb.toString();
	}

	@Override
	public String getPKValues() {
		StringBuilder sb = new StringBuilder();

		sb.append("CnSm0001ItDto : PK [");
		sb.append("\n    cldDt = '").append(cldDt).append("'");
		sb.append("\n]");

		return sb.toString();
	}

}
