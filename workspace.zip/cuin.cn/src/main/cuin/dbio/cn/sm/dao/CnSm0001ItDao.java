/**
 * 
 * 
 */
package cuin.dbio.cn.sm.dao;

import java.util.List;

import cuin.dbio.cn.sm.dto.CnSm0001ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnSm0001ItDao.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_SM0001_IT DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 *
 */
public interface CnSm0001ItDao {

	CnSm0001ItDto select(CnSm0001ItDto cnSm0001ItDto);

	int insert(CnSm0001ItDto cnSm0001ItDto);

	int update(CnSm0001ItDto cnSm0001ItDto);

	int delete(CnSm0001ItDto cnSm0001ItDto);

	List<CnSm0001ItDto> list(CnSm0001ItDto cnSm0001ItDto);

	int[] insertList(List<CnSm0001ItDto> cnSm0001ItDtos);

	int[] updateList(List<CnSm0001ItDto> cnSm0001ItDtos);

	int[] deleteList(List<CnSm0001ItDto> cnSm0001ItDtos);

}
