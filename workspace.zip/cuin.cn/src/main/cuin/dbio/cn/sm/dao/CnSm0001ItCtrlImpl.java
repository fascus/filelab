/**
 * 
 * 
 */
package cuin.dbio.cn.sm.dao;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cuin.cn.dbio.core.sys.DbioUpdateCallback;
import cuin.cn.dbio.core.sys.DbioUtils;
import cuin.cn.dbio.core.sys.ServiceInDto;
import cuin.cn.exception.CuinRecordExistsException;
import cuin.cn.exception.CuinRecordNotExistsException;
import cuin.cn.util.BeanUtils;
import cuin.dbio.cn.sm.dto.CnSm0001ItDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : CnSm0001ItCtrlImpl.java
 * 작 성 자 : 시스템 자동 생성
 * 작 성 일 : 2013.12.01
 * 설    명 : CN_SM0001_IT DBIO 컨트롤러 구현체.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
@Component
public class CnSm0001ItCtrlImpl implements CnSm0001ItCtrl {

	private final static Logger logger = LoggerFactory
			.getLogger(CnSm0001ItCtrlImpl.class);

	// CN_SM0001_IT (CN_SM0001_IT) DAO
	@Autowired
	private CnSm0001ItDao cnSm0001ItDao;

	private DbioUpdateCallback dbioUpdateCallback;

	/**
	 * 단건 조회 (select single record).
	 *
	 * @param serviceInDto 서비스 입력 DTO (PK 컬럼들을 포함하고 있어야 함).
	 * @return 테이블 DTO (CnSm0001ItDao), 존재하지 않을 경우 null 반환.
	 */
	@Override
	public CnSm0001ItDto select(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnSm0001ItDto cnSm0001ItDto = BeanUtils.toBean(serviceInDto,
				CnSm0001ItDto.class);
		CnSm0001ItDto foundCnSm0001ItDto = cnSm0001ItDao.select(cnSm0001ItDto);
		if (foundCnSm0001ItDto != null
				&& "Y".equals(foundCnSm0001ItDto.getUseYn())) {
			return foundCnSm0001ItDto;
		} else {
			return null;
		}
	}

	/**
	 * 단건 등록 (insert single record).
	 * 이력 테이블이 존재하고, 이력 저장 방식이 '현행'이면 이력 테이블에도 레코드를 추가함.
	 *
	 * @param serviceInDto 서비스 입력 DTO (테이블 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 등록되면 1 반환
	 * @throws CuinRecordExistsException 이미 존재하는 레코드 등록을 시도한 경우 예외 발생
	 */
	@Override
	public int insert(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnSm0001ItDto cnSm0001ItDto = BeanUtils.toBean(serviceInDto,
				CnSm0001ItDto.class);

		CnSm0001ItDto existingDto = cnSm0001ItDao.select(cnSm0001ItDto);
		if (existingDto != null) {
			if ("N".equals(existingDto.getUseYn())) {
				DbioUtils.setSysProperties(cnSm0001ItDto);

				return cnSm0001ItDao.update(cnSm0001ItDto);
			} else {
				String errMsg = "A record with the same identity already exists in database. "
						+ cnSm0001ItDto.getPKValues();
				logger.error(errMsg);
				throw new CuinRecordExistsException(errMsg);
			}
		}

		DbioUtils.setSysProperties(cnSm0001ItDto);
		return cnSm0001ItDao.insert(cnSm0001ItDto);
	}

	/**
	 * 단건 변경 (update single record).
	 * 이력 테이블이 존재하면 이력 테이블에도 레코드를 추가함.
	 *
	 * @param serviceInDto 서비스 입력 DTO (테이블 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 변경되면 1 반환
	 * @throws CuinRecordNotExistsException 변경 대상 레코드가 존재하지 않을 경우 예외 발생.
	 */
	@Override
	public int update(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnSm0001ItDto newCnSm0001ItDto = BeanUtils.toBean(serviceInDto,
				CnSm0001ItDto.class);

		// 마스터 테이블에서 과거 데이터 추출
		CnSm0001ItDto oldCnSm0001ItDto = checkExists(newCnSm0001ItDto);
		// 마스터 레코드 업데이트
		DbioUtils.setSysProperties(newCnSm0001ItDto, oldCnSm0001ItDto);
		return cnSm0001ItDao.update(newCnSm0001ItDto);
	}

	/**
	 * 단건 삭제 (delete single record).
	 * 이력 테이블이 존재하면 이력 테이블 레코드 또한 삭제 처리.
	 *
	 * @param serviceInDto 서비스 입력 DTO (PK 컬럼을 모두 포함하고 있어야 함).
	 * @return 정상 변경되면 1 반환
	 * @throws CuinRecordNotExistsException 삭제 대상 레코드가 존재하지 않을 경우 예외 발생.
	 */
	@Override
	public int delete(ServiceInDto serviceInDto) {
		if (logger.isTraceEnabled()) {
			logger.trace("ServiceInDto [" + serviceInDto.getClass().getName()
					+ "]\n" + serviceInDto.toString());
		}

		CnSm0001ItDto cnSm0001ItDto = BeanUtils.toBean(serviceInDto,
				CnSm0001ItDto.class);

		// 삭제 대상 레코드 존재 여부 확인
		CnSm0001ItDto oldCnSm0001ItDto = checkExists(cnSm0001ItDto);

		// 마스터 테이블 삭제
		DbioUtils.setSysProperties(cnSm0001ItDto, oldCnSm0001ItDto);

		int deleteCnt = cnSm0001ItDao.delete(cnSm0001ItDto);

		return deleteCnt;
	}

	/**
	 * 변경 혹은 삭제 대상 레코드 존재 여부 검사.
	 *
	 * @param cnSm0001ItDto 변경 대상 레코드의 primary key 값을 포함한 DTO
	 * @return 변경 혹은 삭제 대상 레코드
	 */
	private CnSm0001ItDto checkExists(CnSm0001ItDto cnSm0001ItDto) {
		CnSm0001ItDto storedDto = cnSm0001ItDao.select(cnSm0001ItDto);
		if (storedDto == null) {
			String errMsg = "Requested record not found. \n"
					+ cnSm0001ItDto.getPKValues();
			logger.error(errMsg);
			throw new CuinRecordNotExistsException(errMsg);
		}

		return storedDto;
	}

	/**
	 * CN_SM0001_IT 일괄 등록
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] insertList(List serviceInDtoList) {
		if (dbioUpdateCallback == null) {
			List<CnSm0001ItDto> tablsDtoList = new ArrayList<CnSm0001ItDto>();
			for (Object dto : serviceInDtoList) {
				CnSm0001ItDto tableDto = BeanUtils.toBean(dto,
						CnSm0001ItDto.class);
				DbioUtils.setSysProperties(tableDto);
				tablsDtoList.add(tableDto);
			}
			return cnSm0001ItDao.insertList(tablsDtoList);
		} else {
			int[] results = new int[serviceInDtoList.size()];
			int idx = 0;
			for (Object dto : serviceInDtoList) {
				dbioUpdateCallback.updateDto(dto);
				results[idx++] = insert((ServiceInDto) dto);
			}
			return results;
		}
	}

	/**
	 * CN_SM0001_IT 일괄 변경
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] updateList(List serviceInDtoList) {
		int[] results = new int[serviceInDtoList.size()];
		int idx = 0;
		for (Object dto : serviceInDtoList) {
			if (dbioUpdateCallback != null) {
				dbioUpdateCallback.updateDto(dto);
			}
			results[idx++] = update((ServiceInDto) dto);
		}
		return results;
		/* 
		List<CnSm0001ItDto> tablsDtoList = new ArrayList<CnSm0001ItDto>();
		for (Object dto : serviceInDtoList) {
			CnSm0001ItDto tableDto = BeanUtils.toBean(dto, CnSm0001ItDto.class);
			if (dbioUpdateCallback != null) {
				dbioUpdateCallback.updateDto(tableDto);
			}
		    DbioUtils.setSysProperties(tableDto);
			tablsDtoList.add(tableDto);
		}	
		return cnSm0001ItDao.updateList(tablsDtoList);
		 */
	}

	/**
	 * CN_SM0001_IT 일괄 삭제
	 *
	 * @param serviceInDtoList 서비스 객체 리스트
	 */
	public int[] deleteList(List serviceInDtoList) {

		int listSize = serviceInDtoList.size();
		int[] deleteResults = new int[listSize];
		for (int idx = 0; idx < listSize; idx++) {
			CnSm0001ItDto tableDto = BeanUtils.toBean(
					serviceInDtoList.get(idx), CnSm0001ItDto.class);

			DbioUtils.setSysProperties(tableDto);
			deleteResults[idx] = cnSm0001ItDao.delete(tableDto);
		}
		return deleteResults;
	}

	public void setBatchCallback(DbioUpdateCallback dbioUpdateCallback) {
		this.dbioUpdateCallback = dbioUpdateCallback;
	}

}
