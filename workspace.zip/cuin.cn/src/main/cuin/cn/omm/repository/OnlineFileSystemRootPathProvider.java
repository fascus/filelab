package cuin.cn.omm.repository;

import hone.common.util.EnvUtils;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : OMM API
 * 파 일 명 : OnlineFileSystemRootPathProvider.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.11.20
 * 설    명 : 온라인 서비스 저장소 루트 경로 반환
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class OnlineFileSystemRootPathProvider implements FileSystemRootPathProvider {

	@Override
	public String getRootPath() {
		return EnvUtils.getProperty(EnvUtils.FILE_IO_ROOT_PATH);
	}

}
