package cuin.cn.omm.repository;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.springframework.core.io.AbstractResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : OMM API
 * 파 일 명 : OnlineFileSystemResource.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.11.24
 * 설    명 : 온라인 서비스 저장소 루트 경로 반환
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class OnlineFileSystemResource extends AbstractResource {

	private static FileSystemRootPathProvider fileSystemRootPathProvider = new OnlineFileSystemRootPathProvider();
	private final File file;
	private final String path;

	public OnlineFileSystemResource(String path) {
		Assert.notNull(path);

		path = fileSystemRootPathProvider.getRootPath() + File.separator + path;
		file = new File(path);
		this.path = StringUtils.cleanPath(path);
	}

	public final String getPath() {
		return path;
	}

	public boolean exists() {
		return file.exists();
	}

	public boolean isReadable() {
		return file.canRead() && !file.isDirectory();
	}

	public InputStream getInputStream() throws IOException {
		return new FileInputStream(file);
	}

	public File getFile() {
		return file;
	}

	public long contentLength() throws IOException {
		return file.length();
	}

	public Resource createRelative(String relativePath) {
		String pathToUse = StringUtils.applyRelativePath(path, relativePath);
		return new FileSystemResource(pathToUse);
	}

	public String getFilename() {
		return file.getName();
	}

	public String getDescription() {
		return (new StringBuilder("file [")).append(file.getAbsolutePath()).append("]").toString();
	}

	public boolean isWritable() {
		return file.canWrite() && !file.isDirectory();
	}

	public OutputStream getOutputStream() throws IOException {
		return new FileOutputStream(file);
	}
}
