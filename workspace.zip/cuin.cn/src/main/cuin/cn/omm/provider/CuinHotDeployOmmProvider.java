package cuin.cn.omm.provider;

import hone.omm.OmmException;
import hone.omm.loader.OmmLoader;
import hone.omm.model.OmmMap;
import hone.omm.provider.OmmMapNotFoundException;
import hone.omm.provider.OmmProvider;

import org.springframework.beans.factory.InitializingBean;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : OMM API
 * 파 일 명 : CuinHotDeployOmmProvider.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.07.21
 * 설    명 : 신협공제 Hot-deploy OMM Provider 기본 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CuinHotDeployOmmProvider implements OmmProvider, InitializingBean {

	private OmmLoader ommLoader;

	public void setOmmLoader(OmmLoader ommLoader) {
		this.ommLoader = ommLoader;
	}

	public OmmMap get(String msgId) {

		OmmMap ommMap = ommLoader.load(msgId);

		if (ommMap == null) {
			throw new OmmMapNotFoundException("Can not find a object message mapping. msgId = [" + msgId + "]");
		}
		return ommMap;
	}

	public void afterPropertiesSet() {
		if (ommLoader == null) {
			throw new OmmException("Please inject OMM Loader.");
		}
	}
}
