package cuin.cn.omm.file;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : OMM API
 * 파 일 명 : FileSystemRootPathProvider.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.10.28
 * 설    명 : 파일 저장소 루트 경로 반환 인터페이스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface FileSystemRootPathProvider {

	String getRootPath();

}
