package cuin.cn.omm.file;

import hone.core.util.ApplicationContextHolder;
import hone.omm.model.OmmMap;
import hone.omm.provider.OmmProvider;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.FileSystemResource;

/**
 * 파일 시스템 기반의 파일 아이템 쓰기 (file system based file item writer)
 * 
 * @param <T> 출력 DTO 클래스
 */
public abstract class FileSystemOmmFileItemWriter<T> {
	private static final Logger logger = LoggerFactory.getLogger(FileSystemOmmFileItemWriter.class);
	private static final String DEFAULT_LINE_FEED = "\n";
	private static final String FILE_SEPERATOR = "/";

	private String resourcePath;
	private OutputStream outputStream;

	private OmmProvider ommProvider;
	private String ommMapId;
	private OmmMap ommMap;

	protected boolean forceLinefeed = false;

	private FileSystemRootPathProvider fileSystemRootPathProvider;

	/**
	 * OMM 프로바이더 설정.
	 * 
	 * @param ommProvider
	 */
	public void setOmmProvider(OmmProvider ommProvider) {
		this.ommProvider = ommProvider;
	}

	/**
	 * OMM 맵 ID 설정.
	 * 
	 * @param ommMapId
	 */
	public void setOmmMapId(String ommMapId) {
		this.ommMapId = ommMapId;
	}

	/**
	 * Public setter for 'file system root path' provider
	 */
	public void setRootPathProvider(FileSystemRootPathProvider fileSystemRootPathProvider) {
		this.fileSystemRootPathProvider = fileSystemRootPathProvider;
	}

	/**
	 * Public setter for the input resource path.
	 */
	public void setResourcePath(String resourcePath) {
		this.resourcePath = resourcePath;
	}

	/**
	 * 줄바꿈 문자 추가 여부
	 */
	public void setForceLinefeed(boolean forceLinefeed) {
		this.forceLinefeed = forceLinefeed;
	}

	public void open() {
		if (ommProvider == null) {
			ommProvider = ApplicationContextHolder.getApplicationContext().getBean(OmmProvider.class);
		}
		if (ommMapId == null) {
			throw new IllegalStateException("OMM ID must be set");
		}
		if (resourcePath == null) {
			throw new IllegalStateException("Output resource path must be set");
		}
		if (fileSystemRootPathProvider == null) {
			fileSystemRootPathProvider = new OnlineFileSystemRootPathProvider();
		}

		String resourceAbsPath = fileSystemRootPathProvider.getRootPath() + FILE_SEPERATOR + resourcePath;

		// 쓰기 파일 폴더 생성
		int lastSeperatorIndex = resourceAbsPath.lastIndexOf(FILE_SEPERATOR);
		if (lastSeperatorIndex > -1) {
			String resourceFolder = resourceAbsPath.substring(0, lastSeperatorIndex);
			new File(resourceFolder).mkdirs();
		}

		FileSystemResource resource = new FileSystemResource(new File(resourceAbsPath));

		try {
			outputStream = resource.getOutputStream();
		} catch (IOException e) {
			outputStream = null;
			throw new IllegalArgumentException("Cannot write to output resource : " + resourceAbsPath, e);
		}
		ommMap = ommProvider.get(ommMapId);
		afterOpen(ommMap, outputStream);
	}

	/**
	 * 출력 스트림을 이용해 writer 초기화
	 */
	protected abstract void afterOpen(OmmMap ommMap, OutputStream outputStream);

	/**
	 * 줄바꿈 문자 출력
	 */
	protected void writeLineFeed() {
		try {
			String lineFeed = ommMap.getLineFeed();
			if (lineFeed == null) {
				lineFeed = DEFAULT_LINE_FEED;
			}
			outputStream.write(lineFeed.getBytes());
		} catch (IOException e) {
			logger.error("Error while line feed character to output stream", e);
		}
	}

	public void close() {
		beforeClose();
		if (outputStream != null) {
			try {
				outputStream.close();
			} catch (IOException e) {
				logger.error("Error while close output stream", e);
			}
			outputStream = null;
		}
		resourcePath = null;
	}

	/**
	 * 출력 스트림을 닫기 전에 전처리 작업 수행
	 */
	protected abstract void beforeClose();
}
