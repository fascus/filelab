package cuin.cn.omm.loader;

import hone.omm.OmmException;
import hone.omm.loader.OmmLoader;
import hone.omm.loader.OmmLoadingException;
import hone.omm.loader.fs.AbstractFileSystemOmmLoader;
import hone.omm.model.OmmMap;

import java.io.BufferedReader;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.FileSystemResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.EncodedResource;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : OMM API
 * 파 일 명 : FileSystemOmmLoader.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.07.29
 * 설    명 : 파일 시스템에서 OMM 맵 파일 로드.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class FileSystemOmmLoader extends AbstractFileSystemOmmLoader implements OmmLoader, InitializingBean {

	private static final Logger logger = LoggerFactory.getLogger(FileSystemOmmLoader.class);
	private static final String SEPERATOR = "/";
	private static final String OMM_FILE_EXT = ".mmap";
	private ResourceLoader resourceLoader;
	private String rootPath;

	@Override
	public void afterPropertiesSet() {
		try {
			super.afterPropertiesSet();
		} catch (Exception e) {
			throw new OmmException(e.getMessage(), e);
		}
		resourceLoader = new FileSystemResourceLoader();
	}

	public void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}

	@Override
	public OmmMap load(String ommId) {

		try {
			String replacedPath = ommId.replaceAll("\\.", SEPERATOR);
			StringBuilder absPathBuf = new StringBuilder();
			absPathBuf.append("file:").append(rootPath).append(SEPERATOR).append(replacedPath).append(OMM_FILE_EXT);
			String absPath = absPathBuf.toString();
			if (logger.isDebugEnabled()) {
				logger.debug("Load OMM map at '" + absPath + "'");
			}
			Resource resource = resourceLoader.getResource(absPath);
			EncodedResource encodedResource = new EncodedResource(resource, "UTF-8");
			BufferedReader bufferedReader = new BufferedReader(encodedResource.getReader());
			StringBuilder sb = new StringBuilder();
			String line = bufferedReader.readLine();
			while (line != null) {
				sb.append(line).append('\n');
				line = bufferedReader.readLine();
			}
			OmmMap ommMap = getOmmBuilder().toOmm(sb.toString(), OmmMap.class);
			bufferedReader.close();
			return ommMap;
		} catch (IOException e) {
			throw new OmmLoadingException("Error occured to load resource. : " + ommId, e);
		}
	}

	@Override
	public OmmMap[] loadAll() {
		throw new UnsupportedOperationException("Not yet implemented.");
	}

}
