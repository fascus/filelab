package cuin.cn.etc;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 API
 * 파 일 명 : TrmlInfoDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.08.09
 * 설    명 : 온라인 단말 정보 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class TrmlInfoDto {
	// 조합인가번호
	String johapNo;
	// 지소(지점)번호
	String jisoNo;
	// 단말번호
	String termNo;

	/**
	 * 조합인가번호 반환.
	 */
	public String getJohapNo() {
		return johapNo;
	}

	public void setJohapNo(String johapNo) {
		this.johapNo = johapNo;
	}

	/**
	 * 지소(지점)번호 반환.
	 */
	public String getJisoNo() {
		return jisoNo;
	}

	public void setJisoNo(String jisoNo) {
		this.jisoNo = jisoNo;
	}

	/**
	 * 단말번호 반환.
	 */
	public String getTermNo() {
		return termNo;
	}

	public void setTermNo(String termNo) {
		this.termNo = termNo;
	}

}
