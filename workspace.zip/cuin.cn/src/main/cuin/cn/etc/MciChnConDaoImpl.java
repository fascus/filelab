package cuin.cn.etc;

import hone.core.jdbc.support.RecordSetDaoSupport;
import hone.core.transaction.TransactionManagerHolder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.interceptor.TransactionAttribute;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;
import cuin.cn.exception.CuinException;
import cuin.online.cn.core.service.ServiceControl;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 API
 * 파 일 명 : MciChnConDaoImpl.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.07.19
 * 설    명 : MCI 채널단말 연결 DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class MciChnConDaoImpl extends RecordSetDaoSupport implements MciChnConDao {

	private static final Logger logger = LoggerFactory.getLogger(MciChnConDaoImpl.class);

	@Override
	public String getTermNo(final String operNo) {
		if (operNo == null || operNo.isEmpty()) {
			throw new IllegalArgumentException("Invalid operator number : '" + operNo + "'");
		}

		if (logger.isTraceEnabled()) {
			logger.trace("Lookup channel/terminal connection. Input operator number is : " + operNo);
		}

		TransactionTemplate template = new TransactionTemplate(TransactionManagerHolder.getTransctionManager());
		template.setPropagationBehavior(TransactionAttribute.PROPAGATION_NOT_SUPPORTED);
		template.setName("PROPAGATION_NOT_SUPPORTED");

		String termNo = template.execute(new TransactionCallback<String>() {
			public String doInTransaction(TransactionStatus txStatus) {
				String sql = "SELECT term_no FROM dbchl.chl_chanconn_inf WHERE conn_stat = 'Y' AND oper_no = :operNo";

				MapSqlParameterSource namedParameters = new MapSqlParameterSource();
				namedParameters.addValue("operNo", operNo);
				try {
					return queryForObject(sql, namedParameters, String.class);
				} catch (IncorrectResultSizeDataAccessException e) {
					return null;
				}
			}
		});

		if (logger.isTraceEnabled()) {
			logger.trace("Found terminal number is : " + termNo);
		}
		return termNo;
	}

	@Override
	public TrmlInfoDto getTermInfo(final String operNo) {
		if (operNo == null || operNo.isEmpty()) {
			throw new IllegalArgumentException("Invalid operator number : '" + operNo + "'");
		}

		if (logger.isTraceEnabled()) {
			logger.trace("Lookup channel/terminal connection. Input operator number is : " + operNo);
		}

		TransactionTemplate template = new TransactionTemplate(TransactionManagerHolder.getTransctionManager());
		template.setPropagationBehavior(TransactionAttribute.PROPAGATION_NOT_SUPPORTED);
		template.setName("PROPAGATION_NOT_SUPPORTED");

		TrmlInfoDto trmlInfo = template.execute(new TransactionCallback<TrmlInfoDto>() {
			public TrmlInfoDto doInTransaction(TransactionStatus txStatus) {
				String sql = "SELECT johap_no, jiso_no, term_no FROM dbchl.chl_chanconn_inf WHERE conn_stat = 'Y' AND oper_no = :operNo";

				MapSqlParameterSource namedParameters = new MapSqlParameterSource();
				namedParameters.addValue("operNo", operNo);

				TrmlInfoDto trmlInfo = null;
				try {
					trmlInfo = queryForObject(sql, namedParameters, new BeanPropertyRowMapper<TrmlInfoDto>(TrmlInfoDto.class));
				} catch (DataAccessException e) {
					logger.error("Error while find terminal no. operater no : " + operNo, e);
					ServiceControl.stop(CuinException.DEFAULT_SYS_ERR_CODE, "CNAB000001");
				}
				return trmlInfo;
			}
		});

		if (logger.isTraceEnabled()) {
			logger.trace("Found terminal number is : " + trmlInfo.getTermNo());
		}
		return trmlInfo;
	}
}
