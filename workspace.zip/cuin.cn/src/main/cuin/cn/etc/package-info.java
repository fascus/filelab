/**
 * 신협 공제 공통 API / 기타
 */
package cuin.cn.etc;