package cuin.cn.etc;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 API
 * 파 일 명 : MciChnConDao.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.07.19
 * 설    명 : MCI 채널단말 연결 DAO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface MciChnConDao {

	/**
	 * 접속 중(온라인 상태) 단말번호 반환
	 * 
	 * @param operNo 접속자 사번
	 * @return 단말 번호. 만일 검색할 수 없을 경우 null 반환
	 */
	String getTermNo(String operNo);

	/**
	 * 접속 중(온라인 상태) 단말 정보 반환
	 * 
	 * @param operNo 접속자 사번
	 * @return 단말 정보
	 */
	TrmlInfoDto getTermInfo(String operNo);

}
