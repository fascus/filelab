package cuin.cn.util;

import hone.common.util.DateUtils;
import hone.core.util.ApplicationContextHolder;
import cuin.cn.dbio.core.calendar.CalendarDao;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 API
 * 파 일 명 : CalendarUtils.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.07
 * 설    명 : 신협 공제 달력 API
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public final class CalendarUtils {
	private static CalendarDao calendarDao;

	/*
	 * this class does not provide public constructor
	 */
	private CalendarUtils() {
		// do nothing
	}

	private static CalendarDao getCalendarDao() {
		if (calendarDao == null) {
			calendarDao = ApplicationContextHolder.getApplicationContext().getBean(CalendarDao.class);
		}
		return calendarDao;
	}

	/**
	 * 영업일 여부.
	 * 
	 * @param baseDateStr YYYYMMDD 형식의 기준 일자
	 * @return 영업일이면 true, 아니면 false
	 */
	public static boolean isBizDay(String baseDateStr) {
		return getCalendarDao().isBizDay(baseDateStr);
	}

	/**
	 * 휴일 여부.
	 * 
	 * @param baseDate YYYYMMDD 형식의 기준 일자
	 * @param 휴일이면 true, 영업일이면 false
	 */
	public static boolean isHoliday(String baseDateStr) {
		return getCalendarDao().isHoliday(baseDateStr);
	}

	/**
	 * 이전/이후 영업일 (입력 = 기준일자, plug/minus n일, 출력 = 이전 혹은 다음 영업일).
	 * 
	 * @param baseDateStr YYYYMMDD 형식의 기준 일자
	 * @param term (+/-) n 일
	 * @return 이전 혹은 이후 영업일
	 */
	public static String otherBizDay(String baseDateStr, int term) {
		if (term == 0) {
			return nextBizDay(baseDateStr);
		} else {
			return getCalendarDao().otherBizDay(baseDateStr, term);
		}
	}

	/*
	 * 지정 일자 이후의 첫 영업일 반환.
	 * 
	 * @param baseDate YYYYMMDD 형식의 기준 일자
	 * 
	 * @return 지정 일자 이후의 첫 영업일 (지정 일자가 영업일인 경우, 지정 일자를 반환)
	 */
	private static String nextBizDay(String baseDateStr) {
		String nextDate = baseDateStr;
		while (!isBizDay(nextDate)) {
			nextDate = DateUtils.getDateString(DateUtils.getAfterDate(nextDate, 0, 0, 1));
		}
		return nextDate;
	}

}
