package cuin.cn.util;

import java.util.Set;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 API
 * 파 일 명 : DualMap.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.15
 * 설    명 : 2개의 키(key)를 사용하는 맵 인터페이스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface DualMap<K1, K2, V> {

	void put(K1 key1, K2 key2, V value);

	V get(K1 key1, K2 key2);

	Set<K2> keySet(K1 key1);

	boolean containsKey(K1 key1, K2 key2);
}
