package cuin.cn.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketException;

import org.apache.commons.net.ftp.FTPClient;


/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : FTP 전송 유틸
 * 파 일 명 : FtpUtils.java
 * 작 성 자 : 이태훈
 * 작 성 일 : 2013.12.9
 * 설    명 : FTP upload / download 기능 제공
 * 		, 무분별한 FTP 전송을 제한하기 위하여 enum 및 properties를 등록해야함.
 * 		, 등록절차 (1. FtpBzDv 에 업무 등록 -> 2.FtpBzDv의 업무에 해당하는 프로퍼티 등록 (ftp.업무명.(local.path | remote.path | id | pswd | ip | port)
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class FtpUtils {


	/**
	 * FTP 파일 전송. 업무 enum을 등록 하고 localFile 와 remoteFile는 절대경로가 아닌 개별 파일 root의 상대경로로 등록한다.
	 * @param ftpBzDv
	 * @param localFile
	 * @param remoteFile
	 * @throws SocketException
	 * @throws IOException
	 */
	public static boolean put(FtpBzDv ftpBzDv, String localFile, String remoteFile) throws SocketException, IOException {
		return put(ftpBzDv, localFile, remoteFile, "EUC-KR");
	}

	/**
	 * FTP 파일 전송. 업무 enum을 등록 하고 localFile 와 remoteFile는 절대경로가 아닌 프로퍼티에 등록된 패스를 root로 하여 상대경로로 등록한다.
	 * @param ftpBzDv
	 * @param localFile
	 * @param remoteFile
	 * @param encodeName
	 * @throws SocketException
	 * @throws IOException
	 */
	public static boolean put(FtpBzDv ftpBzDv, String localFile, String remoteFile, String encodeName) throws SocketException, IOException {
		FtpServInfo ftpServInfo = new FtpServInfo(ftpBzDv);

		FTPClient client = new FTPClient();
		client.setControlEncoding(encodeName);

		client.connect(ftpServInfo.getIp(), ftpServInfo.getPort());

		client.login(ftpServInfo.getId(), ftpServInfo.getPswd());


		File file = new File(ftpServInfo.getLocalPath() + "/" + localFile);
		InputStream is = new FileInputStream(file);

		client.storeFile(ftpServInfo.getRemotePath() + "/" + remoteFile, is);

		client.logout();
		client.disconnect();

		return true;
	}

	/**
	 * FTP 파일 다운로드. 업무 enum을 등록 하고 localFile 와 remoteFile는 절대경로가 아닌 프로퍼티에 등록된 패스를 root로 하여 상대경로로 등록한다.
	 * @param ftpBzDv
	 * @param remoteFile
	 * @param localFile
	 * @throws IOException
	 * @throws SocketException
	 */
	public static boolean get(FtpBzDv ftpBzDv, String remoteFile, String localFile) throws SocketException, IOException {
		return get(ftpBzDv, remoteFile, localFile, "EUC-KR");
	}

	/**
	 * FTP 파일 다운로드. 업무 enum을 등록 하고 localFile 와 remoteFile는 절대경로가 아닌 프로퍼티에 등록된 패스를 root로 하여 상대경로로 등록한다.
	 * @param ftpBzDv
	 * @param remoteFile
	 * @param localFile
	 * @param encodeName
	 * @throws IOException
	 * @throws SocketException
	 */
	public static boolean get(FtpBzDv ftpBzDv, String remoteFile, String localFile, String encodeName) throws SocketException, IOException {
		FtpServInfo ftpServInfo = new FtpServInfo(ftpBzDv);

		FTPClient client = new FTPClient();
		client.setControlEncoding(encodeName);

		client.connect(ftpServInfo.getIp(), ftpServInfo.getPort());

		client.login(ftpServInfo.getId(), ftpServInfo.getPswd());

		File file = new File(ftpServInfo.getLocalPath() + "/" + localFile);

		OutputStream os = new FileOutputStream(file);

		client.retrieveFile(ftpServInfo.getRemotePath() + "/" + remoteFile, os);

		client.logout();
		client.disconnect();

		return true;
	}
}
