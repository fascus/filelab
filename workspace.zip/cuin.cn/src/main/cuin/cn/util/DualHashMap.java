package cuin.cn.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 API
 * 파 일 명 : DualHashMap.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.15
 * 설    명 : 2개의 키(key)를 사용하는 맵 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class DualHashMap<K1, K2, V> implements DualMap<K1, K2, V> {

	private final Map<K1, Map<K2, V>> cascadeMap;

	public DualHashMap() {
		cascadeMap = new HashMap<K1, Map<K2, V>>();
	}

	@Override
	public void put(K1 key1, K2 key2, V value) {
		Map<K2, V> innerMap = cascadeMap.get(key1);
		if (innerMap == null) {
			innerMap = new HashMap<K2, V>();
			cascadeMap.put(key1, innerMap);
		}
		innerMap.put(key2, value);
	}

	@Override
	public V get(K1 key1, K2 key2) {
		Map<K2, V> innerMap = cascadeMap.get(key1);
		return (innerMap == null) ? null : innerMap.get(key2);
	}

	@Override
	public Set<K2> keySet(K1 key1) {
		Map<K2, V> innerMap = cascadeMap.get(key1);
		return (innerMap != null) ? innerMap.keySet() : null;
	}

	@Override
	public boolean containsKey(K1 key1, K2 key2) {
		return get(key1, key2) != null;
	}

}
