package cuin.cn.util;

import hone.common.util.EnvUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.cn.util.exception.NotSupportedExcelTypeException;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 API
 * 파 일 명 : ExcelUtils.java
 * 작 성 자 : 이태훈
 * 작 성 일 : 2013.10.24
 * 설    명 : 엑셀 생성을 위한 유틸
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class ExcelUtils {

	private static final Logger logger = LoggerFactory.getLogger(ExcelUtils.class);

	/**
	 * 유닉스 파일 Separator
	 */
	private final static String UNIX_FILE_SEPARATOR = "/";
	/**
	 * 윈도우 파일 Separator
	 */
	private final static String WINDOWS_FILE_SEPRATOR = "\\";

	/**
	 * <pre>
	 * 엑셀 템플릿을 로드한다.
	 * </pre>
	 * 
	 * @param bsnsDv
	 * @param tmplFileNm
	 * @return
	 * @throws IllegalArgumentException
	 * @throws NotSupportedExcelTypeException
	 * @throws IOException
	 */
	public static XSSFWorkbook buildTempateWorkbook(BsnsDvEnums bsnsDv, String templateFileName) throws IllegalArgumentException, NotSupportedExcelTypeException, IOException {
		File templateFile = null;
		XSSFWorkbook workbook = null;

		// 업무구분 안들어올 경우 예외처리
		if (bsnsDv == null) {
			throw new IllegalArgumentException("Argument bsnsDv (Business Devision) is null ");
		}

		// 파일명 예외처리
		if (templateFileName == null || templateFileName.isEmpty()) {
			throw new IllegalArgumentException("Argument tmplFileNm (Template File name) is empty ");
		}

		// Separator 여러가지 섞여올 경우 시스템 Separator 통일
		if (File.separator.equals(UNIX_FILE_SEPARATOR)) {
			templateFileName = templateFileName.replace(WINDOWS_FILE_SEPRATOR, File.separator);
		} else {
			templateFileName = templateFileName.replace(UNIX_FILE_SEPARATOR, File.separator);
		}

		// 첫글자가 Separator 경우 제거
		if (templateFileName.substring(0, 0).equals(File.separator)) {
			templateFileName = templateFileName.substring(1, templateFileName.length());
		}

		// xlsx 파일이 아닐 경우 예외 처리
		if (!templateFileName.substring(templateFileName.lastIndexOf('.') + 1, templateFileName.length()).equalsIgnoreCase("xlsx")) {
			throw new NotSupportedExcelTypeException("ExcelUtils only can support .xlsx file.");
		}

		String templateFullPath = makeTemplatePath(bsnsDv, templateFileName);
		templateFile = new File(templateFullPath);

		if (!templateFile.exists()) {
			throw new FileNotFoundException(String.format("[%s] not found.", templateFileName));
		}

		FileInputStream is = new FileInputStream(templateFile);
		return new XSSFWorkbook(is);
	}

	/**
	 * <pre>
	 * 업무구분과 파일명으로 작성된 XSSFWorkbook 을 엑셀 파일로 저장한다.
	 * </pre>
	 * 
	 * @param workbook
	 * @param bsnsDv
	 * @param excelFileName
	 * @return
	 */
	public static boolean publishExcelWorkbook(XSSFWorkbook workbook, BsnsDvEnums bsnsDv, String excelFileName, boolean isForceOverwrite) throws IllegalStateException, NotSupportedExcelTypeException,
			IOException {

		// Workbook 이 null 이거나 첫번째 시트가 없을 경우 예외처리
		if (workbook == null || workbook.getSheetAt(0) == null) {
			throw new IllegalStateException("Invalid or empty workbook.");
		}

		// 업무구분 안들어올 경우 예외처리
		if (bsnsDv == null) {
			throw new IllegalArgumentException("Argument bsnsDv (Business Devision) is null ");
		}

		// 파일명 예외처리
		if (excelFileName == null || excelFileName.isEmpty()) {
			throw new IllegalArgumentException("Argument tmplFileNm (Template File name) is empty ");
		}

		// Separator 가 여러가지 섞여올 경우 시스템 Separtor 로 통일
		if (File.separator.equals(UNIX_FILE_SEPARATOR)) {
			excelFileName = excelFileName.replace(WINDOWS_FILE_SEPRATOR, File.separator);
		} else {
			excelFileName = excelFileName.replace(UNIX_FILE_SEPARATOR, File.separator);
		}

		// 첫글자가 Separator 일 경우 제거
		if (excelFileName.substring(0, 0).equals(File.separator)) {
			excelFileName = excelFileName.substring(1, excelFileName.length());
		}

		// xlsx 파일이 아닐 경우 예외 처리
		if (!excelFileName.substring(excelFileName.lastIndexOf('.') + 1, excelFileName.length()).equalsIgnoreCase("xlsx")) {
			throw new NotSupportedExcelTypeException("ExcelUtils only can support .xlsx file.");
		}

		String excelFullPath = makePublishPath(bsnsDv, excelFileName);

		File excelFile = new File(excelFullPath);

		// 해당 파일이 존재할 경우 덮어쓰기 가 false일 경우 예외 처리, true일 경우 해당 파일 삭제
		if (excelFile.exists()) {
			if (!isForceOverwrite) {
				throw new IllegalStateException(String.format("[%s] is already exists.", excelFileName));
			} else {
				excelFile.delete();
			}
		}

		FileOutputStream os = new FileOutputStream(excelFullPath, false);
		try {
			workbook.write(os);
		} finally {
			try {
				os.close();
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}

		return true;

	}

	/**
	 * <pre>
	 * </pre
	 * 
	 * * *플릿파일 위치 전체 경로 작성 </pre * *
	 * 
	 * @param bsnsDv
	 * @param tmplFileNm
	 * @return
	 */
	private static String makeTemplatePath(BsnsDvEnums bsnsDv, String tmplFileNm) {
		return EnvUtils.getProperty(EnvUtils.EXCEL_TEMPLATE_STORED_ROOT_PATH) + File.separator + bsnsDv.getValue() + File.separator + tmplFileNm;
	}

	/**
	 * <pre>
	 * 업무구분과 파일명으로 저장할  파일 전체 경로 작성
	 * </pre>
	 * 
	 * @param bsnsDv
	 * @param tmplFileNm
	 * @return
	 */
	private static String makePublishPath(BsnsDvEnums bsnsDv, String tmplFileNm) {
		return EnvUtils.getProperty(EnvUtils.EXCEL_PUBLISH_ROOT_PATH) + File.separator + bsnsDv.getValue() + File.separator + tmplFileNm;
	}

	public static void cloneRow(XSSFWorkbook workbook, String sheetName, int srcRowIndex, int destRowIndex) {
		int sheetIndex = workbook.getSheetIndex(sheetName);
		cloneRow(workbook, sheetIndex, srcRowIndex, destRowIndex);
	}

	/**
	 * <pre>
	 *  엑셀 Row를 통째로 복제
	 *  srcRowIndex 의 Row를 통째로 destRowIndex로 복제한다.
	 *  기존destRowIndex에 데이터가 있는 셀이 존재할 경우 그 Row부터 한줄 아래로 밀리게 된다.
	 * </pr	 *
	 * 
	 *  @param workbook : 로딩된 Workbook
	 *  @param sheetIndex : 엑셀시트 순번 (첫번 째 시트가 0)
	 *  @param srcRowIndex : 원본 Row 순번 (1번행이 0)
	 * @param destRowIndex : 대상 Row 순번 (1번행이 0)
	 */
	public static void cloneRow(XSSFWorkbook workbook, int sheetIndex, int srcRowIndex, int destRowIndex) {
		XSSFSheet sheet = workbook.getSheetAt(sheetIndex);

		sheet.shiftRows(destRowIndex, destRowIndex + 1, 1);

		XSSFRow destRow = sheet.createRow(destRowIndex);
		XSSFRow sourceRow = sheet.getRow(srcRowIndex);

		for (int i = 0; i < sourceRow.getLastCellNum(); i++) {
			// Grab a copy of the old/new cell
			XSSFCell oldCell = sourceRow.getCell(i);
			XSSFCell newCell = destRow.createCell(i);

			// If the old cell is null jump to next cell
			if (oldCell == null) {
				newCell = null;
				continue;
			}

			// Copy style from old cell and apply to new cell
			XSSFCellStyle newCellStyle = workbook.createCellStyle();
			newCellStyle.cloneStyleFrom(oldCell.getCellStyle());
			newCell.setCellStyle(newCellStyle);

			// If there is a cell comment, copy
			if (newCell.getCellComment() != null) {
				newCell.setCellComment(oldCell.getCellComment());
			}

			// If there is a cell hyperlink, copy
			if (oldCell.getHyperlink() != null) {
				newCell.setHyperlink(oldCell.getHyperlink());
			}

			// Set the cell data type
			newCell.setCellType(oldCell.getCellType());

			// Set the cell data value
			switch (oldCell.getCellType()) {
				case Cell.CELL_TYPE_BLANK:
					newCell.setCellValue(oldCell.getStringCellValue());
					break;
				case Cell.CELL_TYPE_BOOLEAN:
					newCell.setCellValue(oldCell.getBooleanCellValue());
					break;
				case Cell.CELL_TYPE_ERROR:
					newCell.setCellErrorValue(oldCell.getErrorCellValue());
					break;
				case Cell.CELL_TYPE_FORMULA:
					newCell.setCellFormula(oldCell.getCellFormula());
					break;
				case Cell.CELL_TYPE_NUMERIC:
					newCell.setCellValue(oldCell.getNumericCellValue());
					break;
				case Cell.CELL_TYPE_STRING:
					newCell.setCellValue(oldCell.getRichStringCellValue());
					break;
			}
		}

		// If there are are any merged regions in the source row, copy to new
		// row
		for (int i = 0; i < sheet.getNumMergedRegions(); i++) {
			CellRangeAddress cellRangeAddress = sheet.getMergedRegion(i);
			if (cellRangeAddress.getFirstRow() == sourceRow.getRowNum()) {
				CellRangeAddress newCellRangeAddress = new CellRangeAddress(destRow.getRowNum(), (destRow.getRowNum() + (cellRangeAddress.getLastRow() - cellRangeAddress.getFirstRow())),
						cellRangeAddress.getFirstColumn(), cellRangeAddress.getLastColumn());
				sheet.addMergedRegion(newCellRangeAddress);
			}
		}
	}
}
