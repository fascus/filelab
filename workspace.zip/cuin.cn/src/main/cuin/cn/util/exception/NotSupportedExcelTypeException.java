package cuin.cn.util.exception;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 API
 * 파 일 명 : NotSupportedExcelTypeException.java
 * 작 성 자 : 이태훈
 * 작 성 일 : 2013.10.16
 * 설    명 : ExcelUtils에서 읽기 위한 템플릿 파일이 엑셀2007 이상 버전 파일이 아닌 경우 처리하기 위한 Exception  엑셀 파일이 아니거나 구버전(~2003) 엑셀 파일이 올 경우, 또는 파일이 비정상일 경우 발생
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class NotSupportedExcelTypeException extends RuntimeException {

	private static final long serialVersionUID = 223624159145260640L;

	/**
	 * <pre>
	 * ExcelUtils에서 읽기 위한 템플릿 파일이 엑셀2007 이상 버전 파일이 아닌 경우 처리하기 위한 Exception
	 * 엑셀 파일이 아니거나 구버전(~2003) 엑셀 파일이 올 경우, 또는 파일이 비정상일 경우 발생
	 * </pre>
	 * 
	 */
	public NotSupportedExcelTypeException(String message) {
		super(message);
	}

}
