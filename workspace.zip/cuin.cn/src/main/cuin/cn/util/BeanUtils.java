package cuin.cn.util;

import static org.springframework.beans.BeanUtils.getPropertyDescriptors;
import hone.common.util.DateUtils;

import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("rawtypes")
/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 API
 * 파 일 명 : BeanUtils.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.30
 * 설    명 : 빈 속성 설정 유틸리티 (set bean properties).
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public final class BeanUtils {

	private static final Logger logger = LoggerFactory.getLogger(BeanUtils.class);

	private BeanUtils() {
		// this class does not provide public constructor
	}

	/**
	 * 빈(bean) 속성 설정.
	 * 
	 * @param bean 속성 설정 대상 빈(bean)
	 * @param propName 속성 명칭
	 * @param propValue 속성 값
	 * @throws IllegalStateException 빈 내부에 해당 속성이 존재하지 않을 경우 예외 발생
	 */
	public static void setProperty(Object bean, String propName, Object propValue) {
		if (bean == null) {
			throw new IllegalArgumentException("Input bean is null");
		}
		if (propName == null || propName.isEmpty()) {
			throw new IllegalArgumentException("Input 'propName' is null or empty");
		}
		if (propValue == null) {
			throw new IllegalArgumentException("Input 'propValue' is null");
		}

		Class beanClass = bean.getClass();
		PropertyDescriptor[] targetPds = getPropertyDescriptors(beanClass);
		String errMsg = String.format("Cannot access [%s] property in [%s] ", propName, beanClass.getName());
		Method writeMethod = null;
		for (PropertyDescriptor desc : targetPds) {
			writeMethod = desc.getWriteMethod();
			if (propName.equals(desc.getName()) && writeMethod != null) {
				break;
			}
		}
		if (writeMethod == null) {
			throw new IllegalStateException(errMsg + ", write method not found");
		}
		try {
			writeMethod.invoke(bean, new Object[] { propValue });
		} catch (IllegalAccessException e) {
			throw new IllegalStateException(errMsg, e);
		} catch (InvocationTargetException e) {
			throw new IllegalStateException(errMsg, e);
		}
	}

	/**
	 * 빈(bean) 속성 값 반환.
	 * 
	 * @param bean 속성 설정 대상 빈(bean)
	 * @param propName 속성 명칭
	 * @return 속성 값
	 * @throws IllegalStateException 빈 내부에 해당 속성이 존재하지 않을 경우 예외 발생
	 */
	public static Object getProperty(Object bean, String propName) {
		if (bean == null) {
			throw new IllegalArgumentException("Input bean is null");
		}
		if (propName == null || propName.isEmpty()) {
			throw new IllegalArgumentException("Input 'propName' is null or empty");
		}

		Class beanClass = bean.getClass();
		PropertyDescriptor[] targetPds = getPropertyDescriptors(beanClass);
		String errMsg = String.format("Cannot access [%s] property in [%s] ", propName, beanClass.getName());
		for (PropertyDescriptor desc : targetPds) {
			if (propName.equals(desc.getName())) {
				Method readMethod = desc.getReadMethod();
				if (readMethod != null) {
					Object propValue = null;
					try {
						propValue = readMethod.invoke(bean, new Object[] {});
					} catch (IllegalAccessException e) {
						throw new IllegalStateException(errMsg, e);
					} catch (InvocationTargetException e) {
						throw new IllegalStateException(errMsg, e);
					}
					return propValue;
				}
				break;
			}
		}
		throw new IllegalStateException(errMsg + ", read method not found");
	}

	/**
	 * 대상(target) 클래스 인스턴스 리스트를 생성한 후, 원본(source) 객체 리스트의 속성(member variable)을
	 * 대상 인스턴스로 매핑(mapping) 한 후 반환한다.
	 * 
	 * @param source 원본 객체
	 * @param targetClass 대상 클래스
	 */
	public static <C> List<C> toList(List sourceList, Class<C> targetClass) {

		List<C> targetList = new ArrayList<C>();
		for (Object instance : sourceList) {
			targetList.add(BeanUtils.toBean(instance, targetClass));
		}
		return targetList;
	}

	/**
	 * 대상(target) 클래스 인스턴스를 생성한 후, 원본(source) 객체의 속성(member variable)을 대상 인스턴스로
	 * 매핑(mapping) 한 후 반환한다.
	 * 
	 * @param sourceBean 원본 객체
	 * @param targetClass 대상 클래스
	 */
	public static <C> C toBean(Object sourceBean, Class<C> targetClass) {
		C targetBean = createInstance(targetClass);
		return populateProps(sourceBean, targetBean, false, false);
	}

	/**
	 * 원본(source) 객체의 속성들(member variables)을 대상 인스턴스로 매핑(mapping) 한 후 반환한다.
	 * 
	 * @param sourceBean 원본 객체
	 * @param targetBean 대상 객체
	 * @return 속성 값이 복사된 대상 객체
	 */
	public static <C> C toBean(Object sourceBean, C targetBean) {
		return populateProps(sourceBean, targetBean, false, false);
	}

	/**
	 * 대상(target) 클래스 인스턴스를 생성한 후, 원본(source) 객체의 속성(member variable)을 대상 인스턴스로
	 * 매핑(mapping) 한 후 반환한다. 복사할 수 없는 속성(필드)는 무시한다.
	 * 
	 * @param sourceBean 원본 객체
	 * @param targetClass 대상 클래스
	 */
	public static <C> C populate(Object sourceBean, Class<C> targetClass) {
		C targetBean = createInstance(targetClass);
		return populateProps(sourceBean, targetBean, true, false);
	}

	/**
	 * 원본 객체의 속성 중에서 빈 값(empty value)을 가진 속성을 제외하고 대상 인스턴스로 매핑(mapping)한다. (원본
	 * 속성의 타입이 문자열인 경우 null 혹은 길이가 zero 인 값을 무시, 정수형인 경우 zero 값을 무시)
	 * 
	 * @param sourceBean 원본 객체
	 * @param targetBean 대상 객체
	 * @return 속성 값이 복사된 대상 객체
	 */
	public static <C> C merge(Object sourceBean, C targetBean) {
		return populateProps(sourceBean, targetBean, true, true);
	}

	/**
	 * 원본(source) 객체의 속성(member variable)을 대상 인스턴스로 매핑(mapping) 한 후 반환한다. 복사할 수
	 * 없는 속성(필드)는 무시한다.
	 * 
	 * @param sourceBean 원본 객체
	 * @param targetBean 대상 객체
	 * @return 속성 값이 복사된 대상 객체
	 */
	public static <C> C populate(Object sourceBean, C targetBean) {
		return populateProps(sourceBean, targetBean, true, false);
	}

	private static <C> C createInstance(Class<C> targetClass) {
		C targetBean = null;
		try {
			targetBean = targetClass.newInstance();
		} catch (InstantiationException e) {
			throw new IllegalArgumentException("Cannot instantiate class : " + targetClass.getName(), e);
		} catch (IllegalAccessException e) {
			throw new IllegalArgumentException("Cannot instantiate class : " + targetClass.getName(), e);
		}
		return targetBean;
	}

	private static <C> C populateProps(Object sourceBean, C targetBean, boolean faultTolerance, boolean skipEmpty) {
		if (targetBean == null) {
			throw new IllegalArgumentException("Target bean is null.");
		}
		if (sourceBean == null) {
			return targetBean;
		}
		String srcPropName = null;
		Class targetClass = targetBean.getClass();
		PropertyDescriptor[] targetPds = getPropertyDescriptors(targetClass);
		PropertyDescriptor[] sourcePds = getPropertyDescriptors(sourceBean.getClass());
		Object[] emptyParams = new Object[] {};
		for (PropertyDescriptor srcDesc : sourcePds) {
			Method readMethod = srcDesc.getReadMethod();
			srcPropName = srcDesc.getName();
			Object srcValue = null;
			boolean skipProp = false;
			try {
				srcValue = readMethod.invoke(sourceBean, emptyParams);
			}
			// if cannot read field value then skip that...
			catch (Exception ex) {
				skipProp = true;
			}
			if (!skipProp && isNotEmpty(srcValue, skipEmpty)) {
				for (PropertyDescriptor targetDesc : targetPds) {
					if (srcPropName.equals(targetDesc.getName())) {
						srcValue = convertValueIfRequired(targetDesc, srcPropName, srcValue);
						Method writeMethod = targetDesc.getWriteMethod();
						if (writeMethod != null) {
							try {
								writeMethod.invoke(targetBean, new Object[] { srcValue });
							} catch (IllegalArgumentException e) {
								if (!faultTolerance) {
									throw new IllegalArgumentException("Cannot copy property : " + srcPropName, e);
								}
							} catch (IllegalAccessException e) {
								if (!faultTolerance) {
									throw new IllegalStateException("Cannot access the property : " + srcPropName, e);
								}
							} catch (InvocationTargetException e) {
								if (!faultTolerance) {
									throw new IllegalArgumentException("Cannot copy property : " + srcPropName, e);
								}
							}
						}
						break;
					}
				}
			}
		}
		return targetBean;
	}

	private static boolean isNotEmpty(Object srcValue, boolean skipEmpty) {
		if (!skipEmpty) {
			return srcValue != null;
		} else {
			if (srcValue instanceof String) {
				return srcValue != null && !((String) srcValue).isEmpty();
			} else if (srcValue instanceof Integer) {
				return ((Integer) srcValue) != 0;
			} else {
				return srcValue != null;
			}
		}
	}

	private static Object convertValueIfRequired(PropertyDescriptor targetDesc, String srcPropName, Object srcValue) {
		Class<?> targetPropType = targetDesc.getPropertyType();
		targetPropType.equals(int.class);
		Class<?> sourcePropType = srcValue.getClass();
		if (!targetPropType.equals(sourcePropType)) {
			if (targetPropType.equals(Timestamp.class)) {
				// 대상 속성 타입 = Timestamp, 원본 속성 타입 = String
				if (sourcePropType.equals(String.class)) {
					return DateUtils.toTimestamp((String) srcValue);
				} else {
					String errMsg = String.format("Cannot convert [type : %s, name : %s, value : %s] to java.sql.Date type.", sourcePropType.getName(), srcPropName, srcValue);
					logger.error(errMsg);
					throw new IllegalArgumentException(errMsg);
				}
			} else if (targetPropType.equals(String.class)) {
				// 대상 속성 타입 = String, 원본 속성 타입 = Timestamp
				if (sourcePropType.equals(Timestamp.class)) {
					return DateUtils.getDateTimeString((Timestamp) srcValue);
				}
				// 대상 속성 타입 = String, 원본 속성 타입 = Long
				else if (sourcePropType.equals(Long.class)) {
					return ((Long) srcValue).toString();
				} else {
					String errMsg = String.format("Cannot convert [type : %s, name : %s, value : %s] to java.lang.String.", sourcePropType.getName(), srcPropName, srcValue);
					logger.error(errMsg);
					throw new IllegalArgumentException(errMsg);
				}
			}
			// 대상 속성 타입 = BigDecimal, 원본 속성 타입 = long
			else if (targetPropType.equals(BigDecimal.class) && sourcePropType.equals(long.class)) {
				return BigDecimal.valueOf((Long) srcValue);
			}
		}

		return srcValue;
	}

	/**
	 * 
	 * @param bean
	 * @param propName
	 * @param propValue
	 */
	public static void setPropertyIfNull(Object bean, String propName, Object propValue) {
		if (getProperty(bean, propName) == null) {
			setProperty(bean, propName, propValue);
		}
	}
}
