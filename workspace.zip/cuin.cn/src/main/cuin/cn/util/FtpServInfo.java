package cuin.cn.util;

import hone.common.util.EnvUtils;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : FTP 전송 구조체 class (FtpUtils에서 사용)
 * 파 일 명 : FtpServInfo.java
 * 작 성 자 : 이태훈
 * 작 성 일 : 2013.12.9
 * 설    명 : Ftp 전송 정보를 로딩하는 클래스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class FtpServInfo {
	private String ip;
	private int port;
	private String id;
	private String pswd;
	private String localPath;
	private String remotePath;
	public String getIp() {
		return ip;
	}
	public int getPort() {
		return port;
	}
	public String getId() {
		return id;
	}
	public String getPswd() {
		return pswd;
	}
	public String getLocalPath() {
		return localPath;
	}
	public String getRemotePath() {
		return remotePath;
	}


	public FtpServInfo(FtpBzDv ftpBzDv) {
		ip = getStringProperty(String.format("ftp.%s.ip", ftpBzDv.getValue()));
		port = getIntProperty(String.format("ftp.%s.port", ftpBzDv.getValue()));
		id = getStringProperty(String.format("ftp.%s.id", ftpBzDv.getValue()));
		pswd = getStringProperty(String.format("ftp.%s.pswd", ftpBzDv.getValue()));
		localPath = getStringProperty(String.format("ftp.%s.local.path", ftpBzDv.getValue()));
		remotePath = getStringProperty(String.format("ftp.%s.remote.path", ftpBzDv.getValue()));
	}

	private String getStringProperty(String propName) {
		String value = EnvUtils.getProperty(propName);

		if(value == null) {
			throw new IllegalStateException(String.format("Cannot find property '%s'!"));
		}

		return value;
	}

	private int getIntProperty(String propName) {
		String value = EnvUtils.getProperty(propName);
		int rtvValue = 0;
		if(value == null) {
			throw new IllegalStateException(String.format("Cannot find property '%s'!"));
		}

		try {
			rtvValue = Integer.parseInt(value);
		} catch(NumberFormatException nfe) {
			throw new IllegalStateException("Property '%s' is not number!", nfe);
		}

		return rtvValue;
	}

}
