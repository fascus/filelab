package cuin.cn.util;

import hone.common.util.StringUtils;
import hone.core.util.ApplicationContextHolder;

import java.util.ArrayList;
import java.util.List;

import cuin.cn.dbio.core.intgcd.IntgCdDao;
import cuin.cn.dbio.core.intgcd.IntgCdDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 API
 * 파 일 명 : CodeUtils.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.07.24
 * 설    명 : 신협 공제  공통 코드 API
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public final class CodeUtils {
	private static IntgCdDao intgCdDao;

	/*
	 * this class does not provide public constructor
	 */
	private CodeUtils() {
		// do nothing
	}

	private static IntgCdDao getIntgCdDao() {
		if (intgCdDao == null) {
			intgCdDao = ApplicationContextHolder.getApplicationContext().getBean(IntgCdDao.class);
		}
		return intgCdDao;
	}

	/**
	 * 통합코드 존재 여부 검사.
	 * 
	 * @param cdGrrpId 코드그룹ID
	 * @param cd 코드
	 * @return 코드 존재 여부. 존재하면 true, 아니면 false 반환.
	 */
	public static boolean isIntgCd(String cdGrpId, String cd) {
		return inquiryIntgCd(cdGrpId, cd) != null;
	}

	/**
	 * 통합코드 명칭 조회.
	 * 
	 * @param cdGrrpId 코드그룹ID
	 * @param cd 코드
	 * @return 코드명칭. 만일 찾을 수 없을 경우 null 반환
	 * */
	public static String inquiryIntgCd(String cdGrpId, String cd) {
		if (StringUtils.isEmpty(cdGrpId) || StringUtils.isEmpty(cd)) {
			return null;
		}
		return getIntgCdDao().inquiryIntgCd(cdGrpId, cd);
	}

	/**
	 * 통합코드 정식명칭 조회.
	 * 
	 * @param cdGrrpId 코드그룹ID
	 * @param cd 코드
	 * @return 코드명칭. 만일 찾을 수 없을 경우 null 반환
	 */
	public static String inquiryIntgCdRgfNm(String cdGrpId, String cd) {
		if (StringUtils.isEmpty(cdGrpId) || StringUtils.isEmpty(cd)) {
			return null;
		}
		return getIntgCdDao().inquiryIntgCdRgfNm(cdGrpId, cd);
	}

	/**
	 * 통합코드 목록 조회.
	 * 
	 * @param cdGrpId 통합코드그룹ID
	 * @return 통합코드 정보를 포함한 DTO 목록, 찾을 수 없을 경우 null 반환
	 */
	public static List<IntgCdDto> inquiryIntgCds(String cdGrpId) {
		if (StringUtils.isEmpty(cdGrpId)) {
			return null;
		}
		return getIntgCdDao().inquiryIntgCds(cdGrpId);
	}

	/**
	 * 통합 코드(값) 목록 조회
	 * 
	 * @return 통합코드 문자열 배열, 찾을 수 없을 경우 null 반환
	 */
	public static String[] inquiryIntgCdArr(String cdGrpId) {
		if (StringUtils.isEmpty(cdGrpId)) {
			return null;
		}

		List<IntgCdDto> intgCdDtos = getIntgCdDao().inquiryIntgCds(cdGrpId);
		List<String> intgCdList = new ArrayList<String>();
		for (IntgCdDto dto : intgCdDtos) {
			intgCdList.add(dto.getIntgCd());
		}

		String[] strArr = new String[intgCdList.size()];
		intgCdList.toArray(strArr);
		return strArr;
	}

}
