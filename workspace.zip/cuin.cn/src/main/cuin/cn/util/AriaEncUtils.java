package cuin.cn.util;

import hone.common.util.EnvUtils;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;

import kr.cipher.aria.Cipher;
import cuin.cn.exception.CuinEAIException;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 API
 * 파 일 명 : AriaEncUtils.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.10.14
 * 설    명 : ARIA 암호화 유틸리티.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class AriaEncUtils {

	// ARAI 마스터 키 설정 변수 명칭
	private static final String CUIN_ARIA_MASTER_KEY = "cuin.aria.master.key";

	/**
	 * ARIA 암호화.
	 * 
	 * @param plainText 평문
	 * @return 암호문
	 */
	public static String encrypt(String plainText) {

		byte[] masterKey = getMasterKey();
		try {
			return Cipher.encrypt(plainText, masterKey, masterKey.length * 8, "UTF-8");
		} catch (InvalidKeyException e) {
			throw new CuinEAIException("Invalid ARIA master key.", e);
		} catch (UnsupportedEncodingException e) {
			throw new CuinEAIException("Unsupported encoding error.", e);
		}
	}

	/**
	 * ARIA 복호화.
	 * 
	 * @param encText 암호문
	 * @return 평문
	 */
	public static String decrypt(String encText) {
		byte[] masterKey = getMasterKey();
		try {
			return Cipher.decrypt(encText, masterKey, masterKey.length * 8, "UTF-8");
		} catch (InvalidKeyException e) {
			throw new CuinEAIException("Invalid ARIA master key.", e);
		} catch (UnsupportedEncodingException e) {
			throw new CuinEAIException("Unsupported encoding error.", e);
		}
	}

	/**
	 * 빈(bean)의 특정 속성을 암호화.
	 * 
	 * @param bean 암호화 대상 빈(bean)
	 * @param propName 암호화 대상 속성
	 */
	public static void encryptProperty(Object bean, String propName) {
		String plainText = (String) BeanUtils.getProperty(bean, propName);
		BeanUtils.setProperty(bean, propName, encrypt(plainText));
	}

	/**
	 * 빈(bean)의 특정 속성을 복호화.
	 * 
	 * @param bean 복호화 대상 빈(bean)
	 * @param propName 복호화 대상 속성
	 */
	public static void decryptProperty(Object bean, String propName) {
		String encText = (String) BeanUtils.getProperty(bean, propName);
		BeanUtils.setProperty(bean, propName, decrypt(encText));
	}

	private static byte[] getMasterKey() {
		return EnvUtils.getProperty(CUIN_ARIA_MASTER_KEY).getBytes();
	}
}
