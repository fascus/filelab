package cuin.cn.util;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : FTP 전송 업무 구분 (FtpUtils에서 사용)
 * 파 일 명 : FtpBzDv.java
 * 작 성 자 : 이태훈
 * 작 성 일 : 2013.12.9
 * 설    명 : FtpUtils에서 무분별한 FTP 전송을 제한하기 위하여 개별 업무마다 생성하는 enum
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public enum FtpBzDv {
	// 이미지 서식 전송 업무 (공통팀, 박용길 신청)
	IMAGE_FORM_DV_CD("image.form.dv.cd");

	private String value;

	FtpBzDv(String ftpBzDv) {
		this.value = ftpBzDv;
	}

	public String getValue() {
		return this.value;
	}

}
