package cuin.cn.util;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 API
 * 파 일 명 : BsnsDvEnums.java
 * 작 성 자 : 이태훈
 * 작 성 일 : 2013.10.16
 * 설    명 :
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public enum BsnsDvEnums {
	/** 공통 */
	CN("CN")
	/** 상품 */
	, PF("PF")
	/** Rule시스템 */
	, RS("RS")
	/** 고객 */
	, CT("CT")
	/** 신계약 */
	, NC("NC")
	/** 보전 */
	, KI("KI")
	/** 보상 */
	, CP("CP")
	/** 독립회계 */
	, IA("IA")
	/** 영업 */
	, BS("BS")
	/** 콜센터 */
	, XXXX("XXXX")
	/** 계리결산 */
	, VL("VL")
	/** 재보험 */
	, RI("RI")
	/** 경험통계 */
	, ES("ES")
	/** 정보계 */
	, SI("SI")
	/** EUS */
	, EU("EU")
	/** 의무전자매뉴얼 */
	, MU("MU")
	/** 메타시스템 */
	, MS("MS")
	/** 데이터이행 */
	, DM("DM")
	/** 기술아키텍처 */
	, TA("TA")
	/** 응용아키텍처 */
	, AA("AA")
	/** DB아키텍처 */
	, DA("DA");

	String value;

	private BsnsDvEnums(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}
}
