package cuin.cn.rule;

import hone.core.HoneException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.innoexpert.rulesclient.ConnectionProperties;
import com.innoexpert.rulesclient.Constants;
import com.innoexpert.rulesclient.ItemValue;
import com.innoexpert.rulesclient.ResultSet;
import com.innoexpert.rulesclient.RuleReq;
import com.innoexpert.rulesclient.RulesException;
import com.innoexpert.rulesclient.RulesInterface;

import cuin.cn.exception.CuinBizException;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 룰/상품
 * 파 일 명 : RuleAdaptor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.28
 * 설    명 : 룰  엔진 인터페이스 API (rule engine interface API).
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class RuleAdaptor {

	private static final Logger logger = LoggerFactory.getLogger(RuleAdaptor.class);
	// '년-월-일' 형식 날짜 정규식
	private static final String YYYYMMDD_DATE_PATTERN = "^(19|20)\\d{2}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[0-1])$";
	private static final Pattern datePattern = Pattern.compile(YYYYMMDD_DATE_PATTERN);

	// 룰 코드(rule code)
	private String ruleCode;
	// 상품 항목 별칭 및 값 목록
	private List<ItemValue> itemValues;
	// 룰 호출 사용자 ID (로그인 계정)
	private String userId;
	// 룰 호출 프로그램 ID (서비스 클래스의 fully qualified name)
	private String serviceId;
	// 룰 기준일자
	private String ruleDate;

	/**
	 * <pre>
	 * 기본 생성자.
	 * 
	 * 룰 엔진 사용자 ID 및 호출 프로그램 ID를 "unknown"으로 기본 설정한다.
	 * </pre>
	 */
	public RuleAdaptor() {
		itemValues = new ArrayList<ItemValue>();
		userId = "unknown";
		serviceId = "unknown";
	}

	/**
	 * <pre>
	 * 호출하는 룰(rule) 코드를 설정한다.
	 * 
	 * 존재하지 않는 상품 코드를 설정하고 rule engine을 호출할 경우,
	 * 상품 코드로 "EEEE", 상품명은 오류 메시지를 반환한다.
	 * </pre>
	 * 
	 * @param ruleCode rule 엔진에 존재하는 rule 코드
	 */
	public void setRuleCode(String ruleCode) {
		this.ruleCode = ruleCode;
	}

	/**
	 * <pre>
	 * 룰 엔진(rule engine)에 전달할 문자열 아이템(속성)을 추가한다.
	 * 
	 * 상품 속성의 별칭은 상품 팩토리의 상품속성정의서 또는 룰 인터페이스 정의서를 참고해야 한다.
	 * </pre>
	 * 
	 * @param alias 상품 속성의 별칭(영문명)
	 * @param value 상품 속성의 입력 값 (문자열)
	 */
	public void addItem(String alias, String value) {
		if (value != null) {
			for (ItemValue existingValue : itemValues) {
				if (existingValue.getCode().equals(alias)) {
					existingValue.addValue(value);
					return;
				}
			}
			ItemValue newItemValue = new ItemValue(alias);
			newItemValue.addValue(value);
			itemValues.add(newItemValue);
		}
	}

	/**
	 * <pre>
	 * 룰 엔진(rule engine)에 전달할 숫자 아이템(속성)을 추가한다.
	 * 
	 * 상품 속성의 별칭은 상품 팩토리의 상품속성정의서 또는 룰 인터페이스 정의서를 참고해야 한다.
	 * </pre>
	 * 
	 * @param alias 상품 속성의 별칭(영문명)
	 * @param value 상품 속성의 입력 값 (double 형)
	 */
	public void addItem(String alias, long value) {
		addItem(alias, (double) value);
	}

	/**
	 * <pre>
	 * 룰 엔진(rule engine)에 전달할 숫자 아이템(속성)을 추가한다.
	 * 
	 * 상품 속성의 별칭은 상품 팩토리의 상품속성정의서 또는 룰 인터페이스 정의서를 참고해야 한다.
	 * </pre>
	 * 
	 * @param alias 상품 속성의 별칭(영문명)
	 * @param value 상품 속성의 입력 값 (double 형)
	 */
	public void addItem(String alias, double value) {
		for (ItemValue existingValue : itemValues) {
			if (existingValue.getCode().equals(alias)) {
				existingValue.addValue(value);
				return;
			}
		}
		ItemValue newItemValue = new ItemValue(alias);
		newItemValue.addValue(value);
		itemValues.add(newItemValue);
	}

	/**
	 * <pre>
	 * 룰 엔진(rule engine)에 전달할 아이템(속성)을 추가한다.
	 * 
	 * 상품 속성의 별칭은 상품 팩토리의 상품속성정의서 또는 룰 인터페이스 정의서를 참고해야 한다.
	 * </pre>
	 * 
	 * @param alias 상품 속성의 별칭(영문명)
	 * @param values 상품 속성의 입력 값 목록 (가변 길이 인자)
	 */
	public void addItems(String alias, String... values) {
		ItemValue itemValue = new ItemValue(alias);
		for (String value : values) {
			itemValue.addValue(value);
		}

		itemValues.add(itemValue);
	}

	/**
	 * <pre>
	 * 호출할 룰(rule)의 기준 일자를 설정한다.
	 * 
	 * 기준일자는 룰의 버전이 여러 개인 경우 해당일자에 사용 중인 룰이 실행 된다.
	 * 기준일자를 지정하기 않으면 현재 일자(서비스 실행일자)를 기준 일자로 사용한다.
	 * </pre>
	 * 
	 * @param date YYYY-MM-DD 형식의 날짜 문자열
	 */
	public void setRuleDate(String date) {
		Matcher matcher = datePattern.matcher(date);

		if (matcher.matches()) {
			this.ruleDate = date;
		} else {
			throw new CuinBizException("Illegal date format : " + date + " (YYYY-MM-DD) formatted date required");
		}
	}

	/**
	 * <pre>
	 * 룰 엔진(rule engine)을 호출하는 사용자 ID(로그인 계정)를 설정한다.
	 * (개발 시 디버깅, 운영 시 영향도 관리를 위해 사용된다.)
	 * </pre>
	 * 
	 * @param userId 로그인 계정
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * <pre>
	 * 룰 엔진(rule engine)을 호출하는 서비스 ID를 설정한다.
	 * 
	 * (룰을 호출하는 프로그램 ID, 가급적 호출 서비스의 fully qualified name 설정해야 한다.)
	 * </pre>
	 * 
	 * @param serviceId 룰 호출 서비스 ID
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	/**
	 * <pre>
	 * 룰(rule) 인터페이스를 호출한 후, 실행 결과를 반환한다.
	 * </pre>
	 * 
	 * @return 룰 호출 결과 데이터 셋 (ResultSet)
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ResultSet execute() {

		// 필수 입력 항목 검사.
		if (ruleCode == null) {
			throw new HoneException("Must set 'ruleCode', call setRuleCode(ruleCode) please.");
		}

		// rule 요청을 위한 필수 인자 설정
		RuleReq ruleReq = new RuleReq();
		ruleReq.setRuleCode(ruleCode);
		if (ruleDate != null) {
			ruleReq.setDate(ruleDate);
		}
		for (ItemValue itemValue : itemValues) {
			ruleReq.addItem(itemValue);
		}

		// 룰 호출 로그 생성을 위한 추가 인자 설정
		HashMap callctx = new HashMap();
		Properties pros = new Properties();
		pros.put("userid", userId);
		pros.put("appid", serviceId);
		callctx.put("ruletrace.loginfo", pros);
		ruleReq.setAdditional(callctx);

		RulesInterface ruleInterface = null;
		ResultSet resultSet = null;

		boolean isThrowBizException = false;
		try {
			ruleInterface = ConnectionProperties.getConnection();
			resultSet = ruleInterface.execute(ruleReq, Constants.CODETYPE_ALIAS);
		} catch (RulesException re) {
			logger.error(re.getMessage(), re);
			isThrowBizException = true;
		} finally {
			if (ruleInterface != null) {
				ruleInterface.close();
			}
		}
		// PreserveStackTrace 를 회피하기 위한 코드
		if (isThrowBizException) {
			throw new CuinBizException("Error while request rule");
		}

		return resultSet;
	}
}
