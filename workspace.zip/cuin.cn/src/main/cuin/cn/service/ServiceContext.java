package cuin.cn.service;

import hone.common.util.DateUtils;
import hone.common.util.StringUtils;
import hone.core.util.ApplicationContextHolder;
import hone.core.util.request.RequestContextUtils;

import java.sql.Timestamp;

import cuin.cn.dbio.core.appmsg.AppMsgDao;
import cuin.cn.exception.CuinException;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 API
 * 파 일 명 : ServiceContext.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.31
 * 설    명 : 신협 공제 온라인 서비스 실행 중 컨트롤러, 서비스, DAO 컴포넌트 간 공유하는 정보들을 읽거나 설정하는 API.  서비스 컨텍스트(service context)는 전문 컨트롤러 계층에서 전문 거래 서비스 인스턴스를 준비하는 시점에 준비(초기화)되며,  서비스 인스턴스가 전문 응답을 전송하고 종료하는 시점에 서비스 컨텍스트는 자동으로 제거된다.  온라인 서비스 개발자는 컨트롤러가 서비스 컨텍스트에 담아놓은 '전사 공통 키(global ID'),  '거래코드', '화면 ID' 등을 이용해 서비스 실행 관련 정보를 획득할 수 있다.  또한, 서비스 실행 중 다양한 컴포넌트(서비스, DAO, 공통 모듈 등)에서 공유해야 하는 객체들을 보관하는 용도로 사용할 수 있다.  서비스 컨텍스트에서 정보를 조회하는 코드 예제는 아래와 같다.   전사 공통 키 조회  ServiceContext.getAttribute(ServiceContext.GLOBAL_ID);   서비스 내에서 사용하는 속성 설정 및 조회  ServiceContext.setAttribute("key1", "value1");  ServiceContext.getAttribute("key1");  }
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public final class ServiceContext {

	// 줄바꿈 문자
	private static final String LINE_BREAK = "\n";
	// 어플리케이션 메시지 최대 길이 제한
	private static final int MAX_APP_MSG_LEN = 100 * 99;
	// 메시지 출력 처리 속성 기본 값. (메시지 도착 즉시 팝업 윈도우에 출력)
	private static final String DEFAULT_MSG_PRT_ATTR = "10100000";
	// 업무 메시지 조회 DAO
	private static AppMsgDao appMsgDao;

	/**
	 * 메시지 출력 유형
	 */
	public enum MsgPrtType {
		/**
		 * 팝업 창으로 출력
		 */
		POPUP("0100000"),
		/**
		 * Alert 화면으로 출력
		 */
		ALERT("0010000"),
		/**
		 * status bar 혹은 메시지 프레임에 출력
		 */
		STATUS_BAR("0001000");

		private String attr;

		MsgPrtType(String attr) {
			this.attr = attr;
		}

		public String toString() {
			return attr;
		}
	}

	/**
	 * 서비스 컨텍스트 시스템 속성
	 */
	public enum ContextSysAttr {
		/**
		 * 전사 공통 키(global ID) 속성 키(key)
		 */
		GLOBAL_ID("globalId"),
		/**
		 * 채널 ID 키(key)
		 */
		CHANNEL_ID("channelId"),
		/**
		 * 거래 코드 속성 키(key)
		 */
		TRANSACTION_CODE("transactionCode"),
		/**
		 * 화면 ID 속성 키(key)
		 */
		SCREEN_ID("screenId"),
		/**
		 * 메시지 출력 처리 속성 키 (key)
		 */
		MSG_PRT_ATTR("msgPrtAttr"),
		/**
		 * 어플리케이션 메시지 속성 키 (key)
		 */
		APP_MSG("appMsg"),
		/**
		 * 클라이언트 IP 주소 속성 키 (key)
		 */
		CLIENT_IP("clientIp"),
		/**
		 * 사용자 ID 속성 키 (key)
		 */
		USER_ID("userId"),
		/**
		 * 사원 성명 속성 키 (key)
		 */
		EMP_NM("empNm"),
		/**
		 * 사원 구분 코드 속성 키 (key)
		 */
		EMP_DV_CD("empDvCd"),
		/**
		 * 조직 코드 속성 키 (key)
		 */
		ORZ_CD("orzCd"),
		/**
		 * 조직 구분 코드 속성 키(key)
		 */
		ORZ_DV_CD("orzDvCd"),
		/**
		 * 조직 명칭 속성 키 (key)
		 */
		ORZ_NM("orzNm"),
		/**
		 * 조합인가번호 (조합 소속인 경우에만 유효) 속성 키 (key)
		 */
		CRUN_CUOC_NO("crunCuocNo"),
		/**
		 * 조합명 (조합 소속인 경우에만 유효) 속성 키 (key)
		 */
		CRUN_CUOC_NM("crunCuocNm"),
		/**
		 * 부서 코드 (중앙회 소속인 경우에만 유효) 속성 키 (key)
		 */
		DPM_CD("dpmCd"),
		/**
		 * 부서 명칭 (중앙회 소속인 경우에만 유효) 속성 키 (key)
		 */
		DPM_NM("dpmNm"),
		/**
		 * 상위 조직 코드 (지소 코드) 속성 키 (key)
		 */
		HGR_ORZ_CD("hgrOrzCd"),
		/**
		 * 상위 조직 명칭 (지소 명칭) 속성 키 (key)
		 */
		HGR_ORZ_NM("hgrOrzNm"),
		/**
		 * 트랜잭션 타임스탬프 속성 키(key)
		 */
		TX_TIMESTAMP("txTimestamp"),
		/**
		 * 전문 헤더 (EAI 전송 등 전문 재활용이 필요한 경우 참조함)
		 */
		REQUEST_HEADER("requestHeader"),
		/**
		 * EAI 전문 순번
		 */
		EAI_TRX_SEQ("eaiTrxSeq"),
		/**
		 * 쿼리 수행 시간
		 */
		QUERY_ELPASED_TIME("queryElapsedTime");

		private String key;

		ContextSysAttr(String key) {
			this.key = key;
		}

		public String getKey() {
			return key;
		}
	}

	private ServiceContext() {
		// this class does not provide public constructor
	}

	/**
	 * 로그인 사용자의 사원번호를 반환한다.
	 *
	 * @return 로그인 사용자의 사원번호
	 */
	public static String getUserId() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.USER_ID);
	}

	/**
	 * 로그인 사용자의 성명을 반환한다.
	 *
	 * @return 로그인 사용자의 사원 성명
	 */
	public static String getEmpNm() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.EMP_NM);
	}

	/**
	 * 로그인 사용자의 사원구분코드를 반환한다.
	 *
	 * @return 로그인 사용자의 사원구분코드
	 */
	public static String getEmpDvCd() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.EMP_DV_CD);
	}

	/**
	 * 로그인 사용자의 조직 코드를 반환한다.
	 *
	 * @return 로그인 사용자의 조직 코드
	 */
	public static String getOrzCd() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.ORZ_CD);
	}

	/**
	 * 로그인 사용자의 조직 구분 코드를 반환한다.
	 *
	 * @return 로그인 사용자의 조직 구분 코드
	 */
	public static String getOrzDvCd() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.ORZ_DV_CD);
	}

	/**
	 * 로그인 사용자의 조직 명칭을 반환한다.
	 *
	 * @return 로그인 사용자의 조직 명칭
	 */
	public static String getOrzNm() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.ORZ_NM);
	}

	/**
	 * 로그인 사용자의 조합인가번호를 반환한다 (조합 소속인 경우).
	 *
	 * @return 로그인 사용자의 조합인가번호 반환 (조합 소속인 경우)
	 */
	public static String getCrunCuocNo() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.CRUN_CUOC_NO);
	}

	/**
	 * 로그인 사용자의 조합 명칭을 반환한다 (조합 소속인 경우).
	 *
	 * @return 로그인 사용자의 조합 명칭 반환 (조합 소속인 경우)
	 */
	public static String getCrunCuocNm() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.CRUN_CUOC_NM);
	}

	/**
	 * 로그인 사용자의 부서 코드를 반환한다 (중앙회 소속인 경우).
	 *
	 * @return 로그인 사용자의 부서 코드 (중앙회 소속인 경우)
	 */
	public static String getDpmCd() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.DPM_CD);
	}

	/**
	 * 로그인 사용자의 부서 명칭을 반환한다 (중앙회 소속인 경우).
	 *
	 * @return 로그인 사용자의 부서 명칭 (중앙회 소속인 경우)
	 */
	public static String getDpmNm() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.DPM_NM);
	}

	/**
	 * 로그인 사용자의 상위 부서 코드를 반환한다.
	 *
	 * @return 로그인 사용자의 상위 부서 코드
	 */
	public static String getHgrOrzCd() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.HGR_ORZ_CD);
	}

	/**
	 * 로그인 사용자의 상위 부서 명칭을 반환한다.
	 *
	 * @return 로그인 사용자의 상위 부서 명칭
	 */
	public static String getHgrOrzNm() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.HGR_ORZ_NM);
	}

	/**
	 * 시스템의 현재 날짜를 'yyyyMMdd' 형식으로 반환한다.
	 *
	 * @return 'yyyyMMdd' 형식의 현재 날짜.
	 */
	public static String getSysDate() {
		Timestamp now = (Timestamp) getSysAttr(ContextSysAttr.TX_TIMESTAMP);
		return DateUtils.getTimestampString(now, "yyyyMMdd");
	}

	/**
	 * 시스템의 현재 날짜/시간을 'yyyyMMddHHmmss' 형식으로 반환한다.
	 *
	 * @return 'yyyyMMddHHmmss' 형식의 현재 날짜 및 시간
	 */
	public static String getSysDateTime() {
		Timestamp now = (Timestamp) getSysAttr(ContextSysAttr.TX_TIMESTAMP);
		return DateUtils.getTimestampString(now, "yyyyMMddHHmmss");
	}

	/**
	 * 서비스 컨텍스트에 설정된 시스템 속성을 반환한다.
	 *
	 * @param contextSysAttr 시스템 속성 유형
	 * @return 속성 값, 존재하지 않는 키(key)를 입력한 경우 null 반환
	 */
	public static Object getSysAttr(ContextSysAttr contextSysAttr) {
		return getAttribute(contextSysAttr.getKey());
	}

	/**
	 * 서비스 컨텍스트에 시스템 속성 값을 추가한다. 이미 존재할 경우에는 덮어쓴다.
	 *
	 * @param contextSysAttr 시스템 속성 유형
	 * @param value 속성 값
	 */
	public static void setSysAttr(ContextSysAttr contextSysAttr, Object value) {
		setAttribute(contextSysAttr.getKey(), value);
	}

	/**
	 * 서비스 컨텍스트에 설정된 개별 서비스 속성을 반환한다.
	 *
	 * @param key
	 * @return 속성 값
	 * @throws key 값이 null 혹은 빈 값(empty value)이거나, 시스템 속성 키를 입력한 경우에
	 *             IllegalArgumentException 예외를 던진다.
	 */
	public static Object getServiceAttr(String key) {
		if (key == null || key.isEmpty()) {
			throw new IllegalArgumentException("Key argument is null or empty");
		}

		filterContextSysAttr(key);
		return getAttribute(key);
	}

	/**
	 * 서비스 컨텍스트에 개별 서비스 속성 값을 추가한다. 이미 존재할 경우에는 덮어쓴다.
	 *
	 * @param contextSysAttr 시스템 속성 유형
	 * @param value 속성 값
	 * @throws key 값이 null 혹은 빈 값(empty value)이거나, 시스템 속성 키를 입력한 경우에
	 *             IllegalArgumentException 예외를 던진다.
	 */
	public static void setServiceAttr(String key, Object value) {
		filterContextSysAttr(key);
		setAttribute(key, value);
	}

	/**
	 * 메시지 출력 처리 속성을 반환한다. 어플리케이션 계층에서 설정하지 않았을 경우 기본 값은 즉시 팝업 창에 출력
	 */
	public static String getMsgPrtAttr() {
		String value = (String) getAttribute(ContextSysAttr.MSG_PRT_ATTR.getKey());
		return (value != null) ? value : DEFAULT_MSG_PRT_ATTR;
	}

	/**
	 * 메시지 출력 처리 속성을 지정한다.
	 *
	 * ex) ServiceContext.setMsgPrtAttr(ServiceContext.MsgPrtType.STATUS_BAR);
	 *
	 * @param msgPrtArr 메시지 출력 처리 속성
	 */
	public static void setMsgPrtAttr(MsgPrtType msgPrtType) {
		setAttribute(ContextSysAttr.MSG_PRT_ATTR.getKey(), "1" + msgPrtType.toString());
	}

	/**
	 * <pre>
	 * 어플리케이션(서비스) 메시지를 추가한다.
	 * 단일 전문 거래 내에서 2번 이상 addServiceMessage를 호출할 경우,
	 * 메시지가 내부 버퍼에 누적된 응답 전문으로 모두 출력된다.
	 * </pre>
	 *
	 * @param 클라이언트 화면에 출력할 메시지
	 * @throws IllegalStateException 이미 추가된 메시지와 추가할 메시지를 결합한 메시지 길이가 제한을 초과할 경우
	 *             예외 발생
	 */
	private static void appendAppMessage(String msg) {

		if (msg == null || msg.isEmpty()) {
			throw new IllegalArgumentException("message argument is null or missing");
		}

		String appMsgs = (String) getSysAttr(ContextSysAttr.APP_MSG);
		int appMsgsLen = (appMsgs != null) ? appMsgs.length() : 0;
		if ((appMsgsLen + msg.length() + 1) > MAX_APP_MSG_LEN) {
			throw new IllegalStateException("Cannot append message(overflow error). max allowed lenghth is " + MAX_APP_MSG_LEN);
		}

		StringBuilder sb = new StringBuilder();
		if (appMsgs != null && appMsgs.length() > 0) {
			sb.append(appMsgs).append(LINE_BREAK);
		}
		sb.append(msg);
		setSysAttr(ContextSysAttr.APP_MSG, sb.toString());
	}

	/**
	 * 예외 발생 시, 서비스 메시지를 추가한 후 서비스를 종료한다.
	 *
	 * @param msgTxt 예외 상황에 대한 추가 정보를 제공하는 메시지
	 * @param thr 원본 예외 (cause exception)
	 */
	public static void addAppMessage(String msgTxt, Exception ex) {
		throw new CuinException(msgTxt, ex);
	}

	/**
	 * <pre>
	 * 어플리케이션(서비스) 메시지를 추가한다.
	 * 단일 전문 거래 내에서 2번 이상 addServiceMessage를 호출할 경우,
	 * 메시지가 내부 버퍼에 누적된 응답 전문으로 모두 출력된다.
	 * </pre>
	 *
	 * @param msgTxt 클라이언트 화면에 출력할 메시지
	 * @throws IllegalStateException 누적된 메시지 길이가 최대 길이 제한을 초과할 경우 예외 발생
	 * @throws IllegalArgumentException 존재하지 않는 메시지 코드를 입력한 경우
	 */
	public static void addAppMessage(String msgTxt) {
		appendAppMessage(msgTxt);
	}

	/**
	 * <pre>
	 * 어플리케이션(서비스) 메시지를 추가한다.
	 * 단일 전문 거래 내에서 2번 이상 addServiceMessage를 호출할 경우,
	 * 메시지가 내부 버퍼에 누적된 응답 전문으로 모두 출력된다.
	 * </pre>
	 *
	 * @param msgCode 클라이언트 화면에 출력할 메시지 코드
	 * @throws IllegalStateException 누적된 메시지 길이가 최대 길이 제한을 초과할 경우 예외 발생
	 * @throws IllegalArgumentException 존재하지 않는 메시지 코드를 입력한 경우
	 */
	public static void addAppMessageCode(String msgCode) {

		if (StringUtils.isEmpty(msgCode)) {
			throw new IllegalArgumentException("msgCode is null or empty.");
		}

		appendAppMessage(getAppMsgDao().getAppMsg(msgCode));
	}

	/**
	 * <pre>
	 * 어플리케이션(서비스) 메시지를 추가한다.
	 * 단일 전문 거래 내에서 2번 이상 addServiceMessage를 호출할 경우,
	 * 메시지가 내부 버퍼에 누적된 응답 전문으로 모두 출력된다.
	 * </pre>
	 *
	 * @param msgCode 클라이언트 화면에 출력할 메시지 코드
	 * @param args 메시지 출력 인자
	 * @throws IllegalStateException 누적된 메시지 길이가 최대 길이 제한을 초과할 경우 예외 발생
	 * @throws IllegalArgumentException 존재하지 않는 메시지 코드를 입력한 경우
	 */
	public static void addAppMessageCode(String msgCode, Object... args) {
		String msgTxt = getAppMsgDao().getAppMsg(msgCode);
		appendAppMessage(String.format(msgTxt, args));
	}

	/**
	 * 시스템 속성 키를 입력한 경우에 IllegalArgumentException을 발생한다.
	 *
	 * @param key 컨텍스트 속성 키
	 */
	private static void filterContextSysAttr(String key) {
		ContextSysAttr[] sysValues = ContextSysAttr.values();
		for (ContextSysAttr sysAttr : sysValues) {
			if (sysAttr.getKey().equals(key)) {
				throw new IllegalArgumentException("System arguement key is not allowed : " + key);
			}
		}
	}

	/**
	 * 서비스 컨텍스트에 설정된 속성을 반환한다.
	 *
	 * @param key 속성 키(key)
	 * @return 속성 값, 존재하지 않는 키(key)를 입력한 경우 null 반환
	 */
	private static Object getAttribute(String key) {
		return RequestContextUtils.getRequestContext().getAttribute(key);
	}

	/**
	 * 서비스 컨텍스트에 속성을 추가한다. 이미 존재할 경우에는 덮어쓴다.
	 *
	 * @param key 속성 키(key)
	 * @param value 속성 값
	 */
	private static void setAttribute(String key, Object value) {
		RequestContextUtils.getRequestContext().setAttribute(key, value);
	}

	private static AppMsgDao getAppMsgDao() {
		if (appMsgDao == null) {
			appMsgDao = ApplicationContextHolder.getApplicationContext().getBean(AppMsgDao.class);
		}
		return appMsgDao;
	}

}
