package cuin.cn.innr.dto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : InnrLkRcveErrDto.java
 * 작 성 자 : 이태훈
 * 작 성 일 : 2013.11.21
 * 설    명 : 대내 인터페이스 오류 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class InnrLkRcveErrDto implements InnrLkRcveDto {
	private static final long serialVersionUID = -4223824818265520560L;

	private String errMsg;
	private String sysErrCd;

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public String getSysErrCode() {
		return sysErrCd;
	}

	public void setSysErrCode(String sysErrCd) {
		this.sysErrCd = sysErrCd;
	}
}
