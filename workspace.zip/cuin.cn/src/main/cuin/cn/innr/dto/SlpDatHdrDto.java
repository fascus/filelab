package cuin.cn.innr.dto;

import java.io.Serializable;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : MesgDatHdrDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.11.30
 * 설    명 : 통장인쇄/전표발행 데이터 헤더 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class SlpDatHdrDto implements Serializable {

	private static final long serialVersionUID = -7764231203403828503L;

	private String datType;
	private int datLen;
	private String txId;
	private String scrId1;
	private int formCnt;
	private String scrId2;

	public String getDatType() {
		return datType;
	}

	public void setDatType(String datType) {
		this.datType = datType;
	}

	public int getDatLen() {
		return datLen;
	}

	public void setDatLen(int datLen) {
		this.datLen = datLen;
	}

	public String getTxId() {
		return txId;
	}

	public void setTxId(String txId) {
		this.txId = txId;
	}

	public String getScrId1() {
		return scrId1;
	}

	public void setScrId1(String scrId1) {
		this.scrId1 = scrId1;
	}

	public int getFormCnt() {
		return formCnt;
	}

	public void setFormCnt(int formCnt) {
		this.formCnt = formCnt;
	}

	public String getScrId2() {
		return scrId2;
	}

	public void setScrId2(String scrId2) {
		this.scrId2 = scrId2;
	}

	@Override
	public String toString() {
		return "SlpDatHdrDto [datType=" + datType + ", datLen=" + datLen + ", txId=" + txId + ", scrId1=" + scrId1 + ", formCnt=" + formCnt + ", scrId2=" + scrId2 + "]";
	}

}
