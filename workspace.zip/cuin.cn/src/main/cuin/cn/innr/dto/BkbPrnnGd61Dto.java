package cuin.cn.innr.dto;

import java.io.Serializable;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : BkbPrnnGd61Dto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.11.30
 * 설    명 : 통장 인쇄 그리드 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class BkbPrnnGd61Dto implements Serializable {

	private static final long serialVersionUID = 6152913423437182267L;

	// 통장인자거래구분코드
	private String pbookPrtTrTyCode;
	// 통장인자처리일자
	private String pbookPrtProcDate;
	// 통장인자거래종류1
	private String pbookPrtTrKind1;
	// 통장인자적요12
	private String pbookPrtRemk12;
	// 통장인자적요11
	private String pbookPrtRemk11;
	// 통장인자적요13
	private String pbookPrtRemk13;
	// 통장인자취급조합인가번호
	private String pbookPrtTretCuIngno;
	// 통장인자메시지1
	private String pbookPrtMsg1;
	// 통장인자메시지2
	private String pbookPrtMsg2;
	// 통장인자메시지3
	private String pbookPrtMsg3;
	// 통장인자처리일자2
	private String pbookPrtProcDate2;
	// 통장인자거래종류2
	private String pbookPrtTrKind2;
	// 통장인자적요22
	private String pbookPrtRemk22;
	// 통장인자적요21
	private String pbookPrtRemk21;
	// 통장인자적요23
	private String pbookPrtRemk23;
	// 통장인자취급조합번호2
	private String pbookPrtTretCuNo2;
	// 통장인자처리일자3
	private String pbookPrtProcDate3;
	// 통장인자거래종류3
	private String pbookPrtTrKind3;
	// 통장인자적요32
	private String pbookPrtRemk32;
	// 통장인자적요31
	private String pbookPrtRemk31;
	// 통장인자적요33
	private String pbookPrtRemk33;
	// 통장인자취급조합번호3
	private String pbookPrtTretCuNo3;
	// 통장인자시작라인
	private int pbookPrtBeginLine;

	public String getPbookPrtTrTyCode() {
		return pbookPrtTrTyCode;
	}

	public void setPbookPrtTrTyCode(String pbookPrtTrTyCode) {
		this.pbookPrtTrTyCode = pbookPrtTrTyCode;
	}

	public String getPbookPrtProcDate() {
		return pbookPrtProcDate;
	}

	public void setPbookPrtProcDate(String pbookPrtProcDate) {
		this.pbookPrtProcDate = pbookPrtProcDate;
	}

	public String getPbookPrtTrKind1() {
		return pbookPrtTrKind1;
	}

	public void setPbookPrtTrKind1(String pbookPrtTrKind1) {
		this.pbookPrtTrKind1 = pbookPrtTrKind1;
	}

	public String getPbookPrtRemk12() {
		return pbookPrtRemk12;
	}

	public void setPbookPrtRemk12(String pbookPrtRemk12) {
		this.pbookPrtRemk12 = pbookPrtRemk12;
	}

	public String getPbookPrtRemk11() {
		return pbookPrtRemk11;
	}

	public void setPbookPrtRemk11(String pbookPrtRemk11) {
		this.pbookPrtRemk11 = pbookPrtRemk11;
	}

	public String getPbookPrtRemk13() {
		return pbookPrtRemk13;
	}

	public void setPbookPrtRemk13(String pbookPrtRemk13) {
		this.pbookPrtRemk13 = pbookPrtRemk13;
	}

	public String getPbookPrtTretCuIngno() {
		return pbookPrtTretCuIngno;
	}

	public void setPbookPrtTretCuIngno(String pbookPrtTretCuIngno) {
		this.pbookPrtTretCuIngno = pbookPrtTretCuIngno;
	}

	public String getPbookPrtMsg1() {
		return pbookPrtMsg1;
	}

	public void setPbookPrtMsg1(String pbookPrtMsg1) {
		this.pbookPrtMsg1 = pbookPrtMsg1;
	}

	public String getPbookPrtMsg2() {
		return pbookPrtMsg2;
	}

	public void setPbookPrtMsg2(String pbookPrtMsg2) {
		this.pbookPrtMsg2 = pbookPrtMsg2;
	}

	public String getPbookPrtMsg3() {
		return pbookPrtMsg3;
	}

	public void setPbookPrtMsg3(String pbookPrtMsg3) {
		this.pbookPrtMsg3 = pbookPrtMsg3;
	}

	public String getPbookPrtProcDate2() {
		return pbookPrtProcDate2;
	}

	public void setPbookPrtProcDate2(String pbookPrtProcDate2) {
		this.pbookPrtProcDate2 = pbookPrtProcDate2;
	}

	public String getPbookPrtTrKind2() {
		return pbookPrtTrKind2;
	}

	public void setPbookPrtTrKind2(String pbookPrtTrKind2) {
		this.pbookPrtTrKind2 = pbookPrtTrKind2;
	}

	public String getPbookPrtRemk22() {
		return pbookPrtRemk22;
	}

	public void setPbookPrtRemk22(String pbookPrtRemk22) {
		this.pbookPrtRemk22 = pbookPrtRemk22;
	}

	public String getPbookPrtRemk21() {
		return pbookPrtRemk21;
	}

	public void setPbookPrtRemk21(String pbookPrtRemk21) {
		this.pbookPrtRemk21 = pbookPrtRemk21;
	}

	public String getPbookPrtRemk23() {
		return pbookPrtRemk23;
	}

	public void setPbookPrtRemk23(String pbookPrtRemk23) {
		this.pbookPrtRemk23 = pbookPrtRemk23;
	}

	public String getPbookPrtTretCuNo2() {
		return pbookPrtTretCuNo2;
	}

	public void setPbookPrtTretCuNo2(String pbookPrtTretCuNo2) {
		this.pbookPrtTretCuNo2 = pbookPrtTretCuNo2;
	}

	public String getPbookPrtProcDate3() {
		return pbookPrtProcDate3;
	}

	public void setPbookPrtProcDate3(String pbookPrtProcDate3) {
		this.pbookPrtProcDate3 = pbookPrtProcDate3;
	}

	public String getPbookPrtTrKind3() {
		return pbookPrtTrKind3;
	}

	public void setPbookPrtTrKind3(String pbookPrtTrKind3) {
		this.pbookPrtTrKind3 = pbookPrtTrKind3;
	}

	public String getPbookPrtRemk32() {
		return pbookPrtRemk32;
	}

	public void setPbookPrtRemk32(String pbookPrtRemk32) {
		this.pbookPrtRemk32 = pbookPrtRemk32;
	}

	public String getPbookPrtRemk31() {
		return pbookPrtRemk31;
	}

	public void setPbookPrtRemk31(String pbookPrtRemk31) {
		this.pbookPrtRemk31 = pbookPrtRemk31;
	}

	public String getPbookPrtRemk33() {
		return pbookPrtRemk33;
	}

	public void setPbookPrtRemk33(String pbookPrtRemk33) {
		this.pbookPrtRemk33 = pbookPrtRemk33;
	}

	public String getPbookPrtTretCuNo3() {
		return pbookPrtTretCuNo3;
	}

	public void setPbookPrtTretCuNo3(String pbookPrtTretCuNo3) {
		this.pbookPrtTretCuNo3 = pbookPrtTretCuNo3;
	}

	public int getPbookPrtBeginLine() {
		return pbookPrtBeginLine;
	}

	public void setPbookPrtBeginLine(int pbookPrtBeginLine) {
		this.pbookPrtBeginLine = pbookPrtBeginLine;
	}

	@Override
	public String toString() {
		return "BkbPrnnGd61Dto [pbookPrtTrTyCode=" + pbookPrtTrTyCode + ", pbookPrtProcDate=" + pbookPrtProcDate + ", pbookPrtTrKind1=" + pbookPrtTrKind1 + ", pbookPrtRemk12=" + pbookPrtRemk12
				+ ", pbookPrtRemk11=" + pbookPrtRemk11 + ", pbookPrtRemk13=" + pbookPrtRemk13 + ", pbookPrtTretCuIngno=" + pbookPrtTretCuIngno + ", pbookPrtMsg1=" + pbookPrtMsg1 + ", pbookPrtMsg2="
				+ pbookPrtMsg2 + ", pbookPrtMsg3=" + pbookPrtMsg3 + ", pbookPrtProcDate2=" + pbookPrtProcDate2 + ", pbookPrtTrKind2=" + pbookPrtTrKind2 + ", pbookPrtRemk22=" + pbookPrtRemk22
				+ ", pbookPrtRemk21=" + pbookPrtRemk21 + ", pbookPrtRemk23=" + pbookPrtRemk23 + ", pbookPrtTretCuNo2=" + pbookPrtTretCuNo2 + ", pbookPrtProcDate3=" + pbookPrtProcDate3
				+ ", pbookPrtTrKind3=" + pbookPrtTrKind3 + ", pbookPrtRemk32=" + pbookPrtRemk32 + ", pbookPrtRemk31=" + pbookPrtRemk31 + ", pbookPrtRemk33=" + pbookPrtRemk33 + ", pbookPrtTretCuNo3="
				+ pbookPrtTretCuNo3 + ", pbookPrtBeginLine=" + pbookPrtBeginLine + "]";
	}

}
