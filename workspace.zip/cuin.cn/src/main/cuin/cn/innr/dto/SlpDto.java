package cuin.cn.innr.dto;

import java.io.Serializable;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : SlpDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.12.02
 * 설    명 : 통장/전표 인쇄 DTO 인터페이스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface SlpDto extends Serializable {

}
