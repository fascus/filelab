package cuin.cn.innr.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : BkbPrnnDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.11.30
 * 설    명 : 통장 인쇄 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class BkbPrnnDto implements SlpDto {

	private static final long serialVersionUID = -8313717251353046083L;

	// 통장인자상품명
	private String pbookPrtStockNm;
	// 통장인자만기
	private String pbookPrtDue;
	// 통장인자대월만기일자
	private String pbookPrtOvrdDueDate;
	// 통장인자한도
	private String pbookPrtLimt;
	// 통장인자대월한도금액
	private long pbookPrtOvrdLimtAmt;
	// 통장인자계좌번호
	private String pbookPrtActno;
	// 통장인자성명
	private String pbookPrtName;
	// 통장인자잔액
	private String pbookPrtBal;
	// 통장인자통장연결번호
	private int pbookPrtPbookCnctNo;
	// GD61 list
	private List<BkbPrnnGd61Dto> gd61List = new ArrayList<BkbPrnnGd61Dto>();

	public String getPbookPrtStockNm() {
		return pbookPrtStockNm;
	}

	public void setPbookPrtStockNm(String pbookPrtStockNm) {
		this.pbookPrtStockNm = pbookPrtStockNm;
	}

	public String getPbookPrtDue() {
		return pbookPrtDue;
	}

	public void setPbookPrtDue(String pbookPrtDue) {
		this.pbookPrtDue = pbookPrtDue;
	}

	public String getPbookPrtOvrdDueDate() {
		return pbookPrtOvrdDueDate;
	}

	public void setPbookPrtOvrdDueDate(String pbookPrtOvrdDueDate) {
		this.pbookPrtOvrdDueDate = pbookPrtOvrdDueDate;
	}

	public String getPbookPrtLimt() {
		return pbookPrtLimt;
	}

	public void setPbookPrtLimt(String pbookPrtLimt) {
		this.pbookPrtLimt = pbookPrtLimt;
	}

	public long getPbookPrtOvrdLimtAmt() {
		return pbookPrtOvrdLimtAmt;
	}

	public void setPbookPrtOvrdLimtAmt(long pbookPrtOvrdLimtAmt) {
		this.pbookPrtOvrdLimtAmt = pbookPrtOvrdLimtAmt;
	}

	public String getPbookPrtActno() {
		return pbookPrtActno;
	}

	public void setPbookPrtActno(String pbookPrtActno) {
		this.pbookPrtActno = pbookPrtActno;
	}

	public String getPbookPrtName() {
		return pbookPrtName;
	}

	public void setPbookPrtName(String pbookPrtName) {
		this.pbookPrtName = pbookPrtName;
	}

	public String getPbookPrtBal() {
		return pbookPrtBal;
	}

	public void setPbookPrtBal(String pbookPrtBal) {
		this.pbookPrtBal = pbookPrtBal;
	}

	public int getPbookPrtPbookCnctNo() {
		return pbookPrtPbookCnctNo;
	}

	public void setPbookPrtPbookCnctNo(int pbookPrtPbookCnctNo) {
		this.pbookPrtPbookCnctNo = pbookPrtPbookCnctNo;
	}

	public List<BkbPrnnGd61Dto> getGd61List() {
		return gd61List;
	}

	public void setGd61List(List<BkbPrnnGd61Dto> gd61List) {
		this.gd61List = gd61List;
	}

	@Override
	public String toString() {
		return "BkbPrnnDto [pbookPrtStockNm=" + pbookPrtStockNm + ", pbookPrtDue=" + pbookPrtDue + ", pbookPrtOvrdDueDate=" + pbookPrtOvrdDueDate + ", pbookPrtLimt=" + pbookPrtLimt
				+ ", pbookPrtOvrdLimtAmt=" + pbookPrtOvrdLimtAmt + ", pbookPrtActno=" + pbookPrtActno + ", pbookPrtName=" + pbookPrtName + ", pbookPrtBal=" + pbookPrtBal + ", pbookPrtPbookCnctNo="
				+ pbookPrtPbookCnctNo + ", gd61List=" + gd61List + "]";
	}

}
