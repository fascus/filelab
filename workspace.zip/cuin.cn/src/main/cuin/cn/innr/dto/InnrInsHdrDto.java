package cuin.cn.innr.dto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : InnrInsHdrDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.13
 * 설    명 : 신협공제 대내 공통 헤더 DTO (900 byte).
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class InnrInsHdrDto {
	// 업무거래일자 (8)
	private String caProcDate;
	// 업무취소구분 (1)
	private String caCanTy;
	// 업무취소사유코드 (2)
	private String caCanResnCode;
	// 업무정정구분 (1)
	private String caCrctTy;
	// 업무정정사유코드 (2)
	private String caCrctResnCode;
	// 업무연속구분 (1)
	private String caContTy;
	// 업무원전문번호 (32)
	private String caWonMsgno;
	// 업무원거래코드 (12)
	private String caWonTrCode;
	// 업무전표번호 (6)
	private String caSlipNo;
	// 업무계좌번호 (30)
	private String caBusiActno;
	// 업무구입금계좌번호 (16)
	private String caOldIamtActno;
	// 업무구출금계좌번호 (16)
	private String caOldOamtActno;
	// 업무CD거래업무코드 (3)
	private String caCdTrBusiCode;
	// 업무거래후잔액 (18)
	private long caTrAfBal;
	// 업무연결전표번호 (6)
	private String caCnctSlipNo;
	// 업무수수료계산금액 (18)
	private long caFeeCalcAmt;
	// 업무수수료감면구분 (1)
	private String caFeeRdonTy;
	// 업무수수료조정금액 (18)
	private long caFeeAdjuAmt;
	// 업무취급수수료 (18)
	private long caTretFee;
	// 업무개설수수료 (18)
	private long caOpenFee;
	// 업무수취수수료 (18)
	private long caRecvFee;
	// 업무계좌조합인가번호 (5)
	private String caActCuIngno;
	// 업무계좌본지소코드 (2)
	private String caActMainBrofiCode;
	// 업무계좌조합원고유번호 (14)
	private String caActCustUnqno;
	// 업무계좌상품코드 (4)
	private String caActStockCode;
	// 업무계좌여수신구분 (1)
	private String caActLndpTy;
	// 업무계좌조합원여부 (1)
	private String caActCustYn;
	// 업무기동거래 (1)
	private String caBusiManeTr;
	// 업무취소거래코드 (12)
	private String caCanTrCode;
	// 업무대외응답코드 (10)
	private String caForeRespCode;
	// 업무수수료종류코드 (3)
	private String caFeeKindCode;
	// 업무취급은행코드 (2)
	private String caTretBankCode;
	// 업무망구분 (1)
	private String caNetTy;
	// 업무당타발구분 (1)
	private String caOtherTy;
	// 업무수수료환구분 (1)
	private String caFeeExchTy;
	// 업무환거래구분 (1)
	private String caExchTrTy;
	// 업무휴일구분 (1)
	private String caHdayTy;
	// 업무마감전후구분 (1)
	private String caClosBfafTy;
	// 업무수수료기관구분 (1)
	private String caFeeOrgnTy;
	// 업무통화코드 (3)
	private String caCurrCode;
	// 업무기준금액 (18)
	private long caBaseAmt;
	// 업무감면금액 (18)
	private long caRdonAmt;
	// 업무발급건수 (9)
	private long caIsueCnt;
	// 업무수표종류 (2)
	private String caChqKind;
	// 업무증명서발급구분 (1)
	private String caCertIsueTy;
	// 업무처리점구분 (1)
	private String caProcBrTy;
	// 업무현금대체구분 (2)
	private String caCashTrnsTy;
	// 업무개설은행코드 (2)
	private String caOpenBankCode;
	// 업무개설조합인가번호 (5)
	private String caOpenCuIngno;
	// 업무개설본지점코드 (2)
	private String caOpenMnbrCode;
	// 업무출금계좌번호 (16)
	private String caOamtActno;
	// 업무수취은행코드 (2)
	private String caRecvBankCode;
	// 업무수취조합인가번호 (5)
	private String caRecvCuIngno;
	// 업무수취본지점코드 (2)
	private String caRecvMnbrCode;
	// 업무입금계좌번호 (16)
	private String caIamtCctno;
	// 업무수수료징구금액 (18)
	private long caFeeCollAmt;
	// 업무회계거래종류코드 (3)
	private String caAcoTrKindCode;
	// 업무회계정산코드 (3)
	private String caAcoSettCode;
	// 업무개설정산코드 (3)
	private String caOpenSettCode;
	// 업무수취정산코드 (3)
	private String caRecvSettCode;
	// 업무회계업무분류코드 (2)
	private String caAcoBusiClasCode;
	// 업무전표유무 (1)
	private String caSlipExst;
	// 업무인자유무 (1)
	private String caPrtExst;
	// 업무거래분류구분 (2)
	private String caTrClasTy;
	// 업무회비인가번호 (5)
	private String caMbfeeIngno;
	// 업무환한도거래구분코드 (2)
	private String caExchLimtTrTyCode;
	// 업무환한도거래유형 (2)
	private String caExchLimtTrTy;
	// 업무CMS고객번호 (20)
	private String caCmsCustNo;
	// 업무ARS코드 (2)
	private String caArsCode;
	// 업무상대은행코드 (2)
	private String caEachBankCode;
	// 업무상대은행지점코드 (6)
	private String caEachBankBrCode;
	// 업무상대계좌번호 (16)
	private String caEachActno;
	// 업무상대계좌예금주 (40)
	private String caEachActDepor;
	// 업무카드번호 (20)
	private String caCardNo;
	// 업무적요 (40)
	private String caRemk;
	// 업무공백1 (1)
	private String caSpc1;
	// 업무공백2 (2)
	private String caSpc2;
	// 업무공백3 (3)
	private String caSpc3;
	// 업무공백5 (5)
	private String caSpc5;
	// 업무공백16 (16)
	private String caSpc16;
	// 대외거래일자 (8)
	private String fiTrDate;
	// 대외거래고유번호 (12)
	private String fiTrUnqno;
	// 대외전문추적번호 (6)
	private String fiMsgTracNo;
	// 대외거래종류 (4)
	private String fiTrKindCode;
	// 대외업무거래구분 (2)
	private String fiBusiTy;
	// 대외기관구분 (3)
	private String fiOrgnTy;
	// 대외마감구분 (1)
	private String fiClosTy;
	// 대외당타발구분 (1)
	private String fiThisOutTy;
	// 대외당타지구분 (1)
	private String fiHtTy;
	// 대외3행입출금구분 (1)
	private String fiCdIoamtTy;
	// 대외내부응답코드 (8)
	private String fiInsdRespCode;
	// 대외응답코드 (4)
	private String fiRespCode;
	// 대외응답서비스명 (12)
	private String fiRespServNm;
	// 대외개설어음교환소코드 (2)
	private String fiOpenCghousCode;
	// 대외취급어음교환소코드 (2)
	private String fiTretCghousCode;
	// 대외수취어음교환소코드 (2)
	private String fiRecvCghousCode;
	// 대외에러응답여부 (1)
	private String fiErrRespYn;
	// 대외출금계좌번호 (16)
	private String fiOamtActno;
	// 대외출금계좌주 (20)
	private String fiOamtName;
	// 대외입금계좌번호 (16)
	private String fiIamtActno;
	// 대외입금계좌주 (20)
	private String fiIamtName;
	// 대외카드번호 (16)
	private String fiCardNo;
	// 대외관리인가번호 (5)
	private String fiIngno;
	// 대외비동기화 (1)
	private String fiNonXa;
	// 대외공동망지점번호 (6)
	private String fiNetwCode;
	// 대외거래구분코드 (6)
	private String fiTrTyCode;
	// 대외포멧오류 (1)
	private String fiFormatErrYn;
	// 대외거래종별 (4)
	private String fiMsgClas;
	// 대외거래구분 (6)
	private String fiTrTy;
	// 대외취급인가번호 (5)
	private String fiTretIngno;
	// 대외취급본지점코드 (2)
	private String fiTretBrofiCode;
	// 대외출금계좌관리인가번호 (5)
	private String fiOamtIngno;
	// 대외출금본지점코드 (2)
	private String fiOamtBrofiCode;
	// 대외입금계좌관리인가번호 (5)
	private String fiIamtIngno;
	// 대외입금본지점코드 (2)
	private String fiIamtBrofiCode;
	// 대외거래금액 (18)
	private long fiTrAmt;
	// 대외수수료금액 (18)
	private long fiFeeAmt;
	// 대외조합원고유번호 (14)
	private String fiCustUnqno;
	// 대외여유 (13)
	private String fiFiller;

	public String getCaProcDate() {
		return caProcDate;
	}

	public void setCaProcDate(String caProcDate) {
		this.caProcDate = caProcDate;
	}

	public String getCaCanTy() {
		return caCanTy;
	}

	public void setCaCanTy(String caCanTy) {
		this.caCanTy = caCanTy;
	}

	public String getCaCanResnCode() {
		return caCanResnCode;
	}

	public void setCaCanResnCode(String caCanResnCode) {
		this.caCanResnCode = caCanResnCode;
	}

	public String getCaCrctTy() {
		return caCrctTy;
	}

	public void setCaCrctTy(String caCrctTy) {
		this.caCrctTy = caCrctTy;
	}

	public String getCaCrctResnCode() {
		return caCrctResnCode;
	}

	public void setCaCrctResnCode(String caCrctResnCode) {
		this.caCrctResnCode = caCrctResnCode;
	}

	public String getCaContTy() {
		return caContTy;
	}

	public void setCaContTy(String caContTy) {
		this.caContTy = caContTy;
	}

	public String getCaWonMsgno() {
		return caWonMsgno;
	}

	public void setCaWonMsgno(String caWonMsgno) {
		this.caWonMsgno = caWonMsgno;
	}

	public String getCaWonTrCode() {
		return caWonTrCode;
	}

	public void setCaWonTrCode(String caWonTrCode) {
		this.caWonTrCode = caWonTrCode;
	}

	public String getCaSlipNo() {
		return caSlipNo;
	}

	public void setCaSlipNo(String caSlipNo) {
		this.caSlipNo = caSlipNo;
	}

	public String getCaBusiActno() {
		return caBusiActno;
	}

	public void setCaBusiActno(String caBusiActno) {
		this.caBusiActno = caBusiActno;
	}

	public String getCaOldIamtActno() {
		return caOldIamtActno;
	}

	public void setCaOldIamtActno(String caOldIamtActno) {
		this.caOldIamtActno = caOldIamtActno;
	}

	public String getCaOldOamtActno() {
		return caOldOamtActno;
	}

	public void setCaOldOamtActno(String caOldOamtActno) {
		this.caOldOamtActno = caOldOamtActno;
	}

	public String getCaCdTrBusiCode() {
		return caCdTrBusiCode;
	}

	public void setCaCdTrBusiCode(String caCdTrBusiCode) {
		this.caCdTrBusiCode = caCdTrBusiCode;
	}

	public long getCaTrAfBal() {
		return caTrAfBal;
	}

	public void setCaTrAfBal(long caTrAfBal) {
		this.caTrAfBal = caTrAfBal;
	}

	public String getCaCnctSlipNo() {
		return caCnctSlipNo;
	}

	public void setCaCnctSlipNo(String caCnctSlipNo) {
		this.caCnctSlipNo = caCnctSlipNo;
	}

	public long getCaFeeCalcAmt() {
		return caFeeCalcAmt;
	}

	public void setCaFeeCalcAmt(long caFeeCalcAmt) {
		this.caFeeCalcAmt = caFeeCalcAmt;
	}

	public String getCaFeeRdonTy() {
		return caFeeRdonTy;
	}

	public void setCaFeeRdonTy(String caFeeRdonTy) {
		this.caFeeRdonTy = caFeeRdonTy;
	}

	public long getCaFeeAdjuAmt() {
		return caFeeAdjuAmt;
	}

	public void setCaFeeAdjuAmt(long caFeeAdjuAmt) {
		this.caFeeAdjuAmt = caFeeAdjuAmt;
	}

	public long getCaTretFee() {
		return caTretFee;
	}

	public void setCaTretFee(long caTretFee) {
		this.caTretFee = caTretFee;
	}

	public long getCaOpenFee() {
		return caOpenFee;
	}

	public void setCaOpenFee(long caOpenFee) {
		this.caOpenFee = caOpenFee;
	}

	public long getCaRecvFee() {
		return caRecvFee;
	}

	public void setCaRecvFee(long caRecvFee) {
		this.caRecvFee = caRecvFee;
	}

	public String getCaActCuIngno() {
		return caActCuIngno;
	}

	public void setCaActCuIngno(String caActCuIngno) {
		this.caActCuIngno = caActCuIngno;
	}

	public String getCaActMainBrofiCode() {
		return caActMainBrofiCode;
	}

	public void setCaActMainBrofiCode(String caActMainBrofiCode) {
		this.caActMainBrofiCode = caActMainBrofiCode;
	}

	public String getCaActCustUnqno() {
		return caActCustUnqno;
	}

	public void setCaActCustUnqno(String caActCustUnqno) {
		this.caActCustUnqno = caActCustUnqno;
	}

	public String getCaActStockCode() {
		return caActStockCode;
	}

	public void setCaActStockCode(String caActStockCode) {
		this.caActStockCode = caActStockCode;
	}

	public String getCaActLndpTy() {
		return caActLndpTy;
	}

	public void setCaActLndpTy(String caActLndpTy) {
		this.caActLndpTy = caActLndpTy;
	}

	public String getCaActCustYn() {
		return caActCustYn;
	}

	public void setCaActCustYn(String caActCustYn) {
		this.caActCustYn = caActCustYn;
	}

	public String getCaBusiManeTr() {
		return caBusiManeTr;
	}

	public void setCaBusiManeTr(String caBusiManeTr) {
		this.caBusiManeTr = caBusiManeTr;
	}

	public String getCaCanTrCode() {
		return caCanTrCode;
	}

	public void setCaCanTrCode(String caCanTrCode) {
		this.caCanTrCode = caCanTrCode;
	}

	public String getCaForeRespCode() {
		return caForeRespCode;
	}

	public void setCaForeRespCode(String caForeRespCode) {
		this.caForeRespCode = caForeRespCode;
	}

	public String getCaFeeKindCode() {
		return caFeeKindCode;
	}

	public void setCaFeeKindCode(String caFeeKindCode) {
		this.caFeeKindCode = caFeeKindCode;
	}

	public String getCaTretBankCode() {
		return caTretBankCode;
	}

	public void setCaTretBankCode(String caTretBankCode) {
		this.caTretBankCode = caTretBankCode;
	}

	public String getCaNetTy() {
		return caNetTy;
	}

	public void setCaNetTy(String caNetTy) {
		this.caNetTy = caNetTy;
	}

	public String getCaOtherTy() {
		return caOtherTy;
	}

	public void setCaOtherTy(String caOtherTy) {
		this.caOtherTy = caOtherTy;
	}

	public String getCaFeeExchTy() {
		return caFeeExchTy;
	}

	public void setCaFeeExchTy(String caFeeExchTy) {
		this.caFeeExchTy = caFeeExchTy;
	}

	public String getCaExchTrTy() {
		return caExchTrTy;
	}

	public void setCaExchTrTy(String caExchTrTy) {
		this.caExchTrTy = caExchTrTy;
	}

	public String getCaHdayTy() {
		return caHdayTy;
	}

	public void setCaHdayTy(String caHdayTy) {
		this.caHdayTy = caHdayTy;
	}

	public String getCaClosBfafTy() {
		return caClosBfafTy;
	}

	public void setCaClosBfafTy(String caClosBfafTy) {
		this.caClosBfafTy = caClosBfafTy;
	}

	public String getCaFeeOrgnTy() {
		return caFeeOrgnTy;
	}

	public void setCaFeeOrgnTy(String caFeeOrgnTy) {
		this.caFeeOrgnTy = caFeeOrgnTy;
	}

	public String getCaCurrCode() {
		return caCurrCode;
	}

	public void setCaCurrCode(String caCurrCode) {
		this.caCurrCode = caCurrCode;
	}

	public long getCaBaseAmt() {
		return caBaseAmt;
	}

	public void setCaBaseAmt(long caBaseAmt) {
		this.caBaseAmt = caBaseAmt;
	}

	public long getCaRdonAmt() {
		return caRdonAmt;
	}

	public void setCaRdonAmt(long caRdonAmt) {
		this.caRdonAmt = caRdonAmt;
	}

	public long getCaIsueCnt() {
		return caIsueCnt;
	}

	public void setCaIsueCnt(long caIsueCnt) {
		this.caIsueCnt = caIsueCnt;
	}

	public String getCaChqKind() {
		return caChqKind;
	}

	public void setCaChqKind(String caChqKind) {
		this.caChqKind = caChqKind;
	}

	public String getCaCertIsueTy() {
		return caCertIsueTy;
	}

	public void setCaCertIsueTy(String caCertIsueTy) {
		this.caCertIsueTy = caCertIsueTy;
	}

	public String getCaProcBrTy() {
		return caProcBrTy;
	}

	public void setCaProcBrTy(String caProcBrTy) {
		this.caProcBrTy = caProcBrTy;
	}

	public String getCaCashTrnsTy() {
		return caCashTrnsTy;
	}

	public void setCaCashTrnsTy(String caCashTrnsTy) {
		this.caCashTrnsTy = caCashTrnsTy;
	}

	public String getCaOpenBankCode() {
		return caOpenBankCode;
	}

	public void setCaOpenBankCode(String caOpenBankCode) {
		this.caOpenBankCode = caOpenBankCode;
	}

	public String getCaOpenCuIngno() {
		return caOpenCuIngno;
	}

	public void setCaOpenCuIngno(String caOpenCuIngno) {
		this.caOpenCuIngno = caOpenCuIngno;
	}

	public String getCaOpenMnbrCode() {
		return caOpenMnbrCode;
	}

	public void setCaOpenMnbrCode(String caOpenMnbrCode) {
		this.caOpenMnbrCode = caOpenMnbrCode;
	}

	public String getCaOamtActno() {
		return caOamtActno;
	}

	public void setCaOamtActno(String caOamtActno) {
		this.caOamtActno = caOamtActno;
	}

	public String getCaRecvBankCode() {
		return caRecvBankCode;
	}

	public void setCaRecvBankCode(String caRecvBankCode) {
		this.caRecvBankCode = caRecvBankCode;
	}

	public String getCaRecvCuIngno() {
		return caRecvCuIngno;
	}

	public void setCaRecvCuIngno(String caRecvCuIngno) {
		this.caRecvCuIngno = caRecvCuIngno;
	}

	public String getCaRecvMnbrCode() {
		return caRecvMnbrCode;
	}

	public void setCaRecvMnbrCode(String caRecvMnbrCode) {
		this.caRecvMnbrCode = caRecvMnbrCode;
	}

	public String getCaIamtCctno() {
		return caIamtCctno;
	}

	public void setCaIamtCctno(String caIamtCctno) {
		this.caIamtCctno = caIamtCctno;
	}

	public long getCaFeeCollAmt() {
		return caFeeCollAmt;
	}

	public void setCaFeeCollAmt(long caFeeCollAmt) {
		this.caFeeCollAmt = caFeeCollAmt;
	}

	public String getCaAcoTrKindCode() {
		return caAcoTrKindCode;
	}

	public void setCaAcoTrKindCode(String caAcoTrKindCode) {
		this.caAcoTrKindCode = caAcoTrKindCode;
	}

	public String getCaAcoSettCode() {
		return caAcoSettCode;
	}

	public void setCaAcoSettCode(String caAcoSettCode) {
		this.caAcoSettCode = caAcoSettCode;
	}

	public String getCaOpenSettCode() {
		return caOpenSettCode;
	}

	public void setCaOpenSettCode(String caOpenSettCode) {
		this.caOpenSettCode = caOpenSettCode;
	}

	public String getCaRecvSettCode() {
		return caRecvSettCode;
	}

	public void setCaRecvSettCode(String caRecvSettCode) {
		this.caRecvSettCode = caRecvSettCode;
	}

	public String getCaAcoBusiClasCode() {
		return caAcoBusiClasCode;
	}

	public void setCaAcoBusiClasCode(String caAcoBusiClasCode) {
		this.caAcoBusiClasCode = caAcoBusiClasCode;
	}

	public String getCaSlipExst() {
		return caSlipExst;
	}

	public void setCaSlipExst(String caSlipExst) {
		this.caSlipExst = caSlipExst;
	}

	public String getCaPrtExst() {
		return caPrtExst;
	}

	public void setCaPrtExst(String caPrtExst) {
		this.caPrtExst = caPrtExst;
	}

	public String getCaTrClasTy() {
		return caTrClasTy;
	}

	public void setCaTrClasTy(String caTrClasTy) {
		this.caTrClasTy = caTrClasTy;
	}

	public String getCaMbfeeIngno() {
		return caMbfeeIngno;
	}

	public void setCaMbfeeIngno(String caMbfeeIngno) {
		this.caMbfeeIngno = caMbfeeIngno;
	}

	public String getCaExchLimtTrTyCode() {
		return caExchLimtTrTyCode;
	}

	public void setCaExchLimtTrTyCode(String caExchLimtTrTyCode) {
		this.caExchLimtTrTyCode = caExchLimtTrTyCode;
	}

	public String getCaExchLimtTrTy() {
		return caExchLimtTrTy;
	}

	public void setCaExchLimtTrTy(String caExchLimtTrTy) {
		this.caExchLimtTrTy = caExchLimtTrTy;
	}

	public String getCaCmsCustNo() {
		return caCmsCustNo;
	}

	public void setCaCmsCustNo(String caCmsCustNo) {
		this.caCmsCustNo = caCmsCustNo;
	}

	public String getCaArsCode() {
		return caArsCode;
	}

	public void setCaArsCode(String caArsCode) {
		this.caArsCode = caArsCode;
	}

	public String getCaEachBankCode() {
		return caEachBankCode;
	}

	public void setCaEachBankCode(String caEachBankCode) {
		this.caEachBankCode = caEachBankCode;
	}

	public String getCaEachBankBrCode() {
		return caEachBankBrCode;
	}

	public void setCaEachBankBrCode(String caEachBankBrCode) {
		this.caEachBankBrCode = caEachBankBrCode;
	}

	public String getCaEachActno() {
		return caEachActno;
	}

	public void setCaEachActno(String caEachActno) {
		this.caEachActno = caEachActno;
	}

	public String getCaEachActDepor() {
		return caEachActDepor;
	}

	public void setCaEachActDepor(String caEachActDepor) {
		this.caEachActDepor = caEachActDepor;
	}

	public String getCaCardNo() {
		return caCardNo;
	}

	public void setCaCardNo(String caCardNo) {
		this.caCardNo = caCardNo;
	}

	public String getCaRemk() {
		return caRemk;
	}

	public void setCaRemk(String caRemk) {
		this.caRemk = caRemk;
	}

	public String getCaSpc1() {
		return caSpc1;
	}

	public void setCaSpc1(String caSpc1) {
		this.caSpc1 = caSpc1;
	}

	public String getCaSpc2() {
		return caSpc2;
	}

	public void setCaSpc2(String caSpc2) {
		this.caSpc2 = caSpc2;
	}

	public String getCaSpc3() {
		return caSpc3;
	}

	public void setCaSpc3(String caSpc3) {
		this.caSpc3 = caSpc3;
	}

	public String getCaSpc5() {
		return caSpc5;
	}

	public void setCaSpc5(String caSpc5) {
		this.caSpc5 = caSpc5;
	}

	public String getCaSpc16() {
		return caSpc16;
	}

	public void setCaSpc16(String caSpc16) {
		this.caSpc16 = caSpc16;
	}

	public String getFiTrDate() {
		return fiTrDate;
	}

	public void setFiTrDate(String fiTrDate) {
		this.fiTrDate = fiTrDate;
	}

	public String getFiTrUnqno() {
		return fiTrUnqno;
	}

	public void setFiTrUnqno(String fiTrUnqno) {
		this.fiTrUnqno = fiTrUnqno;
	}

	public String getFiMsgTracNo() {
		return fiMsgTracNo;
	}

	public void setFiMsgTracNo(String fiMsgTracNo) {
		this.fiMsgTracNo = fiMsgTracNo;
	}

	public String getFiTrKindCode() {
		return fiTrKindCode;
	}

	public void setFiTrKindCode(String fiTrKindCode) {
		this.fiTrKindCode = fiTrKindCode;
	}

	public String getFiBusiTy() {
		return fiBusiTy;
	}

	public void setFiBusiTy(String fiBusiTy) {
		this.fiBusiTy = fiBusiTy;
	}

	public String getFiOrgnTy() {
		return fiOrgnTy;
	}

	public void setFiOrgnTy(String fiOrgnTy) {
		this.fiOrgnTy = fiOrgnTy;
	}

	public String getFiClosTy() {
		return fiClosTy;
	}

	public void setFiClosTy(String fiClosTy) {
		this.fiClosTy = fiClosTy;
	}

	public String getFiThisOutTy() {
		return fiThisOutTy;
	}

	public void setFiThisOutTy(String fiThisOutTy) {
		this.fiThisOutTy = fiThisOutTy;
	}

	public String getFiHtTy() {
		return fiHtTy;
	}

	public void setFiHtTy(String fiHtTy) {
		this.fiHtTy = fiHtTy;
	}

	public String getFiCdIoamtTy() {
		return fiCdIoamtTy;
	}

	public void setFiCdIoamtTy(String fiCdIoamtTy) {
		this.fiCdIoamtTy = fiCdIoamtTy;
	}

	public String getFiInsdRespCode() {
		return fiInsdRespCode;
	}

	public void setFiInsdRespCode(String fiInsdRespCode) {
		this.fiInsdRespCode = fiInsdRespCode;
	}

	public String getFiRespCode() {
		return fiRespCode;
	}

	public void setFiRespCode(String fiRespCode) {
		this.fiRespCode = fiRespCode;
	}

	public String getFiRespServNm() {
		return fiRespServNm;
	}

	public void setFiRespServNm(String fiRespServNm) {
		this.fiRespServNm = fiRespServNm;
	}

	public String getFiOpenCghousCode() {
		return fiOpenCghousCode;
	}

	public void setFiOpenCghousCode(String fiOpenCghousCode) {
		this.fiOpenCghousCode = fiOpenCghousCode;
	}

	public String getFiTretCghousCode() {
		return fiTretCghousCode;
	}

	public void setFiTretCghousCode(String fiTretCghousCode) {
		this.fiTretCghousCode = fiTretCghousCode;
	}

	public String getFiRecvCghousCode() {
		return fiRecvCghousCode;
	}

	public void setFiRecvCghousCode(String fiRecvCghousCode) {
		this.fiRecvCghousCode = fiRecvCghousCode;
	}

	public String getFiErrRespYn() {
		return fiErrRespYn;
	}

	public void setFiErrRespYn(String fiErrRespYn) {
		this.fiErrRespYn = fiErrRespYn;
	}

	public String getFiOamtActno() {
		return fiOamtActno;
	}

	public void setFiOamtActno(String fiOamtActno) {
		this.fiOamtActno = fiOamtActno;
	}

	public String getFiOamtName() {
		return fiOamtName;
	}

	public void setFiOamtName(String fiOamtName) {
		this.fiOamtName = fiOamtName;
	}

	public String getFiIamtActno() {
		return fiIamtActno;
	}

	public void setFiIamtActno(String fiIamtActno) {
		this.fiIamtActno = fiIamtActno;
	}

	public String getFiIamtName() {
		return fiIamtName;
	}

	public void setFiIamtName(String fiIamtName) {
		this.fiIamtName = fiIamtName;
	}

	public String getFiCardNo() {
		return fiCardNo;
	}

	public void setFiCardNo(String fiCardNo) {
		this.fiCardNo = fiCardNo;
	}

	public String getFiIngno() {
		return fiIngno;
	}

	public void setFiIngno(String fiIngno) {
		this.fiIngno = fiIngno;
	}

	public String getFiNonXa() {
		return fiNonXa;
	}

	public void setFiNonXa(String fiNonXa) {
		this.fiNonXa = fiNonXa;
	}

	public String getFiNetwCode() {
		return fiNetwCode;
	}

	public void setFiNetwCode(String fiNetwCode) {
		this.fiNetwCode = fiNetwCode;
	}

	public String getFiTrTyCode() {
		return fiTrTyCode;
	}

	public void setFiTrTyCode(String fiTrTyCode) {
		this.fiTrTyCode = fiTrTyCode;
	}

	public String getFiFormatErrYn() {
		return fiFormatErrYn;
	}

	public void setFiFormatErrYn(String fiFormatErrYn) {
		this.fiFormatErrYn = fiFormatErrYn;
	}

	public String getFiMsgClas() {
		return fiMsgClas;
	}

	public void setFiMsgClas(String fiMsgClas) {
		this.fiMsgClas = fiMsgClas;
	}

	public String getFiTrTy() {
		return fiTrTy;
	}

	public void setFiTrTy(String fiTrTy) {
		this.fiTrTy = fiTrTy;
	}

	public String getFiTretIngno() {
		return fiTretIngno;
	}

	public void setFiTretIngno(String fiTretIngno) {
		this.fiTretIngno = fiTretIngno;
	}

	public String getFiTretBrofiCode() {
		return fiTretBrofiCode;
	}

	public void setFiTretBrofiCode(String fiTretBrofiCode) {
		this.fiTretBrofiCode = fiTretBrofiCode;
	}

	public String getFiOamtIngno() {
		return fiOamtIngno;
	}

	public void setFiOamtIngno(String fiOamtIngno) {
		this.fiOamtIngno = fiOamtIngno;
	}

	public String getFiOamtBrofiCode() {
		return fiOamtBrofiCode;
	}

	public void setFiOamtBrofiCode(String fiOamtBrofiCode) {
		this.fiOamtBrofiCode = fiOamtBrofiCode;
	}

	public String getFiIamtIngno() {
		return fiIamtIngno;
	}

	public void setFiIamtIngno(String fiIamtIngno) {
		this.fiIamtIngno = fiIamtIngno;
	}

	public String getFiIamtBrofiCode() {
		return fiIamtBrofiCode;
	}

	public void setFiIamtBrofiCode(String fiIamtBrofiCode) {
		this.fiIamtBrofiCode = fiIamtBrofiCode;
	}

	public long getFiTrAmt() {
		return fiTrAmt;
	}

	public void setFiTrAmt(long fiTrAmt) {
		this.fiTrAmt = fiTrAmt;
	}

	public long getFiFeeAmt() {
		return fiFeeAmt;
	}

	public void setFiFeeAmt(long fiFeeAmt) {
		this.fiFeeAmt = fiFeeAmt;
	}

	public String getFiCustUnqno() {
		return fiCustUnqno;
	}

	public void setFiCustUnqno(String fiCustUnqno) {
		this.fiCustUnqno = fiCustUnqno;
	}

	public String getFiFiller() {
		return fiFiller;
	}

	public void setFiFiller(String fiFiller) {
		this.fiFiller = fiFiller;
	}

	@Override
	public String toString() {
		return "InnrInsHdrDto [caProcDate=" + caProcDate + ", caCanTy=" + caCanTy + ", caCanResnCode=" + caCanResnCode + ", caCrctTy=" + caCrctTy + ", caCrctResnCode=" + caCrctResnCode
				+ ", caContTy=" + caContTy + ", caWonMsgno=" + caWonMsgno + ", caWonTrCode=" + caWonTrCode + ", caSlipNo=" + caSlipNo + ", caBusiActno=" + caBusiActno + ", caOldIamtActno="
				+ caOldIamtActno + ", caOldOamtActno=" + caOldOamtActno + ", caCdTrBusiCode=" + caCdTrBusiCode + ", caTrAfBal=" + caTrAfBal + ", caCnctSlipNo=" + caCnctSlipNo + ", caFeeCalcAmt="
				+ caFeeCalcAmt + ", caFeeRdonTy=" + caFeeRdonTy + ", caFeeAdjuAmt=" + caFeeAdjuAmt + ", caTretFee=" + caTretFee + ", caOpenFee=" + caOpenFee + ", caRecvFee=" + caRecvFee
				+ ", caActCuIngno=" + caActCuIngno + ", caActMainBrofiCode=" + caActMainBrofiCode + ", caActCustUnqno=" + caActCustUnqno + ", caActStockCode=" + caActStockCode + ", caActLndpTy="
				+ caActLndpTy + ", caActCustYn=" + caActCustYn + ", caBusiManeTr=" + caBusiManeTr + ", caCanTrCode=" + caCanTrCode + ", caForeRespCode=" + caForeRespCode + ", caFeeKindCode="
				+ caFeeKindCode + ", caTretBankCode=" + caTretBankCode + ", caNetTy=" + caNetTy + ", caOtherTy=" + caOtherTy + ", caFeeExchTy=" + caFeeExchTy + ", caExchTrTy=" + caExchTrTy
				+ ", caHdayTy=" + caHdayTy + ", caClosBfafTy=" + caClosBfafTy + ", caFeeOrgnTy=" + caFeeOrgnTy + ", caCurrCode=" + caCurrCode + ", caBaseAmt=" + caBaseAmt + ", caRdonAmt=" + caRdonAmt
				+ ", caIsueCnt=" + caIsueCnt + ", caChqKind=" + caChqKind + ", caCertIsueTy=" + caCertIsueTy + ", caProcBrTy=" + caProcBrTy + ", caCashTrnsTy=" + caCashTrnsTy + ", caOpenBankCode="
				+ caOpenBankCode + ", caOpenCuIngno=" + caOpenCuIngno + ", caOpenMnbrCode=" + caOpenMnbrCode + ", caOamtActno=" + caOamtActno + ", caRecvBankCode=" + caRecvBankCode
				+ ", caRecvCuIngno=" + caRecvCuIngno + ", caRecvMnbrCode=" + caRecvMnbrCode + ", caIamtCctno=" + caIamtCctno + ", caFeeCollAmt=" + caFeeCollAmt + ", caAcoTrKindCode="
				+ caAcoTrKindCode + ", caAcoSettCode=" + caAcoSettCode + ", caOpenSettCode=" + caOpenSettCode + ", caRecvSettCode=" + caRecvSettCode + ", caAcoBusiClasCode=" + caAcoBusiClasCode
				+ ", caSlipExst=" + caSlipExst + ", caPrtExst=" + caPrtExst + ", caTrClasTy=" + caTrClasTy + ", caMbfeeIngno=" + caMbfeeIngno + ", caExchLimtTrTyCode=" + caExchLimtTrTyCode
				+ ", caExchLimtTrTy=" + caExchLimtTrTy + ", caCmsCustNo=" + caCmsCustNo + ", caArsCode=" + caArsCode + ", caEachBankCode=" + caEachBankCode + ", caEachBankBrCode=" + caEachBankBrCode
				+ ", caEachActno=" + caEachActno + ", caEachActDepor=" + caEachActDepor + ", caCardNo=" + caCardNo + ", caRemk=" + caRemk + ", caSpc1=" + caSpc1 + ", caSpc2=" + caSpc2 + ", caSpc3="
				+ caSpc3 + ", caSpc5=" + caSpc5 + ", caSpc16=" + caSpc16 + ", fiTrDate=" + fiTrDate + ", fiTrUnqno=" + fiTrUnqno + ", fiMsgTracNo=" + fiMsgTracNo + ", fiTrKindCode=" + fiTrKindCode
				+ ", fiBusiTy=" + fiBusiTy + ", fiOrgnTy=" + fiOrgnTy + ", fiClosTy=" + fiClosTy + ", fiThisOutTy=" + fiThisOutTy + ", fiHtTy=" + fiHtTy + ", fiCdIoamtTy=" + fiCdIoamtTy
				+ ", fiInsdRespCode=" + fiInsdRespCode + ", fiRespCode=" + fiRespCode + ", fiRespServNm=" + fiRespServNm + ", fiOpenCghousCode=" + fiOpenCghousCode + ", fiTretCghousCode="
				+ fiTretCghousCode + ", fiRecvCghousCode=" + fiRecvCghousCode + ", fiErrRespYn=" + fiErrRespYn + ", fiOamtActno=" + fiOamtActno + ", fiOamtName=" + fiOamtName + ", fiIamtActno="
				+ fiIamtActno + ", fiIamtName=" + fiIamtName + ", fiCardNo=" + fiCardNo + ", fiIngno=" + fiIngno + ", fiNonXa=" + fiNonXa + ", fiNetwCode=" + fiNetwCode + ", fiTrTyCode=" + fiTrTyCode
				+ ", fiFormatErrYn=" + fiFormatErrYn + ", fiMsgClas=" + fiMsgClas + ", fiTrTy=" + fiTrTy + ", fiTretIngno=" + fiTretIngno + ", fiTretBrofiCode=" + fiTretBrofiCode + ", fiOamtIngno="
				+ fiOamtIngno + ", fiOamtBrofiCode=" + fiOamtBrofiCode + ", fiIamtIngno=" + fiIamtIngno + ", fiIamtBrofiCode=" + fiIamtBrofiCode + ", fiTrAmt=" + fiTrAmt + ", fiFeeAmt=" + fiFeeAmt
				+ ", fiCustUnqno=" + fiCustUnqno + ", fiFiller=" + fiFiller + "]";
	}

}
