package cuin.cn.innr.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : BkbPrnn2Dto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.11.29
 * 설    명 : 통장 인쇄 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class BkbPrnn2Dto implements SlpDto {

	private static final long serialVersionUID = -8992726717868602889L;

	// 계좌번호
	private String actNo;
	// 인쇄여부
	private String prtYn;
	// 통장표지개설일자
	private String pbookCovrOpenDate;
	// 통장표지계좌번호
	private String pbookCovrActno;
	// 통장표지연결번호
	private int pbookCovrCnctNo;
	// 통장표지발급번호
	private String pbookCovrIsueNo;
	// 통장표지과세구분명
	private String pbookCovrTaxTyNm;
	// 통장표지조합원번호
	private String pbookCovrCustNo;
	// 통장표지실명번호
	private String pbookCovrRealNo;
	// 통장표지사원번호
	private String pbookCovrEmpno;
	// 통장표지성명
	private String pbookCovrName;
	// 통장표지년도
	private String pbookCovrYear;
	// 통장표지월수
	private String pbookCovrMms;
	// 통장표지일수
	private String pbookCovrDds;
	// 통장표지약어명
	private String pbookCovrAbbrNm;
	// 통장표지본지소명
	private String pbookCovrMnbrNm;
	// 통장표지본지소명1
	private String pbookCovrMnbrNm1;
	// 통장표지전화번호
	private String pbookCovrTelNo;
	// 통장표지전화번호1
	private String pbookCovrTelNo1;
	// 통장표지학교명
	private String pbookCovrSchlNm;
	// 통장표지반1
	private String pbookCovrClss1;
	// 통장표지번호1
	private String pbookCovrNo1;
	// 통장표지반2
	private String pbookCovrClss2;
	// 통장표지번호2
	private String pbookCovrNo2;
	// 통장표지반3
	private String pbookCovrClss3;
	// 통장표지번호3
	private String pbookCovrNo3;
	// 통장표지반4
	private String pbookCovrClss4;
	// 통장표지번호4
	private String pbookCovrNo4;
	// 통장표지반5
	private String pbookCovrClss5;
	// 통장표지번호5
	private String pbookCovrNo5;
	// 통장표지반6
	private String pbookCovrClss6;
	// 통장표지번호6
	private String pbookCovrNo6;
	// 통장표지계약기간
	private int pbookCovrContrTerm;
	// 통장표지만기일자
	private String pbookCovrDueDate;
	// 통장표지불입일자
	private String pbookCovrPamentDate;
	// 통장표지매일납입금액
	private long pbookCovrEddPaymAmt;
	// 통장표지만기금액
	private long pbookCovrDueAmt;
	// 통장표지월불입금액
	private long pbookCovrMmPamentAmt;
	// 통장표지월불입일
	private String pbookCovrMmPamentDd;
	// 통장표지통장신청
	private String pbookCovrPbookReq;
	// 통장표지안내문구내용
	private String pbookCovrGuidPhrCntn;
	// 통장표지안내문구내용2
	private String pbookCovrGuidPhrCntn2;
	// 통장표지안내문구내용3
	private String pbookCovrGuidPhrCntn3;
	// 통장표지안내문구내용4
	private String pbookCovrGuidPhrCntn4;
	// 통장표지안내문구내용5
	private String pbookCovrGuidPhrCntn5;
	// 통장표지부기명
	private String pbookCovrAdmkNm;
	// 통장인자통장이월구분
	private String pbookPrtPbookCrfwdTy;
	// 통장인자시작라인
	private int pbookPrtBeginLine;
	// 통장인자개설일자
	private String pbookPrtOpenDate;
	// 통장인자상품명
	private String pbookPrtStockNm;
	// 통장인자만기
	private String pbookPrtDue;
	// 통장인자대월만기일자
	private String pbookPrtOvrdDueDate;
	// 통장인자한도
	private String pbookPrtLimt;
	// 통장인자대월한도금액
	private long pbookPrtOvrdLimtAmt;
	// 통장인자통장종류
	private String pbookPrtPbookKind;
	// 통장인자계좌번호2
	private String pbookPrtActno2;
	// 통장인자만기일자1
	private String pbookPrtDueDate1;
	// 통장인자월불입금액
	private long pbookPrtMmPamentAmt;
	// 통장인자계약기간
	private int pbookPrtContrTerm;
	// 통장인자이자율
	private String pbookPrtIntRate;
	// 통장인자월불입일
	private String pbookPrtMmPamentDd;
	// 통장인자만기지급금액
	private int pbookPrtDuePayAmt;
	// 통장인자계약기간1
	private String pbookPrtContrTerm1;
	// 통장인자계좌번호
	private String pbookPrtActno;
	// 통장인자만기지급금액1
	private long pbookPrtDuePayAmt1;
	// 통장인자계좌번호1
	private String pbookPrtActno1;
	// 통장인자만기일자
	private String pbookPrtDueDate;
	// 통장인자성명
	private String pbookPrtName;
	// 통장인자월불입금액1
	private long pbookPrtMmPamentAmt1;
	// 통장인자월불입일1
	private String pbookPrtMmPamentDd1;
	// 통장인자만기일자2
	private String pbookPrtDueDate2;
	// 통장인자잔액
	private String pbookPrtBal;
	// 통장인자계좌번호3
	private String pbookPrtActno3;
	// 통장인자통장연결번호
	String pbookPrtPbookCnctNo;
	// 통장인자불입방법
	private String pbookPrtPamentMeth;
	// 반복횟수
	private int gd61Cnt;
	// 시작라인
	private int gd61Strtln;
	// GD61리스트
	private List<BkbPrnn2Gd61Dto> gd61List = new ArrayList<BkbPrnn2Gd61Dto>();

	public String getActNo() {
		return actNo;
	}

	public void setActNo(String actNo) {
		this.actNo = actNo;
	}

	public String getPrtYn() {
		return prtYn;
	}

	public void setPrtYn(String prtYn) {
		this.prtYn = prtYn;
	}

	public String getPbookCovrOpenDate() {
		return pbookCovrOpenDate;
	}

	public void setPbookCovrOpenDate(String pbookCovrOpenDate) {
		this.pbookCovrOpenDate = pbookCovrOpenDate;
	}

	public String getPbookCovrActno() {
		return pbookCovrActno;
	}

	public void setPbookCovrActno(String pbookCovrActno) {
		this.pbookCovrActno = pbookCovrActno;
	}

	public int getPbookCovrCnctNo() {
		return pbookCovrCnctNo;
	}

	public void setPbookCovrCnctNo(int pbookCovrCnctNo) {
		this.pbookCovrCnctNo = pbookCovrCnctNo;
	}

	public String getPbookCovrIsueNo() {
		return pbookCovrIsueNo;
	}

	public void setPbookCovrIsueNo(String pbookCovrIsueNo) {
		this.pbookCovrIsueNo = pbookCovrIsueNo;
	}

	public String getPbookCovrTaxTyNm() {
		return pbookCovrTaxTyNm;
	}

	public void setPbookCovrTaxTyNm(String pbookCovrTaxTyNm) {
		this.pbookCovrTaxTyNm = pbookCovrTaxTyNm;
	}

	public String getPbookCovrCustNo() {
		return pbookCovrCustNo;
	}

	public void setPbookCovrCustNo(String pbookCovrCustNo) {
		this.pbookCovrCustNo = pbookCovrCustNo;
	}

	public String getPbookCovrRealNo() {
		return pbookCovrRealNo;
	}

	public void setPbookCovrRealNo(String pbookCovrRealNo) {
		this.pbookCovrRealNo = pbookCovrRealNo;
	}

	public String getPbookCovrEmpno() {
		return pbookCovrEmpno;
	}

	public void setPbookCovrEmpno(String pbookCovrEmpno) {
		this.pbookCovrEmpno = pbookCovrEmpno;
	}

	public String getPbookCovrName() {
		return pbookCovrName;
	}

	public void setPbookCovrName(String pbookCovrName) {
		this.pbookCovrName = pbookCovrName;
	}

	public String getPbookCovrYear() {
		return pbookCovrYear;
	}

	public void setPbookCovrYear(String pbookCovrYear) {
		this.pbookCovrYear = pbookCovrYear;
	}

	public String getPbookCovrMms() {
		return pbookCovrMms;
	}

	public void setPbookCovrMms(String pbookCovrMms) {
		this.pbookCovrMms = pbookCovrMms;
	}

	public String getPbookCovrDds() {
		return pbookCovrDds;
	}

	public void setPbookCovrDds(String pbookCovrDds) {
		this.pbookCovrDds = pbookCovrDds;
	}

	public String getPbookCovrAbbrNm() {
		return pbookCovrAbbrNm;
	}

	public void setPbookCovrAbbrNm(String pbookCovrAbbrNm) {
		this.pbookCovrAbbrNm = pbookCovrAbbrNm;
	}

	public String getPbookCovrMnbrNm() {
		return pbookCovrMnbrNm;
	}

	public void setPbookCovrMnbrNm(String pbookCovrMnbrNm) {
		this.pbookCovrMnbrNm = pbookCovrMnbrNm;
	}

	public String getPbookCovrMnbrNm1() {
		return pbookCovrMnbrNm1;
	}

	public void setPbookCovrMnbrNm1(String pbookCovrMnbrNm1) {
		this.pbookCovrMnbrNm1 = pbookCovrMnbrNm1;
	}

	public String getPbookCovrTelNo() {
		return pbookCovrTelNo;
	}

	public void setPbookCovrTelNo(String pbookCovrTelNo) {
		this.pbookCovrTelNo = pbookCovrTelNo;
	}

	public String getPbookCovrTelNo1() {
		return pbookCovrTelNo1;
	}

	public void setPbookCovrTelNo1(String pbookCovrTelNo1) {
		this.pbookCovrTelNo1 = pbookCovrTelNo1;
	}

	public String getPbookCovrSchlNm() {
		return pbookCovrSchlNm;
	}

	public void setPbookCovrSchlNm(String pbookCovrSchlNm) {
		this.pbookCovrSchlNm = pbookCovrSchlNm;
	}

	public String getPbookCovrClss1() {
		return pbookCovrClss1;
	}

	public void setPbookCovrClss1(String pbookCovrClss1) {
		this.pbookCovrClss1 = pbookCovrClss1;
	}

	public String getPbookCovrNo1() {
		return pbookCovrNo1;
	}

	public void setPbookCovrNo1(String pbookCovrNo1) {
		this.pbookCovrNo1 = pbookCovrNo1;
	}

	public String getPbookCovrClss2() {
		return pbookCovrClss2;
	}

	public void setPbookCovrClss2(String pbookCovrClss2) {
		this.pbookCovrClss2 = pbookCovrClss2;
	}

	public String getPbookCovrNo2() {
		return pbookCovrNo2;
	}

	public void setPbookCovrNo2(String pbookCovrNo2) {
		this.pbookCovrNo2 = pbookCovrNo2;
	}

	public String getPbookCovrClss3() {
		return pbookCovrClss3;
	}

	public void setPbookCovrClss3(String pbookCovrClss3) {
		this.pbookCovrClss3 = pbookCovrClss3;
	}

	public String getPbookCovrNo3() {
		return pbookCovrNo3;
	}

	public void setPbookCovrNo3(String pbookCovrNo3) {
		this.pbookCovrNo3 = pbookCovrNo3;
	}

	public String getPbookCovrClss4() {
		return pbookCovrClss4;
	}

	public void setPbookCovrClss4(String pbookCovrClss4) {
		this.pbookCovrClss4 = pbookCovrClss4;
	}

	public String getPbookCovrNo4() {
		return pbookCovrNo4;
	}

	public void setPbookCovrNo4(String pbookCovrNo4) {
		this.pbookCovrNo4 = pbookCovrNo4;
	}

	public String getPbookCovrClss5() {
		return pbookCovrClss5;
	}

	public void setPbookCovrClss5(String pbookCovrClss5) {
		this.pbookCovrClss5 = pbookCovrClss5;
	}

	public String getPbookCovrNo5() {
		return pbookCovrNo5;
	}

	public void setPbookCovrNo5(String pbookCovrNo5) {
		this.pbookCovrNo5 = pbookCovrNo5;
	}

	public String getPbookCovrClss6() {
		return pbookCovrClss6;
	}

	public void setPbookCovrClss6(String pbookCovrClss6) {
		this.pbookCovrClss6 = pbookCovrClss6;
	}

	public String getPbookCovrNo6() {
		return pbookCovrNo6;
	}

	public void setPbookCovrNo6(String pbookCovrNo6) {
		this.pbookCovrNo6 = pbookCovrNo6;
	}

	public int getPbookCovrContrTerm() {
		return pbookCovrContrTerm;
	}

	public void setPbookCovrContrTerm(int pbookCovrContrTerm) {
		this.pbookCovrContrTerm = pbookCovrContrTerm;
	}

	public String getPbookCovrDueDate() {
		return pbookCovrDueDate;
	}

	public void setPbookCovrDueDate(String pbookCovrDueDate) {
		this.pbookCovrDueDate = pbookCovrDueDate;
	}

	public String getPbookCovrPamentDate() {
		return pbookCovrPamentDate;
	}

	public void setPbookCovrPamentDate(String pbookCovrPamentDate) {
		this.pbookCovrPamentDate = pbookCovrPamentDate;
	}

	public long getPbookCovrEddPaymAmt() {
		return pbookCovrEddPaymAmt;
	}

	public void setPbookCovrEddPaymAmt(long pbookCovrEddPaymAmt) {
		this.pbookCovrEddPaymAmt = pbookCovrEddPaymAmt;
	}

	public long getPbookCovrDueAmt() {
		return pbookCovrDueAmt;
	}

	public void setPbookCovrDueAmt(long pbookCovrDueAmt) {
		this.pbookCovrDueAmt = pbookCovrDueAmt;
	}

	public long getPbookCovrMmPamentAmt() {
		return pbookCovrMmPamentAmt;
	}

	public void setPbookCovrMmPamentAmt(long pbookCovrMmPamentAmt) {
		this.pbookCovrMmPamentAmt = pbookCovrMmPamentAmt;
	}

	public String getPbookCovrMmPamentDd() {
		return pbookCovrMmPamentDd;
	}

	public void setPbookCovrMmPamentDd(String pbookCovrMmPamentDd) {
		this.pbookCovrMmPamentDd = pbookCovrMmPamentDd;
	}

	public String getPbookCovrPbookReq() {
		return pbookCovrPbookReq;
	}

	public void setPbookCovrPbookReq(String pbookCovrPbookReq) {
		this.pbookCovrPbookReq = pbookCovrPbookReq;
	}

	public String getPbookCovrGuidPhrCntn() {
		return pbookCovrGuidPhrCntn;
	}

	public void setPbookCovrGuidPhrCntn(String pbookCovrGuidPhrCntn) {
		this.pbookCovrGuidPhrCntn = pbookCovrGuidPhrCntn;
	}

	public String getPbookCovrGuidPhrCntn2() {
		return pbookCovrGuidPhrCntn2;
	}

	public void setPbookCovrGuidPhrCntn2(String pbookCovrGuidPhrCntn2) {
		this.pbookCovrGuidPhrCntn2 = pbookCovrGuidPhrCntn2;
	}

	public String getPbookCovrGuidPhrCntn3() {
		return pbookCovrGuidPhrCntn3;
	}

	public void setPbookCovrGuidPhrCntn3(String pbookCovrGuidPhrCntn3) {
		this.pbookCovrGuidPhrCntn3 = pbookCovrGuidPhrCntn3;
	}

	public String getPbookCovrGuidPhrCntn4() {
		return pbookCovrGuidPhrCntn4;
	}

	public void setPbookCovrGuidPhrCntn4(String pbookCovrGuidPhrCntn4) {
		this.pbookCovrGuidPhrCntn4 = pbookCovrGuidPhrCntn4;
	}

	public String getPbookCovrGuidPhrCntn5() {
		return pbookCovrGuidPhrCntn5;
	}

	public void setPbookCovrGuidPhrCntn5(String pbookCovrGuidPhrCntn5) {
		this.pbookCovrGuidPhrCntn5 = pbookCovrGuidPhrCntn5;
	}

	public String getPbookCovrAdmkNm() {
		return pbookCovrAdmkNm;
	}

	public void setPbookCovrAdmkNm(String pbookCovrAdmkNm) {
		this.pbookCovrAdmkNm = pbookCovrAdmkNm;
	}

	public String getPbookPrtPbookCrfwdTy() {
		return pbookPrtPbookCrfwdTy;
	}

	public void setPbookPrtPbookCrfwdTy(String pbookPrtPbookCrfwdTy) {
		this.pbookPrtPbookCrfwdTy = pbookPrtPbookCrfwdTy;
	}

	public int getPbookPrtBeginLine() {
		return pbookPrtBeginLine;
	}

	public void setPbookPrtBeginLine(int pbookPrtBeginLine) {
		this.pbookPrtBeginLine = pbookPrtBeginLine;
	}

	public String getPbookPrtOpenDate() {
		return pbookPrtOpenDate;
	}

	public void setPbookPrtOpenDate(String pbookPrtOpenDate) {
		this.pbookPrtOpenDate = pbookPrtOpenDate;
	}

	public String getPbookPrtStockNm() {
		return pbookPrtStockNm;
	}

	public void setPbookPrtStockNm(String pbookPrtStockNm) {
		this.pbookPrtStockNm = pbookPrtStockNm;
	}

	public String getPbookPrtDue() {
		return pbookPrtDue;
	}

	public void setPbookPrtDue(String pbookPrtDue) {
		this.pbookPrtDue = pbookPrtDue;
	}

	public String getPbookPrtOvrdDueDate() {
		return pbookPrtOvrdDueDate;
	}

	public void setPbookPrtOvrdDueDate(String pbookPrtOvrdDueDate) {
		this.pbookPrtOvrdDueDate = pbookPrtOvrdDueDate;
	}

	public String getPbookPrtLimt() {
		return pbookPrtLimt;
	}

	public void setPbookPrtLimt(String pbookPrtLimt) {
		this.pbookPrtLimt = pbookPrtLimt;
	}

	public long getPbookPrtOvrdLimtAmt() {
		return pbookPrtOvrdLimtAmt;
	}

	public void setPbookPrtOvrdLimtAmt(long pbookPrtOvrdLimtAmt) {
		this.pbookPrtOvrdLimtAmt = pbookPrtOvrdLimtAmt;
	}

	public String getPbookPrtPbookKind() {
		return pbookPrtPbookKind;
	}

	public void setPbookPrtPbookKind(String pbookPrtPbookKind) {
		this.pbookPrtPbookKind = pbookPrtPbookKind;
	}

	public String getPbookPrtActno2() {
		return pbookPrtActno2;
	}

	public void setPbookPrtActno2(String pbookPrtActno2) {
		this.pbookPrtActno2 = pbookPrtActno2;
	}

	public String getPbookPrtDueDate1() {
		return pbookPrtDueDate1;
	}

	public void setPbookPrtDueDate1(String pbookPrtDueDate1) {
		this.pbookPrtDueDate1 = pbookPrtDueDate1;
	}

	public long getPbookPrtMmPamentAmt() {
		return pbookPrtMmPamentAmt;
	}

	public void setPbookPrtMmPamentAmt(long pbookPrtMmPamentAmt) {
		this.pbookPrtMmPamentAmt = pbookPrtMmPamentAmt;
	}

	public int getPbookPrtContrTerm() {
		return pbookPrtContrTerm;
	}

	public void setPbookPrtContrTerm(int pbookPrtContrTerm) {
		this.pbookPrtContrTerm = pbookPrtContrTerm;
	}

	public String getPbookPrtIntRate() {
		return pbookPrtIntRate;
	}

	public void setPbookPrtIntRate(String pbookPrtIntRate) {
		this.pbookPrtIntRate = pbookPrtIntRate;
	}

	public String getPbookPrtMmPamentDd() {
		return pbookPrtMmPamentDd;
	}

	public void setPbookPrtMmPamentDd(String pbookPrtMmPamentDd) {
		this.pbookPrtMmPamentDd = pbookPrtMmPamentDd;
	}

	public int getPbookPrtDuePayAmt() {
		return pbookPrtDuePayAmt;
	}

	public void setPbookPrtDuePayAmt(int pbookPrtDuePayAmt) {
		this.pbookPrtDuePayAmt = pbookPrtDuePayAmt;
	}

	public String getPbookPrtContrTerm1() {
		return pbookPrtContrTerm1;
	}

	public void setPbookPrtContrTerm1(String pbookPrtContrTerm1) {
		this.pbookPrtContrTerm1 = pbookPrtContrTerm1;
	}

	public String getPbookPrtActno() {
		return pbookPrtActno;
	}

	public void setPbookPrtActno(String pbookPrtActno) {
		this.pbookPrtActno = pbookPrtActno;
	}

	public long getPbookPrtDuePayAmt1() {
		return pbookPrtDuePayAmt1;
	}

	public void setPbookPrtDuePayAmt1(long pbookPrtDuePayAmt1) {
		this.pbookPrtDuePayAmt1 = pbookPrtDuePayAmt1;
	}

	public String getPbookPrtActno1() {
		return pbookPrtActno1;
	}

	public void setPbookPrtActno1(String pbookPrtActno1) {
		this.pbookPrtActno1 = pbookPrtActno1;
	}

	public String getPbookPrtDueDate() {
		return pbookPrtDueDate;
	}

	public void setPbookPrtDueDate(String pbookPrtDueDate) {
		this.pbookPrtDueDate = pbookPrtDueDate;
	}

	public String getPbookPrtName() {
		return pbookPrtName;
	}

	public void setPbookPrtName(String pbookPrtName) {
		this.pbookPrtName = pbookPrtName;
	}

	public long getPbookPrtMmPamentAmt1() {
		return pbookPrtMmPamentAmt1;
	}

	public void setPbookPrtMmPamentAmt1(long pbookPrtMmPamentAmt1) {
		this.pbookPrtMmPamentAmt1 = pbookPrtMmPamentAmt1;
	}

	public String getPbookPrtMmPamentDd1() {
		return pbookPrtMmPamentDd1;
	}

	public void setPbookPrtMmPamentDd1(String pbookPrtMmPamentDd1) {
		this.pbookPrtMmPamentDd1 = pbookPrtMmPamentDd1;
	}

	public String getPbookPrtDueDate2() {
		return pbookPrtDueDate2;
	}

	public void setPbookPrtDueDate2(String pbookPrtDueDate2) {
		this.pbookPrtDueDate2 = pbookPrtDueDate2;
	}

	public String getPbookPrtBal() {
		return pbookPrtBal;
	}

	public void setPbookPrtBal(String pbookPrtBal) {
		this.pbookPrtBal = pbookPrtBal;
	}

	public String getPbookPrtActno3() {
		return pbookPrtActno3;
	}

	public void setPbookPrtActno3(String pbookPrtActno3) {
		this.pbookPrtActno3 = pbookPrtActno3;
	}

	public String getPbookPrtPbookCnctNo() {
		return pbookPrtPbookCnctNo;
	}

	public void setPbookPrtPbookCnctNo(String pbookPrtPbookCnctNo) {
		this.pbookPrtPbookCnctNo = pbookPrtPbookCnctNo;
	}

	public String getPbookPrtPamentMeth() {
		return pbookPrtPamentMeth;
	}

	public void setPbookPrtPamentMeth(String pbookPrtPamentMeth) {
		this.pbookPrtPamentMeth = pbookPrtPamentMeth;
	}

	public int getGd61Cnt() {
		return gd61Cnt;
	}

	public void setGd61Cnt(int gd61Cnt) {
		this.gd61Cnt = gd61Cnt;
	}

	public int getGd61Strtln() {
		return gd61Strtln;
	}

	public void setGd61Strtln(int gd61Strtln) {
		this.gd61Strtln = gd61Strtln;
	}

	public List<BkbPrnn2Gd61Dto> getGd61List() {
		return gd61List;
	}

	public void setGd61List(List<BkbPrnn2Gd61Dto> gd61List) {
		this.gd61List = gd61List;
	}

	@Override
	public String toString() {
		return "BkbPrnn2Dto [actNo=" + actNo + ", prtYn=" + prtYn + ", pbookCovrOpenDate=" + pbookCovrOpenDate + ", pbookCovrActno=" + pbookCovrActno + ", pbookCovrCnctNo=" + pbookCovrCnctNo
				+ ", pbookCovrIsueNo=" + pbookCovrIsueNo + ", pbookCovrTaxTyNm=" + pbookCovrTaxTyNm + ", pbookCovrCustNo=" + pbookCovrCustNo + ", pbookCovrRealNo=" + pbookCovrRealNo
				+ ", pbookCovrEmpno=" + pbookCovrEmpno + ", pbookCovrName=" + pbookCovrName + ", pbookCovrYear=" + pbookCovrYear + ", pbookCovrMms=" + pbookCovrMms + ", pbookCovrDds=" + pbookCovrDds
				+ ", pbookCovrAbbrNm=" + pbookCovrAbbrNm + ", pbookCovrMnbrNm=" + pbookCovrMnbrNm + ", pbookCovrMnbrNm1=" + pbookCovrMnbrNm1 + ", pbookCovrTelNo=" + pbookCovrTelNo
				+ ", pbookCovrTelNo1=" + pbookCovrTelNo1 + ", pbookCovrSchlNm=" + pbookCovrSchlNm + ", pbookCovrClss1=" + pbookCovrClss1 + ", pbookCovrNo1=" + pbookCovrNo1 + ", pbookCovrClss2="
				+ pbookCovrClss2 + ", pbookCovrNo2=" + pbookCovrNo2 + ", pbookCovrClss3=" + pbookCovrClss3 + ", pbookCovrNo3=" + pbookCovrNo3 + ", pbookCovrClss4=" + pbookCovrClss4
				+ ", pbookCovrNo4=" + pbookCovrNo4 + ", pbookCovrClss5=" + pbookCovrClss5 + ", pbookCovrNo5=" + pbookCovrNo5 + ", pbookCovrClss6=" + pbookCovrClss6 + ", pbookCovrNo6=" + pbookCovrNo6
				+ ", pbookCovrContrTerm=" + pbookCovrContrTerm + ", pbookCovrDueDate=" + pbookCovrDueDate + ", pbookCovrPamentDate=" + pbookCovrPamentDate + ", pbookCovrEddPaymAmt="
				+ pbookCovrEddPaymAmt + ", pbookCovrDueAmt=" + pbookCovrDueAmt + ", pbookCovrMmPamentAmt=" + pbookCovrMmPamentAmt + ", pbookCovrMmPamentDd=" + pbookCovrMmPamentDd
				+ ", pbookCovrPbookReq=" + pbookCovrPbookReq + ", pbookCovrGuidPhrCntn=" + pbookCovrGuidPhrCntn + ", pbookCovrGuidPhrCntn2=" + pbookCovrGuidPhrCntn2 + ", pbookCovrGuidPhrCntn3="
				+ pbookCovrGuidPhrCntn3 + ", pbookCovrGuidPhrCntn4=" + pbookCovrGuidPhrCntn4 + ", pbookCovrGuidPhrCntn5=" + pbookCovrGuidPhrCntn5 + ", pbookCovrAdmkNm=" + pbookCovrAdmkNm
				+ ", pbookPrtPbookCrfwdTy=" + pbookPrtPbookCrfwdTy + ", pbookPrtBeginLine=" + pbookPrtBeginLine + ", pbookPrtOpenDate=" + pbookPrtOpenDate + ", pbookPrtStockNm=" + pbookPrtStockNm
				+ ", pbookPrtDue=" + pbookPrtDue + ", pbookPrtOvrdDueDate=" + pbookPrtOvrdDueDate + ", pbookPrtLimt=" + pbookPrtLimt + ", pbookPrtOvrdLimtAmt=" + pbookPrtOvrdLimtAmt
				+ ", pbookPrtPbookKind=" + pbookPrtPbookKind + ", pbookPrtActno2=" + pbookPrtActno2 + ", pbookPrtDueDate1=" + pbookPrtDueDate1 + ", pbookPrtMmPamentAmt=" + pbookPrtMmPamentAmt
				+ ", pbookPrtContrTerm=" + pbookPrtContrTerm + ", pbookPrtIntRate=" + pbookPrtIntRate + ", pbookPrtMmPamentDd=" + pbookPrtMmPamentDd + ", pbookPrtDuePayAmt=" + pbookPrtDuePayAmt
				+ ", pbookPrtContrTerm1=" + pbookPrtContrTerm1 + ", pbookPrtActno=" + pbookPrtActno + ", pbookPrtDuePayAmt1=" + pbookPrtDuePayAmt1 + ", pbookPrtActno1=" + pbookPrtActno1
				+ ", pbookPrtDueDate=" + pbookPrtDueDate + ", pbookPrtName=" + pbookPrtName + ", pbookPrtMmPamentAmt1=" + pbookPrtMmPamentAmt1 + ", pbookPrtMmPamentDd1=" + pbookPrtMmPamentDd1
				+ ", pbookPrtDueDate2=" + pbookPrtDueDate2 + ", pbookPrtBal=" + pbookPrtBal + ", pbookPrtActno3=" + pbookPrtActno3 + ", pbookPrtPbookCnctNo=" + pbookPrtPbookCnctNo
				+ ", pbookPrtPamentMeth=" + pbookPrtPamentMeth + ", gd61Cnt=" + gd61Cnt + ", gd61Strtln=" + gd61Strtln + ", gd61List=" + gd61List + "]";
	}

}
