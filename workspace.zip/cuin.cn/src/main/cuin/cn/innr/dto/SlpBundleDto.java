package cuin.cn.innr.dto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : SlpBundleDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.12.02
 * 설    명 : 전표/통장 인쇄 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class SlpBundleDto {

	private SlpDto slpDto;
	private SlpDatHdrDto slpDatHdrDto;

	public SlpBundleDto(SlpDatHdrDto slpDatHdrDto, SlpDto slpDto) {
		this.slpDatHdrDto = slpDatHdrDto;
		this.slpDto = slpDto;
	}

	public SlpDto getDataDto() {
		return slpDto;
	}

	public SlpDatHdrDto getHdrDto() {
		return slpDatHdrDto;
	}
}
