package cuin.cn.innr.dto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : InnrLnShrHdrDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.08.30
 * 설    명 : 신협  대내 전문 헤더 (100 byte).  인바운드 EAI 서비스에서 사용함.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class InnrLnShrHdrDto {
	// 입력 메시지 길이
	private int len;
	// 요청/응답 구분
	private String ycRespGb;
	// 지부코드
	private String subBrnCd;
	// 인가번호
	private String ingaNo;
	// 본지소코드
	private String bongiCd;
	// 터미널ID
	private String tmnlId;
	// 조작자번호
	private String oprNo;
	// 시스템일자
	private String sysdate;
	// 거래시각
	private String txTime;
	// 거래코드
	private String txCd;
	// 일련번호
	private String seqNo;
	// 실적분담코드
	private String siljkCd;
	// 거래일자
	private String txDate;
	// 마감후구분
	private String eodAftGb;
	// 시스템구분
	private String sysGb;
	// 서버이름
	private String svrNm;
	// 제한시간
	private int timeout;
	// 전문번호
	private String telMsgNo;
	// 버전정보
	private String verInfo;
	// 거래종류
	private String txType;
	// 대내외구분
	private String daeIoGb;
	// 연동구분
	private String gathGb;
	// 경유구분
	private String crossGb;
	// 응답코드
	private String errCd;
	// 단말구분
	private String wsGb;
	// 거래체크
	private String filler;

	public int getLen() {
		return len;
	}

	public void setLen(int len) {
		this.len = len;
	}

	public String getYcRespGb() {
		return ycRespGb;
	}

	public void setYcRespGb(String ycRespGb) {
		this.ycRespGb = ycRespGb;
	}

	public String getSubBrnCd() {
		return subBrnCd;
	}

	public void setSubBrnCd(String subBrnCd) {
		this.subBrnCd = subBrnCd;
	}

	public String getIngaNo() {
		return ingaNo;
	}

	public void setIngaNo(String ingaNo) {
		this.ingaNo = ingaNo;
	}

	public String getBongiCd() {
		return bongiCd;
	}

	public void setBongiCd(String bongiCd) {
		this.bongiCd = bongiCd;
	}

	public String getTmnlId() {
		return tmnlId;
	}

	public void setTmnlId(String tmnlId) {
		this.tmnlId = tmnlId;
	}

	public String getOprNo() {
		return oprNo;
	}

	public void setOprNo(String oprNo) {
		this.oprNo = oprNo;
	}

	public String getSysdate() {
		return sysdate;
	}

	public void setSysdate(String sysdate) {
		this.sysdate = sysdate;
	}

	public String getTxTime() {
		return txTime;
	}

	public void setTxTime(String txTime) {
		this.txTime = txTime;
	}

	public String getTxCd() {
		return txCd;
	}

	public void setTxCd(String txCd) {
		this.txCd = txCd;
	}

	public String getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}

	public String getSiljkCd() {
		return siljkCd;
	}

	public void setSiljkCd(String siljkCd) {
		this.siljkCd = siljkCd;
	}

	public String getTxDate() {
		return txDate;
	}

	public void setTxDate(String txDate) {
		this.txDate = txDate;
	}

	public String getEodAftGb() {
		return eodAftGb;
	}

	public void setEodAftGb(String eodAftGb) {
		this.eodAftGb = eodAftGb;
	}

	public String getSysGb() {
		return sysGb;
	}

	public void setSysGb(String sysGb) {
		this.sysGb = sysGb;
	}

	public String getSvrNm() {
		return svrNm;
	}

	public void setSvrNm(String svrNm) {
		this.svrNm = svrNm;
	}

	public int getTimeout() {
		return timeout;
	}

	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	public String getTelMsgNo() {
		return telMsgNo;
	}

	public void setTelMsgNo(String telMsgNo) {
		this.telMsgNo = telMsgNo;
	}

	public String getVerInfo() {
		return verInfo;
	}

	public void setVerInfo(String verInfo) {
		this.verInfo = verInfo;
	}

	public String getTxType() {
		return txType;
	}

	public void setTxType(String txType) {
		this.txType = txType;
	}

	public String getDaeIoGb() {
		return daeIoGb;
	}

	public void setDaeIoGb(String daeIoGb) {
		this.daeIoGb = daeIoGb;
	}

	public String getGathGb() {
		return gathGb;
	}

	public void setGathGb(String gathGb) {
		this.gathGb = gathGb;
	}

	public String getCrossGb() {
		return crossGb;
	}

	public void setCrossGb(String crossGb) {
		this.crossGb = crossGb;
	}

	public String getErrCd() {
		return errCd;
	}

	public void setErrCd(String errCd) {
		this.errCd = errCd;
	}

	public String getWsGb() {
		return wsGb;
	}

	public void setWsGb(String wsGb) {
		this.wsGb = wsGb;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	@Override
	public String toString() {
		return "InnrLnShrHdrDto [len=" + len + ", ycRespGb=" + ycRespGb + ", subBrnCd=" + subBrnCd + ", ingaNo=" + ingaNo + ", bongiCd=" + bongiCd + ", tmnlId=" + tmnlId + ", oprNo=" + oprNo
				+ ", sysdate=" + sysdate + ", txTime=" + txTime + ", txCd=" + txCd + ", seqNo=" + seqNo + ", siljkCd=" + siljkCd + ", txDate=" + txDate + ", eodAftGb=" + eodAftGb + ", sysGb=" + sysGb
				+ ", svrNm=" + svrNm + ", timeout=" + timeout + ", telMsgNo=" + telMsgNo + ", verInfo=" + verInfo + ", txType=" + txType + ", daeIoGb=" + daeIoGb + ", gathGb=" + gathGb + ", crossGb="
				+ crossGb + ", errCd=" + errCd + ", wsGb=" + wsGb + ", filler=" + filler + "]";
	}
}
