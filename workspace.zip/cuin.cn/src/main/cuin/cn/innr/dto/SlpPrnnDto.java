package cuin.cn.innr.dto;

import java.math.BigDecimal;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : SlpPrnnDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.11.30
 * 설    명 : 전표 인쇄 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class SlpPrnnDto implements SlpDto {

	private static final long serialVersionUID = -6635319645707645578L;

	// 전표인자거래일자
	private String slipPrtTrDate;
	// 전표인자과목명
	private String slipPrtItemNm;
	// 전표인자입출구분명
	private String slipPrtInpayTyNm;
	// 전표인자거래시각
	private String slipPrtTrTime;
	// 전표인자계좌번호
	private String slipPrtActno;
	// 전표인자거래전잔액
	private BigDecimal slipPrtTrBfBal;
	// 전표인자본지소코드
	private String slipPrtMnbrCode;
	// 전표인자성명
	private String slipPrtName;
	// 전표인자거래금액
	private BigDecimal slipPrtTrAmt;
	// 전표인자마감구분명
	private String slipPrtClosTyNm;
	// 전표인자적요
	private String slipPrtRemk;
	// 전표인자거래후잔액
	private BigDecimal slipPrtTrAfBal;
	// 전표인자거래매체구분명
	private String slipPrtTrMeduTyNm;
	// 전표인자거래구분명
	private String slipPrtTrTyNm;
	// 전표인자취급자성명
	private String slipPrtTretManName;
	// 전표인자우대구분명
	private String slipPrtPrefTyNm;
	// 전표인자전표번호
	private long slipPrtSlipNo;
	// 전표인자면제사유
	private String slipPrtDiscResn;
	// 전표인자수수료명
	private String slipPrtFeeNm;
	// 전표인자수수료금액
	private BigDecimal slipPrtFeeAmt;

	public String getSlipPrtTrDate() {
		return slipPrtTrDate;
	}

	public void setSlipPrtTrDate(String slipPrtTrDate) {
		this.slipPrtTrDate = slipPrtTrDate;
	}

	public String getSlipPrtItemNm() {
		return slipPrtItemNm;
	}

	public void setSlipPrtItemNm(String slipPrtItemNm) {
		this.slipPrtItemNm = slipPrtItemNm;
	}

	public String getSlipPrtInpayTyNm() {
		return slipPrtInpayTyNm;
	}

	public void setSlipPrtInpayTyNm(String slipPrtInpayTyNm) {
		this.slipPrtInpayTyNm = slipPrtInpayTyNm;
	}

	public String getSlipPrtTrTime() {
		return slipPrtTrTime;
	}

	public void setSlipPrtTrTime(String slipPrtTrTime) {
		this.slipPrtTrTime = slipPrtTrTime;
	}

	public String getSlipPrtActno() {
		return slipPrtActno;
	}

	public void setSlipPrtActno(String slipPrtActno) {
		this.slipPrtActno = slipPrtActno;
	}

	public BigDecimal getSlipPrtTrBfBal() {
		return slipPrtTrBfBal;
	}

	public void setSlipPrtTrBfBal(BigDecimal slipPrtTrBfBal) {
		this.slipPrtTrBfBal = slipPrtTrBfBal;
	}

	public String getSlipPrtMnbrCode() {
		return slipPrtMnbrCode;
	}

	public void setSlipPrtMnbrCode(String slipPrtMnbrCode) {
		this.slipPrtMnbrCode = slipPrtMnbrCode;
	}

	public String getSlipPrtName() {
		return slipPrtName;
	}

	public void setSlipPrtName(String slipPrtName) {
		this.slipPrtName = slipPrtName;
	}

	public BigDecimal getSlipPrtTrAmt() {
		return slipPrtTrAmt;
	}

	public void setSlipPrtTrAmt(BigDecimal slipPrtTrAmt) {
		this.slipPrtTrAmt = slipPrtTrAmt;
	}

	public String getSlipPrtClosTyNm() {
		return slipPrtClosTyNm;
	}

	public void setSlipPrtClosTyNm(String slipPrtClosTyNm) {
		this.slipPrtClosTyNm = slipPrtClosTyNm;
	}

	public String getSlipPrtRemk() {
		return slipPrtRemk;
	}

	public void setSlipPrtRemk(String slipPrtRemk) {
		this.slipPrtRemk = slipPrtRemk;
	}

	public BigDecimal getSlipPrtTrAfBal() {
		return slipPrtTrAfBal;
	}

	public void setSlipPrtTrAfBal(BigDecimal slipPrtTrAfBal) {
		this.slipPrtTrAfBal = slipPrtTrAfBal;
	}

	public String getSlipPrtTrMeduTyNm() {
		return slipPrtTrMeduTyNm;
	}

	public void setSlipPrtTrMeduTyNm(String slipPrtTrMeduTyNm) {
		this.slipPrtTrMeduTyNm = slipPrtTrMeduTyNm;
	}

	public String getSlipPrtTrTyNm() {
		return slipPrtTrTyNm;
	}

	public void setSlipPrtTrTyNm(String slipPrtTrTyNm) {
		this.slipPrtTrTyNm = slipPrtTrTyNm;
	}

	public String getSlipPrtTretManName() {
		return slipPrtTretManName;
	}

	public void setSlipPrtTretManName(String slipPrtTretManName) {
		this.slipPrtTretManName = slipPrtTretManName;
	}

	public String getSlipPrtPrefTyNm() {
		return slipPrtPrefTyNm;
	}

	public void setSlipPrtPrefTyNm(String slipPrtPrefTyNm) {
		this.slipPrtPrefTyNm = slipPrtPrefTyNm;
	}

	public long getSlipPrtSlipNo() {
		return slipPrtSlipNo;
	}

	public void setSlipPrtSlipNo(long slipPrtSlipNo) {
		this.slipPrtSlipNo = slipPrtSlipNo;
	}

	public String getSlipPrtDiscResn() {
		return slipPrtDiscResn;
	}

	public void setSlipPrtDiscResn(String slipPrtDiscResn) {
		this.slipPrtDiscResn = slipPrtDiscResn;
	}

	public String getSlipPrtFeeNm() {
		return slipPrtFeeNm;
	}

	public void setSlipPrtFeeNm(String slipPrtFeeNm) {
		this.slipPrtFeeNm = slipPrtFeeNm;
	}

	public BigDecimal getSlipPrtFeeAmt() {
		return slipPrtFeeAmt;
	}

	public void setSlipPrtFeeAmt(BigDecimal slipPrtFeeAmt) {
		this.slipPrtFeeAmt = slipPrtFeeAmt;
	}

	@Override
	public String toString() {
		return "SlpPrnnDto [slipPrtTrDate=" + slipPrtTrDate + ", slipPrtItemNm=" + slipPrtItemNm + ", slipPrtInpayTyNm=" + slipPrtInpayTyNm + ", slipPrtTrTime=" + slipPrtTrTime + ", slipPrtActno="
				+ slipPrtActno + ", slipPrtTrBfBal=" + slipPrtTrBfBal + ", slipPrtMnbrCode=" + slipPrtMnbrCode + ", slipPrtName=" + slipPrtName + ", slipPrtTrAmt=" + slipPrtTrAmt
				+ ", slipPrtClosTyNm=" + slipPrtClosTyNm + ", slipPrtRemk=" + slipPrtRemk + ", slipPrtTrAfBal=" + slipPrtTrAfBal + ", slipPrtTrMeduTyNm=" + slipPrtTrMeduTyNm + ", slipPrtTrTyNm="
				+ slipPrtTrTyNm + ", slipPrtTretManName=" + slipPrtTretManName + ", slipPrtPrefTyNm=" + slipPrtPrefTyNm + ", slipPrtSlipNo=" + slipPrtSlipNo + ", slipPrtDiscResn=" + slipPrtDiscResn
				+ ", slipPrtFeeNm=" + slipPrtFeeNm + ", slipPrtFeeAmt=" + slipPrtFeeAmt + "]";
	}

}
