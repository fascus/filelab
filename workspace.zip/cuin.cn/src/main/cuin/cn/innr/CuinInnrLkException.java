package cuin.cn.innr;

import cuin.cn.exception.CuinException;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : CuinInnrLkException.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.08.20
 * 설    명 : 대내 연계 예외 클래스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CuinInnrLkException extends CuinException {
	private static final long serialVersionUID = 6991410344034820445L;

	public CuinInnrLkException(String sysErrCode, String errMsg) {
		super(sysErrCode, errMsg);
	}
}
