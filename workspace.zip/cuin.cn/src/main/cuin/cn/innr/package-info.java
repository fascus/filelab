/**
 * 신협 공제 공통 API / 대내 인터페이스
 */
package cuin.cn.innr;

