package cuin.cn.innr;

import hone.omm.model.OmmMap;

import java.io.ByteArrayInputStream;

import cuin.cn.innr.dto.InnrInsHdrDto;
import cuin.cn.innr.dto.InnrLkRcveDto;
import cuin.cn.innr.dto.InnrLkSndnDto;
import cuin.online.cn.core.message.header.CommonRequestHeader;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : InnrLkAdaptor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.08.13
 * 설    명 : 대내 연계 전문 송신 인터페이스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface InnrLkAdaptor {

	/**
	 * 전문 공통 헤더 반환
	 */
	CommonRequestHeader getCommonRequestHeader();

	/**
	 * 전문 공통 헤더 설정 콜백 등록.
	 * 
	 * @param stdHdrClk 공통 헤더 값을 설정하는 콜백 인스턴스
	 */
	void setStdHdrClk(InnrStdHdrClk innrStdHdrClk);

	/**
	 * OMM 맵 반환.
	 * 
	 * @param ommId OMM 맵 ID.
	 * @return OMM 맵 인스턴스.
	 */
	OmmMap getOmmMap(String ommId);

	/**
	 * 대내 거래 중 오류 발생 시, 예외 발생 유무.
	 * 
	 * @param ignore true 이면, 대내 거래 중 오류 발생하더라도 예외를 발생 시키지 않는다.
	 */
	void setIgnoreFailure(boolean ignore);

	/**
	 * 대내 전문 송신 (동기 방식).
	 * 
	 * @param interfaceId EAI 인터페이스 ID
	 * @param innrInsHdrDto 대내 공통 헤더 DTO
	 * @param sndnOmmId 대외 전문 송신 DTO의 OMM Map ID
	 * @param sndnDto 대외 전문 송신 DTO
	 * @param rcveOmmId 수신 DTO의 OMM ID
	 * @return 수신 DTO 인스턴스
	 */
	InnrLkRcveDto request(String interfaceId, InnrInsHdrDto innrInsHdrDto, String sndnOmmId, InnrLkSndnDto sndnDto, String rcveOmmId);

	/**
	 * 대내 전문 송신 (동기 방식).
	 * 
	 * @param interfaceId EAI 인터페이스 ID
	 * @param innrInsHdrDto 대내 공통 헤더 DTO
	 * @param sndnOmmId 대외 전문 송신 DTO의 OMM Map ID
	 * @param sndnDto 대외 전문 송신 DTO
	 * @return 수신 전문 바이트 스트림
	 */
	ByteArrayInputStream request(String interfaceId, InnrInsHdrDto innrInsHdrDto, String sndnOmmId, InnrLkSndnDto sndnDto);

	/**
	 * 대내 전문 송신 (비동기 방식)
	 * 
	 * @param interfaceId EAI 인터페이스 ID
	 * @param innrInsHdrDto 대내 공통 헤더 DTO
	 * @param sndnOmmId 대외 전문 송신 DTO의 OMM Map ID
	 * @param sndnDto 대외 전문 송신 DTO
	 */
	void send(String interfaceId, InnrInsHdrDto innrInsHdrDto, String sndnOmmId, InnrLkSndnDto sndnDto);

}
