package cuin.cn.innr;

import hone.common.util.DateUtils;
import hone.core.util.ApplicationContextHolder;
import hone.omm.marshall.HoneOmmMarshaller;
import hone.omm.marshall.OmmMarshaller;
import hone.omm.marshall.convert.DefaultDateConverter;
import hone.omm.marshall.writer.FixedLengthStreamWriter;
import hone.omm.model.OmmMap;
import hone.omm.provider.OmmProvider;
import hone.omm.unmarshal.HoneOmmUnmarshaller;
import hone.omm.unmarshal.OmmUnmarshaller;
import hone.omm.value.ObjectValueMapper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import cuin.cn.innr.dto.InnrLnShrHdrDto;
import cuin.cn.service.ServiceContext;
import cuin.cn.service.ServiceContext.ContextSysAttr;
import cuin.online.cn.core.message.common.TcpConstants;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : AbstractInnrLkInbService.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.04
 * 설    명 : 대내 연계 전문 인바운드(inbound) 서비스 추상 클래스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public abstract class AbstractInnrLkInbService implements InnrLkInbService {

	private static final Logger logger = LoggerFactory.getLogger(AbstractInnrLkInbService.class);
	private static final String EAI_INBOUND_IP = "EAI_INBOUND";

	// 100 byte 전문 헤더 OMM 맵
	private static final String INNR_LN_SHR_HDR = "cuin.cn.innr.omm.InnrLnShrHdr";
	// 100 byte 전문 헤더 길이
	private static final int INNR_LN_SHR_HDR_LEN = 100;
	// EAI 입출력 전문 마샬링/언마샬링을 위한 OMM pvodier
	private static OmmProvider ommProvider;

	public byte[] reply(byte[] inbMsgData) {

		// EAI 인바운드 로그를 별도 로그 파일로 출력
		MDC.put(TcpConstants.LOG_KEY_CLIENT_IP, EAI_INBOUND_IP);

		if (logger.isDebugEnabled()) {
			try {
				logger.debug(String.format("EAI Inbound Request Msg (%d) :\n[%s]", inbMsgData.length, new String(inbMsgData, TcpConstants.DEFAUL_CHARACTER_SET)));
			} catch (UnsupportedEncodingException e) {
				logger.error(e.getMessage(), e);
			}
		}

		// 전문 파싱 및 빌드를 위한 OMM 프로바이더 준비
		OmmProvider ommProvider = getOmmProvider();

		// ----- 요청 전문 파싱 및 서비스 실행 -----
		boolean succeed = true;
		byte[] outBodyData = null;
		InnrLnShrHdrDto innrLnShrHdrDto = null;
		OmmMap innrLnShrHdrMap = ommProvider.get(INNR_LN_SHR_HDR);
		try {
			// 100 byte 전문 헤더 파싱...
			OmmUnmarshaller<InnrLnShrHdrDto> innrLnShrHdrUnmarshaller = new HoneOmmUnmarshaller<InnrLnShrHdrDto>(innrLnShrHdrMap, new ByteArrayInputStream(inbMsgData, 0, INNR_LN_SHR_HDR_LEN));
			innrLnShrHdrDto = innrLnShrHdrUnmarshaller.read();
			if (logger.isDebugEnabled()) {
				logger.debug("Inbound Msg header : " + innrLnShrHdrDto);
			}

			// 서비스 컨텍스트에 로그인 사용자, 거래코드, 거래 시간 등 설정
			ServiceContext.setSysAttr(ContextSysAttr.USER_ID, innrLnShrHdrDto.getOprNo());
			ServiceContext.setSysAttr(ContextSysAttr.CHANNEL_ID, "");
			ServiceContext.setSysAttr(ServiceContext.ContextSysAttr.TRANSACTION_CODE, getServiceId());
			ServiceContext.setSysAttr(ServiceContext.ContextSysAttr.TX_TIMESTAMP, DateUtils.getTxTimestamp());

			// 바디 메시지 추출
			int bodyLen = innrLnShrHdrDto.getLen() - INNR_LN_SHR_HDR_LEN;
			byte[] bodyBuf = new byte[bodyLen];
			System.arraycopy(inbMsgData, INNR_LN_SHR_HDR_LEN, bodyBuf, 0, bodyLen);

			// 인바운스 서비스 실행 및 출력 데이터 획득
			outBodyData = doReply(ommProvider, innrLnShrHdrDto, bodyBuf);
		} catch (Exception e) {
			logger.error("Error while execute EAI inbound service.", e);
			succeed = false;
		} finally {
			if (outBodyData == null) {
				outBodyData = "".getBytes();
			}
		}

		// ----- 응답 전문 생성 및 반환 -----
		try {
			// 응답 전문 길이 계산
			int outMsgSize = INNR_LN_SHR_HDR_LEN + outBodyData.length;

			// 응답 전문 헤더 생성 (전문 길이 및 응답 코드)
			innrLnShrHdrDto.setLen(outMsgSize);
			innrLnShrHdrDto.setErrCd(succeed ? "APP0000" : "ERR0000");
			innrLnShrHdrDto.setWsGb("0");

			// 응답 전문 헤더 언마샬링
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			FixedLengthStreamWriter streamWriter = new FixedLengthStreamWriter(innrLnShrHdrMap, out);
			streamWriter.setDateConverter(new DefaultDateConverter());
			OmmMarshaller marshaller = new HoneOmmMarshaller(innrLnShrHdrMap, streamWriter, new ObjectValueMapper());
			marshaller.write(innrLnShrHdrDto);
			byte[] outHdrData = out.toByteArray();

			// 응답 전문 조립 및 반환
			byte[] outMsgData = new byte[outMsgSize];
			System.arraycopy(outHdrData, 0, outMsgData, 0, INNR_LN_SHR_HDR_LEN);
			System.arraycopy(outBodyData, 0, outMsgData, INNR_LN_SHR_HDR_LEN, outBodyData.length);

			if (logger.isDebugEnabled()) {
				try {
					logger.debug(String.format("EAI Inbound Response Msg (%d) :\n[%s]", outMsgSize, new String(outMsgData, TcpConstants.DEFAUL_CHARACTER_SET)));
				} catch (UnsupportedEncodingException e) {
					logger.error(e.getMessage(), e);
				}
			}
			return outMsgData;
		} catch (Exception e) {
			logger.error("Error while generate EAI inbound response message.", e);
		} finally {
			MDC.remove(TcpConstants.LOG_KEY_CLIENT_IP);
		}

		return null;
	}

	/**
	 * EAI 서비스 ID 반환
	 */
	protected abstract String getServiceId();

	/**
	 * 인바운드 서비스 수행
	 *
	 * @param ommProvider 출력 전문 데이터 영역 생성을 위한 OMM 프로바이더
	 * @param innrLnShrHdrDto 입력 전문 헤더
	 * @param bodyData 입력 데이터 파트
	 * @return 출력 데이터 파트
	 */
	protected abstract byte[] doReply(OmmProvider ommProvider, InnrLnShrHdrDto innrLnShrHdrDto, byte[] bodyData);

	private OmmProvider getOmmProvider() {
		if (ommProvider == null) {
			ommProvider = ApplicationContextHolder.getApplicationContext().getBean(OmmProvider.class);
		}
		return ommProvider;
	}
}
