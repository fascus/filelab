package cuin.cn.innr;

import hone.common.util.DateUtils;
import hone.common.util.StringUtils;
import hone.core.util.ApplicationContextHolder;
import hone.omm.marshall.HoneOmmMarshaller;
import hone.omm.marshall.OmmMarshaller;
import hone.omm.marshall.convert.DefaultDateConverter;
import hone.omm.marshall.writer.FixedLengthStreamWriter;
import hone.omm.model.OmmMap;
import hone.omm.provider.OmmProvider;
import hone.omm.unmarshal.HoneOmmUnmarshaller;
import hone.omm.unmarshal.OmmUnmarshaller;
import hone.omm.value.ObjectValueMapper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import cuin.cn.service.ServiceContext;
import cuin.cn.service.ServiceContext.ContextSysAttr;
import cuin.cn.util.BeanUtils;
import cuin.online.cn.core.message.common.TcpConstants;
import cuin.online.cn.core.message.header.CommonRequestHeader;
import cuin.online.cn.core.message.header.CommonResponseHeader;
import cuin.online.cn.core.message.header.CuinCommonHeader;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : AbstractDefaultInnrLkInbService.java
 * 작 성 자 : 이태훈
 * 작 성 일 : 2013.11.15
 * 설    명 : EAI 서비스 ID 반환
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public abstract class AbstractDefaultInnrLkInbService implements InnrLkInbService {

	private static final Logger logger = LoggerFactory.getLogger(AbstractDefaultInnrLkInbService.class);
	private static final String EAI_INBOUND_IP = "EAI_INBOUND";

	// EAI 오류시 사용하는 전문 오류코드
	private static final String EAI_ERR_CD_SYS = "APP02746";
	// '전문 종료 표시' 필드 길이
	private static final int MSG_END_MARKER_LENGTH = 2;
	// '전문 종료 표시' 필드 데이터
	private static final String MSG_END_MARKER = "ZZ";
	// '전문 사이즈 블록' 의 사이즈
	private static final int MSG_SIZE_MARKER_LENGTH = 8;

	public byte[] reply(byte[] inbMsgData) {

		// EAI 인바운드 로그를 별도 로그 파일로 출력
		MDC.put(TcpConstants.LOG_KEY_CLIENT_IP, EAI_INBOUND_IP);

		if (logger.isDebugEnabled()) {
			try {
				logger.debug(String.format("EAI Inbound Request Msg (%d) :\n[%s]", inbMsgData.length, new String(inbMsgData, TcpConstants.DEFAUL_CHARACTER_SET)));
			} catch (UnsupportedEncodingException e) {
				logger.error(e.getMessage(), e);
			}
		}

		// 전문 파싱 및 빌드를 위한 OMM 프로바이더 준비
		OmmProvider ommProvider = getOmmProvider();

		// 신협 공통 320byte Header 파싱
		OmmMap headerOmmMap = ommProvider.get(CuinCommonHeader.COMMON_IN_HEADER);
		CommonRequestHeader requestHeader = null;
		OmmUnmarshaller<CommonRequestHeader> requestHeaderUnmarshaller = new HoneOmmUnmarshaller<CommonRequestHeader>(headerOmmMap, new ByteArrayInputStream(inbMsgData, 0,
				TcpConstants.MSG_HEADER_LENGTH));
		requestHeader = requestHeaderUnmarshaller.read();

		if (logger.isDebugEnabled()) {
			logger.debug("Inbound common header : " + requestHeader);
		}

		boolean succeed = true;
		byte[] outBodyData = null;
		try {
			// 서비스 컨텍스트에 로그인 사용자, 거래코드, 거래 시간 등 설정
			String userId = requestHeader.getOpHwnno();

			if(userId.isEmpty()) {
				userId = "EAI_INBOUND";
			}
			ServiceContext.setSysAttr(ContextSysAttr.USER_ID, userId);
			ServiceContext.setSysAttr(ContextSysAttr.CHANNEL_ID, "");
			ServiceContext.setSysAttr(ServiceContext.ContextSysAttr.TRANSACTION_CODE, getServiceId());
			ServiceContext.setSysAttr(ServiceContext.ContextSysAttr.TX_TIMESTAMP, DateUtils.getTxTimestamp());

			// 바디 메시지 추출
			int bodyLen = requestHeader.getMsgLen() + MSG_SIZE_MARKER_LENGTH - TcpConstants.MSG_HEADER_LENGTH - MSG_END_MARKER_LENGTH;
			byte[] bodyBuf = new byte[bodyLen];
			System.arraycopy(inbMsgData, TcpConstants.MSG_HEADER_LENGTH, bodyBuf, 0, bodyLen);

			// 인바운스 서비스 실행 및 출력 데이터 획득
			outBodyData = doReply(ommProvider, requestHeader, bodyBuf);
		} catch (Exception e) {
			logger.error("Error while execute EAI inbound service.", e);
			succeed = false;
		} finally {
			if (outBodyData == null) {
				outBodyData = "".getBytes();
			}
		}

		CommonResponseHeader responseHeader = BeanUtils.toBean(requestHeader, CommonResponseHeader.class);

		int outMsgSize = TcpConstants.MSG_HEADER_LENGTH + outBodyData.length + MSG_END_MARKER_LENGTH;

		// -- [start] 전문 공통 헤더 설정 --
		// 전문 일련번호 1 증가
		int trxSeq = Integer.parseInt(responseHeader.getTrxseq(), 10) + 1;
		responseHeader.setTrxseq(String.format("%02d", trxSeq));
		// 전문 길이 (전문길이 필드의 사이즈만큼 차감)
		responseHeader.setMsgLen(outMsgSize - TcpConstants.MSG_LEN_FIELD_SIZE);
		// 요청/응답 구분 (R : 응답 전문)
		responseHeader.setRqstRespG("R");
		// 처리결과 정상 여부 (0 : 정상, 1: 오류)
		responseHeader.setRstYn(succeed ? 0 : 1);
		// 출력 유형 (1 : 단 전문)
		responseHeader.setOutU(1);
		// 장애 종류 (MCI 및 단말에서 체크하지 않는 필드)
		responseHeader.setErrSys(succeed ? null : "  ");
		// 시스템 오류 코드 (개발자가 직접 오류코드 설정했을 경우는 설정해주지 않는다.)
		if (StringUtils.isEmpty(responseHeader.getErrC()) && !succeed) {
			responseHeader.setErrC(EAI_ERR_CD_SYS);
		}
		// -- [end] 전문 공통 헤더 설정 --

		// 공통 헤더 마샬링
		ByteArrayOutputStream commonHeaderOut = new ByteArrayOutputStream();
		FixedLengthStreamWriter streamWriter = new FixedLengthStreamWriter(headerOmmMap, commonHeaderOut);
		streamWriter.setDateConverter(new DefaultDateConverter());
		OmmMarshaller commonHeaderMarshaller = new HoneOmmMarshaller(headerOmmMap, streamWriter, new ObjectValueMapper());
		commonHeaderMarshaller.write(responseHeader);
		byte[] commonHeaderData = commonHeaderOut.toByteArray();

		// 응답 전문 조립 및 반환
		byte[] outMsgData = new byte[outMsgSize];
		System.arraycopy(commonHeaderData, 0, outMsgData, 0, TcpConstants.MSG_HEADER_LENGTH);
		System.arraycopy(outBodyData, 0, outMsgData, TcpConstants.MSG_HEADER_LENGTH, outBodyData.length);
		System.arraycopy(MSG_END_MARKER.getBytes(), 0, outMsgData, TcpConstants.MSG_HEADER_LENGTH + outBodyData.length, MSG_END_MARKER_LENGTH);

		if (logger.isDebugEnabled()) {
			try {
				logger.debug(String.format("EAI Inbound Response Msg (%d) :\n[%s]", outMsgSize, new String(outMsgData, TcpConstants.DEFAUL_CHARACTER_SET)));
			} catch (UnsupportedEncodingException e) {
				logger.error(e.getMessage(), e);
			}
		}

		MDC.remove(TcpConstants.LOG_KEY_CLIENT_IP);

		return outMsgData;
	}

	protected abstract String getServiceId();

	/**
	 * 인바운드 서비스 수행
	 *
	 * @param ommProvider 출력 전문 데이터 영역 생성을 위한 OMM 프로바이더
	 * @param krinMapsCnHdrDto 입력 전문 헤더
	 * @param bodyData 입력 데이터 파트
	 * @return 출력 데이터 파트
	 */
	protected abstract byte[] doReply(OmmProvider ommProvider, CommonRequestHeader requestHeader, byte[] bodyData);

	private OmmProvider getOmmProvider() {
		return ApplicationContextHolder.getApplicationContext().getBean(OmmProvider.class);
	}

}
