package cuin.cn.innr;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : InnrLkInbService.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.04
 * 설    명 : 대내 연계 전문 인바운드(inbound) 인터페이스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface InnrLkInbService {

	/**
	 * 대내 EAI 인바운드 수행
	 * 
	 * @param inbData 입력 데이터
	 * @return 출력 데이터
	 */
	byte[] reply(byte[] inbData);
}
