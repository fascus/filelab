package cuin.cn.innr.slp;

import hone.core.util.ApplicationContextHolder;
import hone.omm.model.OmmMap;
import hone.omm.provider.OmmProvider;
import hone.omm.unmarshal.HoneOmmUnmarshaller;
import hone.omm.unmarshal.OmmUnmarshaller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.cn.exception.CuinEAIException;
import cuin.cn.innr.dto.BkbPrnn2Dto;
import cuin.cn.innr.dto.SlpBundleDto;
import cuin.cn.innr.dto.SlpDatHdrDto;
import cuin.cn.innr.dto.SlpPrnnDto;
import cuin.cn.service.ServiceContext;
import cuin.online.cn.core.message.common.TcpConstants;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : SlpMesgParser.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.12.02
 * 설    명 : 전표/통장 인쇄 전문 파서(parser)
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class SlpMesgParser {

	private static final Logger logger = LoggerFactory.getLogger(SlpMesgParser.class);

	// 전표 화면 ID
	public static final String SLIP_SCREEN_ID = "SUDPSS0107";
	// 통장인쇄(2) 화면 ID
	public static final String SECOND_BKB_SCR_ID = "SUDPSU0108";

	// 전표/통장 인쇄 DTO 리스트
	public static final String SLP_DTO_LIIST = "SLP_DTO_LIST";

	/**
	 * 신용계 전표/통장 인쇄 전문을 파싱(parsing) 한 후, 서비스 컨텍스트에 적재한다.
	 * 
	 * @param slpMesgBytes 전표/통장 인쇄 전문
	 */
	public static void parse(byte[] slpMesgBytes, int serviceDataLength) {

		// 320 byte 공통 헤더 제거
		byte[] commonHeaderTrimedMsg = Arrays.copyOfRange(slpMesgBytes, TcpConstants.MSG_HEADER_LENGTH, slpMesgBytes.length);
		// 전표/통장 인쇄 데이터 파트 추출 (서비스 데이터 제거)
		byte[] eaiServiceDataTrimmedMsg = Arrays.copyOfRange(commonHeaderTrimedMsg, serviceDataLength, commonHeaderTrimedMsg.length);

		List<SlpBundleDto> slpBundleList = new ArrayList<SlpBundleDto>();
		// 전표/통장 인쇄 데이터 파트 헤더 추출
		OmmProvider ommProvider = ApplicationContextHolder.getApplicationContext().getBean(OmmProvider.class);
		InputStream inputStream = new ByteArrayInputStream(eaiServiceDataTrimmedMsg);
		OmmMap slpDatHdrMap = ommProvider.get("cuin.cn.innr.omm.SlpDatHdr");
		try {
			while (inputStream.available() > slpDatHdrMap.getInLength()) {
				OmmUnmarshaller ommUnmarshaller = new HoneOmmUnmarshaller(slpDatHdrMap, inputStream);
				SlpDatHdrDto slpDatHdrDto = (SlpDatHdrDto) ommUnmarshaller.read();
				if (logger.isDebugEnabled()) {
					logger.debug("Slip data header : " + slpDatHdrDto);
				}
				String scrId = slpDatHdrDto.getTxId().substring(0, 10);
				// 전표 데이터 인 경우,
				if (scrId.equals(SLIP_SCREEN_ID)) {
					OmmMap slpPrnnMap = ommProvider.get("cuin.cn.innr.omm.SlpPrnn");
					ommUnmarshaller = new HoneOmmUnmarshaller(slpPrnnMap, inputStream);
					SlpPrnnDto slpPrnnDto = (SlpPrnnDto) ommUnmarshaller.read();
					if (logger.isDebugEnabled()) {
						logger.debug("Slip print data : \n" + slpPrnnDto);
					}
					slpBundleList.add(new SlpBundleDto(slpDatHdrDto, slpPrnnDto));
				}
				// 통장 인쇄 데이터인 경우...
				else if (scrId.equals(SECOND_BKB_SCR_ID)) {
					OmmMap bkbPrnn2Map = ommProvider.get("cuin.cn.innr.omm.BkbPrnn2");
					ommUnmarshaller = new HoneOmmUnmarshaller(bkbPrnn2Map, inputStream);
					BkbPrnn2Dto bkbPrnn2Dto = (BkbPrnn2Dto) ommUnmarshaller.read();
					if (logger.isDebugEnabled()) {
						logger.debug("Bank book print data : \n" + bkbPrnn2Dto);
					}
					slpBundleList.add(new SlpBundleDto(slpDatHdrDto, bkbPrnn2Dto));
				}

			}
			if (slpBundleList.size() > 0) {
				ServiceContext.setServiceAttr(SLP_DTO_LIIST, slpBundleList);
			} else {
				logger.warn("Cannot find slip data in inner link message");
			}
		} catch (IOException e) {
			throw new CuinEAIException("Error while parse slip message", e);
		}
	}
}
