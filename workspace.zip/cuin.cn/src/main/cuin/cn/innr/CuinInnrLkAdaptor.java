package cuin.cn.innr;

import hone.common.util.StringUtils;
import hone.core.util.ApplicationContextHolder;
import hone.omm.marshall.HoneOmmMarshaller;
import hone.omm.marshall.OmmMarshaller;
import hone.omm.marshall.convert.DefaultDateConverter;
import hone.omm.marshall.writer.FixedLengthStreamWriter;
import hone.omm.model.OmmMap;
import hone.omm.provider.OmmProvider;
import hone.omm.unmarshal.HoneOmmUnmarshaller;
import hone.omm.unmarshal.OmmUnmarshaller;
import hone.omm.value.ObjectValueMapper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.cn.eai.EaiAdaptor;
import cuin.cn.innr.dto.InnrInsHdrDto;
import cuin.cn.innr.dto.InnrLkRcveDto;
import cuin.cn.innr.dto.InnrLkSndnDto;
import cuin.cn.service.ServiceContext;
import cuin.online.cn.core.message.common.TcpConstants;
import cuin.online.cn.core.message.header.CommonRequestHeader;
import cuin.online.cn.core.message.header.CommonResponseHeader;
import cuin.online.cn.core.message.header.CuinCommonHeader;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : CuinInnrLkAdaptor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.08.13
 * 설    명 : 신협공제 대내 전문 송신 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CuinInnrLkAdaptor implements InnrLkAdaptor {
	private static final Logger logger = LoggerFactory.getLogger(CuinInnrLkAdaptor.class);

	// 대내 공통 헤더 OMM ID
	private static final String INNR_INS_HDR_OMM_ID = "cuin.cn.innr.omm.InnrInsHdr";
	// '전문 종료 표시' 필드 길이
	private static final int MSG_END_MARKER_LENGTH = 2;
	// '전문 종료 표시' 필드 데이터
	private static final String MSG_END_MARKER = "ZZ";

	// 전문 마샬링/언마샬링을 위한 OMM 프로바이더
	private static OmmProvider ommProvider;
	// EAI 송수신 어댑터
	private static EaiAdaptor eaiAdaptor;

	// 대내 연계 오류 코드
	private static final int ERR_RES = 1;
	// 대내 전문 발송 시 표준 헤더 업데이트를 위한 콜백...
	private InnrStdHdrClk stdHdrClk;
	// 대내 요청 전문 헤더 (온라인 전문 입력 헤더를 복제)
	private CommonRequestHeader commonRequestHeader;
	// 대내 응답 전문 헤더
	private CommonResponseHeader commonResponseHeader;
	// 전문 진행 번호... (대내 전문은 온라인 서비스에서 2회 이상 발송할 수 있으므로,
	// 전문 진행 번호를 멤버 변수로 설정해 발송할 때마다 증가되도록 한다.)
	private int trxSeq;
	// 대내 거래 시도 중 오류 발생 시, 예외 발생 유무
	private boolean ignoreFailure;

	public CuinInnrLkAdaptor() {
		// 온라인 서비스 전문 헤더를 이용해 전문 공통 헤더를 생성.
		CommonRequestHeader original = (CommonRequestHeader) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.REQUEST_HEADER);
		try {
			commonRequestHeader = (CommonRequestHeader) original.clone();
		} catch (CloneNotSupportedException e) {
			logger.error(e.getMessage(), e);
		}

		// 전문 순번을 서비스 컨텍스트에서 획득
		Integer trxSeqInServiceContext = (Integer) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.EAI_TRX_SEQ);
		if (trxSeqInServiceContext == null) {
			trxSeq = Integer.parseInt(commonRequestHeader.getTrxseq(), 10);
		} else {
			trxSeq = trxSeqInServiceContext;
		}

		// 대내 거래 시, 전문 변환 방식은 '1:BYPASS' 로 고정.
		commonRequestHeader.setMsgSndG("1");
		// 대내 거래 시, 송신인터페이스 구분 '2:EAI'로 고정
		commonRequestHeader.setSndInfcG(2);
		// 대내 거래 시, EAI 인터페이스/XA '1:XA'로 고정
		commonRequestHeader.setEaiTrxG(1);

		// 대내 거래 시도 중 오류 발생 시, 기본적으로 예외 객체를 던진다.
		ignoreFailure = false;
	}

	/**
	 * 대내 전문을 위한 온라인 서비스 요청 전문 헤더 반환.
	 */
	public CommonRequestHeader getCommonRequestHeader() {
		return commonRequestHeader;
	}

	/**
	 * 대내 전문 응답 전문 헤더 반환
	 */
	public CommonResponseHeader getCommonResponseHeader() {
		return commonResponseHeader;
	}

	/**
	 * 전문 송신 직전에 공통 헤더를 변경하는 콜백(callback) 인스턴스 설정.
	 */
	@Override
	public void setStdHdrClk(InnrStdHdrClk stdHdrClk) {
		this.stdHdrClk = stdHdrClk;
	}

	/**
	 * OMM 객체 반환.
	 */
	public OmmMap getOmmMap(String ommId) {
		return ommProvider.get(ommId);
	}

	/**
	 * 대내 거래 중 오류 발생 시, 예외 발생 유무.
	 * 
	 * @param ignore true 이며 대내 거래 중 오류 발생하더라도 예외를 발생 시키지 않는다.
	 */
	public void setIgnoreFailure(boolean ignore) {
		ignoreFailure = ignore;
	}

	private String extractErrMsg(byte[] responseBytes) {
		final int SKIP_LEN = 108;
		final int ERR_FIELD_LENGTH = 100;
		final int ERR_MSG_LENGTH_FIELD_SIZE = 2;

		// 오류 발생 필드 정보
		String errFieldInfo = null;
		// 어플리케이션 메시지
		String appErrMsg = null;
		try {
			int readIndex = TcpConstants.MSG_HEADER_LENGTH + SKIP_LEN;
			byte[] errFieldBytes = new byte[ERR_FIELD_LENGTH];
			System.arraycopy(responseBytes, readIndex, errFieldBytes, 0, ERR_FIELD_LENGTH);
			errFieldInfo = new String(errFieldBytes, TcpConstants.DEFAUL_CHARACTER_SET);

			readIndex += ERR_FIELD_LENGTH;
			byte[] appErrMsgCntBuf = new byte[ERR_MSG_LENGTH_FIELD_SIZE];
			System.arraycopy(responseBytes, readIndex, appErrMsgCntBuf, 0, ERR_MSG_LENGTH_FIELD_SIZE);
			int appErrMsgCnt = StringUtils.parseInt(new String(appErrMsgCntBuf, TcpConstants.DEFAUL_CHARACTER_SET));

			readIndex += ERR_MSG_LENGTH_FIELD_SIZE;
			byte[] appErrMsgBuf = new byte[ERR_FIELD_LENGTH * appErrMsgCnt];
			System.arraycopy(responseBytes, readIndex, appErrMsgBuf, 0, appErrMsgBuf.length);
			appErrMsg = new String(appErrMsgBuf, TcpConstants.DEFAUL_CHARACTER_SET);
		} catch (UnsupportedEncodingException ex) {
			logger.error(ex.getMessage(), ex);
		}
		return (appErrMsg == null) ? errFieldInfo : appErrMsg;
	}

	private byte[] requestViaEai(String interfaceId, byte[] sendDataBytes) {
		byte[] responseBytes = eaiAdaptor.request(interfaceId, sendDataBytes);
		if (logger.isDebugEnabled()) {
			try {
				logger.debug("Inner linked response message :\n----- ----- -----\n" + new String(responseBytes, TcpConstants.DEFAUL_CHARACTER_SET) + "\n----- ----- -----\n");
			} catch (UnsupportedEncodingException ex) {
				logger.error(ex.getMessage(), ex);
			}
		}
		return responseBytes;
	}

	/*
	 * EAI 송수신을 위한 OMM 프로바이더 및 EAI 어댑터 초기화.
	 */
	private void prepare2send() {

		// 전문 생성을 위한 OMM 프로바이더 초기화
		if (ommProvider == null) {
			ommProvider = ApplicationContextHolder.getApplicationContext().getBean(OmmProvider.class);
			if (ommProvider == null) {
				throw new IllegalStateException("Cannot find OMM Provider. check framework settings.");
			}
		}

		// EAI 어댑터 초기화
		if (eaiAdaptor == null) {
			eaiAdaptor = ApplicationContextHolder.getApplicationContext().getBean(EaiAdaptor.class);
			if (eaiAdaptor == null) {
				throw new IllegalStateException("Cannot find EAI Adaptor bean. check environment settings.");
			}
		}
	}

	/*
	 * 대내 연계 응답 전문 헤더 파싱(parsing)
	 */
	private CommonResponseHeader parseResponseHeader(byte[] responseBytes) {
		OmmMap outHeaderOmmMap = ommProvider.get(CuinCommonHeader.COMMON_OUT_HEADER);
		OmmUnmarshaller<CommonResponseHeader> outputHeaderUnmarshaller = new HoneOmmUnmarshaller<CommonResponseHeader>(outHeaderOmmMap, new ByteArrayInputStream(responseBytes, 0,
				TcpConstants.MSG_HEADER_LENGTH));
		try {
			return outputHeaderUnmarshaller.read();
		} catch (Exception e) {
			throw new IllegalStateException("Invalid message header. (잘못된 전문 헤더 오류)", e);
		}
	}

	/*
	 * 대내 연계 전문 데이터 생성 (320 byte 표준 헤더 + 900 byte 공통 헤더 + 데이터 파트)
	 */
	private byte[] buildRequestMsg(String sndnOmmId, InnrInsHdrDto innrInsHdrDto, InnrLkSndnDto sndnDto) {

		// 대내 공통 헤더 파트 생성
		byte[] innrInsHdrBytes = buildInnrInsHdrBytes(innrInsHdrDto);

		// 대내 연계 전문 데이터 파트 생성
		byte[] lnMesgBodyBytes = buildBodyBytes(sndnOmmId, sndnDto);

		// 공통 표준 헤더를 포함한 전문 길이 계산 및 공통 헤더 생성
		int wholeMsgLength = TcpConstants.MSG_HEADER_LENGTH + innrInsHdrBytes.length + lnMesgBodyBytes.length + MSG_END_MARKER_LENGTH;
		byte[] lnMesgHeaderBytes = buildHeaderBytes(wholeMsgLength);

		// 응답 전문 전체 텍스트 생성
		byte[] wholeMsgBuf = new byte[wholeMsgLength];
		int pos = 0;

		// 표준 전문 헤더 출력
		System.arraycopy(lnMesgHeaderBytes, 0, wholeMsgBuf, pos, TcpConstants.MSG_HEADER_LENGTH);
		pos += TcpConstants.MSG_HEADER_LENGTH;

		// 대내 전문 공통 헤더 파트 출력
		if (innrInsHdrBytes.length > 0) {
			System.arraycopy(innrInsHdrBytes, 0, wholeMsgBuf, pos, innrInsHdrBytes.length);
			pos += innrInsHdrBytes.length;
		}

		// 대내 전문 데이터 파트 출력
		if (lnMesgBodyBytes.length > 0) {
			System.arraycopy(lnMesgBodyBytes, 0, wholeMsgBuf, pos, lnMesgBodyBytes.length);
			pos += lnMesgBodyBytes.length;
		}

		// 전문 종료 파트 출력
		System.arraycopy(MSG_END_MARKER.getBytes(), 0, wholeMsgBuf, pos, 2);

		// 대내 연계 전문 송신 로그 출력
		if (logger.isDebugEnabled()) {
			try {
				logger.debug("Inner linked request message :\n----- ----- -----\n" + new String(wholeMsgBuf, TcpConstants.DEFAUL_CHARACTER_SET) + "\n----- ----- -----\n");
			} catch (UnsupportedEncodingException ex) {
				logger.error(ex.getMessage(), ex);
			}
		}

		return wholeMsgBuf;
	}

	/*
	 * 대내 공통 헤더 파트 생성
	 */
	private byte[] buildInnrInsHdrBytes(InnrInsHdrDto innrInsHdrDto) {
		OmmMap ommInMap = ommProvider.get(INNR_INS_HDR_OMM_ID);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		FixedLengthStreamWriter streamWriter = new FixedLengthStreamWriter(ommInMap, baos);
		streamWriter.setDateConverter(new DefaultDateConverter());
		OmmMarshaller headerMarshaller = new HoneOmmMarshaller(ommInMap, streamWriter, new ObjectValueMapper());
		headerMarshaller.write(innrInsHdrDto);
		return baos.toByteArray();
	}

	/*
	 * 대내 전문 요청 데이터 파트 생성
	 */
	private byte[] buildBodyBytes(String sndnOmmId, InnrLkSndnDto sndnDto) {
		OmmMap ommInMap = ommProvider.get(sndnOmmId);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		FixedLengthStreamWriter streamWriter = new FixedLengthStreamWriter(ommInMap, baos);
		streamWriter.setDateConverter(new DefaultDateConverter());
		OmmMarshaller headerMarshaller = new HoneOmmMarshaller(ommInMap, streamWriter, new ObjectValueMapper());
		headerMarshaller.write(sndnDto);
		return baos.toByteArray();
	}

	/**
	 * 온라인 서비스 전문 헤더를 이용해 대내 전문 헤더 생성
	 * 
	 * @param wholeMsgLength
	 * @return
	 */
	private byte[] buildHeaderBytes(int wholeMsgLength) {
		// 전문 공통 헤더 설정 콜백이 설정된 경우, 콜백 메소드 호출
		if (stdHdrClk != null) {
			stdHdrClk.updateStdHdr(commonRequestHeader);
		} else {
			logger.warn("request header setup call is missing. (전문 헤더 설정 콜백이 지정되지 않았습니다.)");
		}

		// -- [start] 전문 공통 헤더 설정 --
		// 전문 일련번호 1 증가
		commonRequestHeader.setTrxseq(String.format("%02d", ++trxSeq));
		ServiceContext.setSysAttr(ServiceContext.ContextSysAttr.EAI_TRX_SEQ, Integer.valueOf(trxSeq));

		// 전문 길이 (전문길이 필드의 사이즈만큼 차감)
		commonRequestHeader.setMsgLen(wholeMsgLength - TcpConstants.MSG_LEN_FIELD_SIZE);
		// -- [end] 전문 공통 헤더 설정 --
		if (logger.isDebugEnabled()) {
			logger.debug("Message Common header : " + commonRequestHeader.toString());
		}

		// 전문 공통 헤더 마샬링
		OmmMap cnHdrOmmMap = ommProvider.get(CuinCommonHeader.COMMON_IN_HEADER);
		ByteArrayOutputStream headerOut = new ByteArrayOutputStream();
		FixedLengthStreamWriter streamWriter = new FixedLengthStreamWriter(cnHdrOmmMap, headerOut);
		streamWriter.setDateConverter(new DefaultDateConverter());
		OmmMarshaller headerMarshaller = new HoneOmmMarshaller(cnHdrOmmMap, streamWriter, new ObjectValueMapper());
		headerMarshaller.write(commonRequestHeader);
		return headerOut.toByteArray();
	}

	private InnrLkRcveDto buildResponseDto(String rcveOmmId, byte[] responseBytes) {
		OmmMap ommMap = ommProvider.get(rcveOmmId);
		ByteArrayInputStream bais = new ByteArrayInputStream(responseBytes, TcpConstants.MSG_HEADER_LENGTH, responseBytes.length - TcpConstants.MSG_HEADER_LENGTH);
		OmmUnmarshaller responseUnmarshaller = new HoneOmmUnmarshaller(ommMap, bais);
		return (InnrLkRcveDto) responseUnmarshaller.read();
	}

	@Override
	public InnrLkRcveDto request(String interfaceId, InnrInsHdrDto innrInsHdrDto, String sndnOmmId, InnrLkSndnDto sndnDto, String rcveOmmId) {
		validateRequestParams(interfaceId, innrInsHdrDto, sndnOmmId, sndnDto);
		prepare2send();

		byte[] responseBytes = sendAndReceive(interfaceId, innrInsHdrDto, sndnOmmId, sndnDto);
		// 대내 전문 거래 결과 오류가 발생했거나, 응답 OMM 맵이 없는 경우 null 반환
		if (responseBytes == null || StringUtils.isEmpty(rcveOmmId)) {
			return null;
		}
		// 대내 전문 거래 응답 데이터 파싱
		else {

			return buildResponseDto(rcveOmmId, responseBytes);
		}
	}

	@Override
	public ByteArrayInputStream request(String interfaceId, InnrInsHdrDto innrInsHdrDto, String sndnOmmId, InnrLkSndnDto sndnDto) {
		validateRequestParams(interfaceId, innrInsHdrDto, sndnOmmId, sndnDto);
		prepare2send();

		byte[] responseBytes = sendAndReceive(interfaceId, innrInsHdrDto, sndnOmmId, sndnDto);
		if (responseBytes == null) {
			return null;
		} else {
			return new ByteArrayInputStream(responseBytes, TcpConstants.MSG_HEADER_LENGTH, responseBytes.length - TcpConstants.MSG_HEADER_LENGTH - MSG_END_MARKER_LENGTH);
		}
	}

	private void validateRequestParams(String interfaceId, InnrInsHdrDto innrInsHdrDto, String sndnOmmId, InnrLkSndnDto sndnDto) {
		if (StringUtils.isEmpty(interfaceId)) {
			throw new IllegalArgumentException("interfaceId is missing. (전문 인터페이스 ID를 설정하시기 바랍니다.)");
		}
		if (innrInsHdrDto == null) {
			throw new IllegalArgumentException("innrInsHdrDto is missing. (대내 공통 헤더를 설정하시기 바랍니다.)");
		}
		if (sndnDto == null) {
			throw new IllegalArgumentException("sndnDto is missing. (대내 전문 입력 DTO를 설정하시기 바랍니다.)");
		}
		if (StringUtils.isEmpty(sndnOmmId)) {
			throw new IllegalArgumentException("sndnOmmId is missing. (대내 전문 송신 OMM ID를 설정하시기 바랍니다.");
		}
	}

	private byte[] sendAndReceive(String interfaceId, InnrInsHdrDto innrInsHdrDto, String sndnOmmId, InnrLkSndnDto sndnDto) {
		// 송신 데이터 생성 (메시지 본문 영역이 없을 경우 빈 데이터 블럭 생성)
		byte[] sendDataBytes = null;
		if (sndnOmmId != null && sndnDto != null) {
			sendDataBytes = buildRequestMsg(sndnOmmId, innrInsHdrDto, sndnDto);
		} else {
			sendDataBytes = new byte[0];
		}

		// EAI 를 통해 대외 전문 송신 ...
		byte[] responseBytes = requestViaEai(interfaceId, sendDataBytes);

		// 응답 전문 파싱(parsing)
		commonResponseHeader = parseResponseHeader(responseBytes);
		// 대내 연계 시 오류 발생 ...
		if (commonResponseHeader.getRstYn() == ERR_RES) {
			String errMsg = extractErrMsg(responseBytes);
			String errCode = commonResponseHeader.getErrC();
			if (ignoreFailure) {
				logger.warn("Error while execute EAI service. Error message : '" + errMsg + "', Error code : '" + errCode + "' (ignoreFailure setting = true)");
				return null;
			} else {
				throw new CuinInnrLkException(commonResponseHeader.getErrC(), errMsg);
			}
		} else {
			return responseBytes;
		}
	}

	@Override
	public void send(String interfaceId, InnrInsHdrDto innrInsHdrDto, String sndnOmmId, InnrLkSndnDto sndnDto) {
		validateRequestParams(interfaceId, innrInsHdrDto, sndnOmmId, sndnDto);

		prepare2send();

		// 대내 비동기 통신 시 기본 값 설정 : 화면 ID = 인터페이스 ID
		commonRequestHeader.setScrId(interfaceId);
		// 대내 비동기 통신 시 기본 값 설정 : EAI 인터페이스/XA 거래 구분(0:Called service commit)
		commonRequestHeader.setEaiTrxG(0);
		// 대내 비동기 통신 시 기본 값 설정 : 송신시스템정보/송신 인터페이스 구분 (1:채널)
		commonRequestHeader.setSndInfcG(1);

		// 송신 데이터 생성 (메시지 본문 영역이 없을 경우 빈 데이터 블럭 생성)
		byte[] sendDataBytes = null;
		if (sndnOmmId != null && sndnDto != null) {
			sendDataBytes = buildRequestMsg(sndnOmmId, innrInsHdrDto, sndnDto);
		} else {
			sendDataBytes = new byte[0];
		}

		// EAI 를 통해 대외 전문 송신 ...
		eaiAdaptor.send(interfaceId, sendDataBytes);
	}

}
