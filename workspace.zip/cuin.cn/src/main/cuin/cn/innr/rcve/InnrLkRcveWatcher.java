package cuin.cn.innr.rcve;

import hone.common.util.StringUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.cn.exception.CuinEAIException;
import cuin.cn.exception.CuinException;
import cuin.cn.innr.dto.InnrLkRcveDto;
import cuin.cn.innr.dto.InnrLkRcveErrDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : InnrLkRcveWatcher.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.10.24
 * 설    명 : 대내 응답 전문 감시기.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class InnrLkRcveWatcher {

	// 매 인터벌 마다 0.5 초간 대기
	private static final int WAIT_PERIOD = 500;
	// 최대 15초 간 대외 전문 수신 대기...
	private static final int MAX_WAIT_SECONDS = 15;

	private static final Logger logger = LoggerFactory.getLogger(InnrLkRcveWatcher.class);

	/**
	 * 대내 비동기 전문 수신 (최대 30초 간 대기).
	 * 
	 * @param globalId 수신 전문 글로벌 ID
	 * 
	 */
	public static final InnrLkRcveMsg waitFor(String globalId) {
		return waitFor(globalId, MAX_WAIT_SECONDS);
	}

	/**
	 * 대내 비동기 전문 수신 (지정한 시간동안 대기).
	 * 
	 * @param globalId 수신 전문 글로벌 ID
	 * @param maxWait 최대 대기 시간 (단위 : 초)
	 */
	public static final InnrLkRcveMsg waitFor(String globalId, int maxWait) {

		if (StringUtils.isEmpty(globalId)) {
			throw new IllegalArgumentException("globalId is missing");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Lookup receive message, global ID : " + globalId);
		}

		int waitHopCount = 0;
		while (waitHopCount < maxWait * 2) {

			if (logger.isDebugEnabled()) {
				logger.debug("Wait for inner link message, hop count = " + waitHopCount);
			}

			try {
				Thread.sleep(WAIT_PERIOD);
			} catch (InterruptedException e) {
				String errMsg = "Error while watching inner link message response.";
				logger.error(errMsg, e);
				throw new CuinException(errMsg, e);
			}

			InnrLkRcveMsg innrLkRcveMsg = InnrLkRcveMsgQueue.lookup(globalId);
			if (innrLkRcveMsg != null) {
				InnrLkRcveDto innrLkRcveDto = innrLkRcveMsg.getInnrLkRcveDto();
				if (innrLkRcveDto instanceof InnrLkRcveErrDto) {
					InnrLkRcveErrDto innrLkRcveErrDto = (InnrLkRcveErrDto) innrLkRcveDto;
					throw new CuinException(innrLkRcveErrDto.getSysErrCode(), innrLkRcveErrDto.getErrMsg());
				}
				return innrLkRcveMsg;
			}
			waitHopCount++;
		}

		InnrLkRcveMsgQueue.log();
		throw new CuinEAIException("Inner link response message not arrived.");
	}
}
