package cuin.cn.innr.rcve;

import hone.common.util.EnvUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.online.cn.core.message.header.CommonResponseHeader;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : InnrLkRcveMsgQueue.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.10.24
 * 설    명 : 대외 응답 전문 큐 (queue).
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class InnrLkRcveMsgQueue {

	private static final Logger logger = LoggerFactory.getLogger(InnrLkRcveMsgQueue.class);
	private static final int GLOBAL_ID_WITH_SEQ_LENGTH = 32;

	private static final String EAI_RCVE_QUEUE_FILE_NAME = "eaiInnrRcveQueue.bin";
	private static final List<InnrLkRcveMsg> rcveMsgList = new ArrayList<InnrLkRcveMsg>();

	public static void add(InnrLkRcveMsg InnrLkRcveMsg) {
		synchronized (rcveMsgList) {
			rcveMsgList.add(InnrLkRcveMsg);
			storeQueueFile();
		}
	}

	public static InnrLkRcveMsg lookup(String globalId) {

		synchronized (rcveMsgList) {
			loadQueueFile();

			for (InnrLkRcveMsg candidate : rcveMsgList) {
				CommonResponseHeader commonResponseHeader = candidate.getCommonResponseHeader();
				String candidateGlobalId = commonResponseHeader.getGlobId();
				if (globalId.length() == GLOBAL_ID_WITH_SEQ_LENGTH) {
					candidateGlobalId += commonResponseHeader.getTrxseq();
				}
				if (candidateGlobalId.equals(globalId)) {
					if (logger.isDebugEnabled()) {
						logger.debug("Inner message received : " + candidate.toString());
					}
					InnrLkRcveMsg foundRcveMsg = candidate;
					rcveMsgList.remove(foundRcveMsg);
					storeQueueFile();
					return foundRcveMsg;
				}
			}
			return null;
		}
	}

	public static List<InnrLkRcveMsg> getRcveMsgList() {
		loadQueueFile();
		return rcveMsgList;
	}

	public static void log() {
		if (logger.isDebugEnabled()) {
			for (InnrLkRcveMsg InnrLkRcveMsg : rcveMsgList) {
				logger.debug("InnrLkRcveMsg : " + InnrLkRcveMsg.toString());
			}
		}
	}

	private static void storeQueueFile() {
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		FileLock fl = null;

		try {
			String queueFilePath = getQueueFilePath();
			fos = new FileOutputStream(queueFilePath);
			fl = fos.getChannel().lock();

			oos = new ObjectOutputStream(fos);
			oos.writeInt(rcveMsgList.size());
			for (InnrLkRcveMsg InnrLkRcveMsg : rcveMsgList) {
				oos.writeObject(InnrLkRcveMsg);
			}
		} catch (Exception e) {
			logger.error("Cannot write to serialization file", e);
		} finally {
			try {
				if (fl != null) {
					fl.release();
				}
				if (oos != null) {
					oos.close();
				}
			} catch (IOException e) {
				logger.error("Error while close serialization file", e);
			}
		}
	}

	private static void loadQueueFile() {
		FileInputStream fis = null;
		ObjectInputStream ois = null;

		try {
			String queueFilePath = getQueueFilePath();
			fis = new FileInputStream(queueFilePath);
			ois = new ObjectInputStream(fis);

			rcveMsgList.clear();
			int rcveMsgCount = ois.readInt();

			for (int i = 0; i < rcveMsgCount; i++) {
				InnrLkRcveMsg InnrLkRcveMsg = (InnrLkRcveMsg) ois.readObject();
				rcveMsgList.add(InnrLkRcveMsg);
			}

			if (logger.isDebugEnabled()) {
				logger.debug("After load message queue. received message count = " + rcveMsgList.size());
			}
		} catch (FileNotFoundException ignored) {
			if (logger.isDebugEnabled()) {
				logger.debug(EAI_RCVE_QUEUE_FILE_NAME + " does not exist.");
			}
		} catch (Exception e) {
			logger.error("Cannot read serialization file", e);
		} finally {
			try {
				if (ois != null) {
					ois.close();
				}
			} catch (IOException e) {
				logger.error("Error while close serialization file", e);
			}
		}
	}

	private static String getQueueFilePath() {
		return EnvUtils.getProperty("eai.rcve.queue.file.location") + File.separator + EAI_RCVE_QUEUE_FILE_NAME;
	}

}
