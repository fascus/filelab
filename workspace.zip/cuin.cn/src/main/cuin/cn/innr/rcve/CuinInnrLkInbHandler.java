package cuin.cn.innr.rcve;

import hone.common.util.StringUtils;
import hone.omm.model.OmmMap;
import hone.omm.provider.OmmProvider;
import hone.omm.unmarshal.HoneOmmUnmarshaller;
import hone.omm.unmarshal.OmmUnmarshaller;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import cuin.cn.innr.dto.InnrLkRcveDto;
import cuin.cn.innr.dto.InnrLkRcveErrDto;
import cuin.online.cn.core.message.common.TcpConstants;
import cuin.online.cn.core.message.header.CommonResponseHeader;
import cuin.online.cn.core.message.header.CuinCommonHeader;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : CuinInnrLkInbHandler.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.10.24
 * 설    명 : 대내 연계 전문 인바운드 핸들러 (inbound handler) 구현체.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CuinInnrLkInbHandler implements InnrLkInbHandler {

	private static final String EAI_INNR_RECEIVE_LOGGER_NAME = "EAI_INNR_RECEIVE";
	private static final Logger logger = LoggerFactory.getLogger(CuinInnrLkInbHandler.class);

	private OmmProvider ommProvider;

	@Override
	public void handleInbMsg(byte[] inbData, InnrLkClk innrLkClk) {

		// EAI 수신 로그를 별도 로그 파일로 출력
		MDC.put(TcpConstants.LOG_KEY_CLIENT_IP, EAI_INNR_RECEIVE_LOGGER_NAME);

		if (logger.isDebugEnabled()) {
			try {
				logger.debug("Inner message reply (대내 전문 응답) : " + new String(inbData, TcpConstants.DEFAUL_CHARACTER_SET));
			} catch (UnsupportedEncodingException e) {
				logger.error(e.getMessage(), e);
			}
		}

		try {
			// 대내 전문 응답 중에서 신협 320 byte 헤더 파싱
			CommonResponseHeader commonResponseHeader = parseCommonHeader(inbData);
			if (logger.isDebugEnabled()) {
				logger.debug("Inner response common header (신협 공통 응답 헤더) : " + commonResponseHeader);
			}

			InnrLkRcveDto innrLkRcveDto = null;
			// 정상 응답
			if (commonResponseHeader.getRstYn() == 0) {
				// 대내 전문 응답 중에서 데이터 파트 파싱(parsing)
				String rcveOmmId = innrLkClk.getRcveOmmId();
				if (!StringUtils.isEmpty(rcveOmmId)) {
					OmmMap frgLnkMesgHeaderOmmMap = ommProvider.get(rcveOmmId);
					OmmUnmarshaller rcveDataUnmarshaller = new HoneOmmUnmarshaller(frgLnkMesgHeaderOmmMap, new ByteArrayInputStream(inbData, TcpConstants.MSG_HEADER_LENGTH, inbData.length
							- TcpConstants.MSG_HEADER_LENGTH));
					innrLkRcveDto = (InnrLkRcveDto) rcveDataUnmarshaller.read();
				}
				if (logger.isDebugEnabled()) {
					logger.debug("Inner response data (대내 응답 데이터) : " + innrLkRcveDto);
				}
			}
			// 오류 응답
			else {
				InnrLkRcveErrDto innrLkRcveErrDto = new InnrLkRcveErrDto();
				innrLkRcveErrDto.setSysErrCode(commonResponseHeader.getErrC());
				innrLkRcveErrDto.setErrMsg(extractErrMsg(inbData));
				innrLkRcveDto = innrLkRcveErrDto;
			}

			// 응답 데이터를 수신 메시지 큐에 추가...
			InnrLkRcveMsg innrLkRcveMsg = new InnrLkRcveMsg(commonResponseHeader, innrLkRcveDto);
			InnrLkRcveMsgQueue.add(innrLkRcveMsg);
		} catch (Exception e) {
			logger.error("Error while handle received inner message.", e);
		}

		MDC.remove(TcpConstants.LOG_KEY_CLIENT_IP);
	}

	private String extractErrMsg(byte[] responseBytes) {
		final int SKIP_LEN = 108;
		final int ERR_FIELD_LENGTH = 100;
		final int ERR_MSG_LENGTH_FIELD_SIZE = 2;

		// 오류 발생 필드 정보
		String errFieldInfo = null;
		// 어플리케이션 메시지
		String appErrMsg = null;
		try {
			int readIndex = TcpConstants.MSG_HEADER_LENGTH + SKIP_LEN;
			byte[] errFieldBytes = new byte[ERR_FIELD_LENGTH];
			System.arraycopy(responseBytes, readIndex, errFieldBytes, 0, ERR_FIELD_LENGTH);
			errFieldInfo = new String(errFieldBytes, TcpConstants.DEFAUL_CHARACTER_SET);

			readIndex += ERR_FIELD_LENGTH;
			byte[] appErrMsgCntBuf = new byte[ERR_MSG_LENGTH_FIELD_SIZE];
			System.arraycopy(responseBytes, readIndex, appErrMsgCntBuf, 0, ERR_MSG_LENGTH_FIELD_SIZE);
			int appErrMsgCnt = StringUtils.parseInt(new String(appErrMsgCntBuf, TcpConstants.DEFAUL_CHARACTER_SET));

			readIndex += ERR_MSG_LENGTH_FIELD_SIZE;
			byte[] appErrMsgBuf = new byte[ERR_FIELD_LENGTH * appErrMsgCnt];
			System.arraycopy(responseBytes, readIndex, appErrMsgBuf, 0, appErrMsgBuf.length);
			appErrMsg = new String(appErrMsgBuf, TcpConstants.DEFAUL_CHARACTER_SET);
		} catch (UnsupportedEncodingException ex) {
			logger.error(ex.getMessage(), ex);
		}
		return (appErrMsg == null) ? errFieldInfo : appErrMsg;
	}

	/**
	 * 입출력 전문 파싱을 위한 OMM 맵 목록을 제공하는 프로바이더 설정
	 */
	@Override
	public void setOmmProvider(OmmProvider ommProvider) {
		this.ommProvider = ommProvider;
	}

	/**
	 * 요청 전문 헤더 파싱
	 * 
	 * @param msgBuffer 전문 헤더 버퍼
	 * @return 요청 전문 헤더 객체
	 */
	private CommonResponseHeader parseCommonHeader(byte[] msgBuffer) {
		CommonResponseHeader responseHeader;
		OmmMap inHeaderOmmMap = ommProvider.get(CuinCommonHeader.COMMON_OUT_HEADER);
		OmmUnmarshaller<CommonResponseHeader> inputHeaderUnmarshaller = new HoneOmmUnmarshaller<CommonResponseHeader>(inHeaderOmmMap, new ByteArrayInputStream(msgBuffer, 0,
				TcpConstants.MSG_HEADER_LENGTH));
		try {
			responseHeader = inputHeaderUnmarshaller.read();
		} catch (Exception e) {
			throw new IllegalStateException("Invalid message header. (잘못된 전문 헤더 오류)", e);
		}

		return responseHeader;
	}

}
