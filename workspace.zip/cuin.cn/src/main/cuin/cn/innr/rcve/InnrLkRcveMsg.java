package cuin.cn.innr.rcve;

import java.io.Serializable;

import cuin.cn.innr.dto.InnrLkRcveDto;
import cuin.online.cn.core.message.header.CommonResponseHeader;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대내 인터페이스
 * 파 일 명 : InnrLkRcveMsg.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.10.24
 * 설    명 : 대내 전문 응답 메시지 객체.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class InnrLkRcveMsg implements Serializable {

	private static final long serialVersionUID = -8726047916760633809L;

	// 신협 표준 전문 헤더
	private CommonResponseHeader commonResponseHeader;
	// 대내 응답 전문 데이터
	private InnrLkRcveDto innrLkRcveDto;

	public InnrLkRcveMsg(CommonResponseHeader commonResponseHeader, InnrLkRcveDto innrLkRcveDto) {
		this.commonResponseHeader = commonResponseHeader;
		this.innrLkRcveDto = innrLkRcveDto;
	}

	/**
	 * 대내 응답 전문 / 신협 공통 응답 헤더
	 */
	public CommonResponseHeader getCommonResponseHeader() {
		return commonResponseHeader;
	}

	/**
	 * 대내 응답 전문 / 응답 데이터
	 */
	public InnrLkRcveDto getInnrLkRcveDto() {
		return innrLkRcveDto;
	}

	@Override
	public String toString() {
		return "InnrLkRcveMsg [commonResponseHeader=" + commonResponseHeader + ", innrLkRcveDto=" + innrLkRcveDto + "]";
	}
}
