package cuin.cn.dbio.core.calendar;

import hone.core.jdbc.support.RecordSetDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

@Repository
/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 영업일 및 휴일 조회
 * 파 일 명 : CalendarDaoImpl.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.07
 * 설    명 : 영업일휴일 조회 DAO 구현체.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CalendarDaoImpl extends RecordSetDaoSupport implements CalendarDao {

	@Override
	public boolean isBizDay(String baseDate) {
		return queryForBizDay(baseDate);
	}

	@Override
	public boolean isHoliday(String baseDate) {
		return !queryForBizDay(baseDate);
	}

	@Override
	public String otherBizDay(String baseDate, int term) {

		if (term == 0) {
			throw new IllegalArgumentException("term 인자는 0(zero)보다 크거나 작은 값을 입력해야 합니다.");
		}

		MapSqlParameterSource sqlParams = new MapSqlParameterSource();
		sqlParams.addValue("cldDt", baseDate);

		String sql = String.format("SELECT cld_dt FROM (SELECT cld_dt FROM insown.cn_sm0001_it WHERE hdy_yn = 'N' AND cld_dt %s :cldDt ORDER BY cld_dt %s) WHERE rownum <= %d", (term < 0) ? "<" : ">",
				(term < 0) ? "DESC" : "ASC", Math.abs(term));

		List<String> days = queryForList(sql, sqlParams, String.class);
		if (days.size() == 0) {
			throw new IllegalArgumentException(String.format("이전/이후 영업일을 확인할 수 없는 기준 일자입니다. (%s)", baseDate));
		} else {
			return days.get(days.size() - 1);
		}
	}

	/**
	 * 기준일자가 영업일인지 여부를 반환
	 * 
	 * @param baseDate 기준일자
	 * @return 영업일인 경우 true, 아니면 false
	 * @throws 휴일/영업일 테이블에 존재하지 않는 날짜인 경우 예외 발생
	 */
	private boolean queryForBizDay(String baseDate) {
		String sql = "SELECT hdy_yn FROM insown.cn_sm0001_it WHERE cld_dt = :cldDt";

		MapSqlParameterSource sqlParams = new MapSqlParameterSource();
		sqlParams.addValue("cldDt", baseDate);

		try {
			String isHdyYn = queryForObject(sql, sqlParams, String.class);
			return "N".equals(isHdyYn);
		} catch (EmptyResultDataAccessException e) {
			throw new IllegalArgumentException(String.format("휴일/영업일 여부를 확인할 수 없는 기준일자입니다. (%s)", baseDate), e);
		}
	}

}
