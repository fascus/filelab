package cuin.cn.dbio.core.sys;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : DbioUpdateCallback.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.07.25
 * 설    명 : DBIO 일괄 등록변경 개별 레코드 업데이트 시 호출되는 콜백(callback)
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface DbioUpdateCallback<T> {
	void updateDto(T dto);
}
