package cuin.cn.dbio.core.appmsg;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 어플리케이션 메시지
 * 파 일 명 : AppMsgDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.07.11
 * 설    명 : 어플리케이션 메시지 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class AppMsgDto {
	private String bsnsMsgCtt;
	private String bsnsMsgDvCd;

	public String getBsnsMsgCtt() {
		return bsnsMsgCtt;
	}

	public void setBsnsMsgCtt(String bsnsMsgCtt) {
		this.bsnsMsgCtt = bsnsMsgCtt;
	}

	public String getBsnsMsgDvCd() {
		return bsnsMsgDvCd;
	}

	public void setBsnsMsgDvCd(String bsnsMsgDvCd) {
		this.bsnsMsgDvCd = bsnsMsgDvCd;
	}

	public String getMsgText() {
		String msgDvPrefix = null;
		if (bsnsMsgDvCd.equals("E")) {
			msgDvPrefix = "[오류]";
		} else if (bsnsMsgDvCd.equals("I")) {
			msgDvPrefix = "[정보]";
		} else if (bsnsMsgDvCd.equals("L")) {
			msgDvPrefix = "[제한]";
		} else if (bsnsMsgDvCd.equals("W")) {
			msgDvPrefix = "[경고]";
		}

		return msgDvPrefix + " " + bsnsMsgCtt;
	}
}
