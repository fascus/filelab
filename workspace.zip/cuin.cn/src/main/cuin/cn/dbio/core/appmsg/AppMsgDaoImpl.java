package cuin.cn.dbio.core.appmsg;

import hone.core.jdbc.support.RecordSetDaoSupport;

import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;

@Repository
/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 어플리케이션 메시지
 * 파 일 명 : AppMsgDaoImpl.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.07.01
 * 설    명 : 어플리케이션 메시지 획득 DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class AppMsgDaoImpl extends RecordSetDaoSupport implements AppMsgDao {

	private static final int MSG_CODE_LEN = 10;

	@Override
	public String getAppMsg(String msgCode) {

		if (msgCode == null || msgCode.length() < MSG_CODE_LEN) {
			throw new IllegalArgumentException("Invalid application message code : '" + msgCode + "'");
		}

		String sql = "SELECT bsns_msg_ctt, bsns_msg_dv_cd FROM insown.cn_ab0003_mt " + "WHERE use_yn = 'Y' AND vld_bg_dtm < sysdate AND sysdate <= vld_eot_dtm "
				+ "AND dtil_bsns_cd = :dtilBsnsCd AND bsns_msg_no = :bsnsMsgNo";

		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		namedParameters.addValue("dtilBsnsCd", msgCode.substring(0, 4));
		namedParameters.addValue("bsnsMsgNo", msgCode.substring(4));

		try {
			AppMsgDto appMsgDto = (AppMsgDto) queryForObject(sql, namedParameters, new BeanPropertyRowMapper(AppMsgDto.class));
			return appMsgDto.getMsgText();
		} catch (IncorrectResultSizeDataAccessException e) {
			throw new IllegalArgumentException("Cannot find application message. Input message code is '" + msgCode + "'", e);
		}
	}
}
