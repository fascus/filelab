/**
 * 공통 코드
 */
package cuin.cn.dbio.core.intgcd;

