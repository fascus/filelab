package cuin.cn.dbio.core.intgcd;

import java.util.List;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 코드
 * 파 일 명 : IntgCdDao.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.07.24
 * 설    명 : 공통 코드 조회 DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface IntgCdDao {

	/**
	 * 통합코드 코드 명칭 조회.
	 * 
	 * @param cdGrrpId 코드그룹ID
	 * @param cd 코드
	 * @return 코드명칭, 존재하지 않을 경우 null 반환
	 */
	String inquiryIntgCd(String cdGrpId, String cd);

	/**
	 * 통합코드 코드 정식 명칭 (유효값 정식명) 조회.
	 * 
	 * @param cdGrrpId 코드그룹ID
	 * @param cd 코드
	 * @return 코드정식명칭, 존재하지 않을 경우 null 반환
	 */
	String inquiryIntgCdRgfNm(String cdGrpId, String cd);

	/**
	 * 통합코드 목록 조회.
	 * 
	 * @param cdGrrpId 코드그룹ID
	 * @param 통합코드 DTO 목록
	 */
	List<IntgCdDto> inquiryIntgCds(String cdGrpId);

}
