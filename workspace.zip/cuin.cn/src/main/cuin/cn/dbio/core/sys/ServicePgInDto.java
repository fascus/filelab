package cuin.cn.dbio.core.sys;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : ServicePgInDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.23
 * 설    명 : 페이지 입력 DTO 인터페이스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface ServicePgInDto extends ServiceInDto {

	/**
	 * 페이지 번호
	 */
	int getPageNo();
}
