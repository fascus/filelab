package cuin.cn.dbio.core.calendar;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 영업일 및 휴일 조회
 * 파 일 명 : CalendarDao.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.07
 * 설    명 : 영업일휴일 조회 DAO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface CalendarDao {

	/**
	 * 영업일 여부
	 * 
	 * @param baseDate YYYYMMDD 형식의 기준 일자
	 */
	boolean isBizDay(String baseDate);

	/**
	 * 휴일 여부
	 * 
	 * @param baseDate YYYYMMDD 형식의 기준 일자
	 */
	boolean isHoliday(String baseDate);

	/**
	 * 이전/이후 영업얼 (입력 = 기준일자, plug/minus n일, 출력 = 이전 혹은 다음 영업일, date type)
	 * 
	 * @param baseDate YYYYMMDD 형식의 기준 일자
	 * @param term (+/-) n 일
	 */
	String otherBizDay(String baseDate, int term);
}
