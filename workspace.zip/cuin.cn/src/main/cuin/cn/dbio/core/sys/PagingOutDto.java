package cuin.cn.dbio.core.sys;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : PagingOutDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.23
 * 설    명 : 페이지 출력 DTO 인터페이스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface PagingOutDto {

	/**
	 * 연속유무 설정
	 * 
	 * @param isCont 다음 페이지가 존재하면 1, 아니면 0
	 */
	void setIscont(int isCont);

	/**
	 * 다음 페이지 번호 설정
	 * 
	 * @param pageNo 다음 페이지 번호 (존재하지 않을 경우, zero 설정)
	 */
	void setPageNo(int pageNo);
}
