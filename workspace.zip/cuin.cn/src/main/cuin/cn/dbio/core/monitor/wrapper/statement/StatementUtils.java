package cuin.cn.dbio.core.monitor.wrapper.statement;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import oracle.jdbc.OracleConnection;

import org.apache.commons.dbcp.DelegatingConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.cn.dbio.core.monitor.wrapper.conn.ConnectionWrapper;
import cuin.cn.service.ServiceContext;
import cuin.cn.service.ServiceContext.ContextSysAttr;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DB 모니터링
 * 파 일 명 : StatementUtils.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.11.12
 * 설    명 : 오라클 모듈/액션 정보 설정
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class StatementUtils {

	private static final Logger logger = LoggerFactory.getLogger(StatementUtils.class);
	private static final String HQML_ID_PATTERN = "[/][\\*]\\s+(cuin.).+[\\*][/]";
	private static final int MAX_ACTION_LENGTH = 32;

	static void logSql(String sql, long elapsedTime) {
		Logger logger = LoggerFactory.getLogger(hone.core.jdbc.monitor.JdbcMonitor.Logger.Sql.getName());
		if (logger.isDebugEnabled()) {
			logger.debug(String.format("Elapsedtime: %d, Sql: %s", new Object[] { Long.valueOf(elapsedTime), sql }));
		}
	}

	public static void accumulateQueryTime(long elapsedTime) {
		Long queryElapsedTime = (Long) ServiceContext.getSysAttr(ContextSysAttr.QUERY_ELPASED_TIME);
		if (queryElapsedTime == null) {
			queryElapsedTime = Long.valueOf(elapsedTime);
		} else {
			queryElapsedTime = queryElapsedTime + elapsedTime;
		}
		ServiceContext.setSysAttr(ContextSysAttr.QUERY_ELPASED_TIME, queryElapsedTime);
	}

	static void updateE2eMetrics(String sql, Connection connection) {
		String hqmlId = getHqmlId(sql);
		String scrId = (String) ServiceContext.getSysAttr(ContextSysAttr.SCREEN_ID);
		String txCode = (String) ServiceContext.getSysAttr(ContextSysAttr.TRANSACTION_CODE);
		String userId = ServiceContext.getUserId();

		if (logger.isTraceEnabled()) {
			logger.trace("Set ORACLE module as : " + scrId + txCode);
			logger.trace("Set ORACLE action as : " + hqmlId);
			logger.trace("Set ORACLE clientid as : " + userId);
		}

		String e2eMetrics[] = new String[OracleConnection.END_TO_END_STATE_INDEX_MAX];
		e2eMetrics[OracleConnection.END_TO_END_ACTION_INDEX] = hqmlId;
		e2eMetrics[OracleConnection.END_TO_END_MODULE_INDEX] = txCode;
		e2eMetrics[OracleConnection.END_TO_END_CLIENTID_INDEX] = userId;
		try {
			OracleConnection oracleConnection = null;
			if (connection instanceof ConnectionWrapper) {
				connection = ((ConnectionWrapper) connection).getOriginalConn();
			}
			if (connection instanceof DelegatingConnection) {
				oracleConnection = (OracleConnection) ((DelegatingConnection) connection).getInnermostDelegate();
			}
			if (oracleConnection != null) {
				oracleConnection.setEndToEndMetrics(e2eMetrics, (short) 0);
			} else {
				logger.error("It's not an oracle connection!");
			}
		} catch (SQLException e) {
			logger.error(e.getMessage(), e);
		}
	}

	private static String getHqmlId(String sql) {

		String hqmlId = extractHqmlId(sql);
		return cutOffHqmlId(hqmlId);
	}

	private static String extractHqmlId(String sql) {
		Pattern hqmlIdPatternRegEx = null;

		if (hqmlIdPatternRegEx == null) {
			hqmlIdPatternRegEx = Pattern.compile(HQML_ID_PATTERN);
		}
		Matcher matcher = hqmlIdPatternRegEx.matcher(sql);
		if (matcher.find()) {
			String hqmlIdWithCommentMark = matcher.group();
			return hqmlIdWithCommentMark.substring(2, hqmlIdWithCommentMark.length() - 2).trim();
		} else {
			return "UNKNOWN_HQML";
		}

//		StackTraceElement element[] = getDaoImplStackTraceElement();
//
//		return null;
	}

	private static StackTraceElement[] getDaoImplStackTraceElement() {
		StackTraceElement[] elements = Thread.currentThread().getStackTrace();

		for(StackTraceElement element : elements) {

		}

		return null;

	}

	private static String cutOffHqmlId(String hqmlId) {
		if (hqmlId == null || hqmlId.length() < MAX_ACTION_LENGTH) {
			return hqmlId;
		} else {
			int idx = 0;
			String[] pkgNames = hqmlId.split("\\.");
			do {
				pkgNames[idx] = String.valueOf(pkgNames[idx].charAt(0));
				idx++;
			} while (calcHqmlIdLength(pkgNames) > MAX_ACTION_LENGTH);
			return bindPkgs(pkgNames);
		}
	}

	private static int calcHqmlIdLength(String[] pkgNames) {
		int hqmlIdLength = pkgNames.length - 1;
		for (String pkgName : pkgNames) {
			hqmlIdLength += pkgName.length();
		}
		return hqmlIdLength;
	}

	private static String bindPkgs(String[] pkgNames) {
		StringBuilder sb = new StringBuilder();
		for (int idx = 0; idx < pkgNames.length; idx++) {
			sb.append(pkgNames[idx]);
			if (idx < pkgNames.length - 1) {
				sb.append('.');
			}
		}
		return sb.toString();
	}
}
