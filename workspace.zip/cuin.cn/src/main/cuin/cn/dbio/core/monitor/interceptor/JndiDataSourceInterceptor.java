package cuin.cn.dbio.core.monitor.interceptor;

import hone.common.util.StringUtils;
import hone.core.jdbc.monitor.JdbcMonitor;

import java.sql.Connection;
import java.sql.SQLException;

import jeus.jdbc.common.JeusConnection;
import jeus.jdbc.common.JeusConnectionImpl;
import oracle.jdbc.OracleConnection;

import org.apache.commons.dbcp.DelegatingConnection;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.cn.service.ServiceContext;
import cuin.cn.service.ServiceContext.ContextSysAttr;

@Aspect
public class JndiDataSourceInterceptor  {
	private static final Logger logger = LoggerFactory.getLogger(JndiDataSourceInterceptor.class);

	public JndiDataSourceInterceptor() {
		logger.info("DatasourceInterceptor bean has been created.");
	}


    @Before("execution(* execute*(..))")
	public void before(JoinPoint joinPoint) throws Throwable {

    	logger.error("BEFORE in " + joinPoint.getTarget().getClass().getName());
    }


//  Around("execution(public * java.sql.PreparedStatement.execute*(..))")


    @Around("execution(* execute*(..))")
	public Object around(ProceedingJoinPoint joinPoint) throws Throwable {

    	logger.error("INTERCEPTOR");
    	Object returnObj = joinPoint.proceed();

		if (!JdbcMonitor.isMonitorEnabled()) {
			return returnObj;
		}

		if(returnObj != null && JeusConnection.class.isAssignableFrom(returnObj.getClass())) {
//			logger.debug("Jeus connection caught");
			long elapsedTime = System.currentTimeMillis();
//			StatementUtils.accumulateQueryTime(elapsedTime);
			updateE2eMetrics((Connection)((JeusConnectionImpl)returnObj).getActualHandle());
		} else {
			if (returnObj != null && Connection.class.isAssignableFrom(returnObj.getClass())) {
				logger.debug("Pure connection caught");
				long elapsedTime = System.currentTimeMillis();
//				StatementUtils.accumulateQueryTime(elapsedTime);
				updateE2eMetrics((Connection)returnObj);
//				return new ConnectionWrapper((Connection) returnObj);
			}
		}



		return returnObj;
	}


	private void updateE2eMetrics(Connection connection) {
		String hqmlId = extractHqmlId();
//		logger.info("HQML-ID : " + hqmlId);
		String scrId = StringUtils.nullToEmpty((String) ServiceContext.getSysAttr(ContextSysAttr.SCREEN_ID));
		String txCode = StringUtils.nullToEmpty((String) ServiceContext.getSysAttr(ContextSysAttr.TRANSACTION_CODE));
		String userId = StringUtils.nullToEmpty(ServiceContext.getUserId());

		if(txCode.equals("HEALTHCHK000")) {
			return;
		}
		if(userId.isEmpty()) {
			userId = "UNKNOWN_USER";
		}

//		if (logger.isTraceEnabled()) {
			logger.debug("Set ORACLE module as : " + scrId + txCode);
			logger.debug("Set ORACLE action as : " + hqmlId);
			logger.debug("Set ORACLE clientid as : " + userId);
//		}

		String e2eMetrics[] = new String[OracleConnection.END_TO_END_STATE_INDEX_MAX];
		e2eMetrics[OracleConnection.END_TO_END_ACTION_INDEX] = hqmlId;
		e2eMetrics[OracleConnection.END_TO_END_MODULE_INDEX] = txCode;
		e2eMetrics[OracleConnection.END_TO_END_CLIENTID_INDEX] = userId;
		try {
			OracleConnection oracleConnection = null;
//			if (connection instanceof Connection) {
//				connection = (connection).getOriginalConn();
//			}
			if (connection instanceof DelegatingConnection) {
				oracleConnection = (OracleConnection) ((DelegatingConnection) connection).getInnermostDelegate();
			}
			if (oracleConnection != null) {
				oracleConnection.setEndToEndMetrics(e2eMetrics, (short) 0);
			} else {
				logger.error("It's not an oracle connection!");
			}
		} catch (SQLException e) {
			logger.error(e.getMessage(), e);
		}
	}

	private String extractHqmlId() {
		StackTraceElement[] elements = Thread.currentThread().getStackTrace();
		String hqmlId = "UNKNOWN_SQL";

		for(StackTraceElement element : elements) {
//			logger.debug(element.getClassName());
			if(element.getClassName().indexOf("Dao") > -1) {
				hqmlId = element.getClassName().substring(element.getClassName().lastIndexOf(".") + 1) + "." + element.getMethodName();
				if(hqmlId.length() > 40) {
					hqmlId = hqmlId.substring(hqmlId.length() - 40);
				}
				break;
			}
		}

		return hqmlId;
	}


}
