package cuin.cn.dbio.core.sys;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : PagingInDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.23
 * 설    명 : 페이지 조회 입력 DTO 인터페이스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface PagingInDto {

	/**
	 * 페이지 당 레코드 출력 건수 설정
	 */
	void setRecPerPage(int recPerPage);

	/**
	 * 쿼리 실행 결과에서 반환할 레코드들의 시작 행(row) 번호 설정
	 */
	void setBeginRowNum(int beginRowNum);

	/**
	 * 쿼리 실행 결과에서 반환할 레코드들의 마지막 행(row) 번호 설정
	 */
	void setEndRowNum(int endRowNum);
}
