package cuin.cn.dbio.core.sys;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : EntityDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.23
 * 설    명 : 엔티티 DTO 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface EntityDto extends ServiceInDto {
	/**
	 * @return 기본 키 컬럼 및 값 반환
	 */
	String getPKValues();
}
