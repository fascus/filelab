package cuin.cn.dbio.core.timestamp;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : TimestampDao.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.07
 * 설    명 : 데이터베이스 타임스탬프 획득 DAO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface TimestampDao {

	/**
	 * 데이터베이스의 현재 날짜와 시간 반환
	 * 
	 * @return YYYYMMDDHH24MISS 형식의 날짜와 시간 반환
	 */
	String getTimestamp();

}
