package cuin.cn.dbio.core.intgcd;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 코드
 * 파 일 명 : IntgCdDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.07.26
 * 설    명 : 통합코드 정보 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class IntgCdDto {
	// 통합코드
	private String intgCd;
	// 상위 통합코드
	private String hgrIntgCd;
	// 통합코드 명칭
	private String intgCdNm;
	// 통합코드 정식명
	private String intgCdEngNm;
	// 통합코드 설명
	private String intgCdDscr;
	// 통합코드 화면순서
	private int intgCdScrnSqc;

	/**
	 * @return 통합코드 반환
	 */
	public String getIntgCd() {
		return intgCd;
	}

	public void setIntgCd(String intgCd) {
		this.intgCd = intgCd;
	}

	/**
	 * @return 상위통합코드 반환
	 */
	public String getHgrIntgCd() {
		return hgrIntgCd;
	}

	public void setHgrIntgCd(String hgrIntgCd) {
		this.hgrIntgCd = hgrIntgCd;
	}

	/**
	 * @return 통합코드 명칭 반환
	 */
	public String getIntgCdNm() {
		return intgCdNm;
	}

	public void setIntgCdNm(String intgCdNm) {
		this.intgCdNm = intgCdNm;
	}

	/**
	 * @return 통합코드 정식명칭 반환
	 */
	public String getIntgCdEngNm() {
		return intgCdEngNm;
	}

	public void setIntgCdEngNm(String intgCdEngNm) {
		this.intgCdEngNm = intgCdEngNm;
	}

	/**
	 * @return 통합코드 설명 반환
	 */
	public String getIntgCdDscr() {
		return intgCdDscr;
	}

	public void setIntgCdDscr(String intgCdDscr) {
		this.intgCdDscr = intgCdDscr;
	}

	/**
	 * @return 통합코드 화면순서 반환
	 */
	public int getIntgCdScrnSqc() {
		return intgCdScrnSqc;
	}

	public void setIntgCdScrnSqc(int intgCdScrnSqc) {
		this.intgCdScrnSqc = intgCdScrnSqc;
	}

	@Override
	public String toString() {
		return "IntgCdDto [intgCd=" + intgCd + ", hgrIntgCd=" + hgrIntgCd + ", intgCdNm=" + intgCdNm + ", intgCdEngNm=" + intgCdEngNm + ", intgCdDscr=" + intgCdDscr + ", intgCdScrnSqc="
				+ intgCdScrnSqc + "]";
	}

}
