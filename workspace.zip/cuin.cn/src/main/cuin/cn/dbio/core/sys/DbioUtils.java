package cuin.cn.dbio.core.sys;

import hone.common.util.DateUtils;

import java.sql.Timestamp;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.cn.service.ServiceContext;
import cuin.cn.service.ServiceContext.ContextSysAttr;
import cuin.cn.util.BeanUtils;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : DbioUtils.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.27
 * 설    명 : 신협공제 DBIO 유틸리티.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class DbioUtils {

	private static final Logger logger = LoggerFactory.getLogger(DbioUtils.class);

	// '적용 시작일시' 필드 명칭
	public static final String APPLY_BEGIN_DATETIME_FIELD = "aplBgDtm";
	// '적용 종료일시' 필드 명칭
	public static final String APPLY_END_DATETIME_FIELD = "aplEotDtm";

	// '사용 여부' 필드 명칭
	private static final String USE_YN_FIELD = "useYn";
	// '프로그램 ID' 필드 명칭
	private static final String PROGRAM_ID_FIELD = "prgId";
	// '생성 일시' 필드 명칭
	private static final String CREATION_DATETIME_FIELD = "crtnDtm";
	// '생성자 번호' 필드 명칭
	private static final String CREATOR_FIELD = "cnrrNo";
	// '수정 일시' 필드 명칭
	private static final String UPDATE_DATETIME_FIELD = "uptDtm";
	// '수정자 번호' 필드 명칭
	private static final String UPDATER_FIELD = "ameNo";

	/**
	 * 테이블 DTO 생성. 대상(target) 클래스 인스턴스를 생성한 후, 원본(source) 객체의 속성(member
	 * variable)을 대상 인스턴스로 매핑(mapping) 하고, 시스템 속성을 설정한 후 반환한다.
	 * 
	 * @param <C> 테이블 DTO 클래스
	 * @param sourceBean 입력 빈(bean)
	 * @param targetClass 테이블 DTO 클래스
	 * @return 테이블 DTO
	 */
	public static <C> C createTableDto(Object sourceBean, Class<C> targetClass) {
		C tableDto = BeanUtils.toBean(sourceBean, targetClass);
		setSysProperties(tableDto);

		return tableDto;
	}

	/**
	 * DTO 내에 시스템 속성 설정 (신규 생성).
	 * 
	 * @param newRecordDto 신규 레코드 DTO
	 */
	public static void setSysProperties(Object newRecordDto) {

		// 사용 유무
		BeanUtils.setProperty(newRecordDto, USE_YN_FIELD, "Y");

		// 등록 및 수정 일자
		Timestamp now = (Timestamp) ServiceContext.getSysAttr(ContextSysAttr.TX_TIMESTAMP);
		BeanUtils.setPropertyIfNull(newRecordDto, CREATION_DATETIME_FIELD, now);
		BeanUtils.setPropertyIfNull(newRecordDto, UPDATE_DATETIME_FIELD, now);

		// 프로그램 ID, 생성자 및 수정자 ID
		String prgId = getPrgId();
		String employeeNo = getUserId();
		if (prgId != null && employeeNo != null) {
			BeanUtils.setPropertyIfNull(newRecordDto, PROGRAM_ID_FIELD, prgId);
			BeanUtils.setPropertyIfNull(newRecordDto, CREATOR_FIELD, employeeNo);
			BeanUtils.setPropertyIfNull(newRecordDto, UPDATER_FIELD, employeeNo);
		} else {
			logger.warn("Cannot fetch program ID (transaction ID) or creator(user) ID from context");
		}
	}

	/**
	 * DTO 내에 시스템 속성 설정 (갱신), 과거 레코드에서 원본 시스템 속성을 복사.
	 * 
	 * @param newRecordDto 신규 레코드 DTO
	 * @param oldRecordDto 과거 레코드 DTO
	 */
	public static void setSysProperties(Object newRecordDto, Object oldRecordDto) {

		// 사용 유무
		BeanUtils.setProperty(newRecordDto, USE_YN_FIELD, "Y");

		// 프로그램 ID 및 수정자 ID
		String prgId = getPrgId();
		String userId = getUserId();
		if (prgId != null && userId != null) {
			BeanUtils.setPropertyIfNull(newRecordDto, PROGRAM_ID_FIELD, prgId);
			BeanUtils.setPropertyIfNull(newRecordDto, UPDATER_FIELD, userId);
		} else {
			logger.warn("Cannot fetch program ID (transaction ID) or update(user) ID from context");
		}

		// 최초 생성일시 및 생성자
		Timestamp crtnDate = (Timestamp) BeanUtils.getProperty(oldRecordDto, CREATION_DATETIME_FIELD);
		String cnrrNo = (String) BeanUtils.getProperty(oldRecordDto, CREATOR_FIELD);
		BeanUtils.setPropertyIfNull(newRecordDto, CREATION_DATETIME_FIELD, crtnDate);
		BeanUtils.setPropertyIfNull(newRecordDto, CREATOR_FIELD, cnrrNo);

		// 수정일시 (타임스탬프)
		Timestamp now = (Timestamp) ServiceContext.getSysAttr(ContextSysAttr.TX_TIMESTAMP);
		BeanUtils.setPropertyIfNull(newRecordDto, UPDATE_DATETIME_FIELD, now);
	}

	/*
	 * @return 사원번호 반환
	 */
	private static String getUserId() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.USER_ID);
	}

	/*
	 * @return 프로그램 ID (채널 ID + 거래 코드) 반환
	 */
	private static String getPrgId() {
		return (String) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.CHANNEL_ID) + ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.TRANSACTION_CODE);
	}

	/**
	 * 기본 적용기간 설정.
	 * 
	 * 적용 시작일자는 현재 시점, 적용 종료일자는 기본 만료일자(9999년 12월 31일).
	 */
	public static void setDefaultApplyTerm(Object recordDto) {
		BeanUtils.setProperty(recordDto, APPLY_BEGIN_DATETIME_FIELD, ServiceContext.getSysAttr(ContextSysAttr.TX_TIMESTAMP));
		BeanUtils.setProperty(recordDto, APPLY_END_DATETIME_FIELD, DateUtils.getEndOfTime());
	}

	/**
	 * 선분이력 업데이트 (양편 넣기).
	 * 
	 * @param oldRecordDto 선분이력 업데이트 대상 DTO
	 */
	public static void setCloseSegmentHistory(Object oldRecordDto) {
		Timestamp aplEotDtm = (Timestamp) BeanUtils.getProperty(oldRecordDto, APPLY_END_DATETIME_FIELD);
		if (aplEotDtm == null) {
			BeanUtils.setProperty(oldRecordDto, APPLY_BEGIN_DATETIME_FIELD, ServiceContext.getSysAttr(ContextSysAttr.TX_TIMESTAMP));
		}
	}

	/**
	 * 선분이력 속성 설정.
	 * 
	 * @param newRecordDto 신규 레코드 DTO
	 * @param oldRecordDto 과거 레코드 DTO
	 */
	public static void setOpenSegmentHistory(Object newRecordDto, Object oldRecordDto) {
		Timestamp aplBgDtm = (Timestamp) BeanUtils.getProperty(oldRecordDto, APPLY_END_DATETIME_FIELD);
		if (aplBgDtm == null) {
			aplBgDtm = (Timestamp) ServiceContext.getSysAttr(ContextSysAttr.TX_TIMESTAMP);
		}
	}

	/**
	 * 페이지 조회 입력 속성 설정.
	 * 
	 * @param pageNo 페이지 번호
	 * @param recPerPage 페이지 당 출력 레코드 수
	 * @param pgInDto 페이지 조회 입력 DTO
	 */
	public static void setPagingProperties(int pageNo, int recPerPage, PagingInDto pgInDto) {

		if (pageNo < 1) {
			throw new IllegalArgumentException("Invalid page number [" + pageNo + "], must greater than zero.");
		}

		if (recPerPage < 1) {
			throw new IllegalArgumentException("Invalid record count [" + recPerPage + "], must greater than zero.");
		}

		// 페이지 당 출력 레코드 수 설정
		pgInDto.setRecPerPage(recPerPage);

		// 시작 행 번호 설정
		int beginRowNum = (pageNo - 1) * recPerPage;
		pgInDto.setBeginRowNum(beginRowNum);

		// 마지막 행 번호 설정 (다음 페이지 여부 확인을 위해 레코드 하나를 추가)
		int endRowNum = pageNo * recPerPage + 1;
		pgInDto.setEndRowNum(endRowNum);
	}

	/**
	 * 페이지 쿼리 조회 결과 검토 및 연속 조회 설정.
	 * 
	 * @param recPerPage 페이지 당 출력 건수
	 * @param resultList 쿼리 수행 결과 레코드 목록
	 * @param curPageNo 현재 페이지 번호
	 * @return 연속조회 여부 플래그 및 페이지 레코드 목록을 포함한 '페이지 출력 DTO' 반환
	 */
	@SuppressWarnings("rawtypes")
	public static List filterPaging(int recPerPage, int curPageNo, List resultList, PagingOutDto pagingOutDto) {
		if (logger.isDebugEnabled()) {
			logger.debug(String.format("RecPerPage = %d, FetchCount = %d", recPerPage, resultList.size()));
		}

		// 출력 DTO 내에 연속 조회 여부 설정 (다음 페이지 데이터가 존재하면 true, 아니면 false)
		boolean isCont = (resultList != null && resultList.size() > recPerPage);
		pagingOutDto.setIscont(isCont ? 1 : 0);

		// 출력 DTO 내에 다음 페이지 번호 설정
		pagingOutDto.setPageNo(isCont ? curPageNo + 1 : curPageNo);

		// 다음 페이지의 첫번째 레코드를 제외한 레코드 목록 반환 (subList = 현재 페이지 레코드 목록)
		List subList = (isCont) ? resultList.subList(0, resultList.size() - 1) : resultList;

		return subList;
	}

	/**
	 * 응답 데이터 목록 검토 및 연속 조회 설정.
	 */
	public static List splitPaging(int recPerPage, int curPageNo, List resultList, PagingOutDto pagingOutDto) {
		if (logger.isDebugEnabled()) {
			logger.debug(String.format("RecPerPage = %d, ListSize = %d", recPerPage, resultList.size()));
		}

		// 출력 DTO 내에 연속 조회 여부 설정 (다음 페이지 데이터가 존재하면 true, 아니면 false)
		boolean isCont = (resultList != null && resultList.size() > recPerPage * curPageNo);
		pagingOutDto.setIscont(isCont ? 1 : 0);

		// 출력 DTO 내에 다음 페이지 번호 설정
		pagingOutDto.setPageNo(isCont ? curPageNo + 1 : curPageNo);

		// 다음 페이지의 첫번째 레코드를 제외한 레코드 목록 반환 (subList = 현재 페이지 레코드 목록)
		int fromIdx = recPerPage * (curPageNo - 1);
		int toIdx = recPerPage * curPageNo;
		if (toIdx > resultList.size()) {
			toIdx = resultList.size();
		}
		return resultList.subList(fromIdx, toIdx);
	}

	/**
	 * 이력 DTO 생성.
	 * 
	 * @param <C> 이력 DTO 클래스
	 * @param masterDto 마스터 레코드 DTO
	 * @param historyDtoClass 이력 DTO 클래스
	 * @return 이력 DTO
	 */
	public static <C> C createHistoryDto(Object masterDto, Class<C> historyDtoClass) {
		C historyDto = BeanUtils.toBean(masterDto, historyDtoClass);
		// '적용 시작 일시'를 이전 변경(혹은 최초 생성) 시간으로 설정
		BeanUtils.setProperty(historyDto, APPLY_BEGIN_DATETIME_FIELD, BeanUtils.getProperty(masterDto, APPLY_BEGIN_DATETIME_FIELD));
		// '적용 종료 일시'를 현재로 설정
		Timestamp now = (Timestamp) ServiceContext.getSysAttr(ContextSysAttr.TX_TIMESTAMP);
		BeanUtils.setProperty(historyDto, APPLY_END_DATETIME_FIELD, now);

		return historyDto;
	}

}
