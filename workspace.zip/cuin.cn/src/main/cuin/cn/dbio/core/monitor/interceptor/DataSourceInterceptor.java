package cuin.cn.dbio.core.monitor.interceptor;

import hone.core.jdbc.monitor.JdbcMonitor;

import java.sql.Connection;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.cn.dbio.core.monitor.wrapper.conn.ConnectionWrapper;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DB 모니터링
 * 파 일 명 : DataSourceInterceptor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.11.12
 * 설    명 : 데이터 소스 인터셉터
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class DataSourceInterceptor implements MethodInterceptor {
	private static final Logger logger = LoggerFactory.getLogger(DataSourceInterceptor.class);

	public DataSourceInterceptor() {
		logger.info("DatasourceInterceptor bean has been created.");
	}

	public Object invoke(MethodInvocation invocation) throws Throwable {
		logger.info("DatasourceInterceptor invoke..");
		Object returnObj = invocation.proceed();

		if (!JdbcMonitor.isMonitorEnabled()) {
			return returnObj;
		}

		logger.info("DatasourceInterceptor caught object [" + returnObj.getClass().getName() + "]");
		if (returnObj != null && Connection.class.isAssignableFrom(returnObj.getClass()) && !(ConnectionWrapper.class.isAssignableFrom(returnObj.getClass()))) {
			return new ConnectionWrapper((Connection) returnObj);
		}

		return returnObj;
	}
}
