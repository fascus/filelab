package cuin.cn.dbio.core.timestamp;

import hone.core.jdbc.support.RecordSetDaoSupport;

import org.springframework.stereotype.Repository;

@Repository
/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : TimestampDaoImpl.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.07
 * 설    명 : 데이터베이스 타임스탬프 DAO 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class TimestampDaoImpl extends RecordSetDaoSupport implements TimestampDao {

	@Override
	public String getTimestamp() {
		String sql = "SELECT TO_CHAR(sysdate,'YYYYMMDDHH24MISS') FROM dual";
		return queryForObject(sql, null, String.class);
	}

}
