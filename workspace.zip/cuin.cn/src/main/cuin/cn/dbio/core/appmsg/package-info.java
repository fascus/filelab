/**
 * 어플리케이션 메시지
 */
package cuin.cn.dbio.core.appmsg;