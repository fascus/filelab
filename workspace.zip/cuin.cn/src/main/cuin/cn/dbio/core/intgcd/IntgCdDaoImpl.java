package cuin.cn.dbio.core.intgcd;

import hone.common.util.StringUtils;
import hone.core.jdbc.support.RecordSetDaoSupport;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import cuin.cn.dbio.core.spring.jdbc.BeanPropertyRowMapper;

@Repository
/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 코드
 * 파 일 명 : IntgCdDaoImpl.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.07.24
 * 설    명 : 통합코드 조회 DAO 구현체.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class IntgCdDaoImpl extends RecordSetDaoSupport implements IntgCdDao {

	@Override
	public String inquiryIntgCd(String cdGrpId, String cd) {

		validateParam(cdGrpId, cd);

		String cdNm = null;
		try {
			cdNm = queryForObject("SELECT intg_cd_nm FROM insown.cn_im0002_mt WHERE intg_cd_grp_id = :intgCdGrpId AND intg_cd = :intgCd", makeParamSource(cdGrpId, cd), String.class);
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
		return cdNm;
	}

	@Override
	public String inquiryIntgCdRgfNm(String cdGrpId, String cd) {
		validateParam(cdGrpId, cd);

		String cdRgfNm = null;
		try {
			cdRgfNm = queryForObject("SELECT intg_cd_eng_nm FROM insown.cn_im0002_mt WHERE intg_cd_grp_id = :intgCdGrpId AND intg_cd = :intgCd", makeParamSource(cdGrpId, cd), String.class);
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
		return cdRgfNm;
	}

	@Override
	public List<IntgCdDto> inquiryIntgCds(String cdGrpId) {
		if (StringUtils.isEmpty(cdGrpId)) {
			throw new IllegalArgumentException("'cdGrpId' is missing. 통합 코드 그룹 ID가 null 혹은 빈 문자열 입니다.");
		}

		MapSqlParameterSource sqlParamSrc = new MapSqlParameterSource();
		sqlParamSrc.addValue("intgCdGrpId", cdGrpId);

		return queryForList("SELECT intg_cd, hgr_intg_cd, intg_cd_nm, intg_cd_eng_nm, intg_cd_dscr, intg_cd_scrn_sqc FROM insown.cn_im0002_mt WHERE intg_cd_grp_id = :intgCdGrpId ORDER BY intg_cd",
				sqlParamSrc, new BeanPropertyRowMapper<IntgCdDto>(IntgCdDto.class));
	}

	private void validateParam(String cdGrpId, String cd) {
		if (StringUtils.isEmpty(cdGrpId)) {
			throw new IllegalArgumentException("'cdGrpId' is missing. 통합 코드 그룹 ID가 null 혹은 빈 문자열 입니다.");
		} else if (StringUtils.isEmpty(cd)) {
			throw new IllegalArgumentException("'cd' is missing. 통합 코드가 null 혹은 빈 문자열 입니다.");
		}
	}

	private MapSqlParameterSource makeParamSource(String cdGrpId, String cd) {
		MapSqlParameterSource sqlParams = new MapSqlParameterSource();
		sqlParams.addValue("intgCdGrpId", cdGrpId);
		sqlParams.addValue("intgCd", cd);
		return sqlParams;
	}

}
