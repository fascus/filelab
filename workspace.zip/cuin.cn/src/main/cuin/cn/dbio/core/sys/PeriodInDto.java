package cuin.cn.dbio.core.sys;

import java.sql.Timestamp;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : DBIO
 * 파 일 명 : PeriodInDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.07.20
 * 설    명 : 이력 기간 검색 입력 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class PeriodInDto {
	/**
	 * 기준 시작 일시
	 */
	private Timestamp baseBgDtm;
	/**
	 * 기준 종료 일시
	 */
	private Timestamp baseEotDtm;

	public Timestamp getBaseBgDtm() {
		return baseBgDtm;
	}

	public void setBaseBgDtm(Timestamp baseBgDtm) {
		this.baseBgDtm = baseBgDtm;
	}

	public Timestamp getBaseEotDtm() {
		return baseEotDtm;
	}

	public void setBaseEotDtm(Timestamp baseEotDtm) {
		this.baseEotDtm = baseEotDtm;
	}
}
