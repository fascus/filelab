package cuin.cn.exception;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 예외 처리
 * 파 일 명 : CuinRecordExistsException.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.08
 * 설    명 : 이미 존재하는 데이터를 데이터베이스에 등록하려고 시도할 경우 발생하는 예외.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CuinRecordExistsException extends CuinException {

	private static final long serialVersionUID = 3225296354390729603L;
	// 데이터 중복 오류 : '이미 등록된 자료입니다.'
	private static final String ALEADY_EXIST_ERROR = "INS05011";

	/**
	 * 예외 생성자, null 메시지.
	 */
	public CuinRecordExistsException() {
		super(ALEADY_EXIST_ERROR, "중복된 자료가 존재하므로 등록할 수 없습니다.");
	}

	/**
	 * 예외 생성자, 오류 메시지 포함.
	 * 
	 * @param message 오류 메시지
	 */
	public CuinRecordExistsException(String message) {
		super(ALEADY_EXIST_ERROR, message, null);
	}

}
