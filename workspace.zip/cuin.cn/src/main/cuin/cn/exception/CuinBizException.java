package cuin.cn.exception;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 예외 처리
 * 파 일 명 : CuinBizException.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.13
 * 설    명 : 신협공제 업무 예외.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CuinBizException extends RuntimeException {

	private static final long serialVersionUID = -2067065642004362200L;

	/**
	 * 신협공제 업무 예외 생성자
	 * 
	 * @param message 오류 메시지
	 */
	public CuinBizException(String message) {
		super(message);
	}

	/**
	 * 신협공제 업무 예외 생성자
	 * 
	 * @param message 오류 메시지
	 * @param cause 원인 예외 객체
	 */
	public CuinBizException(String message, Throwable cause) {
		super(message, cause);
	}
}
