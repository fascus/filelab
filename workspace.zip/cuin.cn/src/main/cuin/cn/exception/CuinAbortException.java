package cuin.cn.exception;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 예외 처리
 * 파 일 명 : CuinAbortException.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.10.31
 * 설    명 : 온라인 서비스 중단 예외. (정상 종료 처리)
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CuinAbortException extends RuntimeException {
	private static final long serialVersionUID = -3320572188758742764L;
}
