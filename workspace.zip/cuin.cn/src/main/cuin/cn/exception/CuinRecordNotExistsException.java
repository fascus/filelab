package cuin.cn.exception;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 예외 처리
 * 파 일 명 : CuinRecordNotExistsException.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.08
 * 설    명 : 데이터베이스 레코드를 찾지 못하는 경우 발생하는 예외.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CuinRecordNotExistsException extends CuinException {
	private static final long serialVersionUID = 6622193574387394108L;
	// 데이터 오류 : '해당자료가 존재하지 않습니다.'
	private static final String NOT_EXISTS_ERROR = "INS04007";

	public CuinRecordNotExistsException() {
		super(NOT_EXISTS_ERROR, "데이터베이스 조회 오류입니다.");
	}

	public CuinRecordNotExistsException(String message) {
		super(NOT_EXISTS_ERROR, message, null);
	}
}
