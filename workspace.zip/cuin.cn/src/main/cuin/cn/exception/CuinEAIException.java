package cuin.cn.exception;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 예외 처리
 * 파 일 명 : CuinEAIException.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.06.04
 * 설    명 : EAI 에러
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CuinEAIException extends CuinException {
	private static final long serialVersionUID = 6305909588043016058L;

	public CuinEAIException(Throwable cause) {
		super(DEFAULT_SYS_ERR_CODE, "EAI error", cause);
	}

	public CuinEAIException(String message) {
		super(DEFAULT_SYS_ERR_CODE, message);
	}

	public CuinEAIException(String message, Throwable cause) {
		super(DEFAULT_SYS_ERR_CODE, message, cause);
	}
}
