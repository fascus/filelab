package cuin.cn.exception;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 공통 예외 처리
 * 파 일 명 : CuinException.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.07
 * 설    명 : 신협공제 기본 예외 클래스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CuinException extends RuntimeException {

	/**
	 * 기본 시스템 오류 코드 (정상적으로 수행되지 않았습니다.)
	 */
	public static final String DEFAULT_SYS_ERR_CODE = "INS03034";

	private static final long serialVersionUID = 7754447948633071021L;

	// 시스템 오류 코드
	private String sysErrCode;

	/**
	 * 예외 생성자
	 * 
	 * @param sysErrCode 시스템 오류 코드
	 */
	public CuinException(String sysErrCode) {
		this.sysErrCode = sysErrCode;
	}

	/**
	 * 예외 생성자
	 * 
	 * @param sysErrCode 시스템 오류 코드
	 * @param errMsg 오류 메시지
	 */
	public CuinException(String sysErrCode, String errMsg) {
		super(errMsg);
		this.sysErrCode = sysErrCode;
	}

	/**
	 * 예외 생성자
	 * 
	 * @param errMsg 오류 메시지
	 * @param cause 오류 원인 예외
	 */
	public CuinException(String errMsg, Throwable cause) {
		super(errMsg, cause);
		this.sysErrCode = DEFAULT_SYS_ERR_CODE;
	}

	/**
	 * 예외 생성자
	 * 
	 * @param sysErrCode 시스템 오류 코드
	 * @param errMsg 오류 메시지
	 * @param cause 오류 원인 예외
	 */
	public CuinException(String sysErrCode, String errMsg, Throwable cause) {
		super(errMsg, cause);
		this.sysErrCode = sysErrCode;
	}

	/**
	 * 시스템 오류 코드 반환.
	 */
	public String getSysErrCode() {
		return sysErrCode;
	}
}
