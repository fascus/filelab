package cuin.cn.eai;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : EAI 인터페이스
 * 파 일 명 : CuinEaiInterfaces.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.06.05
 * 설    명 : 신협 공제 EAI 인터페이스 ID 목록.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public enum CuinEaiInterfaces {
	/**
	 * 공제 계정계 SMS 발송.
	 */
	INSCORE_SMS("MAZ20001"),
	/**
	 * 공제 정보계 SMS 발송.
	 */
	INSINFO_SMS("MIZ20001");

	private String interfaceId;

	CuinEaiInterfaces(String interfaceId) {
		this.interfaceId = interfaceId;
	}

	/**
	 * @return EAI 인터페이스 ID 반환.
	 */
	public String getId() {
		return interfaceId;
	}
}
