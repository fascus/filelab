package cuin.cn.eai;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : EAI 인터페이스
 * 파 일 명 : EaiAdaptor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.04.02
 * 설    명 : EAI 인터페이스 API.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface EaiAdaptor {

	/**
	 * 문자열 형태의 메시지를 타 시스템으로 전송한다 (단방향).
	 * 
	 * @param interfaceId EAI 인터페이스 ID
	 * @param sendData 타 시스템으로 전송할 문자열 형태의 메시지
	 */
	void send(String interfaceId, String sendData);

	/**
	 * 바이트 배열 형태의 메시지를 타 시스템으로 전송한다 (단방향).
	 * 
	 * @param interfaceId EAI 인터페이스 ID
	 * @param sendData 타 시스템으로 전송할 바이트 배열 형태의 메시지
	 */
	void send(String interfaceId, byte[] sendData);

	/**
	 * 문자열 형태의 메시지를 타 시스템으로 전송한다 (단방향 / 순차처리).
	 * 
	 * @param interfaceId EAI 인터페이스 ID
	 * @param sendData 타 시스템으로 전송할 문자열 형태의 메시지
	 */
	void sendSequential(String interfaceId, String sendData);

	/**
	 * 바이트 배열 형태의 메시지를 타 시스템으로 전송한다 (단방향 / 순차처리).
	 * 
	 * @param interfaceId EAI 인터페이스 ID
	 * @param sendData 타 시스템으로 전송할 바이트 배열 형태의 메시지
	 */
	void sendSequential(String interfaceId, byte[] sendData);

	/**
	 * 문자열 형태의 메시지를 타 시스템으로 전송하고, 응답 메시지를 반환한다 (양방향).
	 * 
	 * @param interfaceId EAI 인터페이스 ID
	 * @param sendData 타 시스템으로 전송할 문자열 형태의 메시지
	 * @return 응답 메시지 문자열
	 */
	String request(String interfaceId, String sendData);

	/**
	 * 바이트 배열 형태의 메시지를 타 시스템으로 전송하고, 응답 데이터(바이트 배열)을 반환한다 (양방향).
	 * 
	 * @param interfaceId EAI 인터페이스 ID
	 * @param sendData 타 시스템으로 전송할 바이트 배열 형태의 메시지
	 * @return 응답 메시지 데이터 (바이트 배열)
	 */
	byte[] request(String interfaceId, byte[] sendData);

	/**
	 * 문자열 형태의 메시지를 타 시스템으로 전송하고, 응답 메시지를 반환한다 (양방향, 순차처리).
	 * 
	 * @param interfaceId EAI 인터페이스 ID
	 * @param sendData 타 시스템으로 전송할 문자열 형태의 메시지
	 * @return 응답 메시지 데이터 (문자열)
	 */
	String requestSequential(String interfaceId, String sendData);

	/**
	 * 바이트 형태의 메시지를 타 시스템으로 전송하고, 응답 메시지를 반환한다 (양방향, 순차처리).
	 * 
	 * @param interfaceId EAI 인터페이스 ID
	 * @param sendData 타 시스템으로 전송할 바이트 배열 형태의 메시지
	 * @return 응답 메시지 데이터 (바이트 배열)
	 */
	byte[] requestSequential(String interfaceId, byte[] sendData);
}
