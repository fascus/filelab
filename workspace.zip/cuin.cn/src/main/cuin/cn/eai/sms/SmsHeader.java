package cuin.cn.eai.sms;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : SMS/LMS 전송
 * 파 일 명 : SmsHeader.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.11.19
 * 설     명 : SMS 헤더
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */

public class SmsHeader {
	// 시스템 아이디 (15자리)
	private String systemId;
	// 사용자 아이디 (12자리)
	private String userId;
	// 부서 코드 (5자리)
	private String deptCd;
	// 업무 아이디 (6자리)
	private String bsnsId;
	// 템플릿 아이디 (20자리)
	private String tmplId;
	// 발송 형태 (1자리)
	private String snnFmm;
	// 예약일시 (12자리)
	private String rsvDtm;
	// 요청일시 (12자리)
	private String rqstDtm;
	// 전체 건수 (7자리)
	private String allNcnt;
	// 실 건수 (7자리)
	private String aclNcnt;
	// 처리 건수 (7자리)
	private String prceNcnt;
	// 문자 메시지 형식 (7자리)
	private String msgFmm;

	// 업무구분코드
	private String bsnsDvCd;

	// 업무구분상세코드
	private String dtilBsnsDvCd;

	public SmsHeader() {
		systemId = "systemId       ";
		userId = "userId      ";
		deptCd = "depCd";
		bsnsId = "bsnsId";
		tmplId = "tmplId              ";
		snnFmm = "R";
		rsvDtm = "000000000000";
		rqstDtm = "000000000000";
		allNcnt = "0000001";
		aclNcnt = "0000001";
		prceNcnt = "0000000";
		msgFmm = "0000LMS";
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDeptCd() {
		return deptCd;
	}

	public void setDeptCd(String deptCd) {
		this.deptCd = deptCd;
	}

	public String getBsnsId() {
		return bsnsId;
	}

	public void setBsnsId(String bsnsId) {
		this.bsnsId = bsnsId;
	}

	public String getTmplId() {
		return tmplId;
	}

	public void setTmplId(String tmplId) {
		this.tmplId = tmplId;
	}

	public String getSnnFmm() {
		return snnFmm;
	}

	public void setSnnFmm(String snnFmm) {
		this.snnFmm = snnFmm;
	}

	public String getRsvDtm() {
		return rsvDtm;
	}

	public void setRsvDtm(String rsvDtm) {
		this.rsvDtm = rsvDtm;
	}

	public String getRqstDtm() {
		return rqstDtm;
	}

	public void setRqstDtm(String rqstDtm) {
		this.rqstDtm = rqstDtm;
	}

	public String getAllNcnt() {
		return allNcnt;
	}

	public void setAllNcnt(String allNcnt) {
		this.allNcnt = allNcnt;
	}

	public String getAclNcnt() {
		return aclNcnt;
	}

	public void setAclNcnt(String aclNcnt) {
		this.aclNcnt = aclNcnt;
	}

	public String getPrceNcnt() {
		return prceNcnt;
	}

	public void setPrceNcnt(String prceNcnt) {
		this.prceNcnt = prceNcnt;
	}

	public String getMsgFmm() {
		return msgFmm;
	}

	public void setMsgFmm(String msgFmm) {
		this.msgFmm = msgFmm;
	}

	@Override
	public String toString() {
		return "SmsHeader [systemId=" + systemId + ", userId=" + userId + ", deptCd=" + deptCd + ", bsnsId=" + bsnsId + ", tmplId=" + tmplId + ", snnFmm=" + snnFmm + ", rsvDtm=" + rsvDtm
				+ ", rqstDtm=" + rqstDtm + ", allNcnt=" + allNcnt + ", aclNcnt=" + aclNcnt + ", prceNcnt=" + prceNcnt + ", msgFmm=" + msgFmm + "]";
	}

	public String getBsnsDvCd() {
		return bsnsDvCd;
	}

	public void setBsnsDvCd(String bsnsDvCd) {
		this.bsnsDvCd = bsnsDvCd;
	}

	public String getDtilBsnsDvCd() {
		return dtilBsnsDvCd;
	}

	public void setDtilBsnsDvCd(String dtilBsnsDvCd) {
		this.dtilBsnsDvCd = dtilBsnsDvCd;
	}

}
