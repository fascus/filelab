package cuin.cn.eai.sms;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : SMS/LMS 전송
 * 파 일 명 : SmsBody.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.11.19
 * 설     명 : SMS/LMS 데이터 바디 (data body)
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */

public class SmsBody {
	// 휴대폰번호 (20 자리)
	private String mpno;
	// 처리여부 (4 자리)
	private String prceYn;
	// SMS 메시지 (80 자리)
	private String smsMsg;
	// LMS 메시지 (1000 자리)
	private String lmsMsg;
	// 메시지 - 개발자는 msg 에 세팅, 프로그램에서 sms , lms 구분을 통해서 입력
	private String msg;
	// 식별 코드 (20 자리)
	private String etcMsg;

	public String getMpno() {
		return mpno;
	}

	public void setMpno(String mpno) {
		this.mpno = mpno;
	}

	public String getPrceYn() {
		return prceYn;
	}

	public void setPrceYn(String prceYn) {
		this.prceYn = prceYn;
	}

	public String getSmsMsg() {
		return smsMsg;
	}

	public void setSmsMsg(String smsMsg) {
		this.smsMsg = smsMsg;
	}

	public String getLmsMsg() {
		return lmsMsg;
	}

	public void setLmsMsg(String lmsMsg) {
		this.lmsMsg = lmsMsg;
	}

	public String getEtcMsg() {
		return etcMsg;
	}

	public void setEtcMsg(String etcMsg) {
		this.etcMsg = etcMsg;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "SmsBody [mpno=" + mpno + ", prceYn=" + prceYn + ", smsMsg=" + smsMsg + ", lmsMsg=" + lmsMsg + ", etcMsg=" + etcMsg + ", msg=" + msg + "]";
	}
}
