package cuin.cn.eai.sms;

import java.util.List;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : SMS/LMS 전송
 * 파 일 명 : EaiSmsSender.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.11.19
 * 설     명 : EAI 를 통한 SMS/LMS 발송 인터페이스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */

public interface EaiSmsSender {

	/**
	 * 계정계 혹은 정보계 유형
	 */
	enum Section {
		// 계정계
		CORE,
		// 정보계
		INFO
	};

	/**
	 * SMS/EMS 발송.
	 * 
	 * @param section 계정계 혹은 정보계
	 * @param phoneNo 전화번호
	 * @param msg 메시지 (최대 1000 바이트)
	 */
	void send(Section section, String phoneNo, String msg);

	/**
	 * SMS 발송.
	 * 
	 * @param section 계정계 혹은 정보계
	 * @param bsnsId 업무 아이디
	 * @param tmplId 템플릿 아이디 (20자리)
	 * @param rsvDtm 예약일시
	 * @param smsBodyList Data 전송 리스트
	 */
	public void sendSMS(Section section, String bsnsId, String tmplId, String rsvDtm, List<SmsBody> smsBodyList);

	/**
	 * SMS 발송.
	 * 
	 * @param section 계정계 혹은 정보계
	 * @param smsHeader.bsnsId 업무 아이디
	 * @param smsHeader.tmplId 템플릿 아이디 (20자리)
	 * @param smsHeader.rsvDtm 예약일시
	 * @param smsHeader.bsnsDvCd 업무구분(BS,KI,CT ... )
	 * @param smsBodyList Data 전송 리스트
	 */
	public void sendSMS(Section section, SmsHeader smsHeader, List<SmsBody> smsBodyList);

	/**
	 * LMS 발송.
	 * 
	 * @param section 계정계 혹은 정보계
	 * @param bsnsId 업무 아이디
	 * @param tmplId 템플릿 아이디 (20자리)
	 * @param rsvDtm 예약일시
	 * @param smsBodyList Data 전송 리스트
	 */
	public void sendLMS(Section section, String bsnsId, String tmplId, String rsvDtm, List<SmsBody> smsBodyList);

	/**
	 * LMS 발송.
	 * 
	 * @param section 계정계 혹은 정보계
	 * @param smsHeader.bsnsId 업무 아이디
	 * @param smsHeader.tmplId 템플릿 아이디 (20자리)
	 * @param smsHeader.rsvDtm 예약일시
	 * @param smsHeader.bsnsDvCd 업무구분(BS,KI,CT ... )
	 * @param smsBodyList Data 전송 리스트
	 */
	public void sendLMS(Section section, SmsHeader smsHeader, List<SmsBody> smsBodyList);

}
