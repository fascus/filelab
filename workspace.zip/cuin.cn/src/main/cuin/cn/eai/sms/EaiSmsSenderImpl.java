package cuin.cn.eai.sms;

import hone.common.util.DateUtils;
import hone.common.util.StringUtils;
import hone.omm.marshall.HoneOmmMarshaller;
import hone.omm.marshall.OmmMarshaller;
import hone.omm.model.OmmMap;
import hone.omm.provider.OmmProvider;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cuin.cn.eai.CuinEaiAdaptor;
import cuin.cn.eai.CuinEaiInterfaces;
import cuin.cn.exception.CuinException;
import cuin.cn.service.ServiceContext;
import cuin.cn.util.BeanUtils;
import cuin.online.cn.core.message.header.CommonRequestHeader;
import cuin.online.cn.core.message.header.CuinCommonHeader;
import cuin.online.cn.im.ims.service.IntgMsgSnDscpSrviService;
import cuin.online.cn.im.ims.service.IntgMsgSnDscpSrviServiceImpl;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : SMS/LMS 전송
 * 파 일 명 : EaiSmsSenderImpl.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.11.19
 * 설    명 : EAI 를 통한 SMS/LMS 발송 구현체.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 * 
 * @stereotype DTO
 */
public class EaiSmsSenderImpl implements EaiSmsSender {
	private static final Logger logger = LoggerFactory.getLogger(IntgMsgSnDscpSrviServiceImpl.class);

	// 전화번호 길이 제한
	private static final int MAX_PHONE_NO_LENGTH = 20;
	// 메시지 길이 제한
	private static final int MAX_MESSAGE_LENGTH = 1000;
	// 단문 메시지 길이 제한
	private static final int SMS_MSG_LENGTH = 80;

	private static final String SMS_TYPE_SHORT = "0000SMS";
	private static final String SMS_TYPE_LONG = "0000LMS";

	private static final String SMS_HEADER_OMM_ID = "cuin.cn.eai.sms.omm.SmsHeader";
	private static final String SMS_BODY_OMM_ID = "cuin.cn.eai.sms.omm.SmsBody";
	private static final String LMS_BODY_OMM_ID = "cuin.cn.eai.sms.omm.LmsBody";

	private OmmProvider ommProvider;

	@Autowired
	private IntgMsgSnDscpSrviService intgMsgSnDscpSrviService;

	/**
	 * SMS/MMS 전문 생성을 위한 OMM 프로바이더 설정
	 * 
	 * @param ommProvider
	 */
	public void setOmmProvider(OmmProvider ommProvider) {
		this.ommProvider = ommProvider;
	}

	/**
	 * SMS/MMS 발송.
	 */
	@Override
	public void send(Section section, String phoneNo, String msg) {
		throw new IllegalArgumentException("Header DTO 를 사용하도록 변경해 주세요.");

	}

	/**
	 * SMS 발송.
	 */
	@Override
	public void sendSMS(Section section, String bsnsId, String tmplId, String rsvDtm, List<SmsBody> smsBodyList) {

		throw new IllegalArgumentException("Header DTO 를 사용하도록 변경해 주세요.");

	}

	/**
	 * SMS 발송.
	 */
	@Override
	public void sendSMS(Section section, SmsHeader smsHeader, List<SmsBody> smsBodyList) {

		// 업무 아이디 인자 점검
		if (smsHeader.getBsnsId() == null || smsHeader.getBsnsId().isEmpty()) {
			throw new IllegalArgumentException("bsnsId is null or empty.");
		}

		// 회신 전화번호 인자 점검
		if (smsHeader.getTmplId() == null || smsHeader.getTmplId().isEmpty()) {
			throw new IllegalArgumentException("tmplId is null or empty.");
		}

		// 예약일시 인자 점검
		if (smsHeader.getRsvDtm() == null || smsHeader.getRsvDtm().isEmpty()) {
			throw new IllegalArgumentException("rsvDtm is null or empty.");
		}

		List<SmsBody> newSmsBodyList = new ArrayList<SmsBody>();

		for (SmsBody smsBody : smsBodyList) {

			String phoneNo = smsBody.getMpno();
			String msg = smsBody.getMsg();

			// 입력 전화번호 인자 점검
			if (phoneNo == null || phoneNo.isEmpty()) {
				throw new IllegalArgumentException("phoneNo is null or empty.");
			} else if (phoneNo.length() > MAX_PHONE_NO_LENGTH) {
				throw new IllegalArgumentException("phoneNo is too large. Max length : " + MAX_PHONE_NO_LENGTH + ", input phone number length : " + phoneNo.length());
			}

			// 입력 메시지 인자 점검
			if (msg == null || msg.isEmpty()) {
				throw new IllegalArgumentException("SMS/LMS message is null or empty.");
			}

			int msgLen = 0;
			int beginIndex = 0;
			int endIndex = 0;
			int byteMsgLen = 0;
			int endCnt = 0;

			try {
				msgLen = msg.getBytes("EUC-KR").length;
			} catch (UnsupportedEncodingException e) {
				throw new CuinException(CuinException.DEFAULT_SYS_ERR_CODE, e.getMessage(), e);
			}

			if (msgLen > SMS_MSG_LENGTH) {
				byteMsgLen = 0;

				while (msgLen > 0) {
					endCnt = 0;

					for (int idx = byteMsgLen; idx < msg.length(); idx++) {

						if (StringUtils.isHangulChar(msg.charAt(idx))) {
							msgLen = msgLen - 2;
							endCnt = endCnt + 2;

							if (endCnt == SMS_MSG_LENGTH - 1 || endCnt == SMS_MSG_LENGTH) {
								break;
							}
						} else {
							msgLen--;
							endCnt = endCnt + 1;

							if (endCnt == SMS_MSG_LENGTH) {
								break;
							}
						}
						byteMsgLen++;
					}

					endIndex = byteMsgLen;

					logger.debug("beginIndex : " + beginIndex + " , beginIndex : " + endIndex + " , msg.length() : " + msg.length());
					String smsMsg = msg.substring(beginIndex, endIndex);

					SmsBody smsBodyDto = BeanUtils.toBean(smsBody, SmsBody.class);
					smsBodyDto.setSmsMsg(smsMsg);
					newSmsBodyList.add(smsBodyDto);

					beginIndex = endIndex;
				}
			} else {
				smsBody.setSmsMsg(msg);
				newSmsBodyList.add(smsBody);
			}
		}

		// SMS 헤더 설정
		SmsHeader smsHeader_sms = createHeaderData(smsHeader, String.valueOf(newSmsBodyList.size()), SMS_TYPE_SHORT);
		byte[] smsData = createSendData(smsHeader_sms, newSmsBodyList);

		// 통합메시지관리 테이블 입력
		intgMsgSnDscpSrviService.registerSmsMsg(smsHeader_sms, newSmsBodyList);

		CuinEaiAdaptor cuinEaiAdaptor = new CuinEaiAdaptor();
		CuinEaiInterfaces sectionType = (section == Section.CORE) ? CuinEaiInterfaces.INSCORE_SMS : CuinEaiInterfaces.INSINFO_SMS;
		// try {
		//
		// String aaa = new String(smsData, "EUC-KR");
		// System.out.println("msg : " + aaa);
		// } catch (UnsupportedEncodingException e) {
		// e.printStackTrace();
		// }
		cuinEaiAdaptor.send(sectionType.getId(), smsData);
	}

	/**
	 * LMS 발송.
	 */
	@Override
	public void sendLMS(Section section, String bsnsId, String tmplId, String rsvDtm, List<SmsBody> smsBodyList) {

		throw new IllegalArgumentException("Header DTO 를 사용하도록 변경해 주세요.");

	}

	/**
	 * LMS 발송.
	 */
	@Override
	public void sendLMS(Section section, SmsHeader smsHeader, List<SmsBody> smsBodyList) {

		// 업무 아이디 인자 점검
		if (smsHeader.getBsnsId() == null || smsHeader.getBsnsId().isEmpty()) {
			throw new IllegalArgumentException("bsnsId is null or empty.");
		}

		// 회신 전화번호 인자 점검
		if (smsHeader.getTmplId() == null || smsHeader.getTmplId().isEmpty()) {
			throw new IllegalArgumentException("tmplId is null or empty.");
		}

		// 예약일시 인자 점검
		if (smsHeader.getRsvDtm() == null || smsHeader.getRsvDtm().isEmpty()) {
			throw new IllegalArgumentException("rsvDtm is null or empty.");
		}

		for (SmsBody smsBody : smsBodyList) {

			String phoneNo = smsBody.getMpno();
			String msg = smsBody.getMsg();

			// 입력 전화번호 인자 점검
			if (phoneNo == null || phoneNo.isEmpty()) {
				throw new IllegalArgumentException("phoneNo is null or empty.");
			} else if (phoneNo.length() > MAX_PHONE_NO_LENGTH) {
				throw new IllegalArgumentException("phoneNo is too large. Max length : " + MAX_PHONE_NO_LENGTH + ", input phone number length : " + phoneNo.length());
			}

			int msgLen = 0;

			// 입력 메시지 인자 점검
			if (msg == null || msg.isEmpty()) {
				throw new IllegalArgumentException("LMS message is null or empty.");
			}

			try {
				msgLen = msg.getBytes("EUC-KR").length;
			} catch (UnsupportedEncodingException e) {
				throw new CuinException(CuinException.DEFAULT_SYS_ERR_CODE, e.getMessage(), e);
			}

			if (msgLen > MAX_MESSAGE_LENGTH) {
				throw new IllegalArgumentException("SMS/LMS message is too large. Max length : " + MAX_MESSAGE_LENGTH + ", input message length : " + msg.length());
			}

			smsBody.setLmsMsg(msg);
		}

		// SMS 헤더 설정
		SmsHeader smsHeader_lms = createHeaderData(smsHeader, String.valueOf(smsBodyList.size()), SMS_TYPE_LONG);

		// 통합메시지관리 테이블 입력
		intgMsgSnDscpSrviService.registerSmsMsg(smsHeader_lms, smsBodyList);

		CuinEaiAdaptor cuinEaiAdaptor = new CuinEaiAdaptor();
		CuinEaiInterfaces sectionType = (section == Section.CORE) ? CuinEaiInterfaces.INSCORE_SMS : CuinEaiInterfaces.INSINFO_SMS;
		byte[] smsData = createSendData(smsHeader_lms, smsBodyList);
		cuinEaiAdaptor.send(sectionType.getId(), smsData);
	}

	/**
	 * 전송 데이터 생성.
	 */
	private byte[] createSendData(SmsHeader smsHeader, List<SmsBody> smsBodyList) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();

		// 전문 헤더 출력
		OmmMap msgHeaderOmmMap = ommProvider.get(CuinCommonHeader.COMMON_IN_HEADER);
		CommonRequestHeader commonRequestHeader = new CommonRequestHeader();
		OmmMarshaller marshaller = new HoneOmmMarshaller(msgHeaderOmmMap, out);
		marshaller.write(commonRequestHeader);

		// SMS 헤더 출력
		OmmMap smsHeaderOmmMap = ommProvider.get(SMS_HEADER_OMM_ID);
		marshaller = new HoneOmmMarshaller(smsHeaderOmmMap, out);
		marshaller.write(smsHeader);

		// SMS 바디 출력
		OmmMap smsBodyOmmMap = ommProvider.get(SMS_BODY_OMM_ID);

		// LMS 바디 출력
		if (SMS_TYPE_LONG.equals(smsHeader.getMsgFmm())) {
			smsBodyOmmMap = ommProvider.get(LMS_BODY_OMM_ID);
		}

		marshaller = new HoneOmmMarshaller(smsBodyOmmMap, out);
		for (SmsBody smsBody : smsBodyList) {
			marshaller.write(smsBody);
		}

		return out.toByteArray();
	}

	/**
	 * 헤더 데이터 생성.
	 */
	private SmsHeader createHeaderData(SmsHeader smsHeader, String size, String msgFmm) {
		// SMS 헤더 설정
		// smsHeader.setBsnsId(bsnsId); // 업무ID
		// smsHeader.setTmplId(tmplId); // 템플릿ID
		// smsHeader.setRsvDtm(rsvDtm); // 예약일시

		smsHeader.setMsgFmm(msgFmm); // 문자 메시지 형식
		smsHeader.setAllNcnt(size); // 전체건수
		smsHeader.setAclNcnt(size); // 실건수
		smsHeader.setRqstDtm(DateUtils.getTodayString("yyyyMMddHHmm")); // 요청일시
		smsHeader.setDeptCd(ServiceContext.getDpmCd()); // 부서코드
		smsHeader.setUserId(ServiceContext.getUserId()); // 사용자ID

		// 발송 형태
		if ("000000000000".equals(smsHeader.getRsvDtm())) {
			smsHeader.setSnnFmm("R");// R : 실시간
		} else {
			smsHeader.setSnnFmm("B");// B : 예약
		}

		return smsHeader;
	}

}
