package cuin.cn.eai;

import com.e1.eai.excp.EAIException;
import com.e1.eai.service.Eai;

import cuin.cn.exception.CuinEAIException;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : EAI 인터페이스
 * 파 일 명 : CuinEaiAdaptor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.06.04
 * 설    명 : EAI 인터페이스 구현체
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CuinEaiAdaptor implements EaiAdaptor {

	private static final String EAI_DEFAULT_TRACE_LEVEL = "3";
	/**
	 * EAI timeout & expire time (in queue) default value
	 */
	private static final String EXPIRE_TIME_MILLI_SECCONDS = "20000";

	@Override
	public void send(String interfaceId, String sendData) {
		try {
			createEai().send(interfaceId, sendData, EAI_DEFAULT_TRACE_LEVEL);
		} catch (EAIException e) {
			throw new CuinEAIException(e);
		}
	}

	@Override
	public void send(String interfaceId, byte[] sendData) {
		try {
			createEai().send(interfaceId, sendData, EAI_DEFAULT_TRACE_LEVEL);
		} catch (EAIException e) {
			throw new CuinEAIException(e);
		}
	}

	@Override
	public void sendSequential(String interfaceId, String sendData) {
		try {
			createEai().sendSequential(interfaceId, sendData, EAI_DEFAULT_TRACE_LEVEL);
		} catch (EAIException e) {
			throw new CuinEAIException(e);
		}
	}

	@Override
	public void sendSequential(String interfaceId, byte[] sendData) {
		try {
			createEai().sendSequential(interfaceId, sendData, EAI_DEFAULT_TRACE_LEVEL);
		} catch (EAIException e) {
			throw new CuinEAIException(e);
		}
	}

	@Override
	public String request(String interfaceId, String sendData) {
		try {
			return createEai().request(interfaceId, sendData, EAI_DEFAULT_TRACE_LEVEL, EXPIRE_TIME_MILLI_SECCONDS);
		} catch (EAIException e) {
			throw new CuinEAIException(e);
		}
	}

	@Override
	public byte[] request(String interfaceId, byte[] sendData) {
		try {
			return createEai().request(interfaceId, sendData, EAI_DEFAULT_TRACE_LEVEL, EXPIRE_TIME_MILLI_SECCONDS);
		} catch (EAIException e) {
			throw new CuinEAIException(e);
		}
	}

	@Override
	public String requestSequential(String interfaceId, String sendData) {
		try {
			return createEai().requestSequential(interfaceId, sendData, EAI_DEFAULT_TRACE_LEVEL, EXPIRE_TIME_MILLI_SECCONDS);
		} catch (EAIException e) {
			throw new CuinEAIException(e);
		}
	}

	@Override
	public byte[] requestSequential(String interfaceId, byte[] sendData) {
		try {
			return createEai().requestSequential(interfaceId, sendData, EAI_DEFAULT_TRACE_LEVEL, EXPIRE_TIME_MILLI_SECCONDS);
		} catch (EAIException e) {
			throw new CuinEAIException(e);
		}
	}

	private Eai createEai() throws EAIException {
		Eai eai = new Eai();
		eai.setTimeOut(Integer.valueOf(EXPIRE_TIME_MILLI_SECCONDS));
		return eai;
	}
}
