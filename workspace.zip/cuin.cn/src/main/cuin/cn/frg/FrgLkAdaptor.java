package cuin.cn.frg;

import cuin.cn.frg.dto.FrgLkCnHdrDto;
import cuin.cn.frg.dto.FrgLkSndnDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : FrgLkAdaptor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.08.08
 * 설    명 : 대외 연계 전문 송신 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface FrgLkAdaptor {

	/**
	 * 표준 전문 헤더 수정을 위한 콜백 등록
	 */
	void setStdHdrClk(FrgStdHdrClk stdHdrClk);

	/**
	 * 대외 전문 공통 헤더 설정
	 * 
	 * @param frgLnkCnHdrDto 대외 전문 공통 헤더 DTO
	 */
	void setFrgCnHdr(FrgLkCnHdrDto frgLnkCnHdrDto);

	/**
	 * 대외 전문 송신 데이터 DTO 설정
	 * 
	 * @param sndnDto 대외 전문 송신 DTO
	 * @param sndnOmmId 대외 전문 송신 DTO의 OMM Map ID
	 */
	void setSndnDto(FrgLkSndnDto sndnDto, String sndnOmmId);

	/**
	 * 대외 전문 데이터 반환
	 */
	String getLnMesg();

	/**
	 * 대외 전문 송신
	 * 
	 * @param interfaceId EAI 인터페이스 ID
	 */
	void send(String interfaceId);

	/**
	 * 송신 데이터를 DTO 형태로 복원
	 */
	FrgLkDtoBundle parseRequestMsg(byte msg[], String frgLkCnHdrOmmId, String frgLkDataOmmId);

}
