package cuin.cn.frg;

import cuin.cn.frg.dto.FrgLkCnHdrDto;
import cuin.cn.frg.dto.FrgLkSndnDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : FrgLkDtoBundle.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.10.16
 * 설    명 : 대외 전문 헤더 및 데이터 DTO를 포함한 번들(bundle).
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class FrgLkDtoBundle {

	// 대외 전문 헤더 DTO
	private FrgLkCnHdrDto frgLkHdrDto;
	// 대외 전문 데이터 DTO
	private FrgLkSndnDto frgLkSndnDto;

	public FrgLkDtoBundle(FrgLkCnHdrDto frgLkHdrDto, FrgLkSndnDto frgLkSndnDto) {
		this.frgLkHdrDto = frgLkHdrDto;
		this.frgLkSndnDto = frgLkSndnDto;
	}

	/**
	 * 대외 전문 헤더 DTO 반환.
	 */
	public FrgLkCnHdrDto getHdrDto() {
		return frgLkHdrDto;
	}

	/**
	 * 대외 전문 데이터 DTO 반환
	 */
	public FrgLkSndnDto getSndnDto() {
		return frgLkSndnDto;
	}
}
