package cuin.cn.frg.dto;

import java.io.Serializable;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : FrgLkRcveDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.08
 * 설    명 : 대외 연계 수신 데이터 DTO 마커(marker) 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface FrgLkRcveDto extends Serializable {

}
