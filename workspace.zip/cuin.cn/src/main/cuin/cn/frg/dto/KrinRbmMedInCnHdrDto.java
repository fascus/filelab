package cuin.cn.frg.dto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : KrinRbmMedInCnHdrDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.08.09
 * 설    명 : 보험개발원 실손의료보험 전문 공통 헤더 DTO.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class KrinRbmMedInCnHdrDto implements FrgLkCnHdrDto {
	private static final long serialVersionUID = -4884516252901966992L;

	/**
	 * Transaction 코드
	 */
	private String trnCd;

	/**
	 * TEXT 개시문자
	 */
	private String textBgnChc;

	/**
	 * 전송종별코드
	 */
	private int mesgClsfCd;

	/**
	 * 업무구분코드
	 */
	private String bsnsDvCd;

	/**
	 * 전문개시시간
	 */
	private String mesgBgnTm;

	/**
	 * 전문관리번호
	 */
	private int mesgMgCd;

	/**
	 * 송신기관코드
	 */
	private String sndnOrCd;

	/**
	 * 수신기관코드
	 */
	private String rcveOrCd;

	/**
	 * 데이터 길이
	 */
	private int dataLng;

	/**
	 * 단말기 번호
	 */
	private String trmlNo;

	/**
	 * 단말기조작자ID
	 */
	private String trmlOprtNo;

	/**
	 * 점포코드
	 */
	private String stoCd;

	/**
	 * 응답코드
	 */
	private String rspnCd;

	/**
	 * 자료계속여부
	 */
	private String datCnnYn;

	/**
	 * 예비란.
	 */
	private String prpr;

	/**
	 * <pre>
	 * Transaction 코드 반환 (get trnCd 9 0)
	 * </pre>
	 */
	public String getTrnCd() {
		return trnCd;
	}

	/**
	 * <pre>
	 * Transaction 코드 설정 (set trnCd 9 0)
	 * </pre>
	 */
	public void setTrnCd(String trnCd) {
		this.trnCd = trnCd;
	}

	/**
	 * <pre>
	 * Text 개시문자 반환 (get textBgnChc 4 0)
	 * </pre>
	 */
	public String getTextBgnChc() {
		return textBgnChc;
	}

	/**
	 * <pre>
	 * Text 개시문자 설정 (set textBgnChc 4 0)
	 * </pre>
	 */
	public void setTextBgnChc(String textBgnChc) {
		this.textBgnChc = textBgnChc;
	}

	/**
	 * <pre>
	 * 전송종별코드 반환 (get mesgClsfCd 4 0)
	 * </pre>
	 */
	public int getMesgClsfCd() {
		return mesgClsfCd;
	}

	/**
	 * <pre>
	 * 전송종별코드 설정 (set mesgClsfCd 4 0)
	 * </pre>
	 */
	public void setMesgClsfCd(int mesgClsfCd) {
		this.mesgClsfCd = mesgClsfCd;
	}

	/**
	 * <pre>
	 * 업무구분코드 반환 (get bsnsDvCd 3 0)
	 * </pre>
	 */
	public String getBsnsDvCd() {
		return bsnsDvCd;
	}

	/**
	 * <pre>
	 * 업무구분코드 설정 (set bsnsDvCd 3 0)
	 * </pre>
	 */
	public void setBsnsDvCd(String bsnsDvCd) {
		this.bsnsDvCd = bsnsDvCd;
	}

	/**
	 * <pre>
	 * 전문개시시간 반환 (get mesgBgnTm 14 0)
	 * </pre>
	 */
	public String getMesgBgnTm() {
		return mesgBgnTm;
	}

	/**
	 * <pre>
	 * 전문개시시간 설정 (set mesgBgnTm 14 0)
	 * </pre>
	 */
	public void setMesgBgnTm(String mesgBgnTm) {
		this.mesgBgnTm = mesgBgnTm;
	}

	/**
	 * <pre>
	 * 전문관리번호 반환 (get mesgMgCd 7 0)
	 * </pre>
	 */
	public int getMesgMgCd() {
		return mesgMgCd;
	}

	/**
	 * <pre>
	 * 전문관리번호 설정 (set mesgMgCd 7 0)
	 * </pre>
	 */
	public void setMesgMgCd(int mesgMgCd) {
		this.mesgMgCd = mesgMgCd;
	}

	/**
	 * <pre>
	 * 송신기관코드 반환 (get sndnOrCd 3 0)
	 * </pre>
	 */
	public String getSndnOrCd() {
		return sndnOrCd;
	}

	/**
	 * <pre>
	 * 송신기관코드 설정 (set sndnOrCd 3 0)
	 * </pre>
	 */
	public void setSndnOrCd(String sndnOrCd) {
		this.sndnOrCd = sndnOrCd;
	}

	/**
	 * <pre>
	 * 수신기관코드 반환 (get sndnOrCd 3 0)
	 * </pre>
	 */
	public String getRcveOrCd() {
		return rcveOrCd;
	}

	/**
	 * <pre>
	 * 수신기관코드 설정 (set sndnOrCd 3 0)
	 * </pre>
	 */
	public void setRcveOrCd(String rcveOrCd) {
		this.rcveOrCd = rcveOrCd;
	}

	/**
	 * <pre>
	 * 데이터 길이 반환 (get dataLng 4 0)
	 * </pre>
	 */
	public int getDataLng() {
		return dataLng;
	}

	/**
	 * <pre>
	 * 데이터 길이 설정 (set dataLng 4 0)
	 * </pre>
	 */
	public void setDataLng(int dataLng) {
		this.dataLng = dataLng;
	}

	/**
	 * <pre>
	 * 단말기 번호 반환(get trmlNo 8 0)
	 * </pre>
	 */
	public String getTrmlNo() {
		return trmlNo;
	}

	/**
	 * <pre>
	 * 단말기 번호 설정(set trmlNo 8 0)
	 * </pre>
	 */
	public void setTrmlNo(String trmlNo) {
		this.trmlNo = trmlNo;
	}

	/**
	 * <pre>
	 * 단말기조작자ID 반환(get trmlNo 13 0)
	 * </pre>
	 */
	public String getTrmlOprtNo() {
		return trmlOprtNo;
	}

	/**
	 * <pre>
	 * 단말기조작자ID 설정(set trmlNo 13 0)
	 * </pre>
	 */
	public void setTrmlOprtNo(String trmlOprtNo) {
		this.trmlOprtNo = trmlOprtNo;
	}

	/**
	 * <pre>
	 * 점포코드 반환(get stoCd 17 0)
	 * </pre>
	 */
	public String getStoCd() {
		return stoCd;
	}

	/**
	 * <pre>
	 * 점포코드 설정(set stoCd 17 0)
	 * </pre>
	 */
	public void setStoCd(String stoCd) {
		this.stoCd = stoCd;
	}

	/**
	 * <pre>
	 * 응답코드 반환(get rspnCd 3 0)
	 * </pre>
	 */
	public String getRspnCd() {
		return rspnCd;
	}

	/**
	 * <pre>
	 * 응답코드 설정(set rspnCd 3 0)
	 * </pre>
	 */
	public void setRspnCd(String rspnCd) {
		this.rspnCd = rspnCd;
	}

	/**
	 * <pre>
	 * 자료계속여부 반환(get datCnnYn 1 0)
	 * </pre>
	 */
	public String getDatCnnYn() {
		return datCnnYn;
	}

	/**
	 * <pre>
	 * 자료계속여부 설정(set datCnnYn 1 0)
	 * </pre>
	 */
	public void setDatCnnYn(String datCnnYn) {
		this.datCnnYn = datCnnYn;
	}

	/**
	 * <pre>
	 * 예비란 반환(get prpr 7 0)
	 * </pre>
	 */
	public String getPrpr() {
		return prpr;
	}

	/**
	 * <pre>
	 * 예비란 설정(set prpr 7 0)
	 * </pre>
	 */
	public void setPrpr(String prpr) {
		this.prpr = prpr;
	}

	@Override
	public boolean hasNext() {
		return datCnnYn != null && datCnnYn.equalsIgnoreCase("Y");
	}

	@Override
	public String toString() {
		return "KrinRbmMedInCnHdrDto [trnCd=" + trnCd + ", textBgnChc=" + textBgnChc + ", mesgClsfCd=" + mesgClsfCd + ", bsnsDvCd=" + bsnsDvCd + ", mesgBgnTm=" + mesgBgnTm + ", mesgMgCd=" + mesgMgCd
				+ ", sndnOrCd=" + sndnOrCd + ", rcveOrCd=" + rcveOrCd + ", dataLng=" + dataLng + ", trmlNo=" + trmlNo + ", trmlOprtNo=" + trmlOprtNo + ", stoCd=" + stoCd + ", rspnCd=" + rspnCd
				+ ", datCnnYn=" + datCnnYn + ", prpr=" + prpr + "]";
	}
}
