package cuin.cn.frg.dto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : KrinMapsCnHdrDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.08.09
 * 설    명 : 보험개발원 MAPS 전문 공통 헤더 DTO.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class KrinMapsCnHdrDto implements FrgLkCnHdrDto {
	private static final long serialVersionUID = 8734344934476349993L;

	/**
	 * 전문송신 Byte 수
	 */
	private int mesgSndnByteSz;

	/**
	 * Transaction 코드
	 */
	private String trnCd;

	/**
	 * Data 구분
	 */
	private String dataDv;

	/**
	 * 전송종별코드
	 */
	private String mesgClsfCd;

	/**
	 * 거래구분코드
	 */
	private String trnDvCd;

	/**
	 * 온라인배치작업ID
	 */
	private String onlBatWkId;

	/**
	 * Block전송구분코드
	 */
	private String snDvCd;

	/**
	 * Data총레코드건수
	 */
	private int dataRcdTcnt;

	/**
	 * 응답코드
	 */
	private String rspnCd;

	/**
	 * 전문관리번호
	 */
	private String mesgMgNo;

	/**
	 * 전문전송일자
	 */
	private String mesgSnDt;

	/**
	 * 전문전송시간
	 */
	private String mesgSnTm;

	/**
	 * 송신기간
	 */
	private String sndnOr;

	/**
	 * 수신기간
	 */
	private String rcveOr;

	/**
	 * 사용자ID
	 */
	private String userId;

	/**
	 * 사용자비밀번호
	 */
	private String userPwd;

	/**
	 * 사용자IP
	 */
	private String userIp;

	/**
	 * 사용자소속점포코드
	 */
	private String userBlgStoCd;

	/**
	 * 사용자소속점포명
	 */
	private String userBlgStoNm;

	/**
	 * 공란
	 */
	private String bln;

	/**
	 * <pre>
	 * 전문송신 Byte 수 반환 (get mesgSndnByteSz 5 0)
	 * </pre>
	 */
	public int getMesgSndnByteSz() {
		return mesgSndnByteSz;
	}

	/**
	 * <pre>
	 * 전문송신 Byte 수 설정 (set mesgSndnByteSz 5 0)
	 * </pre>
	 */
	public void setMesgSndnByteSz(int mesgSndnByteSz) {
		this.mesgSndnByteSz = mesgSndnByteSz;
	}

	/**
	 * <pre>
	 * Transaction코드 반환 (get trnCd 2 0)
	 * </pre>
	 */
	public String getTrnCd() {
		return trnCd;
	}

	/**
	 * <pre>
	 * Transaction코드 설정 (set trnCd 2 0)
	 * </pre>
	 */
	public void setTrnCd(String trnCd) {
		this.trnCd = trnCd;
	}

	/**
	 * <pre>
	 * Data구분 반환 (get dataDv 1 0)
	 * </pre>
	 */
	public String getDataDv() {
		return dataDv;
	}

	/**
	 * <pre>
	 * Data구분 설정 (set dataDv 1 0)
	 * </pre>
	 */
	public void setDataDv(String dataDv) {
		this.dataDv = dataDv;
	}

	/**
	 * <pre>
	 * 전문종별코드 반환(get mesgClsfCd 4 0)
	 * </pre>
	 */
	public String getMesgClsfCd() {
		return mesgClsfCd;
	}

	/**
	 * <pre>
	 * 전문종별코드 설정(set mesgClsfCd 4 0)
	 * </pre>
	 */
	public void setMesgClsfCd(String mesgClsfCd) {
		this.mesgClsfCd = mesgClsfCd;
	}

	/**
	 * <pre>
	 * 거래구분코드 반환(get trnDvCd 6 0)
	 * </pre>
	 */
	public String getTrnDvCd() {
		return trnDvCd;
	}

	/**
	 * <pre>
	 * 거래구분코드 설정(set trnDvCd 6 0)
	 * </pre>
	 */
	public void setTrnDvCd(String trnDvCd) {
		this.trnDvCd = trnDvCd;
	}

	/**
	 * <pre>
	 * 온라인배치작업ID 반환(get onlBatWkId 10 0)
	 * </pre>
	 */
	public String getOnlBatWkId() {
		return onlBatWkId;
	}

	/**
	 * <pre>
	 * 온라인배치작업ID 설정(set onlBatWkId 10 0)
	 * </pre>
	 */
	public void setOnlBatWkId(String onlBatWkId) {
		this.onlBatWkId = onlBatWkId;
	}

	/**
	 * <pre>
	 * Block전송구분코드 반환(get snDvCd 2 0)
	 * </pre>
	 */
	public String getSnDvCd() {
		return snDvCd;
	}

	/**
	 * <pre>
	 * Block전송구분코드 설정(set snDvCd 2 0)
	 * </pre>
	 */
	public void setSnDvCd(String snDvCd) {
		this.snDvCd = snDvCd;
	}

	/**
	 * <pre>
	 * data총레코드건수 반환(get dataRcdTcnt 10 0)
	 * </pre>
	 */
	public int getDataRcdTcnt() {
		return dataRcdTcnt;
	}

	/**
	 * <pre>
	 * data총레코드건수 설정(set dataRcdTcnt 10 0)
	 * </pre>
	 */
	public void setDataRcdTcnt(int dataRcdTcnt) {
		this.dataRcdTcnt = dataRcdTcnt;
	}

	/**
	 * <pre>
	 * 응답코드 반환(get dataRcdTcnt 4 0)
	 * </pre>
	 */
	public String getRspnCd() {
		return rspnCd;
	}

	/**
	 * <pre>
	 * 응답코드 설정(set dataRcdTcnt 4 0)
	 * </pre>
	 */
	public void setRspnCd(String rspnCd) {
		this.rspnCd = rspnCd;
	}

	/**
	 * <pre>
	 * 전문관리번호 반환(get rspnCd 13 0)
	 * </pre>
	 */
	public String getMesgMgNo() {
		return mesgMgNo;
	}

	/**
	 * <pre>
	 * 전문관리번호 설정(set rspnCd 13 0)
	 * </pre>
	 */
	public void setMesgMgNo(String mesgMgNo) {
		this.mesgMgNo = mesgMgNo;
	}

	/**
	 * <pre>
	 * 전문전송일자 반환(get mesgMgNo 8 0)
	 * </pre>
	 */
	public String getMesgSnDt() {
		return mesgSnDt;
	}

	/**
	 * <pre>
	 * 전문전송일자 설정(set mesgMgNo 8 0)
	 * </pre>
	 */
	public void setMesgSnDt(String mesgSnDt) {
		this.mesgSnDt = mesgSnDt;
	}

	/**
	 * <pre>
	 * 전문전송시간 반환(get mesgSnDt 6 0)
	 * </pre>
	 */
	public String getMesgSnTm() {
		return mesgSnTm;
	}

	/**
	 * <pre>
	 * 전문전송시간 설정(set mesgSnDt 6 0)
	 * </pre>
	 */
	public void setMesgSnTm(String mesgSnTm) {
		this.mesgSnTm = mesgSnTm;
	}

	/**
	 * <pre>
	 * 송신기관 반환(get mesgSnTm 3 0)
	 * </pre>
	 */
	public String getSndnOr() {
		return sndnOr;
	}

	/**
	 * <pre>
	 * 송신기관 설정(set mesgSnTm 3 0)
	 * </pre>
	 */
	public void setSndnOr(String sndnOr) {
		this.sndnOr = sndnOr;
	}

	/**
	 * <pre>
	 * 수신기관 반환(get rcveSnTm 3 0)
	 * </pre>
	 */
	public String getRcveOr() {
		return rcveOr;
	}

	/**
	 * <pre>
	 * 송신기관 설정(set rcveSnTm 3 0)
	 * </pre>
	 */
	public void setRcveOr(String rcveOr) {
		this.rcveOr = rcveOr;
	}

	/**
	 * <pre>
	 * 사용자ID 반환(get userId 10 0)
	 * </pre>
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * <pre>
	 * 사용자ID 설정(set userId 10 0)
	 * </pre>
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * <pre>
	 * 사용자PW 반환(get userPwd 24 0)
	 * </pre>
	 */
	public String getUserPwd() {
		return userPwd;
	}

	/**
	 * <pre>
	 * 사용자PW 설정(set userPwd 24 0)
	 * </pre>
	 */
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	/**
	 * <pre>
	 * 사용자ip 반환(get userIp 20 0)
	 * </pre>
	 */
	public String getUserIp() {
		return userIp;
	}

	/**
	 * <pre>
	 * 사용자ip 설정(set userIp 20 0)
	 * </pre>
	 */
	public void setUserIp(String userIp) {
		this.userIp = userIp;
	}

	/**
	 * <pre>
	 * 사용자소속점포코드 반환(get userBlgStoCd 10 0)
	 * </pre>
	 */
	public String getUserBlgStoCd() {
		return userBlgStoCd;
	}

	/**
	 * <pre>
	 * 사용자소속점포코드 설정(get userBlgStoCd 10 0)
	 * </pre>
	 */
	public void setUserBlgStoCd(String userBlgStoCd) {
		this.userBlgStoCd = userBlgStoCd;
	}

	/**
	 * <pre>
	 * 사용자소속점포명 반환(get userBlgStoNm 50 0)
	 * </pre>
	 */
	public String getUserBlgStoNm() {
		return userBlgStoNm;
	}

	/**
	 * <pre>
	 * 사용자소속점포명 설정(set userBlgStoNm 50 0)
	 * </pre>
	 */
	public void setUserBlgStoNm(String userBlgStoNm) {
		this.userBlgStoNm = userBlgStoNm;
	}

	/**
	 * <pre>
	 * 공란 반환(get bln 9 0)
	 * </pre>
	 */
	public String getBln() {
		return bln;
	}

	/**
	 * <pre>
	 * 공란 설정(set bln 9 0)
	 * </pre>
	 */
	public void setBln(String bln) {
		this.bln = bln;
	}

	@Override
	public boolean hasNext() {
		return false;
	}

	@Override
	public String toString() {
		return "KrinMapsCnHdrDto [mesgSndnByteSz=" + mesgSndnByteSz + ", trnCd=" + trnCd + ", dataDv=" + dataDv + ", mesgClsfCd=" + mesgClsfCd + ", trnDvCd=" + trnDvCd + ", onlBatWkId=" + onlBatWkId
				+ ", snDvCd=" + snDvCd + ", dataRcdTcnt=" + dataRcdTcnt + ", rspnCd=" + rspnCd + ", mesgMgNo=" + mesgMgNo + ", mesgSnDt=" + mesgSnDt + ", mesgSnTm=" + mesgSnTm + ", sndnOr=" + sndnOr
				+ ", rcveOr=" + rcveOr + ", userId=" + userId + ", userPwd=" + userPwd + ", userIp=" + userIp + ", userBlgStoCd=" + userBlgStoCd + ", userBlgStoNm=" + userBlgStoNm + ", bln=" + bln
				+ "]";
	}

}
