package cuin.cn.frg.dto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : KfbFrgLkHdrDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.08.08
 * 설    명 : 은행연합회 대외 연계 전문 공통 헤더 DTO.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class KfbFrgLkHdrDto implements FrgLkCnHdrDto {
	private static final long serialVersionUID = 943870078456932265L;

	// 거래 코드
	private String trCode;
	// 시스템 ID
	private String sysTyCode;
	// 금융기관 코드
	private String fincOrgnCode;
	// 전문 종별 코드
	private String msgClasCode;
	// 업무 구분 코드
	private String busiTyCode;
	// 송/수신 Flag
	private String snrFlag;
	// 응답코드
	private String respCode;
	// 점포코드
	private String storCode;
	// 금융기관 전문 관리번호
	private String finstMsgMnNo;
	// 금융기관 전문 전송시간
	private String finstMsgSendTime;
	// 연합회 전문 관리번호
	private String unconMsgMngNo;
	// 연합회 전문 전송시간
	private String unconMsgSendTime;
	// 단말기 조작자 ID
	private String termOperManId;
	// 단말기 조작자 성명 */
	private String termOperManName;
	// 예비 정보 Field */
	private String prptInfoField;

	public String getTrCode() {
		return trCode;
	}

	public void setTrCode(String trCode) {
		this.trCode = trCode;
	}

	public String getSysTyCode() {
		return sysTyCode;
	}

	public void setSysTyCode(String sysTyCode) {
		this.sysTyCode = sysTyCode;
	}

	public String getFincOrgnCode() {
		return fincOrgnCode;
	}

	public void setFincOrgnCode(String fincOrgnCode) {
		this.fincOrgnCode = fincOrgnCode;
	}

	public String getMsgClasCode() {
		return msgClasCode;
	}

	public void setMsgClasCode(String msgClasCode) {
		this.msgClasCode = msgClasCode;
	}

	public String getBusiTyCode() {
		return busiTyCode;
	}

	public void setBusiTyCode(String busiTyCode) {
		this.busiTyCode = busiTyCode;
	}

	public String getSnrFlag() {
		return snrFlag;
	}

	public void setSnrFlag(String snrFlag) {
		this.snrFlag = snrFlag;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

	public String getStorCode() {
		return storCode;
	}

	public void setStorCode(String storCode) {
		this.storCode = storCode;
	}

	public String getFinstMsgMnNo() {
		return finstMsgMnNo;
	}

	public void setFinstMsgMnNo(String finstMsgMnNo) {
		this.finstMsgMnNo = finstMsgMnNo;
	}

	public String getFinstMsgSendTime() {
		return finstMsgSendTime;
	}

	public void setFinstMsgSendTime(String finstMsgSendTime) {
		this.finstMsgSendTime = finstMsgSendTime;
	}

	public String getUnconMsgMngNo() {
		return unconMsgMngNo;
	}

	public void setUnconMsgMngNo(String unconMsgMngNo) {
		this.unconMsgMngNo = unconMsgMngNo;
	}

	public String getUnconMsgSendTime() {
		return unconMsgSendTime;
	}

	public void setUnconMsgSendTime(String unconMsgSendTime) {
		this.unconMsgSendTime = unconMsgSendTime;
	}

	public String getTermOperManId() {
		return termOperManId;
	}

	public void setTermOperManId(String termOperManId) {
		this.termOperManId = termOperManId;
	}

	public String getTermOperManName() {
		return termOperManName;
	}

	public void setTermOperManName(String termOperManName) {
		this.termOperManName = termOperManName;
	}

	public String getPrptInfoField() {
		return prptInfoField;
	}

	public void setPrptInfoField(String prptInfoField) {
		this.prptInfoField = prptInfoField;
	}

	@Override
	public boolean hasNext() {
		return false;
	}

	@Override
	public String toString() {
		return "KfbFrgLkHdrDto [trCode=" + trCode + ", sysTyCode=" + sysTyCode + ", fincOrgnCode=" + fincOrgnCode + ", msgClasCode=" + msgClasCode + ", busiTyCode=" + busiTyCode + ", snrFlag="
				+ snrFlag + ", respCode=" + respCode + ", storCode=" + storCode + ", finstMsgMnNo=" + finstMsgMnNo + ", finstMsgSendTime=" + finstMsgSendTime + ", unconMsgMngNo=" + unconMsgMngNo
				+ ", unconMsgSendTime=" + unconMsgSendTime + ", termOperManId=" + termOperManId + ", termOperManName=" + termOperManName + ", prptInfoField=" + prptInfoField + "]";
	}

}
