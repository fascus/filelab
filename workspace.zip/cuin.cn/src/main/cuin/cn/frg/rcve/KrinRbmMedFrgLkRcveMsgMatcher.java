package cuin.cn.frg.rcve;

import hone.common.util.StringUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.cn.frg.dto.FrgLkCnHdrDto;
import cuin.cn.frg.dto.KrinRbmMedInCnHdrDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : KrinRbmMedFrgLkRcveMsgMatcher.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.11
 * 설    명 : 보험개발원 실손의료보험 대외 수신 전문 검색.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class KrinRbmMedFrgLkRcveMsgMatcher implements FrgLkRcveMsgMatcher {

	private static final Logger logger = LoggerFactory.getLogger(KrinRbmMedFrgLkRcveMsgMatcher.class);

	private int mesgMgCd;

	public KrinRbmMedFrgLkRcveMsgMatcher(int mesgMgCd) {
		this.mesgMgCd = mesgMgCd;
	}

	@Override
	public boolean match(FrgLkRcveMsg frgLkRcveMsg) {
		return match(frgLkRcveMsg, String.valueOf(mesgMgCd));
	}

	@Override
	public boolean match(FrgLkRcveMsg frgLkRcveMsg, String msgKey) {
		int msgNo = StringUtils.parseInt(msgKey);
		// 보험개발원 실손의료보험 헤더 획득
		FrgLkCnHdrDto hdrDto = frgLkRcveMsg.getFrgLkCnHdrDto();
		if (hdrDto instanceof KrinRbmMedInCnHdrDto) {
			// 수신 큐(queue)에 위치한 전문관리번호와 발송 전문관리 번호를 비교...
			int arrivedMesgMgCd = ((KrinRbmMedInCnHdrDto) hdrDto).getMesgMgCd();
			if (logger.isDebugEnabled()) {
				logger.debug("Match mesgMsgCd (for) " + msgNo + ", (received) " + arrivedMesgMgCd);
			}
			return msgNo == arrivedMesgMgCd;
		} else {
			return false;
		}
	}

}
