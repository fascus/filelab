package cuin.cn.frg.rcve;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.online.cn.core.message.header.CommonResponseHeader;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : KfbFrgLkRcveMsgMatcher.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.24
 * 설    명 : 은행연합회 대외 수신 전문 검색.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class KfbFrgLkRcveMsgMatcher implements FrgLkRcveMsgMatcher {

	private static final Logger logger = LoggerFactory.getLogger(KrinMapsFrgLkRcveMsgMatcher.class);

	// 검색 대상 글로벌 ID
	private String globalId;

	/**
	 * @param globalId 글로벌 ID
	 */
	public KfbFrgLkRcveMsgMatcher(String globalId) {
		this.globalId = globalId;
	}

	@Override
	public boolean match(FrgLkRcveMsg frgLkRcveMsg) {
		return match(frgLkRcveMsg, globalId);
	}

	@Override
	public boolean match(FrgLkRcveMsg frgLkRcveMsg, String msgKey) {
		// 전문 공통 헤더 획득
		CommonResponseHeader commonResponseHeader = frgLkRcveMsg.getCommonResponseHeader();
		// 수신 큐(queue)에 위치한 글로벌 ID와 발송 글로벌 ID를 비교...
		String arrivedGlobalId = commonResponseHeader.getGlobId();
		if (logger.isDebugEnabled()) {
			logger.debug("Match global ID (for) : " + globalId + ", (received) " + arrivedGlobalId);
		}
		return msgKey.equals(arrivedGlobalId);
	}

}
