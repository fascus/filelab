package cuin.cn.frg.rcve;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : FrgLkRcveTurnaroundCallback.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.10.17
 * 설    명 : 대외 전문 수신 콜백
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface FrgLkRcveTurnaroundCallback {

	void handleRcveMsg(FrgLkRcveMsg candidate);
}
