package cuin.cn.frg.rcve;

import hone.common.util.StringUtils;
import hone.omm.model.OmmMap;
import hone.omm.provider.OmmProvider;
import hone.omm.unmarshal.HoneOmmUnmarshaller;
import hone.omm.unmarshal.OmmUnmarshaller;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import cuin.cn.frg.cnhdr.CnFrgLkMesgHdrFactory;
import cuin.cn.frg.dto.FrgLkCnHdrDto;
import cuin.cn.frg.dto.FrgLkRcveDto;
import cuin.online.cn.core.message.common.TcpConstants;
import cuin.online.cn.core.message.header.CommonResponseHeader;
import cuin.online.cn.core.message.header.CuinCommonHeader;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : CuinFrgLkInbHandler.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.08
 * 설    명 : 대외 연계 전문 인바운드 핸들러 (inbound handler) 구현체.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CuinFrgLkInbHandler implements FrgLkInbHandler {

	private static final String EAI_RECEIVE = "EAI_RECEIVE";
	private static final Logger logger = LoggerFactory.getLogger(CuinFrgLkInbHandler.class);
	private static final byte[] EMPTY_BYTES = new byte[0];

	private OmmProvider ommProvider;

	@Override
	public void handleInbMsg(byte[] inbData, FrgLkClk frgLkClk) {

		// EAI 수신 로그를 별도 로그 파일로 출력
		MDC.put(TcpConstants.LOG_KEY_CLIENT_IP, EAI_RECEIVE);

		if (logger.isDebugEnabled()) {
			try {
				logger.debug("Foreign message reply (대외 전문 응답) : " + new String(inbData, TcpConstants.DEFAUL_CHARACTER_SET));
			} catch (UnsupportedEncodingException e) {
				logger.error(e.getMessage(), e);
			}
		}

		try {
			// 콜백(callback) 클래스 경로 출력.
			if (logger.isDebugEnabled()) {
				logger.debug("foreign call back class (대외 전문 콜백 클래스) : " + frgLkClk.getClass().getName());
			}

			// 대외 전문 응답 중에서 신협 320 byte 헤더 파싱
			CommonResponseHeader commonResponseHeader = parseCommonHeader(inbData);
			if (logger.isDebugEnabled()) {
				logger.debug("foreign response common header (신협 공통 응답 헤더) : " + commonResponseHeader);
			}

			// 대외 전문 응답 중에서 대외 전문 헤더 파싱
			int hdrLen = 0;
			FrgLkCnHdrDto frgLkCnHdrDto = frgLkClk.getFrgLnkCnHdrDto();
			if (frgLkCnHdrDto != null) {
				hdrLen = CnFrgLkMesgHdrFactory.unmarshall(ommProvider, inbData, frgLkCnHdrDto);
				if (logger.isDebugEnabled()) {
					logger.debug("foreign response header (대외 응답 헤더) : " + frgLkCnHdrDto);
				}
			}

			// 대외 전문 응답 중에서 대외 데이터 파트 파싱
			FrgLkRcveDto frgLkRcveDto = null;
			String rcveOmmId = frgLkClk.getFrgLkRcveOmmId();
			byte[] rcveBytes = EMPTY_BYTES;
			if (!StringUtils.isEmpty(rcveOmmId)) {
				OmmMap frgLnkMesgHeaderOmmMap = ommProvider.get(rcveOmmId);
				if (logger.isDebugEnabled()) {
					logger.debug("Receive data OMM ID : " + rcveOmmId);
					logger.debug("Receive data DTO class : " + frgLnkMesgHeaderOmmMap.getTargetClassName());
				}
				int startIdx = TcpConstants.MSG_HEADER_LENGTH + hdrLen;
				OmmUnmarshaller outHeaderUnmarshaller = new HoneOmmUnmarshaller(frgLnkMesgHeaderOmmMap, new ByteArrayInputStream(inbData, startIdx, inbData.length - startIdx - 2));
				frgLkRcveDto = (FrgLkRcveDto) outHeaderUnmarshaller.read();
				rcveBytes = Arrays.copyOfRange(inbData, startIdx, inbData.length - 2);
			} else {
				logger.error("foreign response message body OMM ID is null");
			}
			if (logger.isDebugEnabled()) {
				logger.debug("foreign response data (대외 응답 데이터) : " + frgLkRcveDto);
			}

			// 응답 데이터를 수신 메시지 큐에 추가...
			FrgLkRcveMsg frgLkRcveMsg = new FrgLkRcveMsg(commonResponseHeader, frgLkCnHdrDto, frgLkRcveDto);
			if (hdrLen > 0) {
				frgLkRcveMsg.setLkCnHdrBytes(Arrays.copyOfRange(inbData, TcpConstants.MSG_HEADER_LENGTH, TcpConstants.MSG_HEADER_LENGTH + hdrLen));
			}
			frgLkRcveMsg.setRcveBytes(rcveBytes);
			FrgLkRcveMsgQueue.add(frgLkRcveMsg);
		} catch (Exception e) {
			logger.error("Error while handle received foreign message.", e);
		}

		MDC.remove(TcpConstants.LOG_KEY_CLIENT_IP);
	}

	/**
	 * 입출력 전문 파싱을 위한 OMM 맵 목록을 제공하는 프로바이더 설정
	 */
	@Override
	public void setOmmProvider(OmmProvider ommProvider) {
		this.ommProvider = ommProvider;
	}

	/**
	 * 응답 전문 헤더 파싱
	 * 
	 * @param msgBuffer 전문 헤더 버퍼
	 * @return 응답 전문 헤더 객체
	 */
	private CommonResponseHeader parseCommonHeader(byte[] msgBuffer) {
		CommonResponseHeader responseHeader;
		OmmMap inHeaderOmmMap = ommProvider.get(CuinCommonHeader.COMMON_OUT_HEADER);
		OmmUnmarshaller<CommonResponseHeader> inputHeaderUnmarshaller = new HoneOmmUnmarshaller<CommonResponseHeader>(inHeaderOmmMap, new ByteArrayInputStream(msgBuffer, 0,
				TcpConstants.MSG_HEADER_LENGTH));
		try {
			responseHeader = inputHeaderUnmarshaller.read();
		} catch (Exception e) {
			throw new IllegalStateException("Invalid message header. (잘못된 전문 헤더 오류)", e);
		}

		return responseHeader;
	}

}
