package cuin.cn.frg.rcve;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : FrgLkRcveMsgMatcher.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.11
 * 설    명 : 대외 전문 응답 메시지 검색.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface FrgLkRcveMsgMatcher {

	/**
	 * 대외 전문 응답 큐에 포함된 메시지가 검색 대상이 맞는지 여부를 반환
	 * 
	 * @param frgLkRcveMsg 대외 전문 응답 큐에 존재하는 메시지
	 * @return 메시지가 검색 대상이 맞다면 true, 아니면 false 반환
	 */
	boolean match(FrgLkRcveMsg frgLkRcveMsg);

	/**
	 * 대외 전문 응답 큐에 포함된 메시지가 검색 대상이 맞는지 여부를 반환
	 * 
	 * @param frgLkRcveMsg 대외 전문 응답 큐에 존재하는 메시지
	 * @param msgKey 전문 ID
	 * @return 메시지가 검색 대상이 맞다면 true, 아니면 false 반환
	 */
	boolean match(FrgLkRcveMsg frgLkRcveMsg, String msgKey);
}
