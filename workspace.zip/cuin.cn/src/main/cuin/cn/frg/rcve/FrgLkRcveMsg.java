package cuin.cn.frg.rcve;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;

import cuin.cn.exception.CuinException;
import cuin.cn.frg.dto.FrgLkCnHdrDto;
import cuin.cn.frg.dto.FrgLkRcveDto;
import cuin.online.cn.core.message.common.TcpConstants;
import cuin.online.cn.core.message.header.CommonResponseHeader;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : FrgLkRcveMsg.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.08
 * 설    명 : 대외 전문 응답 메시지 객체.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class FrgLkRcveMsg implements Serializable {

	private static final long serialVersionUID = -4004139812132172899L;
	private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];

	// 신협 표준 전문 헤더
	private CommonResponseHeader commonResponseHeader;
	// 대외 응답 전문 공통 헤더
	private FrgLkCnHdrDto frgLkCnHdrDto;
	// 대외 응답 전문 헤더 바이트 배열
	private byte[] lkCnHdrBytes;
	// 대외 응답 전문 데이터
	private FrgLkRcveDto frgLkRcveDto;
	// 대외 응답 전문 데이터 바이트 배열
	private byte[] frgLkRcveBytes;

	public FrgLkRcveMsg(CommonResponseHeader commonResponseHeader, FrgLkCnHdrDto frgLkCnHdrDto, FrgLkRcveDto frgLkRcveDto) {
		this.commonResponseHeader = commonResponseHeader;
		this.frgLkCnHdrDto = frgLkCnHdrDto;
		this.frgLkRcveDto = frgLkRcveDto;
		this.lkCnHdrBytes = EMPTY_BYTE_ARRAY;
	}

	/**
	 * 대외 응답 전문 / 신협 공통 응답 헤더
	 */
	public CommonResponseHeader getCommonResponseHeader() {
		return commonResponseHeader;
	}

	/**
	 * 대외 응답 전문 / 대외 공통 응답 헤더
	 */
	public FrgLkCnHdrDto getFrgLkCnHdrDto() {
		return frgLkCnHdrDto;
	}

	/**
	 * 대외 응답 전문 / 응답 데이터
	 */
	public FrgLkRcveDto getFrgLkRcveDto() {
		return frgLkRcveDto;
	}

	@Override
	public String toString() {
		return "FrgLkRcveMsg [commonResponseHeader=" + commonResponseHeader + ", frgLkCnHdrDto=" + frgLkCnHdrDto + ", frgLkRcveDto=" + frgLkRcveDto + "]";
	}

	/**
	 * 응답 전문 헤더(바이트 형식) 설정
	 */
	public void setLkCnHdrBytes(byte[] lkCnHdrBytes) {
		this.lkCnHdrBytes = new byte[lkCnHdrBytes.length];
		System.arraycopy(lkCnHdrBytes, 0, this.lkCnHdrBytes, 0, lkCnHdrBytes.length);
	}

	/**
	 * 응답 전문 데이터 영역(바이트 형식) 설정
	 */
	public void setRcveBytes(byte[] frgLkRcveBytes) {
		this.frgLkRcveBytes = new byte[frgLkRcveBytes.length];
		System.arraycopy(frgLkRcveBytes, 0, this.frgLkRcveBytes, 0, frgLkRcveBytes.length);
	}

	/**
	 * 대외 응답 전문 헤더 + 데이터 바이트 배열
	 */
	public String getRcveBytes() {
		byte[] headerAndData = new byte[lkCnHdrBytes.length + frgLkRcveBytes.length];
		System.arraycopy(lkCnHdrBytes, 0, headerAndData, 0, lkCnHdrBytes.length);
		System.arraycopy(frgLkRcveBytes, 0, headerAndData, lkCnHdrBytes.length, frgLkRcveBytes.length);
		String retStr = null;

		try {
			retStr = new String(headerAndData, TcpConstants.DEFAUL_CHARACTER_SET);
		} catch (UnsupportedEncodingException e) {
			throw new CuinException(e.getMessage(), e);
		}
		return retStr;
	}
}
