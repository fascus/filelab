package cuin.cn.frg.rcve;

import hone.common.util.EnvUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.cn.frg.dto.FrgLkCnHdrDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : FrgLkRcveMsgQueue.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.08
 * 설    명 : 대외 응답 전문 큐 (queue).
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class FrgLkRcveMsgQueue {

	private static final Logger logger = LoggerFactory.getLogger(FrgLkRcveMsgQueue.class);

	private static final String EAI_RCVE_QUEUE_FILE_NAME = "eaiRcveQueue.bin";
	private static final List<FrgLkRcveMsg> rcveMsgList = new ArrayList<FrgLkRcveMsg>();

	public static void add(FrgLkRcveMsg frgLkRcveMsg) {
		synchronized (rcveMsgList) {
			rcveMsgList.add(frgLkRcveMsg);
			storeQueueFile();
		}
	}

	public static List<FrgLkRcveMsg> lookup(FrgLkRcveMsgMatcher finder) {

		synchronized (rcveMsgList) {
			loadQueueFile();

			List<FrgLkRcveMsg> candidateList = null;
			boolean catchAll = false;
			for (FrgLkRcveMsg candidate : rcveMsgList) {
				if (finder.match(candidate)) {
					if (candidateList == null) {
						candidateList = new ArrayList<FrgLkRcveMsg>();
					}
					candidateList.add(candidate);
					if (!catchAll) {
						FrgLkCnHdrDto frgLkCnHdrDto = candidate.getFrgLkCnHdrDto();
						catchAll = (frgLkCnHdrDto == null || !frgLkCnHdrDto.hasNext());
					}
				}
			}

			if (catchAll) {
				if (logger.isDebugEnabled()) {
					logger.debug("Foreign message successfule received. messages count = " + candidateList.size());
					for (FrgLkRcveMsg frgLkRcveMsg : candidateList) {
						logger.debug("Foreign message received : " + frgLkRcveMsg);
					}
				}
				rcveMsgList.removeAll(candidateList);
				storeQueueFile();
				return candidateList;
			} else {
				if (candidateList != null) {
					logger.warn("Not all messsages received. Catched messages count = " + candidateList.size());
				}
				return null;
			}
		}
	}

	public static List<FrgLkRcveMsg> getRcveMsgList() {
		loadQueueFile();
		return rcveMsgList;
	}

	public static void log() {
		if (logger.isDebugEnabled()) {
			for (FrgLkRcveMsg frgLkRcveMsg : rcveMsgList) {
				logger.debug("FrgLkRcveMsg : " + frgLkRcveMsg.toString());
			}
		}
	}

	private static void storeQueueFile() {
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		FileLock fl = null;

		try {
			String queueFilePath = getQueueFilePath();
			fos = new FileOutputStream(queueFilePath);
			fl = fos.getChannel().lock();

			oos = new ObjectOutputStream(fos);
			oos.writeInt(rcveMsgList.size());
			for (FrgLkRcveMsg frgLkRcveMsg : rcveMsgList) {
				oos.writeObject(frgLkRcveMsg);
			}
		} catch (Exception e) {
			logger.error("Cannot write to serialization file", e);
		} finally {
			try {
				if (fl != null) {
					fl.release();
				}
				if (oos != null) {
					oos.close();
				}
			} catch (IOException e) {
				logger.error("Error while close serialization file", e);
			}
		}
	}

	private static void loadQueueFile() {
		FileInputStream fis = null;
		ObjectInputStream ois = null;

		try {
			String queueFilePath = getQueueFilePath();
			fis = new FileInputStream(queueFilePath);
			ois = new ObjectInputStream(fis);

			rcveMsgList.clear();
			int rcveMsgCount = ois.readInt();

			for (int i = 0; i < rcveMsgCount; i++) {
				FrgLkRcveMsg frgLkRcveMsg = (FrgLkRcveMsg) ois.readObject();
				rcveMsgList.add(frgLkRcveMsg);
			}

			if (logger.isDebugEnabled()) {
				logger.debug("After load message queue. received message count = " + rcveMsgList.size());
			}
		} catch (FileNotFoundException e) {
			if (logger.isDebugEnabled()) {
				logger.debug(EAI_RCVE_QUEUE_FILE_NAME + " does not exist.");
			}
		} catch (Exception e) {
			logger.error("Cannot read serialization file", e);
		} finally {
			try {
				if (ois != null) {
					ois.close();
				}
			} catch (IOException e) {
				logger.error("Error while close serialization file", e);
			}
		}
	}

	private static String getQueueFilePath() {
		return EnvUtils.getProperty("eai.rcve.queue.file.location") + File.separator + EAI_RCVE_QUEUE_FILE_NAME;
	}

}
