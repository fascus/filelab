package cuin.cn.frg.rcve;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.cn.exception.CuinEAIException;
import cuin.cn.exception.CuinException;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : FrgLkRcveWatcher.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.09.08
 * 설    명 : 대외 응답 전문 감시기.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class FrgLkRcveWatcher {

	// 매 인터벌 마다 0.5 초간 대기
	private static final int WAIT_PERIOD = 500;
	// 최대 15초 간 대외 전문 수신 대기...
	private static final int MAX_WAIT_COUNT = 30;

	private static final Logger logger = LoggerFactory.getLogger(FrgLkRcveWatcher.class);

	/**
	 * 단일 전문 수신 대기 (최대 15초 간 대기).
	 * 
	 * @param frgLkRcveMsgFinder 대외 수신 전문 비교
	 * @return 수신(응답) 전문
	 */
	public static final FrgLkRcveMsg waitFor(FrgLkRcveMsgMatcher frgLkRcveMsgFinder) {
		return watch(frgLkRcveMsgFinder, MAX_WAIT_COUNT).get(0);
	}

	/**
	 * 단일 전문 수신 대기 (지정한 시간만큼 대기).
	 * 
	 * @param frgLkRcveMsgFinder
	 * @param maxWait 최대 대기 시간 (단위 : 초).
	 * @return 수신(응답) 전문
	 */
	public static final FrgLkRcveMsg waitFor(FrgLkRcveMsgMatcher frgLkRcveMsgFinder, int maxWait) {
		return watch(frgLkRcveMsgFinder, maxWait * 2).get(0);
	}

	/**
	 * 반복 (연속 조회) 전문 수신 (최대 15초 간 대기).
	 * 
	 * @param frgLkRcveMsgMatcher 대외 수신 전문 비교
	 * @return 수신(응답) 전문
	 */
	public static final List<FrgLkRcveMsg> waitForList(FrgLkRcveMsgMatcher frgLkRcveMsgMatcher) {
		return watch(frgLkRcveMsgMatcher, MAX_WAIT_COUNT);
	}

	/**
	 * 반복 (연속 조회) 전문 수신 (지정한 시간만큼 대기).
	 * 
	 * @param frgLkRcveMsgMatcher 대외 수신 전문 비교
	 * @param maxWait 최대 대기 시간 (단위 : 초)
	 * @return 수신(응답) 전문
	 */
	public static final List<FrgLkRcveMsg> waitForList(FrgLkRcveMsgMatcher frgLkRcveMsgMatcher, int maxWait) {
		return watch(frgLkRcveMsgMatcher, maxWait * 2);
	}

	private static List<FrgLkRcveMsg> watch(FrgLkRcveMsgMatcher frgLkRcveMsgMatcher, int maxWaitCount) {
		int waitHopCount = 0;
		while (waitHopCount < maxWaitCount) {

			if (logger.isDebugEnabled()) {
				logger.debug("Wait for foreign message, hop count = " + waitHopCount);
			}

			try {
				Thread.sleep(WAIT_PERIOD);
			} catch (InterruptedException e) {
				String errMsg = "Error while watching foreign message response.";
				logger.error(errMsg, e);
				throw new CuinException(errMsg, e);
			}

			List<FrgLkRcveMsg> frgLkRcveMsgList = FrgLkRcveMsgQueue.lookup(frgLkRcveMsgMatcher);
			if (frgLkRcveMsgList != null) {
				return frgLkRcveMsgList;
			}
			waitHopCount++;
		}

		FrgLkRcveMsgQueue.log();
		throw new CuinEAIException("Foreign response message not arrived.");

	}
}
