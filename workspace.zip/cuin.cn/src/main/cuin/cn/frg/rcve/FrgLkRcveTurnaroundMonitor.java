package cuin.cn.frg.rcve;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.cn.exception.CuinException;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : FrgLkRcveTurnaroundMonitor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.10.18
 * 설    명 : 대외 전문 수신 모니터
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class FrgLkRcveTurnaroundMonitor extends Thread {

	private static final Logger logger = LoggerFactory.getLogger(FrgLkRcveTurnaroundMonitor.class);
	// 매 구간 마다 0.5 초간 대기
	private static final int WAIT_PERIOD = 1000;
	// 최대 대기 시간
	private static final int MAX_HOP_COUNT = 60;

	private int waitHopCount;
	private List<String> msgKeyList = new ArrayList<String>();
	private CountDownLatch countDownLatch;
	private FrgLkRcveMsgMatcher frgLkRcveMsgMatcher;
	private FrgLkRcveTurnaroundCallback frgLkRcveTurnaroundCallback;

	public FrgLkRcveTurnaroundMonitor(CountDownLatch countDownLatch, FrgLkRcveMsgMatcher frgLkRcveMsgMatcher, FrgLkRcveTurnaroundCallback frgLkRcveTurnaroundCallback) {
		this.countDownLatch = countDownLatch;
		this.frgLkRcveMsgMatcher = frgLkRcveMsgMatcher;
		this.frgLkRcveTurnaroundCallback = frgLkRcveTurnaroundCallback;
	}

	/**
	 * 송신 전문 키(key) 추가
	 */
	public void appendMsgKey(String key) {
		synchronized (msgKeyList) {
			msgKeyList.add(key);
		}
	}

	public void run() {
		do {
			try {
				Thread.sleep(WAIT_PERIOD);
			} catch (InterruptedException e) {
				String errMsg = "Error while watching foreign message response.";
				logger.error(errMsg, e);
				throw new CuinException(errMsg, e);
			}

			synchronized (msgKeyList) {
				List<FrgLkRcveMsg> frgLkRcveMsgList = FrgLkRcveMsgQueue.getRcveMsgList();
				for (FrgLkRcveMsg candidate : frgLkRcveMsgList) {
					for (String msgKey : msgKeyList) {
						if (frgLkRcveMsgMatcher.match(candidate, msgKey)) {
							frgLkRcveTurnaroundCallback.handleRcveMsg(candidate);
						}
					}
				}

			}

		} while (waitHopCount++ < MAX_HOP_COUNT);

		countDownLatch.countDown();
	}
}
