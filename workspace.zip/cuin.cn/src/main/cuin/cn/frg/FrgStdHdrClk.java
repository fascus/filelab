package cuin.cn.frg;

import cuin.online.cn.core.message.header.CommonRequestHeader;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : FrgStdHdrClk.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.08.13
 * 설    명 : 대외 연계 송신 시 표준 전문 헤더 설정을 위한 콜백 인터페이스.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public interface FrgStdHdrClk {
	/**
	 * 표준 전문 공통 헤더 설정.
	 * 
	 * @param commonRequestHeader 설정을 위한 표준 전문 공통 헤더
	 */
	void updateStdHdr(CommonRequestHeader commonRequestHeader);
}
