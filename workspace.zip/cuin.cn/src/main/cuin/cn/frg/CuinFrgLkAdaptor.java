package cuin.cn.frg;

import hone.common.util.DateUtils;
import hone.common.util.StringUtils;
import hone.core.util.ApplicationContextHolder;
import hone.omm.marshall.HoneOmmMarshaller;
import hone.omm.marshall.OmmMarshaller;
import hone.omm.marshall.convert.DefaultDateConverter;
import hone.omm.marshall.writer.FixedLengthStreamWriter;
import hone.omm.model.OmmMap;
import hone.omm.provider.OmmProvider;
import hone.omm.unmarshal.HoneOmmUnmarshaller;
import hone.omm.unmarshal.OmmUnmarshaller;
import hone.omm.value.ObjectValueMapper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import cuin.cn.eai.EaiAdaptor;
import cuin.cn.frg.cnhdr.CnFrgLkMesgHdrFactory;
import cuin.cn.frg.dto.FrgLkCnHdrDto;
import cuin.cn.frg.dto.FrgLkSndnDto;
import cuin.cn.service.ServiceContext;
import cuin.online.cn.core.message.common.TcpConstants;
import cuin.online.cn.core.message.header.CommonRequestHeader;
import cuin.online.cn.core.message.header.CuinCommonHeader;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : CuinFrgLkAdaptor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.08.08
 * 설    명 : 신협공제 대외 전문 송신 구현체.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CuinFrgLkAdaptor implements FrgLkAdaptor {
	private static final Logger logger = LoggerFactory.getLogger(CuinFrgLkAdaptor.class);
	private static final Charset DEFAULT_CHARSET = Charset.forName(TcpConstants.DEFAUL_CHARACTER_SET);

	// '전문 종료 표시' 필드 길이
	private static final int MSG_END_MARKER_LENGTH = 2;
	// '전문 종료 표시' 필드 데이터
	private static final String MSG_END_MARKER = "ZZ";
	// EAI 인터페이스 빈
	EaiAdaptor eaiAdaptor;

	// 대외 전문 공통 헤더 DTO
	private FrgLkCnHdrDto frgLkCnHdrDto;
	// 대외 전문 데이터 DTO
	private FrgLkSndnDto sndnDto;
	// 대외 전문 데이터 OMM Map ID
	private String sndnOmmId;

	// 표준 전문 헤더 설정 콜백
	private FrgStdHdrClk stdHdrClk;

	// 대외 전문 전체 데이터 (공통 전문 헤더 포함)
	private byte[] sendDataBytes;

	private int globalIdSeq;
	private String lastDateTime;

	@Override
	public void setStdHdrClk(FrgStdHdrClk stdHdrClk) {
		this.stdHdrClk = stdHdrClk;
	}

	@Override
	public void setFrgCnHdr(FrgLkCnHdrDto frgLnkCnHdrDto) {
		this.frgLkCnHdrDto = frgLnkCnHdrDto;
		sendDataBytes = null;
	}

	@Override
	public void setSndnDto(FrgLkSndnDto sndnDto, String sndnOmmId) {
		this.sndnDto = sndnDto;
		this.sndnOmmId = sndnOmmId;
		sendDataBytes = null;
	}

	@Override
	public void send(String interfaceId) {

		if (sndnDto == null || StringUtils.isEmpty(sndnOmmId)) {
			throw new IllegalStateException("sndnDto or sndnOmmId is missing. (전문 데이터 DTO 및 OMM ID를 설정하시기 바랍니다).");
		}

		// EAI 어댑터 빈 획득...
		popEaiAdaptorBean();
		// EAI 를 통해 대외 전문 송신 ...
		buildRequestMsg(interfaceId);
		eaiAdaptor.send(interfaceId, sendDataBytes);
	}

	private void popEaiAdaptorBean() {
		if (eaiAdaptor == null) {
			eaiAdaptor = ApplicationContextHolder.getApplicationContext().getBean(EaiAdaptor.class);
			if (eaiAdaptor == null) {
				throw new IllegalStateException("Cannot find EAI Adaptor bean. check environment settings.");
			}
		}
	}

	/**
	 * 신협 표준 헤더 및 전문 종료 파트('ZZ')를 제외한 송신 데이터 반환.
	 * 
	 * @return 대외 전문 송신 데이터 반환
	 */
	public String getLnMesg() {

		buildRequestMsg(null);

		int outMsgLen = sendDataBytes.length - (TcpConstants.MSG_HEADER_LENGTH + 2);
		byte[] outMsgBuf = new byte[outMsgLen];
		System.arraycopy(sendDataBytes, TcpConstants.MSG_HEADER_LENGTH, outMsgBuf, 0, outMsgLen);
		String retVal = new String(outMsgBuf, DEFAULT_CHARSET);

		if (logger.isDebugEnabled()) {
			logger.debug("Foreign link send message data length is [" + outMsgBuf.length + "] bytes, [" + retVal.length() + "] character.");
		}

		return retVal;
	}

	/**
	 * 송신 데이터를 DTO 형태로 복원
	 */
	public FrgLkDtoBundle parseRequestMsg(byte msg[], String frgLkCnHdrOmmId, String frgLkDataOmmId) {

		// 전문 언마샬링을 위한 OMM 프로바이더 초기화
		OmmProvider ommProvider = prepareOmmProvider();

		// 대외 전문 헤더 언마샬...
		OmmMap frgLkMesgHeaderOmmMap = ommProvider.get(frgLkCnHdrOmmId);
		int hdrLen = frgLkMesgHeaderOmmMap.getInLength();
		OmmUnmarshaller frgLkHeaderUnmarshaller = new HoneOmmUnmarshaller(frgLkMesgHeaderOmmMap, new ByteArrayInputStream(msg, 0, hdrLen));
		FrgLkCnHdrDto frgLkHdrDto = (FrgLkCnHdrDto) frgLkHeaderUnmarshaller.read();

		// 대외 전문 데이터 언마샬...
		OmmMap frgLkMesgDataOmmMap = ommProvider.get(frgLkDataOmmId);
		OmmUnmarshaller frgLkMesgDataUnmarshaller = new HoneOmmUnmarshaller(frgLkMesgDataOmmMap, new ByteArrayInputStream(msg, hdrLen, msg.length));
		FrgLkSndnDto frgLkSndnDto = (FrgLkSndnDto) frgLkMesgDataUnmarshaller.read();

		return new FrgLkDtoBundle(frgLkHdrDto, frgLkSndnDto);
	}

	private void buildRequestMsg(String interfaceId) {
		if (sendDataBytes != null) {
			return;
		}

		// 전문 마샬링을 위한 OMM 프로바이더 초기화
		OmmProvider ommProvider = prepareOmmProvider();

		// 대외 연계 전문 공통 헤더 생성
		byte[] lnMesgHdrBytes = null;
		if (frgLkCnHdrDto != null) {
			lnMesgHdrBytes = CnFrgLkMesgHdrFactory.marshall(ommProvider, frgLkCnHdrDto);
		} else {
			lnMesgHdrBytes = new byte[0];
		}
		// 대외 연계 전문 데이터 파트 생성
		byte[] lnMesgBodyBytes = buildBodyBytes(ommProvider);
		// 대외 연계 전문 길이 계산
		int frgLkMsgLen = lnMesgHdrBytes.length + lnMesgBodyBytes.length;

		// 표준 헤더를 포함한 전문 길이 계산
		int wholeMsgLength = TcpConstants.MSG_HEADER_LENGTH + frgLkMsgLen + MSG_END_MARKER_LENGTH;

		// 온라인 서비스 전문 헤더를 이용해 전문 공통 헤더를 생성.
		CommonRequestHeader requestHeader = (CommonRequestHeader) ServiceContext.getSysAttr(ServiceContext.ContextSysAttr.REQUEST_HEADER);
		// 온라인 서비스에서 대외 연동 호출 시, 전문 일련번호 1 증가
		if (requestHeader != null) {
			int trxSeq = Integer.parseInt(requestHeader.getTrxseq(), 10) + 1;
			requestHeader.setTrxseq(String.format("%02d", trxSeq));
		}
		// 배치 어플리케이션에서 대외 연동 호출 시, 전문 공통 헤더를 직접 조립
		else {
			requestHeader = generateCommonRequestHeader(interfaceId);
		}
		// 전문 길이 설정 (전문길이 필드의 사이즈만큼 차감)
		requestHeader.setMsgLen(wholeMsgLength - TcpConstants.MSG_LEN_FIELD_SIZE);
		// 전문 공통 헤더 설정 콜백이 설정된 경우, 콜백 메소드 호출
		if (stdHdrClk != null) {
			stdHdrClk.updateStdHdr(requestHeader);
		}

		// 전문 공통 헤더 마샬링
		OmmMap cnHdrOmmMap = ommProvider.get(CuinCommonHeader.COMMON_IN_HEADER);
		ByteArrayOutputStream headerOut = new ByteArrayOutputStream();
		FixedLengthStreamWriter streamWriter = new FixedLengthStreamWriter(cnHdrOmmMap, headerOut);
		streamWriter.setDateConverter(new DefaultDateConverter());
		OmmMarshaller headerMarshaller = new HoneOmmMarshaller(cnHdrOmmMap, streamWriter, new ObjectValueMapper());

		headerMarshaller.write(requestHeader);
		byte[] headerPart = headerOut.toByteArray();

		// 응답 전문 전체 텍스트 생성
		byte[] wholeMsgBuf = new byte[wholeMsgLength];
		int pos = 0;

		// 표준 전문 헤더 출력
		System.arraycopy(headerPart, 0, wholeMsgBuf, pos, TcpConstants.MSG_HEADER_LENGTH);
		pos += TcpConstants.MSG_HEADER_LENGTH;

		// 대외 전문 헤더 파트
		if (lnMesgHdrBytes.length > 0) {
			System.arraycopy(lnMesgHdrBytes, 0, wholeMsgBuf, pos, lnMesgHdrBytes.length);
			pos += lnMesgHdrBytes.length;
		}

		// 대외 전문 데이터 파트 출력
		if (lnMesgBodyBytes.length > 0) {
			System.arraycopy(lnMesgBodyBytes, 0, wholeMsgBuf, pos, lnMesgBodyBytes.length);
			pos += lnMesgBodyBytes.length;
		}

		// 전문 종료 파트 출력
		System.arraycopy(MSG_END_MARKER.getBytes(), 0, wholeMsgBuf, pos, 2);

		// 대외 연계 전문 송신 로그 출력
		if (logger.isDebugEnabled()) {
			logger.debug("Foreign linked request message :\n----- ----- -----\n" + new String(wholeMsgBuf, DEFAULT_CHARSET) + "\n----- ----- -----\nTotal message length = " + wholeMsgBuf.length);
		}

		sendDataBytes = wholeMsgBuf;
	}

	/*
	 * 전문 공통 헤더 생성 (배치 프로그램에서 호출 시)
	 */
	private CommonRequestHeader generateCommonRequestHeader(String interfaceId) {
		CommonRequestHeader commonRequestHeader = new CommonRequestHeader();
		// 전사 공통 키 설정
		commonRequestHeader.setGlobId(generateGlobalId());
		// 진행번호 설정
		commonRequestHeader.setTrxseq("00");
		// 거래코드 (인터페이스 ID 설정)
		commonRequestHeader.setRecvSvcC(interfaceId);
		// 요청/응답 구분
		commonRequestHeader.setRqstRespG("S");
		// FIXME 클라이언트 IP 주소
		commonRequestHeader.setClientIpNo("");
		// 조합/중앙회 구분
		commonRequestHeader.setGrpcoC("1");
		// EAI 인터페이스 동기 구분
		commonRequestHeader.setSyncG("A");
		// EAI 인터페이스 비동기 속성
		commonRequestHeader.setSyncG("1");
		// EAI 인터페이스/XA 거래 구분
		commonRequestHeader.setEaiTrxG(0);
		// TTL 사용 여부
		commonRequestHeader.setTtlUseYn(0);
		// 송신 인터페이스 구분
		commonRequestHeader.setSndInfcG(5);
		// 거래 기준일자 및 전송 일시
		String nowDateTime = DateUtils.getDateTimeString();
		commonRequestHeader.setTxDate(nowDateTime.substring(0, 8));
		commonRequestHeader.setMsgSndMsgIlsi(nowDateTime);
		return commonRequestHeader;
	}

	/*
	 * 전사 공통 키 생성 (30 byte)
	 */
	private String generateGlobalId() {

		StringBuilder globalIdBuf = new StringBuilder();
		String nowDateTime = DateUtils.getDateTimeString();
		// 시스템 일자 (8)
		globalIdBuf.append(nowDateTime.substring(0, 8));
		// 시스템 명칭 (5)
		globalIdBuf.append("BATCH");
		// 시스템 시각 (6)
		globalIdBuf.append(nowDateTime.substring(8));
		// filler (3)
		globalIdBuf.append("000");

		if (nowDateTime.equals(lastDateTime)) {
			globalIdSeq++;
		} else {
			lastDateTime = nowDateTime;
			globalIdSeq = 0;
		}
		// 일련번호 (8)
		globalIdBuf.append(String.format("%08d", globalIdSeq));

		return globalIdBuf.toString();
	}

	/*
	 * OMM provider 반환
	 */
	private OmmProvider prepareOmmProvider() {
		ApplicationContext applicationContext = ApplicationContextHolder.getApplicationContext();
		OmmProvider ommProvider = applicationContext.getBean(OmmProvider.class);
		if (ommProvider == null) {
			throw new IllegalStateException("Cannot find OMM Provider bean. check environment settings.");
		}
		return ommProvider;
	}

	/*
	 * 대외 전문 요청 데이터 파트 생성
	 * 
	 * @param extInDto 대외 전문 입력 DTO
	 * 
	 * @param ommInMapId 입력 전문 OMM ID
	 * 
	 * @return 대외 전문 요청 데이터
	 */
	private byte[] buildBodyBytes(OmmProvider ommProvider) {

		if (sndnDto == null || StringUtils.isEmpty(sndnOmmId)) {
			throw new IllegalStateException("sndnDto or sndnOmmId is missing. (전문 데이터 DTO 및 OMM ID를 설정하시기 바랍니다).");
		}

		OmmMap ommInMap = ommProvider.get(sndnOmmId);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		FixedLengthStreamWriter streamWriter = new FixedLengthStreamWriter(ommInMap, baos);
		streamWriter.setDateConverter(new DefaultDateConverter());
		OmmMarshaller bodyMarshaller = new HoneOmmMarshaller(ommInMap, streamWriter, new ObjectValueMapper());
		bodyMarshaller.write(sndnDto);
		return baos.toByteArray();
	}

}
