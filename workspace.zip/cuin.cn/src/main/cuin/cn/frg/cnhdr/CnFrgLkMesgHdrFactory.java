package cuin.cn.frg.cnhdr;

import hone.omm.marshall.HoneOmmMarshaller;
import hone.omm.marshall.OmmMarshaller;
import hone.omm.marshall.convert.DefaultDateConverter;
import hone.omm.marshall.writer.FixedLengthStreamWriter;
import hone.omm.model.OmmMap;
import hone.omm.provider.OmmProvider;
import hone.omm.unmarshal.HoneOmmUnmarshaller;
import hone.omm.unmarshal.OmmUnmarshaller;
import hone.omm.value.ObjectValueMapper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import cuin.cn.frg.dto.FrgLkCnHdrDto;
import cuin.cn.frg.dto.KfbFrgLkHdrDto;
import cuin.cn.frg.dto.KrinMapsCnHdrDto;
import cuin.cn.frg.dto.KrinRbmMedInCnHdrDto;
import cuin.cn.util.BeanUtils;
import cuin.online.cn.core.message.common.TcpConstants;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 대외 인터페이스
 * 파 일 명 : CnFrgLkMesgHdrFactory.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.08.08
 * 설    명 : 신협공제 대외 연계 전문 헤더 팩토리.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CnFrgLkMesgHdrFactory {
	// 은행연합회 대외 연계 전문 공통 헤더 OMM ID
	private static final String KFB_FRG_LK_HDR_OMM_ID = "cuin.cn.frg.omm.KfbFrgLkHdr";
	// 보험개발원 실손의료보험 대외 연계 전문 공통 헤더 OMM ID
	private static final String KRIN_RBM_MED_IN_CN_HDR_OMM_ID = "cuin.cn.frg.omm.KrinRbmMedInCnHdr";
	// 보험개발원 MAPS 대외 연계 전문 공통 헤더 OMM DI
	private static final String KRIN_MAPS_CN_HDR_OMM_ID = "cuin.cn.frg.omm.KrinMapsCnHdr";

	/**
	 * 대외 연계 전문 공통 헤더 반환
	 */
	public static byte[] marshall(OmmProvider ommProvider, FrgLkCnHdrDto frgLnkCnHdrDto) {

		if (frgLnkCnHdrDto == null) {
			throw new IllegalArgumentException("FrgLkCnHdrDto is null. (공통 헤더 DTO 객체가 null 입니다.)");
		}

		// 공통 헤더 OMM ID 획득
		String frgLkMesgCnHdrOmmId = lookupFrgLkMesgCnHdrOmmId(frgLnkCnHdrDto);

		// 대외 연계 전문 공통 헤더 마샬링
		OmmMap frgLnkMesgHeaderOmmMap = ommProvider.get(frgLkMesgCnHdrOmmId);
		ByteArrayOutputStream headerOutStream = new ByteArrayOutputStream();
		FixedLengthStreamWriter streamWriter = new FixedLengthStreamWriter(frgLnkMesgHeaderOmmMap, headerOutStream);
		streamWriter.setDateConverter(new DefaultDateConverter());
		OmmMarshaller<FrgLkCnHdrDto> headerMarshaller = new HoneOmmMarshaller<FrgLkCnHdrDto>(frgLnkMesgHeaderOmmMap, streamWriter, new ObjectValueMapper());
		headerMarshaller.write(frgLnkCnHdrDto);

		return headerOutStream.toByteArray();
	}

	/**
	 * 대외 연계 전문 공통 헤더 언마샬링
	 * 
	 * @param frgLkCnHdrDto 대외 전문 헤더 객체
	 */
	public static int unmarshall(OmmProvider ommProvider, byte[] inbData, FrgLkCnHdrDto frgLnkCnHdrDto) {

		if (frgLnkCnHdrDto == null) {
			throw new IllegalArgumentException("FrgLkCnHdrDto is null. (공통 헤더 DTO 객체가 null 입니다.)");
		}

		// 공통 헤더 OMM ID 획득
		String frgLkMesgCnHdrOmmId = lookupFrgLkMesgCnHdrOmmId(frgLnkCnHdrDto);

		// 대외 연계 전문 공통 헤더 언마샬링
		OmmMap frgLnkMesgHeaderOmmMap = ommProvider.get(frgLkMesgCnHdrOmmId);
		int hdrLen = frgLnkMesgHeaderOmmMap.getInLength();
		OmmUnmarshaller outHeaderUnmarshaller = new HoneOmmUnmarshaller<FrgLkCnHdrDto>(frgLnkMesgHeaderOmmMap, new ByteArrayInputStream(inbData, TcpConstants.MSG_HEADER_LENGTH, hdrLen));
		BeanUtils.toBean(outHeaderUnmarshaller.read(), frgLnkCnHdrDto);
		return hdrLen;
	}

	/*
	 * 대외 전문 공통 헤더 OMM Map ID 반환
	 * 
	 * @param frgLkCnHdrDto 대외 전문 헤더 객체
	 * 
	 * @return OMM Map ID
	 */
	private static String lookupFrgLkMesgCnHdrOmmId(FrgLkCnHdrDto frgLkCnHdrDto) {

		// 은행연합회 대외 전문 공통 헤더
		if (frgLkCnHdrDto instanceof KfbFrgLkHdrDto) {
			return KFB_FRG_LK_HDR_OMM_ID;
		}
		// 보험개발원 실손의료보험 전문 공통 헤더
		else if (frgLkCnHdrDto instanceof KrinRbmMedInCnHdrDto) {
			return KRIN_RBM_MED_IN_CN_HDR_OMM_ID;
		}
		// 보험개발원 MAPS 전문 공통 헤더
		else if (frgLkCnHdrDto instanceof KrinMapsCnHdrDto) {
			return KRIN_MAPS_CN_HDR_OMM_ID;
		} else {
			throw new IllegalStateException("Unknown foreign link common header DTO : " + frgLkCnHdrDto.getClass().getName());
		}
	}
}
