/**
 * 공통 / 이미지 정보관리
 */
package cuin.batch.cn.ii;

