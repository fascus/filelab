/**
 * 배치 / 공통
 */
package cuin.batch.cn;