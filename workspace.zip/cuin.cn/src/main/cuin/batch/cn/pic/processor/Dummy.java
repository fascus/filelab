package cuin.batch.cn.pic.processor;

import java.util.List;

import org.springframework.batch.core.listener.StepExecutionListenerSupport;
import org.springframework.batch.item.ItemWriter;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 통합코드 배포
 * 파 일 명 : Dummy.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.04.16
 * 설    명 : 더미(dummy) writer
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class Dummy extends StepExecutionListenerSupport implements ItemWriter<Object> {

	@Override
	public void write(List<? extends Object> args) {
	}
}
