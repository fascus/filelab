package cuin.batch.cn.pic.processor;

import hone.batch.runtime.item.processor.AbstractDtoItemProcessor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.batch.cn.pic.dto.MakePicDto;
import cuin.cn.exception.CuinException;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 통합 코드 배포
 * 파 일 명 : MakePicProcessor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.08
 * 설    명 : 통합코드 배포 배치 프로세서
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class MakePicProcessor<I, O, T> extends AbstractDtoItemProcessor<I, O, T> {
	private static final Logger logger = LoggerFactory.getLogger(MakePicProcessor.class);

	@SuppressWarnings("unchecked")
	@Override
	protected T doProcess(T item) {
		MakePicDto inputDto = (MakePicDto) item;
		String dirName = MakePicHeaderProcessor.getBaseDir() + MakePicHeaderProcessor.getIntgCdGrpDirectoryName(inputDto.getIntgCdGrpNm());
		String fileName = dirName + File.separator + inputDto.getIntgCdGrpNm() + ".pic";

		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName, true), "euc-kr"));
			bw.write(inputDto.getIntgCd() + ":" + inputDto.getIntgCdNm() + "\n");
		} catch (IOException e) {
			throw new CuinException(e.getMessage(), e);
		} finally {
			try {
				bw.close();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
		}

		if (logger.isDebugEnabled()) {
			logger.debug(fileName + " = " + inputDto.getIntgCd() + ":" + inputDto.getIntgCdNm());
		}

		return (T) inputDto;
	}

}
