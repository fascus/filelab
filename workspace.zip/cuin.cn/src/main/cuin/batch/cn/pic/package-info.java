/**
 * 공통 / 통합코드 배포
 */
package cuin.batch.cn.pic;