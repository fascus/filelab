package cuin.batch.cn.pic.processor;

import hone.batch.runtime.item.processor.AbstractDtoItemProcessor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.batch.cn.pic.dto.MakePicHeaderDto;
import cuin.cn.exception.CuinException;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 통합코드 배포
 * 파 일 명 : MakePicHeaderProcessor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.08
 * 설    명 : PIC 헤더 생성 프로세서
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class MakePicHeaderProcessor<I, O, T> extends AbstractDtoItemProcessor<I, O, T> {
	private static final Logger logger = LoggerFactory.getLogger(MakePicHeaderProcessor.class);

	public MakePicHeaderProcessor() {
		super();
		deleteFullPath(getBaseDir());
	}

	@SuppressWarnings("unchecked")
	@Override
	protected T doProcess(T item) {
		MakePicHeaderDto inputDto = (MakePicHeaderDto) item;

		String fileName = getBaseDir() + getIntgCdGrpDirectoryName(inputDto.getIntgCdGrpNm()) + File.separator + inputDto.getIntgCdGrpNm() + ".pic";

		String dirName = getBaseDir() + getIntgCdGrpDirectoryName(inputDto.getIntgCdGrpNm());
		File file1 = new File(dirName);
		if (!file1.exists()) {
			file1.mkdirs();
		}

		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName, false), "euc-kr"));

			bw.write("#code_style=liststyle\n");
			bw.write("#code_delimiter=\":\"\n\n");
			bw.write("#code_content\n");
		} catch (IOException e) {
			throw new CuinException(e.getMessage(), e);
		} finally {
			try {
				if (bw != null) {
					bw.close();
				}
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
		}

		return (T) inputDto;
	}

	protected static String getIntgCdGrpDirectoryName(String intgCdGrpNm) {
		String str = intgCdGrpNm.substring(0, 1);
		if (str.compareTo("9") < 0) {
			return ("CODE_0to9");
		} else if (str.compareTo("z") < 0) {
			return ("CODE_AtoZ");
		} else if (str.compareTo("나") < 0) {
			return ("CODE_가");
		} else if (str.compareTo("다") < 0) {
			return ("CODE_나");
		} else if (str.compareTo("라") < 0) {
			return ("CODE_다");
		} else if (str.compareTo("마") < 0) {
			return ("CODE_라");
		} else if (str.compareTo("바") < 0) {
			return ("CODE_마");
		} else if (str.compareTo("사") < 0) {
			return ("CODE_바");
		} else if (str.compareTo("아") < 0) {
			return ("CODE_사");
		} else if (str.compareTo("자") < 0) {
			return ("CODE_아");
		} else if (str.compareTo("차") < 0) {
			return ("CODE_자");
		} else if (str.compareTo("카") < 0) {
			return ("CODE_차");
		} else if (str.compareTo("타") < 0) {
			return ("CODE_카");
		} else if (str.compareTo("파") < 0) {
			return ("CODE_타");
		} else if (str.compareTo("하") < 0) {
			return ("CODE_파");
		} else {
			return ("CODE_하");
		}
	}

	public static boolean deleteFullPath(String delTarget) {
		File delDir = new File(delTarget);

		if (delDir.isDirectory()) {
			File[] allFiles = delDir.listFiles();

			for (File delAllDir : allFiles) {
				deleteFullPath(delAllDir.getAbsolutePath());
			}
		}
		return delDir.delete();
	}

	public static String getBaseDir() {
		if (System.getProperty("os.name").toLowerCase().startsWith("window")) {
			return "C:\\CMMN_CODE\\";
		} else {
			return "/app/hone/pic/";
		}
	}

}
