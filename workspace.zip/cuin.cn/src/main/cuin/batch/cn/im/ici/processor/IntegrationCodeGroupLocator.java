package cuin.batch.cn.im.ici.processor;

import java.util.ArrayList;
import java.util.List;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 통합코드조회
 * 파 일 명 : IntegrationCodeGroupLocator.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.04.19
 * 설    명 : Pick List 폴더 위치 지정자.  Pick list : When a picking list is used to locate and pull goods to fulfill  an order placed by a client, the list often acts as the authorization to  remove the goods from inventory.  (http:www.wisegeek.comwhat-is-a-picking-list.htm)  Pick list 파일들을 하나의 폴더에 모두 보관할 경우, 폴더의 파일 갯수가 지나치게 많아지는 문제가 있다. 따라서, 코드 그룹 명칭의  첫글자를 인덱스(index)로 활용하여, pick list 파일이 저장될 위치를 결정한다.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class IntegrationCodeGroupLocator {

	public static final String CODE_FOLDER_01 = "CODE_0to9";
	public static final String CODE_FOLDER_02 = "CODE_AtoZ";
	public static final String CODE_FOLDER_03 = "CODE_가";
	public static final String CODE_FOLDER_04 = "CODE_나";
	public static final String CODE_FOLDER_05 = "CODE_다";
	public static final String CODE_FOLDER_06 = "CODE_라";
	public static final String CODE_FOLDER_07 = "CODE_마";
	public static final String CODE_FOLDER_08 = "CODE_바";
	public static final String CODE_FOLDER_09 = "CODE_사";
	public static final String CODE_FOLDER_10 = "CODE_아";
	public static final String CODE_FOLDER_11 = "CODE_자";
	public static final String CODE_FOLDER_12 = "CODE_차";
	public static final String CODE_FOLDER_13 = "CODE_카";
	public static final String CODE_FOLDER_14 = "CODE_타";
	public static final String CODE_FOLDER_15 = "CODE_파";
	public static final String CODE_FOLDER_16 = "CODE_하";

	private static final IntegrationCodeGroupLocator singleton = new IntegrationCodeGroupLocator();
	private static final List<CodeGroupLocation> groupLocationList = new ArrayList<CodeGroupLocation>();;

	/**
	 * 싱글턴(singleton) 객체 반환
	 * 
	 * @return IntegrationCodeGroupLocator 의 싱글턴 인스턴스
	 */
	public static IntegrationCodeGroupLocator getInstance() {

		if (singleton == null) {
			groupLocationList.add(singleton.new CodeGroupLocation('/', null, false));
			groupLocationList.add(singleton.new CodeGroupLocation('9', CODE_FOLDER_01, true));
			groupLocationList.add(singleton.new CodeGroupLocation('z', CODE_FOLDER_02, true));
			groupLocationList.add(singleton.new CodeGroupLocation('나', CODE_FOLDER_03, false));
			groupLocationList.add(singleton.new CodeGroupLocation('다', CODE_FOLDER_04, false));
			groupLocationList.add(singleton.new CodeGroupLocation('라', CODE_FOLDER_05, false));
			groupLocationList.add(singleton.new CodeGroupLocation('마', CODE_FOLDER_06, false));
			groupLocationList.add(singleton.new CodeGroupLocation('바', CODE_FOLDER_07, false));
			groupLocationList.add(singleton.new CodeGroupLocation('사', CODE_FOLDER_08, false));
			groupLocationList.add(singleton.new CodeGroupLocation('아', CODE_FOLDER_09, false));
			groupLocationList.add(singleton.new CodeGroupLocation('자', CODE_FOLDER_10, false));
			groupLocationList.add(singleton.new CodeGroupLocation('차', CODE_FOLDER_11, false));
			groupLocationList.add(singleton.new CodeGroupLocation('카', CODE_FOLDER_12, false));
			groupLocationList.add(singleton.new CodeGroupLocation('타', CODE_FOLDER_13, false));
			groupLocationList.add(singleton.new CodeGroupLocation('파', CODE_FOLDER_14, false));
			groupLocationList.add(singleton.new CodeGroupLocation('하', CODE_FOLDER_15, false));
			groupLocationList.add(singleton.new CodeGroupLocation('힣', CODE_FOLDER_16, false));
		}

		return singleton;
	}

	/**
	 * 코드그룹 명칭을 입력받아 'pick list'가 저장될 폴더 위치를 반환한다.
	 * 
	 * @param intgCdGrpNm 코드 그룹 명칭
	 * @return 'pick list'가 저장될 폴더 명칭
	 */
	public String get(String intgCdGrpNm) {
		char firstCharOfGroupName = intgCdGrpNm.charAt(0);

		for (CodeGroupLocation groupLocation : groupLocationList) {

			if (groupLocation.getLastIncluded()) {
				if (firstCharOfGroupName <= groupLocation.getLastIndexChar()) {
					return groupLocation.getFolderName();
				}
			} else {
				if (firstCharOfGroupName < groupLocation.getLastIndexChar()) {
					return groupLocation.getFolderName();
				}
			}
		}
		throw new IllegalArgumentException("Code group name charset is out of bound : " + intgCdGrpNm);
	}

	/**
	 * Pick List 파일이 저장될 폴더 위치 정보
	 */
	public class CodeGroupLocation {
		// 코드 그룹 첫글자이자, 코드 그룹 인덱스
		private char lastIndexChar;
		// pick list 파일이 저장되는 폴더 명칭
		private String folderName;
		// 구간 계산 시 '코드 그룹 첫글자'를 범위에 포함할지 여부
		private boolean lastIncluded;

		public CodeGroupLocation(char lastIndexChar, String folderName, boolean lastIncluded) {
			this.lastIndexChar = lastIndexChar;
			this.folderName = folderName;
			this.lastIncluded = lastIncluded;
		}

		public char getLastIndexChar() {
			return lastIndexChar;
		}

		public String getFolderName() {
			return folderName;
		}

		public boolean getLastIncluded() {
			return lastIncluded;
		}
	}
}
