package cuin.batch.cn.im.ici.processor;

import hone.batch.runtime.item.processor.AbstractDtoItemProcessor;
import cuin.batch.cn.im.ici.dto.IntegrationCodeDto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 통합코드조회
 * 파 일 명 : IntegrationCodeProcessor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.04.25
 * 설    명 : 통합코드를 입력 받아, 통합코드 PIC list 파일이 저장되는 폴더 명칭 설정
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class IntegrationCodeProcessor<I, O, T> extends AbstractDtoItemProcessor<I, O, T> {

	@SuppressWarnings("unchecked")
	@Override
	protected T doProcess(T item) {
		IntegrationCodeDto inputDto = (IntegrationCodeDto) item;

		// 코드 그룹 명칭을 이용해 코드 파일 저장 폴더 명칭을 생성한다.
		String codeGroupName = inputDto.getIntgCdGrpNm();
		String codeGroupFolderName = IntegrationCodeGroupLocator.getInstance().get(codeGroupName);
		inputDto.setIntgCdGrpFld(codeGroupFolderName);

		return (T) inputDto;
	}

}
