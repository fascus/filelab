package cuin.batch.cn.im.ici.writer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.StepExecutionListenerSupport;
import org.springframework.batch.item.ItemWriter;

import cuin.batch.cn.im.ici.dto.IntegrationCodeDto;
import cuin.batch.cn.im.ici.processor.IntegrationCodeGroupLocator;
import cuin.cn.exception.CuinException;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 통합코드조회
 * 파 일 명 : IntegrationCodeWriter.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.04.20
 * 설    명 : 코드 목록을 전달 받아 pick list 파일을 생성하는 writer
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class IntegrationCodeWriter extends StepExecutionListenerSupport implements ItemWriter<Object> {

	// pick list 파일 확장자
	private static final String PIC_LIST_FILE_EXTENSION = ".pic";
	// pick list 파일 인코딩
	private static final String PICK_LIST_FILE_ENCODING = "EUC-KR";
	// pick list 파일들이 저장될 기반 폴더
	private String baseFolder;

	// 코드 그룹 폴더 생성 내역
	private static final Set<String> codeGroupFolderSet = new HashSet<String>();

	// 작업 중인 코드 그룹 명칭
	private String lastGroupName;
	// 배치 수행 중 누적된 코드 버퍼
	private static final List<IntegrationCodeDto> codeDtoList = new ArrayList<IntegrationCodeDto>();

	/**
	 * Pick list 파일이 저장된 기반 폴더(base folder) 지정
	 * 
	 * @param baseFolder
	 */
	public void setBaseFolder(String baseFolder) {
		this.baseFolder = baseFolder;
	}

	/**
	 * step을 수행하기 전에 기반 폴더를 삭제한다.
	 */
	@Override
	public void beforeStep(StepExecution stepExecution) {
		lastGroupName = "<none>";

		// remove files in base folder and sub folders
		deleteRecursive(new File(baseFolder));

		super.beforeStep(stepExecution);
	}

	/**
	 * By default File#delete fails for non-empty directories, it works like
	 * "rm". We need something a little more brutual - this does the equivalent
	 * of "rm -r"
	 * 
	 * @param path Root File Path
	 * @return true iff the file and all sub files/directories have been removed
	 * @throws FileNotFoundException
	 */
	public static boolean deleteRecursive(File path) {
		if (!path.exists()) {
			throw new CuinException(CuinException.DEFAULT_SYS_ERR_CODE, "File not found : " + path.getAbsolutePath());
		}
		boolean ret = true;
		if (path.isDirectory()) {
			for (File f : path.listFiles()) {
				ret = ret && deleteRecursive(f);
			}
		}
		return ret && path.delete();
	}

	/**
	 * 코드 쓰기 작업
	 */
	@Override
	public void write(List<? extends Object> list) {
		for (Object item : list) {
			IntegrationCodeDto codeDto = (IntegrationCodeDto) item;
			String codeGroupName = codeDto.getIntgCdGrpNm();

			if (!lastGroupName.equals(codeGroupName)) {
				flushCodes();
			}

			codeDtoList.add(codeDto);
		}
	}

	/**
	 * 버퍼에 누적된 코드들을 pick list 파일에 저장한다.
	 * 
	 * @throws IOException
	 */
	private void flushCodes() {
		if (codeDtoList.size() > 0) {
			IntegrationCodeDto codeDto = (IntegrationCodeDto) codeDtoList.get(0);
			String codeGroupName = codeDto.getIntgCdGrpNm();

			String codeGroupFolderPath = makeCodeGroupFolder(codeGroupName);
			makeCodeGroupFile(codeGroupFolderPath, codeGroupName, codeDtoList);

			codeDtoList.clear();
			lastGroupName = codeGroupName;
		}
	}

	/**
	 * 코드 그룹 폴더를 생성한다. (이미 생성되어 있는 경우, skip)
	 * 
	 * @param codeGroupName 코드 그룹 명칭
	 * @return
	 */
	private String makeCodeGroupFolder(String codeGroupName) {
		String codeGroupFolderName = IntegrationCodeGroupLocator.getInstance().get(codeGroupName);

		// 코드 그룹 폴더 명칭 생성
		StringBuilder sb = new StringBuilder();
		sb.append(baseFolder);
		sb.append(File.separator);
		sb.append(codeGroupFolderName);
		String codeGroupFolderPath = sb.toString();

		// 해당 코드 그룹 폴더가 존재하지 않을 경우 생성
		if (!codeGroupFolderSet.contains(codeGroupFolderPath)) {
			codeGroupFolderSet.add(codeGroupFolderPath);

			File codeGroupFolderFile = new File(codeGroupFolderPath);
			if (!codeGroupFolderFile.exists()) {
				codeGroupFolderFile.mkdirs();
			}
		}

		return codeGroupFolderPath;
	}

	/**
	 * 코드 그룹 별로 pick list 파일을 생성한다.
	 * 
	 * @param codeGroupFolderPath pick list 파일이 위치하는 폴더
	 * @param codeGroupName 코드 그룹 명칭
	 * @param codeDtoList 코드 목록
	 * @throws IOException
	 */
	private void makeCodeGroupFile(String codeGroupFolderPath, String codeGroupName, List<IntegrationCodeDto> codeDtoList) {
		// pick list 파일 경로 생성
		StringBuilder sb = new StringBuilder();
		sb.append(codeGroupFolderPath).append(File.separator).append(codeGroupName).append(PIC_LIST_FILE_EXTENSION);

		// EUC-KR 인코딩 방식으로 파일 오픈...
		PrintWriter pw = null;
		try {
			OutputStream outputStream = new FileOutputStream(sb.toString());
			pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(outputStream, PICK_LIST_FILE_ENCODING)));

			// pick list 파일 헤더 쓰기...
			pw.println("#code_style=liststyle");
			pw.println("#code_delimiter=\":\"");
			pw.println();
			pw.println("#code_content");

			// pick list 파일에 코드 목록 쓰기..
			for (IntegrationCodeDto codeDto : codeDtoList) {
				pw.println(codeDto.getIntgCd() + ":" + codeDto.getIntgCdNm());
			}
		} catch (IOException e) {
			throw new CuinException(CuinException.DEFAULT_SYS_ERR_CODE, e.getMessage(), e);
		} finally {
			if (pw != null) {
				pw.close();
			}
		}

	}

	/**
	 * 스텝을 완료한 후, 남아 있는 버퍼(코드 목록)를 파일에 저장한다.
	 */
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		flushCodes();

		return super.afterStep(stepExecution);
	}

}
