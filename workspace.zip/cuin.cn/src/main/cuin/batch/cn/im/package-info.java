/**
 * 공통 / 기타정보조회
 */
package cuin.batch.cn.im;

