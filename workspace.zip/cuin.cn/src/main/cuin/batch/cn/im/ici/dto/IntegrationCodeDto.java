package cuin.batch.cn.im.ici.dto;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 통합코드조회
 * 파 일 명 : IntegrationCodeDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.04.19
 * 설    명 : 통합 코드 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class IntegrationCodeDto {
	// 통합 코드 그룹 ID
	private String intgCdGrpId;
	// 통합 코드 그룹 명칭
	private String intgCdGrpNm;
	// 통합 코드 유효값
	private String intgCd;
	// 통합 코드 유효값명
	private String intgCdNm;
	// 통합 코드 그룹 폴더
	private String intgCdGrpFld;

	public String getIntgCdGrpId() {
		return intgCdGrpId;
	}

	public void setIntgCdGrpId(String intgCdGrpId) {
		this.intgCdGrpId = intgCdGrpId;
	}

	public String getIntgCdGrpNm() {
		return intgCdGrpNm;
	}

	public void setIntgCdGrpNm(String intgCdGrpNm) {
		this.intgCdGrpNm = intgCdGrpNm;
	}

	public String getIntgCd() {
		return intgCd;
	}

	public void setIntgCd(String intgCd) {
		this.intgCd = intgCd;
	}

	public String getIntgCdNm() {
		return intgCdNm;
	}

	public void setIntgCdNm(String intgCdNm) {
		this.intgCdNm = intgCdNm;
	}

	public String getIntgCdGrpFld() {
		return intgCdGrpFld;
	}

	public void setIntgCdGrpFld(String intgCdGrpFld) {
		this.intgCdGrpFld = intgCdGrpFld;
	}

}
