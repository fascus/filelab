/**
 * 공통 / 기타정보조회 / 통합코드조회
 */
package cuin.batch.cn.im.ici;

