package cuin.batch.cn.ab.hdy.setter;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementSetter;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 휴일관리
 * 파 일 명 : ParameterSetter.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.04.17
 * 설    명 : 배치 수행 대상 연도(year)를 SQL 파라미터로 설정.
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class ParameterSetter implements PreparedStatementSetter {

	private final String year;

	public ParameterSetter(String year) {
		this.year = year;
	}

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		ps.setString(1, year);
	}

}
