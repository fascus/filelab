package cuin.batch.cn.ab.hdy.dto;

import java.sql.Date;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 휴일관리
 * 파 일 명 : HdyDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.14
 * 설    명 : '휴일' 테이블 레코드 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class HdyDto {

	private static final long serialVersionUID = 7615021229393847313L;

	// 휴일일자
	private String hdyDt;
	// 휴일구분코드
	private String hdyDvCd;
	// 사용여부
	private String useYn;
	// 프로그램 ID
	private String prgId;
	// 생성일시
	private Date crtnDtm;
	// 생성자 번호
	private String cnrrNo;
	// 수정일시
	private Date uptDtm;
	// 수정자번호
	private String ameNo;

	public String getHdyDt() {
		return hdyDt;
	}

	public void setHdyDt(String hdyDt) {
		this.hdyDt = hdyDt;
	}

	public String getHdyDvCd() {
		return hdyDvCd;
	}

	public void setHdyDvCd(String hdyDvCd) {
		this.hdyDvCd = hdyDvCd;
	}

	public String getUseYn() {
		return useYn;
	}

	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public String getPrgId() {
		return prgId;
	}

	public void setPrgId(String prgId) {
		this.prgId = prgId;
	}

	public Date getCrtnDtm() {
		return crtnDtm;
	}

	public void setCrtnDtm(Date crtnDtm) {
		this.crtnDtm = crtnDtm;
	}

	public String getCnrrNo() {
		return cnrrNo;
	}

	public void setCnrrNo(String cnrrNo) {
		this.cnrrNo = cnrrNo;
	}

	public Date getUptDtm() {
		return uptDtm;
	}

	public void setUptDtm(Date uptDtm) {
		this.uptDtm = uptDtm;
	}

	public String getAmeNo() {
		return ameNo;
	}

	public void setAmeNo(String ameNo) {
		this.ameNo = ameNo;
	}
}
