package cuin.batch.cn.ab.hdy.processor;

import hone.batch.runtime.item.processor.AbstractDtoItemProcessor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.batch.cn.ab.hdy.dto.CldDto;
import cuin.cn.dbio.core.sys.DbioUtils;

@SuppressWarnings("unchecked")
/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 휴일관리
 * 파 일 명 : CldDtoItemProcessor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.14
 * 설    명 : 달력 DTO 아이템 프로세서
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class CldDtoItemProcessor<I, O, T> extends AbstractDtoItemProcessor<I, O, T> {

	private static final Logger logger = LoggerFactory.getLogger(CldDtoItemProcessor.class);

	@Override
	protected T doProcess(T item) {
		CldDto cldDto = (CldDto) item;
		DbioUtils.setSysProperties(cldDto);
		if (logger.isDebugEnabled()) {
			logger.debug(cldDto.toString());
		}

		return (T) cldDto;
	}
}
