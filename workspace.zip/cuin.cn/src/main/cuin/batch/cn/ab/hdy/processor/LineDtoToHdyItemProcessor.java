package cuin.batch.cn.ab.hdy.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cuin.batch.cn.ab.hdy.dto.HdyDto;
import cuin.batch.cn.ab.hdy.dto.LineDto;
import cuin.cn.dbio.core.sys.DbioUtils;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 휴일관리
 * 파 일 명 : LineDtoToHdyItemProcessor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.05.14
 * 설    명 : 휴일 설정 정보를 '휴일' DTO 객체로 변환한 후 반환하는 프로세서
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class LineDtoToHdyItemProcessor extends LineDtoItemProcessor {

	private static final Logger logger = LoggerFactory.getLogger(LineDtoToHdyItemProcessor.class);

	@Override
	protected Object doProcess(Object arg) {

		LineDto lineDto = toSolarDate((LineDto) arg);

		HdyDto hdyDto = new HdyDto();
		hdyDto.setHdyDt(lineDto.getHdyDt());
		hdyDto.setHdyDvCd(lineDto.getHdyDvCd());
		DbioUtils.setSysProperties(hdyDto);

		if (logger.isDebugEnabled()) {
			logger.debug(hdyDto.toString());
		}

		return hdyDto;
	}
}
