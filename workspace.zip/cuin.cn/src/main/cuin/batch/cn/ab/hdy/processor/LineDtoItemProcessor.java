package cuin.batch.cn.ab.hdy.processor;

import hone.batch.runtime.item.processor.AbstractDtoItemProcessor;
import hone.common.util.DateUtils;

import java.sql.Date;

import cuin.batch.cn.ab.hdy.dto.LineDto;

@SuppressWarnings("rawtypes")
/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 휴일관리
 * 파 일 명 : LineDtoItemProcessor.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.04.17
 * 설    명 : 휴일 설정 정보를 DTO 객체로 변환한 후 반환하는 프로세서의 추상 클래스
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public abstract class LineDtoItemProcessor extends AbstractDtoItemProcessor {

	protected String year;

	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * 음력 일자인 경우 양력으로 변환하고, 요일구분코드 계산
	 * 
	 * @param lineDto
	 * @return
	 */
	public LineDto toSolarDate(LineDto lineDto) {
		String mgYy = year;
		String inHdyDt = lineDto.getHdyDt();
		String month = inHdyDt.substring(0, 2);
		String day = inHdyDt.substring(3);
		String hdyDt = mgYy + month + day;

		// 음력인 경우, 양력 날자로 변환
		if (lineDto.getCldSys().equals("L")) {

			Date solarDate = DateUtils.toSolar(DateUtils.toDate(hdyDt));
			if (!mgYy.equals(DateUtils.getDateString(solarDate).substring(0, 4))) {
				String year = String.format("%4d", Integer.parseInt(mgYy, 10) - 1);
				solarDate = DateUtils.toSolar(DateUtils.toDate(year + month + day));
			}
			hdyDt = DateUtils.getDateString(solarDate);
		}
		lineDto.setHdyDt(hdyDt);

		// 요일구분코드 설정
		int weekday = DateUtils.getWeekday(DateUtils.toDate(hdyDt));
		String dywDvCd = String.format("%d", weekday);
		lineDto.setDywDvCd(dywDvCd);

		return lineDto;
	}

}
