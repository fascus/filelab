package cuin.batch.cn.ab.hdy.dto;

import java.io.Serializable;

/**
 * <pre>
 * 시스템명 : 신협 차세대공제정보시스템(S/W)
 * 업무구분 : 공통 (cn)
 * 업 무 명 : 휴일관리
 * 파 일 명 : HolidayDto.java
 * 작 성 자 : Application Architect
 * 작 성 일 : 2013.04.17
 * 설    명 : 신협 공제 휴일 정보 DTO
 * --------------------------------------------------------------------------------
 * 변경일            변경자  변경내역
 * --------------------------------------------------------------------------------
 * </pre>
 */
public class HolidayDto implements Serializable {

	private static final long serialVersionUID = 6466478277332591049L;

	// 달력 일자
	private String hdyDt;

	// 휴일 명칭
	private String hdyNm;

	// 관리년도
	private String mgYy;

	// 요일구분코드
	private String dywCd;

	// 휴일구분코드
	private String hdyDvCd;

	// 사고휴일여부
	private String acdHdyYn;

	public String getHdyDt() {
		return hdyDt;
	}

	public void setHdyDt(String hdyDt) {
		this.hdyDt = hdyDt;
	}

	public String getHdyNm() {
		return hdyNm;
	}

	public void setHdyNm(String hdyNm) {
		this.hdyNm = hdyNm;
	}

	public String getMgYy() {
		return mgYy;
	}

	public void setMgYy(String mgYy) {
		this.mgYy = mgYy;
	}

	public String getDywCd() {
		return dywCd;
	}

	public void setDywCd(String dywCd) {
		this.dywCd = dywCd;
	}

	public String getHdyDvCd() {
		return hdyDvCd;
	}

	public void setHdyDvCd(String hdyDvCd) {
		this.hdyDvCd = hdyDvCd;
	}

	public String getAcdHdyYn() {
		return acdHdyYn;
	}

	public void setAcdHdyYn(String acdHdyYn) {
		this.acdHdyYn = acdHdyYn;
	}

	@Override
	public String toString() {
		return "HolidayDto [hdyDt=" + hdyDt + ", mgYy=" + mgYy + ", dywCd=" + dywCd + ", hdyDvCd=" + hdyDvCd + ", acdHdyYn=" + acdHdyYn + "]";
	}
}
