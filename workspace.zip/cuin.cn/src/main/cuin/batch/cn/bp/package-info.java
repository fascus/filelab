/**
 * 공통 / 업무진행사항
 */
package cuin.batch.cn.bp;

